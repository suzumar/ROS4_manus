var recordData = [
    {
        "length": 66753,
        "seq_id": "contig_38",
        "regions": [
            {
                "start": 1,
                "end": 66753,
                "idx": 1,
                "orfs": [
                    {
                        "start": 2,
                        "end": 127,
                        "strand": 1,
                        "locus_tag": "ctg1_1",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2 - 127,\n (total: 126 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=HYGVLAGRLGAAGVAPTTTMLGVTRLAIPGQMVELEGTAVA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=10127\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"HYGVLAGRLGAAGVAPTTTMLGVTRLAIPGQMVELEGTAVA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"CACTACGGCGTGCTGGCCGGGCGTCTGGGAGCGGCCGGTGTCGCCCCGACCACCACCATGCTCGGCGTGACCCGCCTGGCCATCCCCGGCCAGATGGTCGAACTCGAAGGCACCGCCGTCGCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 274,
                        "end": 1653,
                        "strand": -1,
                        "locus_tag": "ctg1_2",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 274 - 1,653,\n (total: 1380 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00004.29 (ATPase family associated with various cellular activities (AAA)): [72:178](score: 57.5, e-value: 1.9e-15)<br>\n \n  PF16193.5 (AAA C-terminal domain): [208:284](score: 77.4, e-value: 8e-22)<br>\n \n  PF12002.8 (MgsA AAA+ ATPase C terminal): [284:450](score: 224.9, e-value: 5.5e-67)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00004.29: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTSTEDDGLFALPEPEPAPPHPPGADSATARPGAPLAVRMRPRSLAEVVGQTHLLRPGAPLRLLAEGGDATSVLLYGPPGTGKTTLARLTAAVADRHFVALSALTSGVKELRDVMSEARRRRDRQGRRTVLFIDEVHRFSRTQQDALLGAVEDGQVLLVAATTENPSFSVVSPLLSRLLVLRLQPLTEDELRELLRRAVKDERGLDGAVLLEPEAEDVLVRLAAGDARSALTALEASAEGVTGTGGSAVDVAAVERAVSGTTVRYDRQGDQHHDVVSAFIKSIRGSDPDAALHYLARMLVAGEDPRFIARRLLVHASEDVGLADPTALQAAVAAAQTVQFIGMPEARLALAQATVHLATAPKSNTVLVGIDEAMSDVRAGAVGEVPPHLRHSRYTGAKELGNGVGYRYPHRTPEGVLPQQYPPGDLVGRDYYRPTDRGGERDLRERLSRLRRVVRGGEG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=11653\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTSTEDDGLFALPEPEPAPPHPPGADSATARPGAPLAVRMRPRSLAEVVGQTHLLRPGAPLRLLAEGGDATSVLLYGPPGTGKTTLARLTAAVADRHFVALSALTSGVKELRDVMSEARRRRDRQGRRTVLFIDEVHRFSRTQQDALLGAVEDGQVLLVAATTENPSFSVVSPLLSRLLVLRLQPLTEDELRELLRRAVKDERGLDGAVLLEPEAEDVLVRLAAGDARSALTALEASAEGVTGTGGSAVDVAAVERAVSGTTVRYDRQGDQHHDVVSAFIKSIRGSDPDAALHYLARMLVAGEDPRFIARRLLVHASEDVGLADPTALQAAVAAAQTVQFIGMPEARLALAQATVHLATAPKSNTVLVGIDEAMSDVRAGAVGEVPPHLRHSRYTGAKELGNGVGYRYPHRTPEGVLPQQYPPGDLVGRDYYRPTDRGGERDLRERLSRLRRVVRGGEG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACGAGCACCGAGGACGACGGACTGTTCGCGTTACCCGAACCGGAGCCGGCCCCACCGCACCCGCCCGGCGCGGACTCCGCGACCGCACGCCCCGGCGCCCCGCTCGCCGTACGGATGCGGCCACGCTCGCTCGCGGAAGTCGTCGGCCAGACACACCTGTTGCGTCCCGGCGCACCTCTGCGACTGCTGGCCGAGGGAGGGGACGCGACGTCGGTGCTGTTGTACGGCCCGCCGGGGACGGGGAAGACCACCCTGGCGCGTCTGACGGCCGCCGTCGCCGACCGCCACTTCGTCGCTCTCTCGGCACTCACCAGCGGCGTCAAGGAACTGCGGGACGTGATGAGCGAGGCGCGCCGCCGCCGGGACCGCCAGGGCAGGCGAACCGTCCTGTTCATCGACGAGGTGCACCGCTTCTCCAGGACCCAGCAGGACGCGCTGCTCGGCGCCGTGGAGGACGGACAGGTCCTGCTCGTCGCCGCGACCACGGAGAACCCGTCGTTCTCGGTGGTGTCCCCACTGCTCTCCCGTCTGCTCGTACTGCGGCTTCAGCCCCTGACCGAGGACGAGCTGCGCGAACTGCTGCGCCGCGCGGTGAAGGACGAGCGAGGCCTCGACGGCGCGGTCCTCCTGGAACCCGAGGCGGAGGACGTCCTGGTGCGCCTCGCGGCCGGCGACGCCCGGAGCGCACTGACCGCACTGGAGGCGAGCGCCGAAGGGGTGACGGGCACCGGAGGCAGCGCGGTCGATGTCGCCGCCGTGGAGCGTGCCGTGTCCGGGACCACGGTGCGCTACGACCGGCAGGGCGACCAACACCATGACGTCGTCAGCGCGTTCATCAAGTCGATCCGGGGGTCGGACCCGGACGCCGCGCTGCACTACCTGGCCCGCATGCTCGTCGCGGGAGAGGATCCGCGCTTCATCGCGCGTCGGCTGCTGGTGCACGCGAGCGAGGACGTCGGACTCGCCGACCCGACGGCGCTGCAGGCCGCCGTCGCGGCGGCCCAGACGGTGCAGTTCATCGGCATGCCCGAGGCGCGCCTGGCTCTCGCCCAGGCAACGGTCCACCTGGCGACGGCGCCGAAGTCGAACACGGTGCTCGTCGGGATCGACGAGGCCATGTCCGACGTCCGCGCGGGCGCCGTGGGGGAGGTCCCCCCGCACCTGCGGCACAGCCGTTACACCGGTGCCAAGGAGCTCGGCAACGGGGTCGGCTACCGGTATCCCCACAGGACCCCCGAGGGAGTGCTGCCACAGCAGTACCCGCCGGGTGACCTCGTGGGCAGGGACTACTACCGGCCCACGGACCGGGGCGGGGAGCGCGACCTGCGGGAACGCCTGAGCAGGCTCCGTCGCGTGGTCCGGGGCGGGGAGGGATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 1875,
                        "end": 2732,
                        "strand": -1,
                        "locus_tag": "ctg1_3",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,875 - 2,732,\n (total: 858 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF02567.16 (Phenazine biosynthesis-like protein): [9:277](score: 238.3, e-value: 1.2e-70)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR00654 (PhzF_family: phenazine biosynthesis protein, PhzF family): [3:281](score: 183.0, e-value: 1.9e-54)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF02567.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF02567.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MGRYEYVVADVFTDVPLEGNPTAVFLDASGLSPGRMQQIAQEMHLSETVFVLPAENDGDVRVRIFTPVNELPFAGHPTLGAAVVLGESHDAKELRMETAKGTVTFELERDDDGRTVAAAMWQPLPVWRTYDRTDELLAALDLVDTGSTLPVEVYDNGPRHVFVGLDGVPALSSLEPDQRILARLPDMAANCFTGSGNRWRLRMFSPAYGVVEDAATGSAAGSIAVHLARYGLAPFGEWIDIRQGIEMGRPSTMRARVTGTPDRIDAVQVAGSAVVVARATLFVQP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=12732\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_3_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MGRYEYVVADVFTDVPLEGNPTAVFLDASGLSPGRMQQIAQEMHLSETVFVLPAENDGDVRVRIFTPVNELPFAGHPTLGAAVVLGESHDAKELRMETAKGTVTFELERDDDGRTVAAAMWQPLPVWRTYDRTDELLAALDLVDTGSTLPVEVYDNGPRHVFVGLDGVPALSSLEPDQRILARLPDMAANCFTGSGNRWRLRMFSPAYGVVEDAATGSAAGSIAVHLARYGLAPFGEWIDIRQGIEMGRPSTMRARVTGTPDRIDAVQVAGSAVVVARATLFVQP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGGCAGGTACGAGTACGTGGTGGCCGATGTCTTCACCGACGTCCCGCTGGAAGGCAACCCCACCGCGGTCTTCCTCGACGCCTCGGGCCTCTCGCCCGGGCGCATGCAGCAGATCGCCCAGGAGATGCATCTGTCGGAGACCGTCTTCGTCCTCCCGGCGGAGAACGACGGCGATGTGCGGGTCCGCATCTTCACGCCCGTCAACGAACTCCCCTTCGCCGGGCATCCGACCCTGGGCGCGGCCGTCGTGCTCGGCGAGTCGCACGACGCCAAGGAACTGCGGATGGAGACCGCCAAAGGCACCGTGACGTTCGAGCTGGAGCGGGACGACGACGGCCGGACCGTCGCGGCAGCCATGTGGCAGCCCCTGCCGGTCTGGCGGACCTACGACCGGACGGACGAACTCCTCGCCGCGCTCGACCTGGTGGACACGGGCAGCACCCTGCCCGTGGAGGTCTACGACAACGGGCCACGGCATGTGTTCGTCGGCCTGGACGGCGTGCCCGCGCTCTCCTCCCTGGAGCCGGACCAGCGGATCCTCGCGCGTCTGCCCGACATGGCGGCCAACTGCTTCACCGGTTCCGGAAACCGGTGGCGGCTGCGCATGTTCTCGCCCGCGTACGGGGTGGTGGAGGACGCCGCGACCGGTTCGGCCGCGGGATCGATCGCGGTACATTTGGCGCGGTACGGCCTGGCCCCGTTCGGCGAGTGGATCGACATCCGTCAGGGCATCGAGATGGGACGCCCCTCGACAATGCGGGCTCGGGTGACGGGGACGCCGGACCGGATCGACGCGGTGCAGGTGGCGGGATCCGCCGTCGTCGTCGCCCGGGCCACGCTGTTCGTCCAGCCCTAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 2806,
                        "end": 4482,
                        "strand": -1,
                        "locus_tag": "ctg1_4",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,806 - 4,482,\n (total: 1677 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00710.20 (Asparaginase, N-terminal): [229:330](score: 27.7, e-value: 1.7e-06)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTGDMRAAGVPRPRIAVFAGPTATILNTPDLVTSNKARARHGLPLRPGRFDALRPQRLAAPATLYVEAFSAHPLEQDAAGLYAPPDGWLDADGTFHAERPPGDAKPVHVVELDPADGLYPLPYMARQADGSAWEETSAAPYADPAGARQTFHPDARRLYEEIERFGLADHGGPVELGSVADFEFFRAAPSGGYTSGPASERLGRDFFVYYPYHLQTEPSLAHLALATNHVQEVLGSGEFTGAQWLEGSPTVDETLYWLGLLVDTKVPLVGHAAQRRHQSLSADGDRNVVDGVKFIASGVALDERGEDRVGACVVVDELVYSARDVTKVDARPGGYEVTGGHGGVVADLGGYGPPQLTYLPTRRHTHRSEVRLTVLPGTVTGVMGSLGGGVTRAEVRTKDADGLVPTAMPHVSITKYSRYAATGTGADDPPVAEEEVEILARIDANLARFPLAGFVCEGMSPFGMADPMKNAALGVAVFAGMPVVRTGRGTTGGMAYRTDPAFVSGNNLTATKARMLLMAALLRFGALPPAADPFDPTPDERAATEKAVAQYQSLFDTH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=14482\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTGDMRAAGVPRPRIAVFAGPTATILNTPDLVTSNKARARHGLPLRPGRFDALRPQRLAAPATLYVEAFSAHPLEQDAAGLYAPPDGWLDADGTFHAERPPGDAKPVHVVELDPADGLYPLPYMARQADGSAWEETSAAPYADPAGARQTFHPDARRLYEEIERFGLADHGGPVELGSVADFEFFRAAPSGGYTSGPASERLGRDFFVYYPYHLQTEPSLAHLALATNHVQEVLGSGEFTGAQWLEGSPTVDETLYWLGLLVDTKVPLVGHAAQRRHQSLSADGDRNVVDGVKFIASGVALDERGEDRVGACVVVDELVYSARDVTKVDARPGGYEVTGGHGGVVADLGGYGPPQLTYLPTRRHTHRSEVRLTVLPGTVTGVMGSLGGGVTRAEVRTKDADGLVPTAMPHVSITKYSRYAATGTGADDPPVAEEEVEILARIDANLARFPLAGFVCEGMSPFGMADPMKNAALGVAVFAGMPVVRTGRGTTGGMAYRTDPAFVSGNNLTATKARMLLMAALLRFGALPPAADPFDPTPDERAATEKAVAQYQSLFDTH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACGGGCGACATGCGGGCGGCCGGCGTCCCGCGCCCCAGGATCGCCGTCTTCGCCGGCCCGACCGCGACGATCCTGAACACCCCGGACCTCGTCACGTCCAACAAGGCACGCGCACGTCACGGCCTGCCGCTCCGGCCCGGCCGCTTCGACGCCCTGCGCCCCCAACGCCTCGCGGCGCCCGCGACGTTGTACGTCGAGGCCTTCAGCGCCCACCCGCTCGAACAGGACGCCGCCGGCCTGTACGCCCCGCCCGACGGCTGGCTCGACGCGGACGGCACCTTCCACGCCGAGCGGCCGCCCGGCGACGCCAAGCCGGTCCACGTCGTCGAACTCGACCCCGCCGACGGCCTGTACCCCCTTCCCTACATGGCACGGCAGGCGGACGGCTCCGCCTGGGAGGAGACCTCGGCAGCGCCGTACGCGGATCCGGCCGGCGCACGGCAGACCTTCCACCCGGACGCCCGGCGCCTCTACGAGGAGATCGAGCGGTTCGGCCTCGCCGACCACGGCGGTCCCGTGGAGCTGGGTTCCGTCGCCGACTTCGAGTTCTTCCGCGCGGCACCCTCGGGCGGGTACACCTCGGGTCCCGCTTCCGAGCGCCTGGGACGGGACTTCTTCGTCTACTACCCCTACCACCTCCAGACCGAGCCGAGCCTCGCGCACCTGGCCCTGGCCACCAATCACGTCCAAGAGGTCCTCGGCTCGGGCGAGTTCACCGGCGCGCAGTGGCTGGAGGGAAGCCCGACCGTCGACGAGACCCTGTACTGGCTCGGACTCCTCGTCGACACCAAGGTGCCGCTCGTCGGACACGCCGCGCAGCGTCGCCACCAGTCGCTGAGCGCCGACGGCGACCGCAACGTGGTGGACGGCGTCAAGTTCATCGCCTCCGGGGTCGCCCTGGACGAACGGGGTGAGGACCGCGTCGGTGCCTGCGTCGTCGTCGACGAACTCGTCTACTCGGCCCGGGACGTGACCAAGGTCGACGCCCGTCCGGGCGGTTACGAGGTCACCGGTGGCCACGGGGGAGTCGTCGCCGACCTCGGCGGCTACGGCCCGCCCCAGCTCACCTACCTGCCCACCCGCAGGCACACCCACCGTTCCGAGGTGCGCCTCACGGTGCTGCCCGGGACCGTGACCGGCGTCATGGGGAGCCTCGGCGGCGGCGTGACCCGGGCCGAGGTCCGGACCAAGGACGCCGACGGGCTGGTACCCACGGCCATGCCGCACGTCTCGATCACCAAGTACAGCAGGTACGCGGCGACGGGCACGGGCGCCGACGACCCGCCCGTCGCCGAGGAGGAGGTCGAGATCCTCGCCCGGATCGACGCCAACCTCGCGCGGTTCCCGCTCGCGGGCTTCGTGTGCGAGGGGATGTCCCCCTTCGGGATGGCCGACCCGATGAAGAACGCGGCGCTGGGCGTCGCCGTCTTCGCCGGCATGCCCGTGGTCCGCACCGGGCGCGGCACCACCGGAGGCATGGCGTACCGCACCGACCCCGCCTTCGTCTCCGGCAACAACCTGACGGCCACCAAGGCACGCATGCTCCTCATGGCCGCGCTGCTCAGGTTCGGTGCCCTGCCGCCGGCCGCCGACCCGTTCGACCCGACTCCCGACGAACGCGCCGCCACCGAGAAGGCGGTCGCCCAGTACCAGTCCCTGTTCGACACACACTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 4479,
                        "end": 4964,
                        "strand": -1,
                        "locus_tag": "ctg1_5",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,479 - 4,964,\n (total: 486 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF04343.13 (Protein of unknown function, DUF488): [13:147](score: 59.9, e-value: 3.6e-16)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VPRLATIGVYGFDVDSYLERLRQADVRLLLDVRQRRGVRGPDYAWANSRRLQAALAEAGIAYEHRRELAPTTELRQLQYAEDARLGVGKRSRSELAAAYTRRYTAEILDPADLGPIVAGLPSRGTTALFCVERDPEACHRSLVARRLSELHDITVEHLRPL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=14964\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VPRLATIGVYGFDVDSYLERLRQADVRLLLDVRQRRGVRGPDYAWANSRRLQAALAEAGIAYEHRRELAPTTELRQLQYAEDARLGVGKRSRSELAAAYTRRYTAEILDPADLGPIVAGLPSRGTTALFCVERDPEACHRSLVARRLSELHDITVEHLRPL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCCCAGACTGGCAACGATCGGCGTCTACGGCTTCGACGTCGATTCCTACCTCGAACGACTGCGGCAGGCAGACGTGCGCCTGCTGCTCGACGTACGACAGCGGCGCGGGGTCCGCGGCCCCGACTACGCCTGGGCCAACTCCCGACGGCTGCAGGCGGCCCTCGCCGAAGCCGGGATCGCGTACGAGCACCGACGGGAACTCGCCCCGACGACCGAACTGCGGCAGCTCCAGTACGCCGAGGACGCCCGCCTGGGCGTCGGCAAGCGCTCCCGCAGCGAGCTCGCCGCCGCGTACACCCGCCGCTACACGGCCGAGATCCTCGATCCGGCCGACCTCGGCCCGATCGTGGCGGGGCTGCCGAGCCGCGGGACCACGGCGCTCTTCTGCGTCGAACGCGACCCGGAGGCATGTCACCGGTCACTGGTCGCCCGCCGGCTCTCCGAACTCCACGACATCACCGTCGAACACCTGAGGCCGCTGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 5032,
                        "end": 6042,
                        "strand": -1,
                        "locus_tag": "ctg1_6",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,032 - 6,042,\n (total: 1011 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1042:O-methyltransferase (Score: 264.3; E-value: 2.6e-80)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF16864.5 (Dimerisation domain): [10:86](score: 31.9, e-value: 9.7e-08)<br>\n \n  PF00891.18 (O-methyltransferase domain): [108:314](score: 105.4, e-value: 2.4e-30)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00891.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008171' target='_blank'>GO:0008171</a>: O-methyltransferase activity<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTVDVQATRDVVDIITGGWRAQALYTAVRLGLPDHVAAGRDNDAELAKATGASEGGVHRLMRLLVAMEVFTGSDATGYRGTRMSAALVDGPRSLRDMCLLYGEEFYSAWDHAHHAISTESSGFEIAYGRPFYDYLGEAPATARRFRRTMNAASMFFHRVPAVFDFAGKKVVDVGGGGGQLLATVLTAAPTATGTLFDREHMAAKAREHLEAAVGPGRVQVVGGDMFAGVPEGGDVYILCRVLAGHDDEDVVRVFEHCRRGMTDASARLLILDRFVEDENPTVLPALWDLHLLMTTGGEHRTVERITRLLARAGLSVERTAHLPMETTALVALPRTA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=16042\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_6_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTVDVQATRDVVDIITGGWRAQALYTAVRLGLPDHVAAGRDNDAELAKATGASEGGVHRLMRLLVAMEVFTGSDATGYRGTRMSAALVDGPRSLRDMCLLYGEEFYSAWDHAHHAISTESSGFEIAYGRPFYDYLGEAPATARRFRRTMNAASMFFHRVPAVFDFAGKKVVDVGGGGGQLLATVLTAAPTATGTLFDREHMAAKAREHLEAAVGPGRVQVVGGDMFAGVPEGGDVYILCRVLAGHDDEDVVRVFEHCRRGMTDASARLLILDRFVEDENPTVLPALWDLHLLMTTGGEHRTVERITRLLARAGLSVERTAHLPMETTALVALPRTA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACAGTCGACGTGCAGGCCACTCGCGACGTGGTCGACATCATCACCGGTGGGTGGCGGGCGCAGGCGCTCTACACCGCGGTCAGGCTCGGGCTGCCCGACCACGTCGCGGCCGGCCGGGACAACGACGCGGAACTCGCCAAGGCGACAGGGGCGAGCGAGGGCGGCGTGCACCGTCTGATGCGTCTGCTGGTGGCCATGGAGGTCTTCACGGGCAGCGACGCCACCGGCTACCGCGGCACCCGGATGAGCGCGGCCCTCGTCGACGGGCCCCGGTCGCTGCGCGACATGTGCCTGCTGTACGGCGAGGAGTTCTACTCCGCCTGGGACCACGCCCACCACGCCATCAGCACGGAGAGCTCAGGCTTCGAGATCGCCTACGGCCGGCCGTTCTACGACTACTTGGGTGAGGCCCCCGCCACCGCCCGCCGCTTCCGGCGCACCATGAACGCCGCCAGCATGTTCTTCCACCGCGTACCCGCGGTCTTCGATTTCGCGGGCAAGAAGGTCGTGGACGTGGGCGGAGGAGGCGGGCAGCTGCTCGCGACCGTCCTCACGGCCGCGCCCACCGCCACGGGCACGCTGTTCGACCGCGAGCACATGGCCGCCAAGGCCCGCGAGCATCTGGAGGCCGCCGTCGGCCCGGGCCGCGTGCAGGTGGTCGGCGGCGACATGTTCGCCGGGGTCCCGGAGGGAGGCGACGTCTACATCCTGTGCCGGGTCCTGGCGGGCCACGACGACGAGGACGTCGTCCGGGTCTTCGAGCACTGCCGCCGCGGCATGACGGACGCCTCGGCCCGGCTGCTGATCCTCGACCGTTTCGTCGAGGACGAGAACCCCACCGTGCTGCCCGCGCTGTGGGACCTGCATCTGCTCATGACCACCGGGGGCGAGCACCGTACCGTCGAGCGGATCACTCGGCTGCTGGCACGGGCCGGCCTGTCCGTCGAGCGCACCGCGCACCTGCCGATGGAGACGACCGCCCTGGTCGCCCTGCCACGCACCGCGTAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 6165,
                        "end": 6611,
                        "strand": -1,
                        "locus_tag": "ctg1_7",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,165 - 6,611,\n (total: 447 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF06983.13 (3-demethylubiquinone-9 3-methyltransferase): [17:142](score: 30.8, e-value: 3.5e-07)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNDVVRTYSKGHQMASQLNPYLAFDGDARQALEFYHQVLGGTLDLGTYGDFGSAELPDPDKIMHATLTTADGFTLMAWDVPERVPFTPGTNVALYLGGDDPRLREHFEKLSAGGTVTLPLEKQMWGDEAGTLVDRFGITWMVNIRQNA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=16611\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_7_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNDVVRTYSKGHQMASQLNPYLAFDGDARQALEFYHQVLGGTLDLGTYGDFGSAELPDPDKIMHATLTTADGFTLMAWDVPERVPFTPGTNVALYLGGDDPRLREHFEKLSAGGTVTLPLEKQMWGDEAGTLVDRFGITWMVNIRQNA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAACGACGTCGTCCGCACGTACAGCAAGGGACATCAGATGGCATCCCAGCTCAACCCGTACCTCGCCTTCGACGGCGACGCGCGCCAGGCCCTGGAGTTCTACCACCAGGTCCTCGGCGGCACGCTGGACCTGGGCACCTACGGTGACTTCGGGTCGGCGGAGCTGCCCGACCCCGACAAGATCATGCACGCGACGCTGACCACCGCCGACGGCTTCACGCTGATGGCGTGGGACGTCCCGGAGCGGGTCCCCTTCACACCGGGCACCAACGTCGCCCTCTATCTCGGCGGCGACGATCCGCGCCTGCGCGAGCACTTCGAGAAGCTGTCCGCGGGAGGCACCGTGACCCTGCCCCTCGAGAAACAGATGTGGGGCGACGAGGCCGGCACGCTCGTGGACAGGTTCGGAATCACCTGGATGGTCAACATCCGGCAGAACGCGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 6621,
                        "end": 7112,
                        "strand": -1,
                        "locus_tag": "ctg1_8",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,621 - 7,112,\n (total: 492 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) phenazine: phzB<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF03284.13 (Phenazine biosynthesis protein A/B): [17:163](score: 243.3, e-value: 7.4e-73)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF03284.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0017000' target='_blank'>GO:0017000</a>: antibiotic biosynthetic process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MGTDHARTEGLHAGPGPRARHRAVVADYMTRKGENRLTRYLLFTEDGSAGLYTSDTGEPVVSVGHEKLKAHGEWSLRMFPDWEWKNVEIFETQDPNRFWVECDGEGRILYPDYPPGYYKNHFLHSFELEDGRIKRQREFMNPFEQLRALGIEVPKINRGGIPT&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=17112\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_8_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MGTDHARTEGLHAGPGPRARHRAVVADYMTRKGENRLTRYLLFTEDGSAGLYTSDTGEPVVSVGHEKLKAHGEWSLRMFPDWEWKNVEIFETQDPNRFWVECDGEGRILYPDYPPGYYKNHFLHSFELEDGRIKRQREFMNPFEQLRALGIEVPKINRGGIPT\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGGAACGGACCACGCCCGGACGGAAGGGCTCCACGCCGGACCCGGCCCGCGCGCCCGGCATCGTGCCGTCGTCGCGGACTACATGACCCGCAAGGGAGAGAACCGGCTCACGCGCTACCTGCTCTTCACCGAGGACGGCAGCGCCGGCCTGTACACGAGCGACACCGGTGAGCCGGTCGTCTCCGTGGGACACGAGAAGCTCAAGGCGCACGGCGAGTGGTCGTTGCGCATGTTCCCCGACTGGGAATGGAAGAACGTCGAGATCTTCGAGACGCAGGACCCGAACCGGTTCTGGGTCGAGTGCGACGGCGAAGGACGGATCCTCTACCCGGACTACCCGCCCGGCTACTACAAGAACCACTTCCTCCACTCCTTCGAACTCGAGGACGGCAGGATCAAGCGGCAGCGGGAGTTCATGAACCCGTTCGAGCAACTGCGCGCGCTGGGCATCGAGGTGCCGAAGATCAACCGGGGCGGGATCCCCACCTAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 7142,
                        "end": 8998,
                        "strand": -1,
                        "locus_tag": "ctg1_9",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,142 - 8,998,\n (total: 1857 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Asn_synthase<br>\n \n  biosynthetic-additional (rule-based-clusters) GATase_7<br>\n \n  biosynthetic-additional (smcogs) SMCOG1177:asparagine synthase (glutamine-hydrolyzing) (Score: 615.1; E-value: 2.3e-186)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF13537.6 (Glutamine amidotransferase domain): [47:169](score: 160.1, e-value: 2e-47)<br>\n \n  PF00733.21 (Asparagine synthase): [239:608](score: 286.8, e-value: 3.4e-85)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR01536 (asn_synth_AEB: asparagine synthase (glutamine-hydrolyzing)): [1:545](score: 493.0, e-value: 2.9e-148)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00733.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004066' target='_blank'>GO:0004066</a>: asparagine synthase (glutamine-hydrolyzing) activity<br>\n  \n   PF00733.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006529' target='_blank'>GO:0006529</a>: asparagine biosynthetic process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MCGITGWVSFDRDLTQQRAQLDGMTRTMACRGPDADGMWLDRHAALGHRRLAVIDIEGGTQPMVLPTDDGPVAITYSGEVYNYTELRGELLRRGHRFETRSDTEVVLHGYAEWGEAVAERLNGMFAFAIWDARVEKLVLIRDRMGVKPLYYSATDDGVLFGSEPKAILANPLADRAVDLAGLRELVSFTQTPGSAVWCGMNEVVPGGLLSADRSGLREHRYWTLPTRPHTDDRETTVATVRELLEDIVSRQTVSDVPRCTLLSGGLDSSVITALAAAKLGRPGEHGEAGEKVRSFAVDFVGRENDFVADELRGTTDAPYAREVAAHVGSLHEAIVLDHAAIADPDVRRAVITARDSPLSLGDMDTSLYLLFQAIKEQSTVALSGESADEVFGGYRWFHQPEVQAAQTFPWMAVFVSGARAQVSDRFNADITAALDLPTYIKDRYAEAVREVERAEGESDHEMRMRVMCHLHLTRFVRMLLERKDRISMAVGLEVRVPFCDHRLVEYVYNTPWSLKTFDGREKSLLRAATADLLPRSVLERVKAPYPATLDPHYTGALLQQSKELLTTDDPVFDLVDRDWLEAITRHDPATMPIDVRNGMERVLDLSTWLDVYRPELRL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=18998\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_9_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MCGITGWVSFDRDLTQQRAQLDGMTRTMACRGPDADGMWLDRHAALGHRRLAVIDIEGGTQPMVLPTDDGPVAITYSGEVYNYTELRGELLRRGHRFETRSDTEVVLHGYAEWGEAVAERLNGMFAFAIWDARVEKLVLIRDRMGVKPLYYSATDDGVLFGSEPKAILANPLADRAVDLAGLRELVSFTQTPGSAVWCGMNEVVPGGLLSADRSGLREHRYWTLPTRPHTDDRETTVATVRELLEDIVSRQTVSDVPRCTLLSGGLDSSVITALAAAKLGRPGEHGEAGEKVRSFAVDFVGRENDFVADELRGTTDAPYAREVAAHVGSLHEAIVLDHAAIADPDVRRAVITARDSPLSLGDMDTSLYLLFQAIKEQSTVALSGESADEVFGGYRWFHQPEVQAAQTFPWMAVFVSGARAQVSDRFNADITAALDLPTYIKDRYAEAVREVERAEGESDHEMRMRVMCHLHLTRFVRMLLERKDRISMAVGLEVRVPFCDHRLVEYVYNTPWSLKTFDGREKSLLRAATADLLPRSVLERVKAPYPATLDPHYTGALLQQSKELLTTDDPVFDLVDRDWLEAITRHDPATMPIDVRNGMERVLDLSTWLDVYRPELRL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTGTGGAATCACGGGCTGGGTCTCGTTCGACCGGGATCTGACTCAACAGCGCGCGCAACTGGACGGGATGACCCGGACCATGGCCTGCCGGGGCCCGGACGCCGACGGCATGTGGCTGGACCGGCACGCGGCACTCGGTCATCGCCGGCTGGCGGTCATCGACATCGAGGGCGGCACCCAGCCGATGGTGCTGCCCACGGACGACGGACCGGTGGCGATCACCTACAGCGGTGAGGTCTACAACTACACCGAACTGCGCGGCGAACTGCTGCGCCGCGGCCACCGCTTCGAGACCCGCAGCGACACCGAGGTGGTCCTCCACGGCTATGCGGAGTGGGGCGAGGCGGTCGCCGAACGGCTCAACGGCATGTTCGCCTTCGCGATCTGGGACGCGCGGGTCGAGAAGCTGGTCCTGATCCGCGACCGGATGGGCGTGAAACCGCTCTACTACTCCGCCACCGACGACGGCGTGCTGTTCGGGTCAGAGCCCAAGGCGATCCTCGCCAACCCGCTCGCCGACCGGGCCGTCGACCTCGCCGGGCTGCGGGAGCTGGTCAGTTTCACCCAGACGCCGGGCAGCGCCGTGTGGTGCGGGATGAACGAGGTCGTCCCCGGCGGCCTGCTCTCCGCCGACCGGTCCGGGCTGCGCGAGCACCGTTACTGGACGCTCCCCACCCGCCCGCACACCGACGACCGGGAAACGACCGTCGCCACCGTGCGTGAACTGCTCGAGGACATCGTCAGCCGGCAGACGGTCTCCGACGTCCCCCGCTGCACCCTGCTGTCCGGCGGCCTCGACTCCAGTGTGATCACCGCGCTGGCCGCAGCGAAGCTGGGCCGCCCCGGCGAACACGGCGAGGCCGGCGAGAAGGTCCGCAGTTTCGCGGTGGACTTCGTCGGCCGCGAGAACGACTTCGTCGCCGATGAACTGAGGGGCACCACGGACGCCCCGTACGCCCGGGAGGTGGCAGCGCACGTCGGCTCGCTGCACGAGGCCATCGTCCTCGACCACGCCGCGATCGCCGACCCGGACGTCCGACGGGCCGTCATCACCGCCCGGGACAGCCCTCTCAGCCTCGGCGACATGGACACCTCGCTGTACCTGCTGTTCCAGGCCATCAAGGAACAGTCGACGGTCGCCCTGTCCGGGGAGTCCGCCGACGAGGTCTTCGGCGGGTACCGGTGGTTCCACCAGCCGGAGGTCCAGGCCGCGCAGACCTTCCCCTGGATGGCGGTGTTCGTCAGCGGCGCGCGCGCGCAGGTGTCGGACCGGTTCAACGCCGACATCACCGCCGCGCTCGACCTGCCCACGTACATCAAGGACCGGTACGCCGAGGCGGTCCGGGAGGTGGAGCGCGCCGAGGGCGAGAGCGACCACGAGATGCGCATGCGGGTGATGTGCCACCTGCACCTGACGCGTTTCGTGCGGATGCTGCTGGAGCGCAAGGACCGCATCAGCATGGCCGTCGGTCTGGAGGTCCGGGTGCCCTTCTGCGACCACCGTCTCGTCGAGTACGTCTACAACACCCCGTGGTCGCTGAAGACCTTCGACGGGCGGGAGAAGAGCCTGCTCCGCGCCGCGACCGCCGACCTGCTGCCGCGGTCGGTGCTGGAACGGGTGAAGGCGCCCTACCCGGCCACGCTGGACCCGCACTACACCGGTGCGCTGCTCCAGCAGTCCAAGGAACTGCTGACGACCGACGACCCGGTCTTCGACCTGGTCGACCGCGACTGGCTGGAGGCCATCACCCGGCACGATCCGGCCACCATGCCGATCGACGTCCGCAACGGCATGGAGCGCGTGCTCGACCTGAGCACCTGGCTGGACGTCTACCGGCCCGAACTGCGGCTCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 9042,
                        "end": 9662,
                        "strand": -1,
                        "locus_tag": "ctg1_10",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,042 - 9,662,\n (total: 621 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01243.20 (Pyridoxamine 5&#39;-phosphate oxidase): [28:114](score: 50.8, e-value: 1.4e-13)<br>\n \n  PF10590.9 (Pyridoxine 5&#39;-phosphate oxidase C-terminal dimerisation region): [164:206](score: 44.9, e-value: 9.1e-12)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR00558 (pdxH: pyridoxamine 5&#39;-phosphate oxidase): [16:206](score: 150.7, e-value: 9.9e-45)<br>\n \n <br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSAPRPPMTADVFAVPPDDPLQLLRSWFDSAVADAVQQPGALALATVDARRRVSNRIVQVLHVRPAGLVFASHTDSRKGRELAGTPWASGVLYWREVGRQVSVSGPARPLPAGESDALWDARPVSTHPMSVAAHQSAPLLDEEALRERARELGRNGSALPRPDRWTGYLLEPEAVEFWQSEPQDGLHRRLRYEREGSSWLTRRLQP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=19662\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_10_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSAPRPPMTADVFAVPPDDPLQLLRSWFDSAVADAVQQPGALALATVDARRRVSNRIVQVLHVRPAGLVFASHTDSRKGRELAGTPWASGVLYWREVGRQVSVSGPARPLPAGESDALWDARPVSTHPMSVAAHQSAPLLDEEALRERARELGRNGSALPRPDRWTGYLLEPEAVEFWQSEPQDGLHRRLRYEREGSSWLTRRLQP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCGCACCCCGTCCCCCCATGACGGCCGACGTGTTCGCGGTTCCGCCCGACGATCCCCTGCAACTGCTGCGGAGCTGGTTCGACAGCGCCGTCGCGGACGCGGTCCAGCAGCCGGGCGCCCTGGCCCTGGCCACCGTCGACGCCCGCCGCCGGGTCTCCAACCGGATCGTCCAGGTCCTCCACGTGCGTCCGGCCGGCCTGGTGTTCGCCAGCCACACCGACAGCCGCAAGGGACGCGAGCTGGCCGGGACACCTTGGGCGTCCGGCGTCCTGTACTGGCGCGAGGTCGGCCGGCAGGTGAGCGTGAGCGGACCGGCCCGGCCGCTGCCCGCCGGGGAATCGGACGCCCTGTGGGACGCCCGTCCCGTCAGCACGCACCCGATGTCGGTCGCGGCGCACCAGAGCGCGCCGCTGCTCGACGAAGAGGCACTGCGCGAACGTGCCCGTGAACTGGGACGGAACGGCTCGGCGCTGCCCCGCCCGGACCGATGGACCGGCTATCTCCTGGAGCCGGAGGCGGTGGAGTTCTGGCAGTCCGAGCCGCAGGACGGGCTGCACCGAAGACTGCGGTACGAGCGTGAGGGTTCCAGCTGGCTCACCCGCCGGCTCCAACCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 9659,
                        "end": 10006,
                        "strand": -1,
                        "locus_tag": "ctg1_11",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,659 - 10,006,\n (total: 348 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) thio_amide<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKATISWWDLTRSDQTIESLRVYLRDEGVEPWTEVHGMRLKFWISDRETNRWGAVMLWDTEADLTAPMPPNRATELIGYPPTVRMLSDVEAVVEGLHTGAAAERGLAFDSFGTPS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=20006\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_11_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKATISWWDLTRSDQTIESLRVYLRDEGVEPWTEVHGMRLKFWISDRETNRWGAVMLWDTEADLTAPMPPNRATELIGYPPTVRMLSDVEAVVEGLHTGAAAERGLAFDSFGTPS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAGCCACCATCTCCTGGTGGGATCTCACCCGGTCGGACCAGACGATCGAGTCGCTCCGCGTCTACCTGCGCGACGAGGGCGTGGAGCCGTGGACGGAGGTCCACGGGATGCGGCTGAAGTTCTGGATCTCCGACCGGGAGACCAACCGCTGGGGCGCCGTGATGCTCTGGGACACGGAGGCCGACCTGACGGCGCCGATGCCCCCGAACCGGGCGACCGAACTCATCGGCTACCCGCCGACCGTCCGCATGCTGTCCGACGTCGAGGCCGTCGTCGAAGGACTGCACACCGGAGCGGCGGCCGAACGCGGCCTGGCCTTCGACAGCTTCGGGACACCGTCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 10003,
                        "end": 11907,
                        "strand": -1,
                        "locus_tag": "ctg1_12",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,003 - 11,907,\n (total: 1905 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1018:isochorismate synthase (Score: 305.5; E-value: 1.4e-92)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00425.18 (chorismate binding enzyme): [122:387](score: 146.5, e-value: 9.9e-43)<br>\n \n  PF00117.28 (Glutamine amidotransferase class-I): [442:621](score: 70.7, e-value: 1.3e-19)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSASRLLEHVLGSDPGPFALLHRPETLGPDHVDVLLGRLDTPARLADIRSPEAAGRAGEARHETLVLVPHRQIAERGFAVTEDDSPLLAMEVTHQGLITTSEALSALPDEPIALAGGRFDIDDDAYADIVSDVLDREIGTGEGSNFVIKRSFVTGITGYSTRSALSLFRRLLTRESGAYWTFIVHTGTRTFVGATPERHVSLRDGVAAMTPISGTYRYPATGPALPEVLEFLTDGKETDELYMVLDEELKMMARVCRRGGRVKGPYLREMTWLAHTEYTIEGDSDLDPRDVLRETMFAPTVTGSPLENACRVIARHEPAGRGYYGGIVALIGRDAAGAHAMDSAILIRTADIDSSGTDGTADVRVGVGATLVRHSDPEAETAETRTKAAGVLAALGGPERLDVHPLVRQALERRNTTIANFWLDDADKRARPHPVLAGRRALIVDAEDTFSAMLAHQLRAVGLSVTPTRFDEPLHFAGHDLVVMGPGPGDPRQTDHPRMARLTSAVEELLDRRIPFLAVCLSHQLLSRRLGLGIRRRDVPNQGAQREIDLFGSPARVGFYNSFSARALSSRLRCPGVGEVDVCLDADTGEVHALRGPHFASVQFHLESVLTQDSERVLAELLVPLMETTEVLKA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=3&amp;to=21907\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_12_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSASRLLEHVLGSDPGPFALLHRPETLGPDHVDVLLGRLDTPARLADIRSPEAAGRAGEARHETLVLVPHRQIAERGFAVTEDDSPLLAMEVTHQGLITTSEALSALPDEPIALAGGRFDIDDDAYADIVSDVLDREIGTGEGSNFVIKRSFVTGITGYSTRSALSLFRRLLTRESGAYWTFIVHTGTRTFVGATPERHVSLRDGVAAMTPISGTYRYPATGPALPEVLEFLTDGKETDELYMVLDEELKMMARVCRRGGRVKGPYLREMTWLAHTEYTIEGDSDLDPRDVLRETMFAPTVTGSPLENACRVIARHEPAGRGYYGGIVALIGRDAAGAHAMDSAILIRTADIDSSGTDGTADVRVGVGATLVRHSDPEAETAETRTKAAGVLAALGGPERLDVHPLVRQALERRNTTIANFWLDDADKRARPHPVLAGRRALIVDAEDTFSAMLAHQLRAVGLSVTPTRFDEPLHFAGHDLVVMGPGPGDPRQTDHPRMARLTSAVEELLDRRIPFLAVCLSHQLLSRRLGLGIRRRDVPNQGAQREIDLFGSPARVGFYNSFSARALSSRLRCPGVGEVDVCLDADTGEVHALRGPHFASVQFHLESVLTQDSERVLAELLVPLMETTEVLKA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCGCGTCGCGTCTTCTGGAGCACGTGCTGGGCAGCGATCCGGGCCCCTTCGCCCTGCTGCACCGCCCCGAGACCCTGGGCCCGGACCACGTGGACGTCCTGCTGGGCAGGCTCGACACCCCCGCCCGGCTCGCCGACATCCGGTCGCCCGAAGCGGCCGGACGAGCCGGCGAGGCCCGGCACGAGACGCTGGTCCTGGTGCCGCACCGGCAGATCGCGGAGCGGGGCTTCGCCGTCACCGAGGACGACTCCCCGCTGCTGGCCATGGAGGTGACCCATCAGGGGCTGATCACCACCTCCGAGGCGCTTTCCGCCCTCCCCGACGAACCGATCGCCCTGGCCGGGGGACGCTTCGACATCGACGACGACGCCTACGCGGACATCGTCAGCGACGTCCTCGACCGCGAGATCGGCACCGGCGAGGGTTCCAACTTCGTCATCAAACGGTCCTTCGTCACCGGCATCACCGGCTACTCCACGCGCAGCGCCCTCAGCCTCTTCCGCCGCCTGCTCACCCGGGAGAGCGGCGCCTACTGGACGTTCATCGTGCACACCGGCACCCGCACCTTCGTCGGCGCCACACCGGAACGCCACGTCAGCCTGCGCGACGGCGTCGCCGCGATGACCCCGATCAGCGGCACCTACCGCTATCCCGCGACAGGACCGGCCCTGCCGGAGGTGCTGGAGTTCCTCACCGACGGCAAGGAGACCGACGAGCTGTACATGGTCCTCGACGAGGAACTCAAGATGATGGCGCGGGTCTGCCGCCGGGGCGGCCGCGTGAAAGGGCCGTACCTGCGGGAGATGACCTGGCTCGCGCACACCGAGTACACCATCGAGGGTGACAGCGACCTCGACCCCCGGGACGTCCTGCGGGAGACGATGTTCGCTCCCACCGTGACCGGCAGCCCGCTGGAGAACGCCTGCCGGGTGATCGCCCGCCACGAGCCCGCCGGCCGTGGGTACTACGGCGGGATCGTCGCCCTGATCGGCCGCGATGCCGCCGGTGCGCACGCCATGGACTCGGCCATCCTCATCCGTACCGCGGACATCGACAGCTCGGGGACCGACGGCACCGCGGACGTCCGGGTCGGCGTGGGGGCCACCTTGGTCCGGCACTCCGACCCGGAAGCCGAGACCGCGGAGACACGTACGAAGGCGGCGGGCGTCCTCGCGGCCCTGGGAGGCCCGGAGCGGCTCGACGTCCACCCCCTCGTCCGCCAGGCCCTGGAGCGGCGCAACACCACGATCGCGAACTTCTGGCTGGACGACGCGGACAAGCGCGCACGGCCCCATCCGGTGCTGGCCGGCCGCCGGGCGCTGATCGTCGACGCCGAGGACACCTTCAGCGCGATGCTCGCCCATCAGCTTCGCGCCGTCGGGCTGAGCGTGACACCGACCCGCTTCGACGAGCCCCTTCACTTCGCCGGTCACGACCTCGTCGTCATGGGGCCAGGACCCGGCGACCCGAGGCAGACCGACCACCCCAGGATGGCCCGCCTCACCTCGGCCGTGGAGGAACTGCTGGACCGCCGCATCCCCTTCCTCGCCGTGTGCCTGAGCCACCAGCTGCTCAGCCGGCGCCTGGGGCTCGGCATCCGGCGTCGGGACGTGCCGAACCAGGGCGCCCAGCGCGAGATCGACCTGTTCGGCTCGCCCGCCCGGGTCGGCTTCTACAACTCCTTCTCGGCCCGCGCCCTGAGCAGCCGGCTGCGGTGCCCCGGTGTCGGAGAGGTGGACGTCTGCCTCGACGCGGACACGGGCGAGGTGCACGCCCTGCGGGGGCCGCACTTCGCCTCGGTGCAGTTCCACCTCGAATCCGTGCTCACCCAGGACAGCGAGCGGGTCCTGGCGGAGCTGCTCGTACCGCTGATGGAGACCACGGAGGTACTGAAAGCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 11904,
                        "end": 12527,
                        "strand": -1,
                        "locus_tag": "ctg1_13",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,904 - 12,527,\n (total: 624 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1027:isochorismatase (Score: 277.4; E-value: 1.5e-84)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00857.20 (Isochorismatase family): [32:204](score: 136.7, e-value: 8.8e-40)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00857.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VPGLAPISAYPLPRAADLPPTTARWGLDHNRAALLVHDMQRYFLAPFPPAVRDPLVRHCAQLRRRCAALGVPVFYTAQPGGMTDEERGLLKDFWGPGMRVDPEDRRIVEELTPAPADQVLTKWRYSAFFRSDLLTQLRTRGRDQLIVCGVYAHVGVLATALEAFTNDIQPFLVADALGDFSADYHRLALDYAAERCAVVTTTEEVFR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=1904&amp;to=22527\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_13_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VPGLAPISAYPLPRAADLPPTTARWGLDHNRAALLVHDMQRYFLAPFPPAVRDPLVRHCAQLRRRCAALGVPVFYTAQPGGMTDEERGLLKDFWGPGMRVDPEDRRIVEELTPAPADQVLTKWRYSAFFRSDLLTQLRTRGRDQLIVCGVYAHVGVLATALEAFTNDIQPFLVADALGDFSADYHRLALDYAAERCAVVTTTEEVFR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCCGGGCCTAGCTCCGATATCCGCCTACCCCCTGCCCCGGGCCGCCGATCTGCCGCCCACGACGGCACGTTGGGGACTCGACCACAACCGCGCGGCCCTGCTCGTGCACGACATGCAGAGGTACTTCCTCGCTCCCTTCCCGCCGGCGGTGCGGGATCCGCTCGTGCGTCACTGCGCACAACTGCGCAGGCGGTGCGCCGCACTCGGCGTCCCCGTGTTCTACACCGCGCAGCCCGGAGGCATGACGGACGAGGAACGCGGGCTGCTCAAGGACTTCTGGGGTCCGGGCATGCGCGTCGATCCGGAGGACCGCCGGATCGTCGAGGAACTCACCCCCGCGCCGGCGGACCAGGTACTCACCAAATGGCGCTACAGCGCCTTCTTCCGCTCGGACCTGCTCACCCAGCTGCGCACCCGCGGCCGCGACCAGCTGATCGTCTGCGGGGTGTACGCCCACGTCGGCGTGCTGGCGACCGCACTCGAGGCGTTCACCAACGACATCCAGCCGTTCCTGGTAGCCGACGCCCTCGGTGACTTCTCCGCCGACTACCACCGGCTGGCCCTCGACTACGCAGCCGAACGATGCGCCGTGGTCACCACCACGGAGGAGGTCTTCCGATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 12515,
                        "end": 13639,
                        "strand": -1,
                        "locus_tag": "ctg1_14",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,515 - 13,639,\n (total: 1125 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01474.16 (Class-II DAHP synthetase family): [1:136](score: 148.9, e-value: 1.6e-43)<br>\n \n  PF01474.16 (Class-II DAHP synthetase family): [149:354](score: 256.9, e-value: 2.6e-76)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01474.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003849' target='_blank'>GO:0003849</a>: 3-deoxy-7-phosphoheptulonate synthase activity<br>\n  \n   PF01474.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009073' target='_blank'>GO:0009073</a>: aromatic amino acid family biosynthetic process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VRNMLAELPGLVDPASLDRLRNRLAAVAAGQALVVQAGDCAEDFAECTAGDVKRRADLLDVLAGVMNEITHRPVIKVGRIGGQYAKPRSATTETVAGVELPVYRGHMVNGAEPDPEARRPDPRRLLTGYHAAHQVFAHLCPTPRDRVDPAVWTSHEALLLDYEVPMVRADREGRLALTSTHWPWIGERTRQPDGAHVALLSEVVNPVACKIGPRTTTTELLDLCARLDPARTPGRLTLIARMGAGAAAELLPPLVRAVRTAGHPVIWLADPMHGNTVTTAEGRKTRVVETVVREVTAFQDAVRSAGATPGGIHLETTPDAVTECADVPEATDHIGDKYTSLCDPRLNPRQAISVVSAWQPQSTTNRAEGESCRA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=2515&amp;to=23639\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_14_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VRNMLAELPGLVDPASLDRLRNRLAAVAAGQALVVQAGDCAEDFAECTAGDVKRRADLLDVLAGVMNEITHRPVIKVGRIGGQYAKPRSATTETVAGVELPVYRGHMVNGAEPDPEARRPDPRRLLTGYHAAHQVFAHLCPTPRDRVDPAVWTSHEALLLDYEVPMVRADREGRLALTSTHWPWIGERTRQPDGAHVALLSEVVNPVACKIGPRTTTTELLDLCARLDPARTPGRLTLIARMGAGAAAELLPPLVRAVRTAGHPVIWLADPMHGNTVTTAEGRKTRVVETVVREVTAFQDAVRSAGATPGGIHLETTPDAVTECADVPEATDHIGDKYTSLCDPRLNPRQAISVVSAWQPQSTTNRAEGESCRA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCGGAACATGCTGGCGGAGCTGCCCGGGCTGGTGGATCCGGCATCACTCGACCGGCTCAGGAATCGTCTGGCCGCGGTAGCCGCCGGGCAGGCGCTGGTGGTGCAAGCGGGGGACTGCGCCGAAGACTTCGCCGAATGCACCGCGGGGGACGTGAAGCGGAGGGCGGATCTCCTCGACGTGCTCGCCGGCGTCATGAACGAGATCACCCACCGGCCGGTCATCAAGGTCGGCCGGATCGGAGGTCAGTACGCCAAGCCGCGGTCGGCGACCACCGAAACGGTGGCCGGTGTCGAACTCCCCGTCTACCGGGGGCACATGGTGAACGGCGCCGAGCCGGACCCCGAGGCGAGGCGACCCGACCCCCGACGTCTGCTGACCGGTTACCACGCCGCCCACCAGGTGTTCGCCCACCTCTGCCCGACCCCGCGGGACCGCGTCGACCCCGCGGTGTGGACCAGTCACGAGGCGCTGCTCCTCGACTACGAGGTTCCGATGGTACGGGCCGACCGGGAAGGCAGGCTCGCGCTCACCTCGACCCACTGGCCGTGGATCGGCGAGCGGACCCGGCAGCCCGACGGAGCCCACGTCGCGTTGCTGTCCGAGGTGGTGAATCCGGTGGCCTGCAAGATCGGTCCCCGCACGACGACCACGGAGCTGCTCGATCTCTGCGCCCGGCTCGACCCCGCGAGGACGCCGGGCAGGCTCACCCTGATCGCACGGATGGGTGCCGGCGCGGCGGCGGAGCTGCTGCCGCCCCTGGTCCGGGCCGTCCGAACCGCCGGGCATCCGGTGATCTGGCTGGCCGACCCCATGCACGGGAACACCGTGACCACCGCGGAGGGACGCAAGACCCGCGTCGTGGAGACCGTCGTCCGTGAGGTCACCGCCTTCCAGGACGCCGTCCGCTCGGCCGGCGCGACCCCGGGCGGGATCCACCTGGAGACCACGCCGGACGCGGTGACCGAGTGCGCCGACGTCCCGGAGGCCACCGACCACATCGGGGACAAGTACACGTCGCTGTGCGATCCGCGGCTCAACCCTCGCCAGGCGATCTCGGTGGTGTCGGCCTGGCAGCCGCAGTCCACCACGAACCGAGCCGAGGGAGAGTCGTGCCGGGCCTAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 13988,
                        "end": 14635,
                        "strand": -1,
                        "locus_tag": "ctg1_15",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,988 - 14,635,\n (total: 648 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSKIKHTLPIAAAAIVMTAGSIAGPGMIVTEPAVAEASTVTKGASAGEAPSAVRAASVESGSKARPGARAAATSPEQLLKMLGERIVAKDIDGIIALHEPEAAIVDWDGSVIRGRAAIRTFYLEWFASNPVLTVNPRQTVIAGGWRAWDNKVRQRTAAIMGDYSLEQDAADGTRESFTGNFCDTVQEQLDGTWLYVQDNPYPPHGDAAASRTAHH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=3988&amp;to=24635\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSKIKHTLPIAAAAIVMTAGSIAGPGMIVTEPAVAEASTVTKGASAGEAPSAVRAASVESGSKARPGARAAATSPEQLLKMLGERIVAKDIDGIIALHEPEAAIVDWDGSVIRGRAAIRTFYLEWFASNPVLTVNPRQTVIAGGWRAWDNKVRQRTAAIMGDYSLEQDAADGTRESFTGNFCDTVQEQLDGTWLYVQDNPYPPHGDAAASRTAHH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGTAAGATCAAACACACGCTTCCGATAGCCGCCGCGGCCATTGTGATGACGGCCGGAAGTATCGCCGGTCCGGGAATGATCGTGACCGAGCCGGCGGTCGCGGAGGCGTCCACCGTCACCAAGGGTGCGTCCGCGGGCGAAGCGCCGTCGGCGGTCAGGGCGGCTTCCGTGGAGTCCGGCTCCAAGGCCAGGCCGGGGGCCCGAGCTGCGGCCACGTCCCCCGAGCAGCTGCTGAAGATGCTCGGCGAGCGCATCGTGGCCAAGGACATCGACGGCATCATCGCGCTCCATGAACCCGAGGCGGCCATCGTCGACTGGGACGGATCCGTCATCCGTGGCCGTGCGGCGATCCGTACGTTCTACCTCGAGTGGTTCGCGTCGAACCCGGTGCTCACCGTCAACCCCCGCCAGACCGTGATCGCGGGCGGCTGGCGTGCGTGGGACAACAAGGTGCGCCAGCGCACGGCGGCCATCATGGGCGACTACAGCCTGGAGCAGGACGCGGCGGACGGCACCCGGGAGAGCTTCACCGGTAATTTCTGCGACACCGTCCAGGAACAGCTGGACGGCACCTGGCTCTATGTGCAGGACAATCCATACCCTCCCCACGGGGATGCGGCCGCCTCGAGGACGGCCCATCACTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 14836,
                        "end": 15060,
                        "strand": 1,
                        "locus_tag": "ctg1_16",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,836 - 15,060,\n (total: 225 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPPSLPAHHVHSGTPTGGVAAPDPPDRPSPSVRRKRLAGHQRVKKEESEIPSPALVVQLKIKITAQRCSGHVNG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=4836&amp;to=25060\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPPSLPAHHVHSGTPTGGVAAPDPPDRPSPSVRRKRLAGHQRVKKEESEIPSPALVVQLKIKITAQRCSGHVNG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCACCGTCACTGCCTGCGCATCACGTGCACAGCGGAACGCCGACCGGCGGCGTTGCGGCACCGGACCCCCCGGACCGGCCATCACCGAGCGTCAGAAGAAAGCGCCTCGCAGGCCACCAGAGAGTAAAGAAAGAGGAAAGCGAGATTCCATCACCCGCCTTAGTGGTTCAACTCAAAATTAAAATCACGGCTCAACGATGTTCCGGCCACGTGAATGGCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 15370,
                        "end": 15744,
                        "strand": 1,
                        "locus_tag": "ctg1_17",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,370 - 15,744,\n (total: 375 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VATVEVSLKDIMTVVEGALGAAVVDYSSGMALGTLGGGKDLDLTVAAAGNTDVIRAKVRTMELLGLTGQIEDILITLESQYHLIRLVTGRSGNGLFLYLVLDKSRSNLAMARHQLKRIEEQLEV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=5370&amp;to=25744\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VATVEVSLKDIMTVVEGALGAAVVDYSSGMALGTLGGGKDLDLTVAAAGNTDVIRAKVRTMELLGLTGQIEDILITLESQYHLIRLVTGRSGNGLFLYLVLDKSRSNLAMARHQLKRIEEQLEV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGGCAACTGTGGAAGTGTCGCTGAAGGACATCATGACCGTCGTCGAAGGAGCCCTGGGAGCGGCCGTCGTCGACTACTCGAGCGGCATGGCGCTGGGAACGCTGGGCGGGGGGAAGGACCTGGACCTCACCGTCGCGGCGGCCGGCAACACGGATGTGATCCGCGCCAAGGTGCGCACGATGGAACTGCTGGGCCTCACCGGCCAGATCGAGGACATCCTCATCACGCTGGAGTCCCAGTACCACCTGATCCGCCTGGTCACCGGCCGCAGCGGCAACGGGCTGTTCCTGTACCTCGTGCTGGACAAGTCCCGCTCGAACCTGGCGATGGCCCGCCACCAGCTCAAGCGGATCGAGGAACAGCTGGAAGTGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 15948,
                        "end": 16313,
                        "strand": 1,
                        "locus_tag": "ctg1_18",
                        "type": "regulatory",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,948 - 16,313,\n (total: 366 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1058:ArsR family transcriptional regulator (Score: 60.5; E-value: 1.9e-18)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01022.20 (Bacterial regulatory protein, arsR family): [17:62](score: 33.7, e-value: 2.3e-08)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01022.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity<br>\n  \n   PF01022.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of transcription, DNA-templated<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MQVPLYQAKAEFFRMLGHPVRIRVLELLQHGPVPVRDLLADIDIEPSSLSQQLAVLRRSGIVVSVREGSTVTYALAGGDVAELLRAARRILTELLAGQSELLAELRQVDVPVPTASASGDG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=5948&amp;to=26313\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_18_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MQVPLYQAKAEFFRMLGHPVRIRVLELLQHGPVPVRDLLADIDIEPSSLSQQLAVLRRSGIVVSVREGSTVTYALAGGDVAELLRAARRILTELLAGQSELLAELRQVDVPVPTASASGDG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCAAGTCCCCCTCTACCAGGCCAAGGCAGAGTTCTTCCGGATGCTGGGGCACCCGGTGCGCATCCGGGTCCTGGAGCTGTTGCAGCACGGGCCCGTGCCGGTGCGGGACCTGCTCGCCGACATCGACATCGAGCCGTCCAGCCTGTCGCAGCAGTTGGCCGTGCTACGCAGGTCCGGCATCGTCGTCTCGGTACGGGAGGGCTCCACCGTGACCTACGCCCTCGCGGGCGGCGACGTCGCCGAACTGCTCCGCGCGGCCCGCAGGATCCTCACGGAACTCCTGGCCGGGCAGAGCGAGCTGCTGGCGGAGCTGCGGCAGGTCGACGTGCCGGTGCCGACGGCGTCCGCGAGCGGGGACGGTTAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 16383,
                        "end": 18746,
                        "strand": -1,
                        "locus_tag": "ctg1_19",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,383 - 18,746,\n (total: 2364 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF04434.17 (SWIM zinc finger): [505:525](score: 25.0, e-value: 1e-05)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF04434.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTPRPSEEAREALRAARARVTGGEGPGQERPASEDAFARGGRAEGEPSRDGSRSGPLDESRDGAPGESRGGSSAGEEPSPVREASPAPSAPRPSDAAREALQRALRARRGASAETRPEPRSRPRPEPHPEPRPGPESGAEVSAEAADEPRPAADAVAGEVTGEVPPYADSTATGAMEATDTTEDTAAEGSSPAEGGTPAATGPDAAETPAPPPAPADNADSAPGADVTPPTTGDGTEPSAHRPGDIAREALRAAREEAARARAREQVDEAKRTRRAQAPAPRVPRTTRGDREADRRAREIRETLADAFRMPDTTDDPAPDAPADVPSGRPDAQPPAREDTAPGTARGTRTTGEPAAAPPVAPSSMAAPARDGDLRRTFPPFPPRSSDGAEQFAETWWGRAWVTALEDGALDPARLARGRGYAEQGHVDAITVTPGLVLAYVRGSRARPYRVQVRLRTFDDADWERFLDAAADRPGHIAALLDKEMPQSLADCGVPLLPGPGDLAPRCSCPDSGHPCKHAAALCYQTARLLDADPFVLLLLRGRSERQVIDALSRLSAARAARAAQNREPEPLPGIRATDALSRRGPGLPPPPAPLPPPPHPEQPPVYPASPGGPDPFALDQLATDAAARAHALLTTGRDPVGPLTLWHDAVRLAAARPGSGLTAGTRALYSSLARAAGRTPGDLARAVAAWRQGGPTGLAVLEEPWDPPAGRFDRARPLLLAADLPAFRPWRNRLTHPRGHVQLRLGRDHLWYAYESEPDQDDWWPRGTPDPDPVGALTGLDTLGDL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=6383&amp;to=28746\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_19_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTPRPSEEAREALRAARARVTGGEGPGQERPASEDAFARGGRAEGEPSRDGSRSGPLDESRDGAPGESRGGSSAGEEPSPVREASPAPSAPRPSDAAREALQRALRARRGASAETRPEPRSRPRPEPHPEPRPGPESGAEVSAEAADEPRPAADAVAGEVTGEVPPYADSTATGAMEATDTTEDTAAEGSSPAEGGTPAATGPDAAETPAPPPAPADNADSAPGADVTPPTTGDGTEPSAHRPGDIAREALRAAREEAARARAREQVDEAKRTRRAQAPAPRVPRTTRGDREADRRAREIRETLADAFRMPDTTDDPAPDAPADVPSGRPDAQPPAREDTAPGTARGTRTTGEPAAAPPVAPSSMAAPARDGDLRRTFPPFPPRSSDGAEQFAETWWGRAWVTALEDGALDPARLARGRGYAEQGHVDAITVTPGLVLAYVRGSRARPYRVQVRLRTFDDADWERFLDAAADRPGHIAALLDKEMPQSLADCGVPLLPGPGDLAPRCSCPDSGHPCKHAAALCYQTARLLDADPFVLLLLRGRSERQVIDALSRLSAARAARAAQNREPEPLPGIRATDALSRRGPGLPPPPAPLPPPPHPEQPPVYPASPGGPDPFALDQLATDAAARAHALLTTGRDPVGPLTLWHDAVRLAAARPGSGLTAGTRALYSSLARAAGRTPGDLARAVAAWRQGGPTGLAVLEEPWDPPAGRFDRARPLLLAADLPAFRPWRNRLTHPRGHVQLRLGRDHLWYAYESEPDQDDWWPRGTPDPDPVGALTGLDTLGDL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACACCCCGGCCGTCGGAGGAGGCACGGGAGGCGCTGCGCGCGGCTCGGGCACGGGTGACCGGGGGAGAGGGGCCGGGGCAGGAGCGCCCGGCCTCCGAGGATGCGTTCGCGCGAGGCGGCCGGGCGGAGGGGGAGCCTTCGCGGGACGGGTCACGGAGCGGGCCGCTGGACGAGTCGCGGGATGGGGCGCCGGGAGAGTCGCGGGGCGGGTCGTCAGCGGGGGAGGAGCCGTCGCCGGTCCGGGAGGCGTCCCCGGCGCCCTCGGCCCCGCGTCCGTCCGACGCGGCCCGTGAGGCCCTCCAGCGTGCGCTGCGGGCACGGCGGGGTGCGTCCGCCGAGACGCGACCCGAGCCGCGCTCCAGGCCGCGACCCGAGCCGCACCCCGAGCCGCGCCCCGGGCCGGAGTCCGGCGCCGAGGTCTCCGCCGAGGCGGCCGACGAGCCGCGGCCGGCCGCGGACGCGGTGGCCGGTGAAGTGACGGGCGAGGTGCCCCCGTACGCGGACTCGACGGCCACGGGTGCCATGGAGGCCACGGACACCACGGAGGACACGGCGGCCGAGGGTTCGTCCCCTGCCGAGGGAGGAACACCCGCCGCGACGGGACCGGACGCAGCCGAGACCCCCGCCCCCCCCCCCGCCCCGGCGGACAACGCCGACTCCGCGCCCGGAGCGGATGTCACGCCCCCCACCACCGGCGACGGCACGGAGCCGTCGGCCCACCGCCCCGGTGACATCGCCCGGGAGGCGCTGCGCGCCGCACGGGAGGAAGCCGCGCGGGCCCGCGCCCGCGAGCAGGTGGACGAGGCCAAGCGCACCCGACGGGCGCAGGCCCCCGCGCCCCGGGTTCCGCGCACCACGCGCGGCGACCGTGAAGCCGACCGCCGCGCGCGGGAGATCCGGGAAACCCTCGCCGACGCCTTCCGCATGCCCGACACGACGGACGACCCGGCCCCGGACGCACCCGCCGACGTACCCAGCGGCAGGCCGGATGCACAGCCGCCGGCCCGTGAGGACACCGCACCCGGGACGGCGCGAGGCACACGAACCACCGGCGAACCGGCGGCGGCGCCTCCCGTCGCCCCGTCCTCCATGGCCGCCCCCGCGCGGGACGGTGACCTGCGCCGTACCTTCCCGCCGTTCCCGCCCCGCTCCTCGGACGGCGCCGAGCAGTTCGCCGAGACCTGGTGGGGCAGGGCGTGGGTCACCGCGCTGGAGGACGGCGCGCTGGACCCCGCCCGGCTCGCCCGCGGACGCGGCTACGCCGAACAGGGACACGTCGACGCCATCACCGTCACGCCCGGCCTGGTCCTCGCGTACGTCCGGGGCAGCCGTGCCCGGCCCTACCGGGTGCAGGTGCGGCTGCGGACGTTCGACGACGCCGACTGGGAGCGGTTCCTGGACGCCGCCGCCGACCGCCCCGGCCACATCGCGGCACTGCTGGACAAGGAGATGCCGCAGTCCCTCGCCGACTGCGGGGTCCCGCTGCTGCCGGGCCCCGGCGACCTCGCCCCACGGTGCAGCTGTCCCGACTCCGGGCACCCTTGCAAGCACGCGGCGGCCCTCTGCTACCAGACCGCCCGGCTGCTCGACGCGGACCCGTTCGTGCTGCTCCTGCTGCGCGGGCGGAGCGAGCGCCAGGTGATCGACGCGCTGTCCCGGCTCAGCGCGGCCCGCGCCGCCCGCGCCGCCCAGAACAGGGAACCGGAGCCGCTGCCCGGCATACGGGCCACCGACGCCCTGTCCCGGCGCGGGCCCGGACTCCCGCCGCCACCCGCGCCGTTGCCCCCGCCGCCGCACCCGGAGCAGCCCCCCGTCTACCCCGCGTCGCCCGGCGGACCCGACCCGTTCGCGCTGGACCAGCTCGCCACCGACGCCGCCGCCCGCGCACACGCCCTGCTCACCACCGGCCGTGACCCGGTCGGCCCACTCACCCTGTGGCACGACGCGGTGCGACTGGCCGCCGCCCGCCCCGGCTCCGGACTGACCGCGGGCACCCGCGCGCTGTACTCCTCCCTCGCCCGGGCCGCCGGCCGCACCCCCGGCGACCTGGCGCGGGCGGTGGCGGCATGGCGCCAGGGAGGCCCGACCGGGCTGGCCGTGCTGGAGGAGCCGTGGGATCCCCCGGCCGGCCGCTTCGACCGCGCCCGCCCGCTGCTGCTCGCCGCCGACCTGCCCGCCTTCCGGCCCTGGCGCAACCGCCTCACCCACCCCCGCGGCCATGTCCAGCTCCGCCTCGGCCGCGACCACCTCTGGTACGCGTACGAGTCGGAGCCGGACCAGGACGACTGGTGGCCCCGGGGCACCCCCGACCCGGACCCGGTCGGCGCCCTGACCGGCCTCGACACCCTCGGCGACCTCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 18743,
                        "end": 21610,
                        "strand": -1,
                        "locus_tag": "ctg1_20",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,743 - 21,610,\n (total: 2868 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF12419.8 (SNF2 Helicase protein): [318:447](score: 113.2, e-value: 7.8e-33)<br>\n \n  PF00176.23 (SNF2 family N-terminal domain): [509:765](score: 167.1, e-value: 4.3e-49)<br>\n \n  PF00271.31 (Helicase conserved C-terminal domain): [783:895](score: 59.2, e-value: 4.4e-16)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00176.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSEATVTAVSGTSDGRVASSRLPAVFLPAPLPRDGRIAFYDPEGADTPSQEGDGDRRTDLTVVRPHGAGARRRTVPALSLPVDEALPLLVAARYDPAAHPATACWGAAALHALRLTARGRLLPGLTAEGYDAWRAGPLEPDDVAHLRAVAAALPYEGHAVPLPGPGPLRLPTPEALVRAFLDAVADALPRTPAAPYASGLPFAARRPQRLPDARDWAAEVAAGMDAGVRISLRLDLSAHDLFDSGETAGGEGGGARGAGAAIVQVHSLSDPTLVADAAALWSGEADHGFGPRARVDAALAVRRAARVWPPLDRLADQDVPDVLALSEDELSDLLGVAATRLAAAGVAVHWPRDLAQDLTATAVVRPAPGSATDGTGFFESEDLLRFGWQIALGGDPLGEAEMDALAEAHRPVVRLRDQWVLVDPALVRKARKRDLGLLDPVDALSVALTGEAEVDGETVQAVPAGTLAALRDRLTAGVRPAAPPPGLDATLRDYQLRGLAWLDLMTSLGLGGCLADDMGLGKTVTLIALHLKRARPEPTLVVCPASLLGNWQREITRFAPGVPVRRFHGPDRTLEELDGGFVLTTYGTMRSAAPTLAEQRWGMVVADEAQHVKNPHSATAKALRTIPAPARVALTGTPVENNLSELWALLDWTTPGLLGPLKSFRARHARAVETGEDEQAVERLARLVRPFLLRRKKSDPGIVPELPPKTETDHPVPLTREQAALYEAVVRESMVAIETAQGMGRRGLVLKLLTALKQICDHPALYLKEEHAPAGDGLAARSGKLALLDELLDTVLAEDGSALVFTQYVGMARLITRHLAERAVPVDLLHGGTPVPERERMVDRFQSGAVPVLVLSLKAAGTGLNLTRAGHVVHFDRWWNPAVEEQATDRAYRIGQTQPVQVHRLVTEGTVEDRIAEMLQSKRALADAILGSGESALTELSDRDLSDLVSLRRSA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=8743&amp;to=31610\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_20_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSEATVTAVSGTSDGRVASSRLPAVFLPAPLPRDGRIAFYDPEGADTPSQEGDGDRRTDLTVVRPHGAGARRRTVPALSLPVDEALPLLVAARYDPAAHPATACWGAAALHALRLTARGRLLPGLTAEGYDAWRAGPLEPDDVAHLRAVAAALPYEGHAVPLPGPGPLRLPTPEALVRAFLDAVADALPRTPAAPYASGLPFAARRPQRLPDARDWAAEVAAGMDAGVRISLRLDLSAHDLFDSGETAGGEGGGARGAGAAIVQVHSLSDPTLVADAAALWSGEADHGFGPRARVDAALAVRRAARVWPPLDRLADQDVPDVLALSEDELSDLLGVAATRLAAAGVAVHWPRDLAQDLTATAVVRPAPGSATDGTGFFESEDLLRFGWQIALGGDPLGEAEMDALAEAHRPVVRLRDQWVLVDPALVRKARKRDLGLLDPVDALSVALTGEAEVDGETVQAVPAGTLAALRDRLTAGVRPAAPPPGLDATLRDYQLRGLAWLDLMTSLGLGGCLADDMGLGKTVTLIALHLKRARPEPTLVVCPASLLGNWQREITRFAPGVPVRRFHGPDRTLEELDGGFVLTTYGTMRSAAPTLAEQRWGMVVADEAQHVKNPHSATAKALRTIPAPARVALTGTPVENNLSELWALLDWTTPGLLGPLKSFRARHARAVETGEDEQAVERLARLVRPFLLRRKKSDPGIVPELPPKTETDHPVPLTREQAALYEAVVRESMVAIETAQGMGRRGLVLKLLTALKQICDHPALYLKEEHAPAGDGLAARSGKLALLDELLDTVLAEDGSALVFTQYVGMARLITRHLAERAVPVDLLHGGTPVPERERMVDRFQSGAVPVLVLSLKAAGTGLNLTRAGHVVHFDRWWNPAVEEQATDRAYRIGQTQPVQVHRLVTEGTVEDRIAEMLQSKRALADAILGSGESALTELSDRDLSDLVSLRRSA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCGAGGCGACCGTGACGGCGGTGTCCGGGACGAGTGACGGACGCGTCGCGTCGTCGCGCCTCCCGGCCGTGTTCCTGCCCGCACCCCTCCCGCGCGACGGGCGGATCGCCTTCTACGACCCCGAGGGCGCGGACACGCCCTCGCAGGAGGGGGACGGCGACCGGCGTACGGACCTCACCGTCGTCCGGCCGCACGGCGCGGGAGCGCGCCGGCGCACCGTCCCCGCGCTGTCCCTGCCCGTGGACGAGGCCCTGCCCCTGCTCGTCGCCGCCCGGTACGACCCCGCGGCCCACCCGGCCACCGCCTGCTGGGGCGCCGCCGCCCTGCACGCGCTGCGGCTCACCGCCCGTGGGCGCCTGCTGCCCGGCCTCACCGCCGAGGGGTACGACGCCTGGCGGGCCGGCCCGCTCGAACCGGACGACGTGGCACACCTGCGCGCGGTGGCCGCCGCCCTCCCCTACGAGGGCCACGCGGTGCCGCTGCCCGGACCCGGCCCCCTGCGTCTGCCCACGCCCGAGGCGCTCGTCCGTGCCTTCCTGGACGCGGTCGCCGACGCCCTGCCCCGCACCCCCGCCGCCCCCTACGCCTCCGGCCTGCCGTTCGCCGCGCGGCGGCCCCAGCGGCTTCCCGACGCCCGGGACTGGGCCGCCGAGGTCGCCGCCGGCATGGACGCGGGCGTGCGGATCTCGCTCCGCCTCGACCTGTCCGCCCACGACCTCTTCGACTCCGGGGAGACCGCCGGCGGCGAGGGCGGCGGCGCGCGCGGCGCGGGCGCCGCGATCGTGCAGGTGCACAGCCTCTCCGACCCGACGCTGGTGGCCGACGCGGCCGCCCTGTGGTCGGGCGAGGCGGACCACGGCTTCGGGCCGCGCGCCCGGGTGGACGCCGCCCTCGCCGTGCGCCGGGCGGCCCGTGTCTGGCCCCCGCTCGACCGGCTCGCCGACCAGGACGTGCCGGACGTACTGGCCCTGTCCGAGGACGAGTTGAGCGATCTGCTCGGGGTGGCGGCCACCCGGCTGGCGGCGGCCGGCGTCGCCGTGCACTGGCCCCGCGACCTCGCGCAGGACCTCACCGCCACGGCCGTCGTCCGGCCCGCGCCCGGCTCGGCGACCGACGGCACCGGCTTCTTCGAGAGCGAGGACCTGCTGCGCTTCGGCTGGCAGATCGCCCTGGGCGGCGACCCGCTCGGCGAGGCCGAGATGGACGCCCTGGCCGAGGCGCACCGCCCGGTCGTCCGGTTGCGCGACCAGTGGGTGCTGGTCGACCCCGCCCTGGTCCGCAAGGCCCGCAAGCGCGACCTGGGGCTGCTCGATCCCGTCGACGCCCTGTCCGTCGCCCTCACCGGGGAGGCGGAGGTCGACGGCGAGACGGTGCAGGCGGTGCCCGCGGGGACGCTGGCCGCCCTCCGCGACCGCCTGACCGCCGGGGTGCGGCCCGCGGCGCCTCCTCCCGGCCTGGACGCCACCCTGCGCGACTACCAGCTGCGCGGCCTGGCCTGGCTCGACCTCATGACCTCCCTCGGCCTCGGCGGCTGCCTCGCCGACGACATGGGCCTCGGCAAGACCGTCACCCTGATCGCCCTGCACCTGAAGCGGGCCCGCCCCGAACCCACCCTGGTGGTCTGCCCCGCGTCCCTGCTCGGCAACTGGCAGCGGGAGATCACCCGGTTCGCCCCCGGCGTCCCCGTGCGCCGCTTCCACGGCCCGGACCGCACCCTGGAGGAGCTGGACGGCGGTTTCGTCCTCACCACCTACGGCACCATGCGCTCCGCCGCGCCCACTTTGGCGGAACAGCGCTGGGGCATGGTCGTCGCCGACGAGGCGCAGCACGTCAAGAACCCGCACTCGGCGACCGCCAAGGCGCTGCGCACCATCCCGGCCCCGGCCAGGGTCGCCCTCACCGGCACCCCCGTGGAGAACAACCTCTCCGAGCTGTGGGCCCTCCTGGACTGGACGACCCCCGGGCTCCTCGGACCGCTGAAGTCCTTCCGCGCCCGTCACGCGCGCGCGGTGGAGACCGGCGAGGACGAGCAGGCGGTCGAGCGGCTGGCCCGGCTCGTCCGCCCCTTCCTGCTCCGGCGCAAGAAGTCCGACCCGGGCATCGTCCCCGAGCTCCCGCCCAAGACGGAGACGGACCACCCGGTGCCGCTCACCCGCGAACAGGCAGCGCTGTACGAGGCGGTGGTGCGCGAGTCGATGGTCGCCATCGAGACCGCGCAGGGCATGGGGCGCCGCGGGCTGGTGCTCAAGCTGCTCACCGCGCTCAAGCAGATCTGCGACCACCCCGCGCTGTACCTGAAGGAGGAACACGCCCCGGCCGGCGACGGCCTCGCCGCCCGCTCCGGCAAACTCGCCCTGCTGGACGAACTGTTGGACACGGTGCTCGCCGAGGACGGCTCGGCCCTCGTCTTCACCCAGTACGTCGGCATGGCCCGCCTGATCACCCGCCACCTCGCCGAGCGCGCCGTCCCGGTCGACCTGCTCCACGGCGGTACGCCGGTGCCCGAGCGGGAGCGGATGGTGGACCGCTTCCAGAGCGGTGCGGTGCCGGTCCTCGTGCTCTCGCTCAAGGCGGCGGGGACGGGACTGAACCTGACCCGGGCGGGTCATGTCGTCCACTTCGACCGCTGGTGGAACCCGGCGGTGGAGGAACAGGCCACCGACCGCGCGTACCGCATCGGCCAGACCCAGCCCGTCCAGGTCCACCGGCTGGTCACCGAGGGCACGGTCGAGGACCGCATCGCGGAGATGCTCCAGTCCAAGCGGGCCCTCGCCGACGCGATCCTCGGCTCGGGCGAGTCCGCGCTCACCGAGCTGTCCGACCGTGATCTGTCCGACCTGGTGTCCCTGCGGAGGTCGGCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 21698,
                        "end": 22303,
                        "strand": -1,
                        "locus_tag": "ctg1_21",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_21</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_21</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,698 - 22,303,\n (total: 606 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTGELPPLTGDPGHPGGPGGAGGSQPGEDRRHMIRRRALTLLIIVLLIGVPAGYLVISANQSRASGKDKEAKYSATGLTEGWPSKLQRRIYQVPIPHPAWWVASYETNNWKTSRLYVEFETSDAGLTAFLTSMGMAEKDLKKDRLTIGDRDRDVTGWTFDGPGTWSGLVHEQENPAPTHDVVVNHDKPGYPRVYVVARTVP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=11698&amp;to=32303\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTGELPPLTGDPGHPGGPGGAGGSQPGEDRRHMIRRRALTLLIIVLLIGVPAGYLVISANQSRASGKDKEAKYSATGLTEGWPSKLQRRIYQVPIPHPAWWVASYETNNWKTSRLYVEFETSDAGLTAFLTSMGMAEKDLKKDRLTIGDRDRDVTGWTFDGPGTWSGLVHEQENPAPTHDVVVNHDKPGYPRVYVVARTVP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACGGGCGAGCTTCCCCCGCTGACGGGCGACCCCGGCCACCCCGGCGGGCCGGGCGGCGCGGGCGGGTCGCAGCCGGGCGAGGACCGGCGGCACATGATCCGCCGCCGCGCCCTCACCCTGCTGATCATCGTGCTGCTCATCGGAGTCCCGGCCGGCTACCTGGTGATCTCCGCGAACCAGAGCCGGGCCAGCGGCAAGGACAAGGAGGCGAAGTACTCCGCGACCGGCCTGACCGAGGGCTGGCCGTCCAAGCTCCAGCGCCGCATCTACCAGGTGCCGATACCGCATCCGGCGTGGTGGGTGGCCTCGTACGAGACCAACAACTGGAAGACCAGCCGCCTGTACGTCGAGTTCGAGACCAGCGACGCGGGCCTGACCGCCTTCCTCACCAGCATGGGCATGGCGGAGAAGGACCTGAAGAAGGACCGCCTCACCATCGGCGACCGCGACCGCGACGTCACCGGCTGGACCTTCGACGGACCCGGCACCTGGTCCGGCCTGGTGCACGAGCAGGAGAACCCGGCGCCCACCCACGACGTGGTCGTCAACCACGACAAGCCCGGCTACCCCCGGGTGTACGTCGTGGCCCGCACCGTGCCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 22300,
                        "end": 23448,
                        "strand": -1,
                        "locus_tag": "ctg1_22",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_22</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_22</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,300 - 23,448,\n (total: 1149 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1108:ROK family protein (Score: 335.4; E-value: 6.9e-102)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00480.20 (ROK family): [37:348](score: 271.4, e-value: 9.8e-81)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR00744 (ROK_glcA_fam: ROK family protein (putative glucokinase)): [38:348](score: 311.4, e-value: 1.6e-93)<br>\n \n <br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSTYRDFTAPIGSRRATVLRTVGTRERRSHLSAPRVPTVGIDIGGTKVMAGVVDADGNILEKLRTETPDKSKSPKVVEDTIVELVLDLSDRHDVHAVGIGAAGWVDADRNRVLFAPHLSWRNEPLRDRLADRLAVPVLVDNDANSAAWAEWRFGAGSGEDNLVMITLGTGIGGAILEDGKVKRGKYGVAGEFGHMQVVPGGHRCPCGNRGCWEQYSSGNALVREAKELAAADSPVAYGIIEHVKGNIADISGPMITELAREGDAMCIELLQDIGQWLGVGIANLAAALDPSCFVIGGGVSAADDLLIGPARDAFKRQLTGRGYRPEARIVRAQLGPEAGMVGAADLARLVARRFRRAKRRRVERYERYERFAEARRTSSESL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=12300&amp;to=33448\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_22_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSTYRDFTAPIGSRRATVLRTVGTRERRSHLSAPRVPTVGIDIGGTKVMAGVVDADGNILEKLRTETPDKSKSPKVVEDTIVELVLDLSDRHDVHAVGIGAAGWVDADRNRVLFAPHLSWRNEPLRDRLADRLAVPVLVDNDANSAAWAEWRFGAGSGEDNLVMITLGTGIGGAILEDGKVKRGKYGVAGEFGHMQVVPGGHRCPCGNRGCWEQYSSGNALVREAKELAAADSPVAYGIIEHVKGNIADISGPMITELAREGDAMCIELLQDIGQWLGVGIANLAAALDPSCFVIGGGVSAADDLLIGPARDAFKRQLTGRGYRPEARIVRAQLGPEAGMVGAADLARLVARRFRRAKRRRVERYERYERFAEARRTSSESL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCACCTACCGCGACTTCACCGCCCCCATCGGATCCCGGCGCGCCACCGTCCTGAGAACGGTCGGCACCCGGGAGCGCCGTTCCCACCTGTCGGCCCCCCGGGTCCCGACCGTGGGGATCGACATCGGCGGCACCAAAGTGATGGCGGGCGTCGTGGACGCCGACGGCAACATCCTGGAGAAGCTCCGCACGGAGACCCCGGACAAGTCCAAGAGCCCGAAGGTCGTCGAGGACACCATCGTGGAGCTGGTGCTGGACCTGTCCGACCGGCACGACGTGCACGCCGTCGGCATCGGCGCGGCCGGCTGGGTCGACGCCGACCGCAACCGCGTGCTGTTCGCCCCCCACCTGTCCTGGCGCAACGAACCCCTCCGGGACCGCCTCGCCGACCGCCTCGCCGTCCCGGTCCTCGTCGACAACGACGCCAACTCCGCCGCCTGGGCCGAATGGCGCTTCGGCGCCGGCAGCGGCGAGGACAACCTCGTCATGATCACGCTCGGCACCGGCATCGGCGGCGCGATCCTGGAGGACGGCAAGGTCAAGCGCGGCAAGTACGGCGTCGCCGGCGAGTTCGGCCACATGCAGGTCGTCCCCGGGGGCCACCGCTGCCCGTGCGGCAACCGCGGCTGCTGGGAGCAGTACAGCTCCGGCAACGCCCTGGTCCGCGAGGCAAAGGAACTGGCCGCCGCCGACTCCCCGGTCGCCTACGGGATCATCGAGCACGTCAAGGGCAACATCGCCGACATCAGCGGCCCGATGATCACCGAGCTGGCCCGCGAGGGCGACGCCATGTGCATCGAGCTGCTCCAGGACATCGGCCAGTGGCTCGGCGTGGGCATCGCCAACCTGGCCGCCGCCCTCGACCCCTCCTGCTTCGTCATCGGCGGCGGTGTCTCCGCGGCCGACGACCTGCTCATCGGCCCCGCGCGGGACGCCTTCAAGCGGCAGCTCACCGGCCGCGGCTACCGCCCGGAGGCCCGTATCGTCCGCGCCCAGCTCGGACCCGAGGCCGGCATGGTCGGCGCCGCCGACCTCGCCCGCCTCGTCGCCCGCCGCTTCCGCCGCGCCAAGCGCCGCCGTGTCGAGCGGTACGAGCGCTACGAGCGCTTCGCGGAGGCCCGCCGTACGAGCTCGGAGTCGCTGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 23682,
                        "end": 24446,
                        "strand": -1,
                        "locus_tag": "ctg1_23",
                        "type": "regulatory",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_23</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_23</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,682 - 24,446,\n (total: 765 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1136:GntR family transcriptional regulator (Score: 247.9; E-value: 1.6e-75)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00392.21 (Bacterial regulatory proteins, gntR family): [24:87](score: 57.7, e-value: 6.6e-16)<br>\n \n  PF07702.13 (UTRA domain): [107:244](score: 136.7, e-value: 4.8e-40)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00392.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity<br>\n  \n   PF00392.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of transcription, DNA-templated<br>\n  \n   PF07702.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF07702.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of transcription, DNA-templated<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VPKPEVDPTVQLELSVDRGSPVPLYFQLSQQLESAIEHGTLTPGTLLGNEIELAARLGLSRPTVRQAIQSLVDKGLLVRRRGVGTQVVHSQVKRPLELSSLYDDLESAGQRPTTAVLVNTMVTASAEVAAALGVTEGTEVHRIERLRSAHGEPIAYLCNYIPPALLDLDTGQLEATGLYRLMRAAGITLHSARQTIGARAATAAEAERLREQPGAPLLTMQRVTFDDTGRAVEYGTHTYRPSRYSFEFQLLVRS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=13682&amp;to=34446\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_23_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VPKPEVDPTVQLELSVDRGSPVPLYFQLSQQLESAIEHGTLTPGTLLGNEIELAARLGLSRPTVRQAIQSLVDKGLLVRRRGVGTQVVHSQVKRPLELSSLYDDLESAGQRPTTAVLVNTMVTASAEVAAALGVTEGTEVHRIERLRSAHGEPIAYLCNYIPPALLDLDTGQLEATGLYRLMRAAGITLHSARQTIGARAATAAEAERLREQPGAPLLTMQRVTFDDTGRAVEYGTHTYRPSRYSFEFQLLVRS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCCGAAACCAGAAGTGGACCCGACCGTGCAGCTGGAGCTCAGCGTGGACCGCGGCTCCCCCGTGCCGTTGTACTTCCAGCTGTCCCAGCAGCTGGAGTCCGCCATCGAGCACGGCACCCTCACTCCCGGCACCCTGCTGGGCAACGAGATCGAGCTGGCCGCACGGCTCGGCCTGTCCCGGCCGACCGTCCGCCAGGCCATCCAGTCGCTCGTCGACAAGGGCCTCCTGGTGCGCCGCCGCGGGGTCGGCACCCAGGTGGTGCACAGCCAGGTCAAACGCCCCCTGGAGCTCAGCAGCCTCTACGACGACCTGGAGTCCGCCGGACAGCGGCCCACCACGGCCGTGCTGGTCAACACCATGGTCACCGCGTCCGCCGAGGTCGCCGCCGCGCTCGGGGTGACGGAGGGCACGGAGGTGCACCGCATCGAACGTCTGCGGTCCGCGCACGGCGAACCCATCGCGTACCTGTGCAACTACATCCCGCCCGCCCTGCTCGACCTGGACACCGGCCAGCTGGAGGCGACCGGCCTGTACCGGCTGATGCGGGCCGCCGGGATCACCCTGCACAGCGCGCGGCAGACCATCGGCGCGCGGGCCGCCACCGCCGCCGAGGCCGAGCGGCTGCGCGAGCAGCCCGGCGCCCCGCTGCTCACGATGCAGCGGGTGACCTTCGACGACACCGGCCGCGCGGTGGAGTACGGCACGCACACCTACCGGCCCTCGCGGTACTCCTTCGAGTTCCAGCTGCTGGTGCGCAGCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 24548,
                        "end": 25570,
                        "strand": 1,
                        "locus_tag": "ctg1_24",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_24</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_24</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,548 - 25,570,\n (total: 1023 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1079:oxidoreductase (Score: 200.3; E-value: 8.6e-61)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01408.22 (Oxidoreductase family, NAD-binding Rossmann fold): [0:118](score: 64.9, e-value: 1.1e-17)<br>\n \n  PF02894.17 (Oxidoreductase family, C-terminal alpha/beta domain): [129:227](score: 29.5, e-value: 6.1e-07)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01408.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n   PF02894.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n   PF02894.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055114' target='_blank'>GO:0055114</a>: oxidation-reduction process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRIGVIGTGRIGTIHAHTLSRHREVGSLILTDVDPARAQALAHRLGETAAPGVDEIYTWGVDAVVITAATSAHADLIGRAARAGLPVFCEKPIALDLAGTLQAITEVETAGTVLQMGFQRRFDRGYTGAREAVRAGRLGRLHTVRAMTSDAEPPAPSRLAQSGGLYRDTLIHDFDVLRWVTGREVVDVYAGGSDAGPPMFREAGDVDTGAALLTLDDGTLATVTGTRLNGAGYDVRMELAGELDQIVVGLDDRTPIASTEPTGPPAADKPWTGFLERFGPAYEAELVAFVEVVRGERPNPCDGREALRALLVAEACERSRRERRAVRPAELLSSATEALT&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=14548&amp;to=35570\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_24_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRIGVIGTGRIGTIHAHTLSRHREVGSLILTDVDPARAQALAHRLGETAAPGVDEIYTWGVDAVVITAATSAHADLIGRAARAGLPVFCEKPIALDLAGTLQAITEVETAGTVLQMGFQRRFDRGYTGAREAVRAGRLGRLHTVRAMTSDAEPPAPSRLAQSGGLYRDTLIHDFDVLRWVTGREVVDVYAGGSDAGPPMFREAGDVDTGAALLTLDDGTLATVTGTRLNGAGYDVRMELAGELDQIVVGLDDRTPIASTEPTGPPAADKPWTGFLERFGPAYEAELVAFVEVVRGERPNPCDGREALRALLVAEACERSRRERRAVRPAELLSSATEALT\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCGCATCGGGGTCATCGGTACGGGCCGGATCGGCACCATTCACGCCCACACACTCAGCAGGCACCGCGAGGTCGGGTCCTTGATCCTCACGGACGTCGATCCGGCGCGGGCCCAGGCCCTCGCCCACCGGCTCGGCGAGACGGCGGCGCCGGGGGTGGACGAGATCTACACCTGGGGAGTGGACGCCGTGGTGATCACCGCGGCCACGTCCGCCCACGCCGATCTGATCGGCCGGGCGGCCCGTGCGGGGCTGCCGGTCTTCTGCGAGAAGCCCATCGCCCTGGATCTCGCCGGGACGTTACAGGCGATCACGGAGGTGGAGACCGCCGGGACGGTGCTTCAGATGGGCTTCCAGCGGCGGTTCGACCGGGGATACACGGGCGCCCGTGAGGCGGTGCGGGCGGGCAGGCTGGGGCGGCTGCACACGGTGCGGGCGATGACGAGCGACGCGGAGCCCCCGGCCCCCTCACGTCTGGCGCAGTCCGGCGGGCTGTACCGGGACACACTGATCCACGACTTCGACGTCCTGCGCTGGGTGACCGGCCGGGAGGTCGTGGACGTCTACGCCGGCGGGTCGGACGCCGGTCCCCCGATGTTCCGCGAGGCGGGCGACGTCGACACCGGCGCGGCGCTCCTCACCCTCGACGACGGCACCCTCGCCACGGTCACCGGGACCCGGCTGAACGGCGCCGGCTACGACGTACGCATGGAACTCGCCGGGGAGCTGGACCAGATCGTGGTCGGCCTGGACGACCGTACGCCGATCGCCTCCACGGAACCGACCGGGCCGCCGGCCGCGGACAAGCCGTGGACGGGCTTCCTGGAGCGGTTCGGGCCCGCCTACGAGGCCGAACTGGTCGCGTTCGTGGAGGTGGTGCGGGGCGAGCGGCCCAACCCCTGCGACGGCCGTGAGGCCCTGCGGGCGCTGCTGGTCGCGGAGGCCTGCGAGCGGTCCCGCCGGGAGCGCAGAGCGGTCCGCCCCGCGGAACTGCTGAGCAGCGCCACGGAGGCCCTGACCTAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 25578,
                        "end": 26084,
                        "strand": -1,
                        "locus_tag": "ctg1_25",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_25</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_25</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,578 - 26,084,\n (total: 507 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF03061.22 (Thioesterase superfamily): [50:102](score: 27.3, e-value: 3.5e-06)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR00369 (unchar_dom_1: uncharacterized domain 1): [21:102](score: 42.2, e-value: 1.7e-11)<br>\n \n <br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTPPPELDLAAARRLLDAQPFSRLLGARLTDFGDGGATLEIDIREDLHQQNGFLHGGVLAYAADNALTFAAGAVLGPAVLTGGFSVQYLRPATGRALRARARRPRGPAPGRDPLRPAHRGAGRHGDPVRGGPGNGPAGRRQDIVNGFPPGHLGPVPPRHPEPVPVRAP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=15578&amp;to=36084\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTPPPELDLAAARRLLDAQPFSRLLGARLTDFGDGGATLEIDIREDLHQQNGFLHGGVLAYAADNALTFAAGAVLGPAVLTGGFSVQYLRPATGRALRARARRPRGPAPGRDPLRPAHRGAGRHGDPVRGGPGNGPAGRRQDIVNGFPPGHLGPVPPRHPEPVPVRAP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCCCGCCCCCCGAGCTCGACCTCGCCGCCGCACGGCGGCTGCTGGACGCCCAGCCCTTCAGCAGGCTGCTGGGCGCCCGGCTCACGGACTTCGGCGACGGCGGGGCGACCCTGGAGATCGACATCCGCGAGGACCTGCACCAGCAGAACGGCTTCCTGCACGGCGGGGTCCTCGCCTACGCGGCGGACAACGCGCTCACCTTCGCCGCCGGCGCCGTCCTCGGCCCGGCCGTGCTGACCGGCGGGTTCTCCGTCCAGTACCTCCGCCCGGCCACCGGCCGCGCCCTGCGTGCCCGCGCACGTCGTCCACGCGGGCCGGCGCCAGGCCGTGACCCGCTGCGACCTGCTCACCGTGGCGCAGGACGGCACGGAGACCCTGTGCGCGGTGGCCCAGGGAACGGTCCTGCCGGTCGCCGCCAGGACATCGTGAACGGGTTCCCGCCCGGACACCTCGGACCCGTTCCGCCGCGACACCCCGAACCCGTTCCCGTCAGGGCACCGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 26138,
                        "end": 26812,
                        "strand": -1,
                        "locus_tag": "ctg1_26",
                        "type": "regulatory",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_26</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_26</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,138 - 26,812,\n (total: 675 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1016:LuxR family DNA-binding response regulator (Score: 183.2; E-value: 6.1e-56)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00072.24 (Response regulator receiver domain): [5:118](score: 93.5, e-value: 8.6e-27)<br>\n \n  PF00196.19 (Bacterial regulatory proteins, luxR family): [157:212](score: 50.6, e-value: 1e-13)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00072.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system<br>\n  \n   PF00196.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of transcription, DNA-templated<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTAIRVLLVDDDPLVRAGLSFMLGGAGDIEIVGEAADGGEVGALVDRTRPDVVLMDIRMPSVDGLTATESLRTREDAPQVVVLTTFHADDQVLRALRAGAAGFVLKDTPPTEIVAAVRRVAAGDPVLSPAVTRQLMAHAAGTAGGTRRARARERVTGLNDREREVAVAVGRGLANAEIAAELYMSVATVKTHVSRILAKLGLNNRVQIALLAHDAGLLEETGSS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=16138&amp;to=36812\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_26_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTAIRVLLVDDDPLVRAGLSFMLGGAGDIEIVGEAADGGEVGALVDRTRPDVVLMDIRMPSVDGLTATESLRTREDAPQVVVLTTFHADDQVLRALRAGAAGFVLKDTPPTEIVAAVRRVAAGDPVLSPAVTRQLMAHAAGTAGGTRRARARERVTGLNDREREVAVAVGRGLANAEIAAELYMSVATVKTHVSRILAKLGLNNRVQIALLAHDAGLLEETGSS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACTGCGATCCGCGTGCTTCTCGTCGACGACGACCCGCTGGTGCGGGCCGGGTTGTCCTTCATGCTGGGCGGGGCCGGCGACATCGAGATCGTCGGCGAGGCCGCCGACGGCGGCGAGGTGGGGGCGCTCGTCGACCGCACCCGCCCGGACGTCGTCCTCATGGACATCCGGATGCCGTCCGTCGACGGGCTCACCGCGACCGAGTCGCTGCGGACCCGCGAGGACGCCCCCCAGGTCGTGGTGCTGACCACCTTCCACGCCGACGACCAGGTGCTGCGGGCCCTGCGCGCGGGCGCCGCCGGGTTCGTCCTCAAGGACACCCCGCCCACCGAGATCGTCGCCGCGGTACGGCGCGTCGCGGCCGGGGACCCGGTGCTGTCGCCCGCGGTCACCCGGCAGCTGATGGCCCACGCGGCCGGCACCGCCGGCGGCACGCGGCGGGCCCGGGCCCGGGAGCGCGTCACCGGGCTCAACGACCGCGAGCGCGAGGTCGCCGTCGCGGTCGGCCGCGGCCTGGCCAACGCGGAGATCGCCGCCGAGCTGTACATGAGCGTGGCCACCGTCAAGACGCACGTCTCCCGCATCCTGGCCAAGCTCGGCCTGAACAACCGCGTGCAGATCGCCCTGCTCGCCCATGACGCGGGGCTGCTGGAGGAGACCGGGAGCTCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 26871,
                        "end": 28121,
                        "strand": -1,
                        "locus_tag": "ctg1_27",
                        "type": "regulatory",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_27</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_27</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,871 - 28,121,\n (total: 1251 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1048:sensor histidine kinase (Score: 244.4; E-value: 3.7e-74)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF07730.13 (Histidine kinase): [214:278](score: 53.5, e-value: 2.6e-14)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF07730.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000155' target='_blank'>GO:0000155</a>: phosphorelay sensor kinase activity<br>\n  \n   PF07730.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046983' target='_blank'>GO:0046983</a>: protein dimerization activity<br>\n  \n   PF07730.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system<br>\n  \n   PF07730.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016021' target='_blank'>GO:0016021</a>: integral component of membrane<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTDDKAARTAPVFAGPRWFFPSALIHDLDPDAARSGRGPRRTARDWAVDFSCFLLAVLIGLLGAETLDNTPDLPRFVSVADQVLGALSCAAVWLRRRWPFALAAVMVPVSFVSETSGGVAVIALFTLAVHRPFRYVAWVAGVQLALVPLYFWWRPDPDLPYAAAVVLLVVLTVAVVGWGMFVRSKRQLMLSLRDRARRAETEARLRAEQAQRLAREAIAREMHDVLAHRLTLLSVHAGALEFRPDAPREEVARAAGVIRESAHEALQDLREIIGVLRAGESEDGGRPQPTLAALDSLVAESRQAGMKVTLEQRVTDPAGVPASVGRTAYRIAQEGLTNARKHAPGTEVTVSVAGGPGEDLAVTVRNPAPEGDVPAVPGAGQGLIGLTERATLAGGTLEHGPAPDGGFEVRARLPWR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=16871&amp;to=38121\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_27_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTDDKAARTAPVFAGPRWFFPSALIHDLDPDAARSGRGPRRTARDWAVDFSCFLLAVLIGLLGAETLDNTPDLPRFVSVADQVLGALSCAAVWLRRRWPFALAAVMVPVSFVSETSGGVAVIALFTLAVHRPFRYVAWVAGVQLALVPLYFWWRPDPDLPYAAAVVLLVVLTVAVVGWGMFVRSKRQLMLSLRDRARRAETEARLRAEQAQRLAREAIAREMHDVLAHRLTLLSVHAGALEFRPDAPREEVARAAGVIRESAHEALQDLREIIGVLRAGESEDGGRPQPTLAALDSLVAESRQAGMKVTLEQRVTDPAGVPASVGRTAYRIAQEGLTNARKHAPGTEVTVSVAGGPGEDLAVTVRNPAPEGDVPAVPGAGQGLIGLTERATLAGGTLEHGPAPDGGFEVRARLPWR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACTGATGACAAGGCGGCGCGGACCGCCCCGGTGTTCGCGGGGCCCAGGTGGTTCTTCCCGTCCGCCCTCATCCACGACCTCGACCCGGACGCCGCCCGCTCGGGGCGCGGGCCCCGGCGCACCGCCCGCGACTGGGCCGTCGACTTCTCCTGCTTCCTGCTCGCCGTGCTGATCGGGCTGCTCGGCGCGGAGACGCTCGACAACACCCCCGACCTTCCCCGGTTCGTGAGCGTGGCCGACCAGGTGCTGGGCGCGCTGTCCTGCGCCGCGGTCTGGCTGCGCCGGCGGTGGCCGTTCGCCCTGGCCGCCGTCATGGTGCCGGTCAGCTTCGTCTCGGAGACCTCCGGCGGCGTGGCGGTCATCGCCCTGTTCACGCTCGCCGTGCACCGGCCCTTCCGGTACGTGGCCTGGGTGGCAGGCGTCCAGCTGGCGCTCGTACCGCTGTACTTCTGGTGGCGTCCCGACCCGGACCTGCCGTATGCCGCCGCGGTCGTCCTGCTCGTCGTGCTGACGGTCGCCGTCGTCGGCTGGGGCATGTTCGTCCGCTCCAAGCGGCAGCTCATGCTGAGCCTCAGGGACCGCGCCCGGCGGGCCGAGACGGAGGCGCGGCTGCGGGCCGAGCAGGCGCAGCGGCTGGCCCGCGAGGCCATCGCGCGCGAGATGCACGACGTGCTGGCGCACCGGCTGACGCTGCTCAGTGTGCACGCGGGCGCCCTGGAGTTCCGGCCCGACGCCCCGCGCGAGGAGGTCGCGCGGGCGGCCGGCGTGATCCGGGAAAGCGCCCACGAGGCGCTGCAGGACCTGAGGGAGATCATCGGGGTGCTGCGGGCCGGTGAGAGCGAGGACGGCGGCCGGCCGCAGCCGACGCTCGCGGCGCTCGACTCCCTCGTCGCCGAGTCCCGGCAGGCGGGCATGAAGGTCACCCTGGAGCAGCGGGTCACCGACCCGGCCGGCGTCCCCGCGTCCGTCGGCCGCACCGCCTACCGGATCGCCCAGGAGGGCCTGACCAACGCCCGCAAGCACGCGCCCGGCACGGAGGTCACCGTGTCGGTCGCCGGCGGGCCGGGGGAGGACCTCGCGGTGACCGTGCGCAACCCCGCCCCGGAGGGGGACGTACCGGCCGTGCCGGGTGCCGGGCAGGGACTGATCGGGCTCACCGAGCGGGCCACCCTGGCCGGCGGCACGCTGGAGCACGGCCCCGCCCCCGACGGCGGCTTCGAGGTACGGGCACGGCTGCCATGGCGATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 28301,
                        "end": 28504,
                        "strand": 1,
                        "locus_tag": "ctg1_28",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_28</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_28</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,301 - 28,504,\n (total: 204 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRKLLEALGFVAVLQGAAGLVTEFADRDWGLVRRTGFFDGYEIYASVALLVLGIALFAVAESRKPGG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=18301&amp;to=38504\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRKLLEALGFVAVLQGAAGLVTEFADRDWGLVRRTGFFDGYEIYASVALLVLGIALFAVAESRKPGG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGGAAACTGCTGGAGGCGCTGGGCTTCGTGGCCGTGCTGCAGGGTGCGGCCGGCCTGGTGACGGAGTTCGCCGACCGGGACTGGGGCCTGGTGCGGCGGACCGGGTTCTTCGACGGCTACGAGATCTACGCGAGCGTCGCCCTGCTGGTGCTGGGGATCGCCCTGTTCGCCGTCGCGGAGAGCCGGAAGCCGGGCGGGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 28557,
                        "end": 28925,
                        "strand": -1,
                        "locus_tag": "ctg1_29",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_29</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_29</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,557 - 28,925,\n (total: 369 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00545.20 (ribonuclease): [36:116](score: 98.4, e-value: 3e-28)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00545.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding<br>\n  \n   PF00545.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004521' target='_blank'>GO:0004521</a>: endoribonuclease activity<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VLGGGGALAAPAAHAAPAAPVAAASVLAVGDICASDLPAEAHDTLDLIDQGGPFPFEQDGTVFQNREGILPDRSSGYYHEYTVITPGSPTRGARRIVTGEEYQEDYYTADHYASFDLVDHTC&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=18557&amp;to=38925\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_29_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VLGGGGALAAPAAHAAPAAPVAAASVLAVGDICASDLPAEAHDTLDLIDQGGPFPFEQDGTVFQNREGILPDRSSGYYHEYTVITPGSPTRGARRIVTGEEYQEDYYTADHYASFDLVDHTC\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCTGGGCGGCGGCGGAGCCCTCGCCGCGCCGGCGGCCCATGCCGCCCCCGCCGCCCCCGTGGCCGCGGCGTCCGTCCTCGCGGTCGGTGACATATGTGCGAGCGACCTGCCCGCCGAGGCGCACGACACCCTCGACCTGATCGACCAGGGCGGCCCCTTCCCCTTCGAGCAGGACGGCACCGTCTTCCAGAACCGGGAAGGCATCCTGCCGGACCGGTCGAGCGGCTACTACCACGAGTACACGGTGATCACGCCCGGTTCCCCCACCCGTGGCGCCCGCCGGATCGTGACCGGTGAGGAGTACCAGGAGGACTACTACACCGCCGACCACTACGCGTCGTTCGACCTGGTCGACCACACCTGCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 29166,
                        "end": 29918,
                        "strand": 1,
                        "locus_tag": "ctg1_30",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_30</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_30</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,166 - 29,918,\n (total: 753 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 208.9; E-value: 1.4e-63)<br>\n \n  biosynthetic-additional (t2pks) KR (Score: 177.4; E-value: 9.7e-55)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF13561.6 (Enoyl-(Acyl carrier protein) reductase): [21:247](score: 192.2, e-value: 9.5e-57)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTTNTMEKTLLGKAALVTGGGRGIGAATALRLAREGADVAVTYVNGKEAAEDVVRAVEALGRRAVALRADAGDPQEASGAVGAAVRELGRLDVLVNNAGVGLLGPLETLSPADVDRVLAVNVRGVFLASRAAAAVLPRGGRIVTVGTCMTQRVPGPGGTLYAMSKAALVGLTKALARELGERGITANIVHPGPIDTDMNPADGPYAAGQAAATALGRFGTAAEVAETIVHLAGAAYVTGAEFAVDGGHAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=19166&amp;to=39918\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_30_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTTNTMEKTLLGKAALVTGGGRGIGAATALRLAREGADVAVTYVNGKEAAEDVVRAVEALGRRAVALRADAGDPQEASGAVGAAVRELGRLDVLVNNAGVGLLGPLETLSPADVDRVLAVNVRGVFLASRAAAAVLPRGGRIVTVGTCMTQRVPGPGGTLYAMSKAALVGLTKALARELGERGITANIVHPGPIDTDMNPADGPYAAGQAAATALGRFGTAAEVAETIVHLAGAAYVTGAEFAVDGGHAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCACGAACACGATGGAGAAGACCCTGCTCGGCAAGGCGGCGCTGGTGACCGGCGGCGGCCGCGGCATCGGCGCCGCGACGGCGCTCCGGCTGGCGCGGGAGGGCGCCGACGTCGCGGTGACGTATGTGAACGGCAAGGAGGCCGCGGAGGACGTCGTACGGGCCGTCGAGGCCCTGGGGCGGCGCGCGGTGGCACTCCGGGCGGACGCCGGCGACCCGCAGGAGGCGTCGGGGGCGGTGGGCGCCGCGGTCCGTGAACTGGGGCGTCTGGACGTCCTCGTGAACAACGCGGGCGTCGGCCTGCTCGGCCCGCTGGAGACCCTCTCCCCCGCCGACGTGGACCGGGTGCTCGCGGTGAACGTCCGCGGTGTCTTCCTGGCCTCGCGCGCGGCGGCCGCCGTGCTGCCACGCGGGGGCCGGATCGTCACCGTGGGCACGTGCATGACGCAGCGGGTGCCCGGCCCCGGCGGGACGCTCTACGCCATGAGCAAGGCGGCGCTGGTGGGGCTGACCAAGGCGCTGGCACGGGAGTTGGGCGAGCGCGGGATCACGGCGAACATCGTCCACCCCGGGCCGATCGACACGGACATGAACCCGGCCGACGGCCCGTACGCGGCCGGGCAGGCGGCGGCGACCGCGCTGGGGCGCTTCGGCACGGCCGCGGAGGTGGCGGAGACGATCGTCCATCTCGCGGGCGCGGCGTACGTGACCGGGGCGGAGTTCGCGGTGGACGGGGGGCACGCGGCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 30056,
                        "end": 31171,
                        "strand": -1,
                        "locus_tag": "ctg1_31",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_31</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_31</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,056 - 31,171,\n (total: 1116 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF03561.15 (Allantoicase repeat): [41:201](score: 156.4, e-value: 4.6e-46)<br>\n \n  PF03561.15 (Allantoicase repeat): [223:352](score: 117.5, e-value: 4.4e-34)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR02961 (allantoicase: allantoicase): [32:352](score: 410.3, e-value: 9.4e-124)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF03561.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004037' target='_blank'>GO:0004037</a>: allantoicase activity<br>\n  \n   PF03561.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000256' target='_blank'>GO:0000256</a>: allantoin catabolic process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTAIETFSGDAHPYGGGDPYADYRTADFPFTHLADLADRRLGAGVIAANDEFFAQRENLLLPGRAVFDPERFGHKGKIMDGWETRRRRGTSAGHPWPTDDDHDWALIRLGTPGVVRGVVVDTAHFRGNYPQAVSVEGTAVDGSPSPEDLLADDVKWTTLVPRTAIGGHAANGFAVTAEQRFTHLRLNQHPDGGIARLRVYGEVVPDLAWLTALGTFDVVALENGGRVEDASDRFYSPAANTIRPGRSQKMDDGWETRRRRDHGHDWITYRLVAQSQIRALEIDTAYLKGNAAGWASVSVRDGEDGDWREILPRTRLQPDTNHRFVLPDPAVGTHARVDIHPDGGISRLRLFGSLTDQGEVALDARRQELGG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=20056&amp;to=41171\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTAIETFSGDAHPYGGGDPYADYRTADFPFTHLADLADRRLGAGVIAANDEFFAQRENLLLPGRAVFDPERFGHKGKIMDGWETRRRRGTSAGHPWPTDDDHDWALIRLGTPGVVRGVVVDTAHFRGNYPQAVSVEGTAVDGSPSPEDLLADDVKWTTLVPRTAIGGHAANGFAVTAEQRFTHLRLNQHPDGGIARLRVYGEVVPDLAWLTALGTFDVVALENGGRVEDASDRFYSPAANTIRPGRSQKMDDGWETRRRRDHGHDWITYRLVAQSQIRALEIDTAYLKGNAAGWASVSVRDGEDGDWREILPRTRLQPDTNHRFVLPDPAVGTHARVDIHPDGGISRLRLFGSLTDQGEVALDARRQELGG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACGGCGATCGAGACCTTCTCCGGCGACGCCCACCCCTACGGCGGGGGCGACCCGTACGCGGACTACCGCACCGCCGACTTCCCCTTCACCCACCTCGCCGACCTCGCCGACCGCCGGCTCGGCGCCGGTGTGATCGCCGCCAACGACGAGTTCTTCGCCCAGCGCGAGAACCTCCTGCTGCCCGGACGCGCCGTCTTCGACCCCGAACGCTTCGGACACAAGGGCAAGATCATGGACGGCTGGGAGACCCGCCGGCGGCGCGGCACCTCCGCCGGGCACCCCTGGCCGACGGACGACGACCACGACTGGGCGCTGATCCGCCTCGGCACGCCCGGCGTCGTCCGCGGCGTCGTCGTCGACACCGCCCACTTCCGCGGCAACTACCCGCAGGCGGTGTCGGTCGAAGGCACCGCGGTGGACGGCTCCCCGTCCCCCGAGGACCTGCTCGCGGACGACGTGAAGTGGACGACGCTGGTACCGCGCACCGCCATCGGCGGCCACGCGGCCAACGGCTTCGCCGTCACGGCCGAACAGCGCTTCACCCACCTGCGCCTCAACCAGCACCCCGACGGCGGCATCGCCCGCCTCCGCGTGTACGGCGAGGTCGTCCCGGATCTGGCGTGGCTCACCGCGCTCGGCACCTTCGACGTCGTCGCCCTGGAGAACGGCGGCCGCGTCGAGGACGCCTCCGACCGCTTCTACTCGCCCGCCGCCAACACCATCCGGCCCGGCCGTTCCCAGAAGATGGACGACGGCTGGGAGACCCGGCGCCGCCGCGACCACGGCCACGACTGGATCACGTACCGCCTGGTCGCCCAGTCGCAGATCCGCGCGCTGGAGATCGACACCGCCTACCTCAAGGGCAACGCCGCCGGCTGGGCGTCGGTGTCCGTGCGGGACGGCGAGGACGGCGACTGGCGGGAGATCCTGCCCCGCACCCGCCTCCAGCCCGACACCAACCACCGCTTCGTCCTCCCGGACCCGGCGGTGGGCACCCACGCGCGCGTGGACATCCACCCCGACGGCGGCATCTCCCGCCTGCGCCTGTTCGGCTCCCTGACCGACCAGGGCGAGGTGGCCCTGGACGCCCGCCGGCAGGAGCTCGGCGGCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 31203,
                        "end": 32543,
                        "strand": -1,
                        "locus_tag": "ctg1_32",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_32</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_32</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 31,203 - 32,543,\n (total: 1341 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01979.20 (Amidohydrolase family): [53:426](score: 90.9, e-value: 9.5e-26)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR03178 (allantoinase: allantoinase): [4:443](score: 637.2, e-value: 3.2e-192)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01979.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016787' target='_blank'>GO:0016787</a>: hydrolase activity<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VPDVELVLRSTRVVTPEGTRAASVAVADGTITAVLPYDAPVPEGARLEDLGEDVLLPGLVDTHVHVNDPGRTEWEGFWTATRAAAAGGITTLVDMPLNSLPPTTTVDHLRVKRKTAADKAHVDVGFWGGALPDNVADLRPLHEAGVFGFKAFLSPSGVDEFPHLDEEQLARSLAEIAAFDGLLIVHAEDPGHLAGAPQRGGPRYADFLASRPRLAEDTAIARLLEQARRFDARVHVLHLSSADALPLLAEARADGVRVTVETCPHYLTLTAEEVPDGASEFKCCPPIRESANQDLLWRALADGTVDCVVTDHSPSTADLKTDDFATAWGGISGLQLSLPAVWTEARRRGHTLEDVVRWMATRTARLAGLDARKGAVAPGHDADFAVLAPDESFTVDPAALQHRNRVTAYAGRTLYGVVRSTWLRGRRILADGEFTAPKGLLLTRTD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=21203&amp;to=42543\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_32_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VPDVELVLRSTRVVTPEGTRAASVAVADGTITAVLPYDAPVPEGARLEDLGEDVLLPGLVDTHVHVNDPGRTEWEGFWTATRAAAAGGITTLVDMPLNSLPPTTTVDHLRVKRKTAADKAHVDVGFWGGALPDNVADLRPLHEAGVFGFKAFLSPSGVDEFPHLDEEQLARSLAEIAAFDGLLIVHAEDPGHLAGAPQRGGPRYADFLASRPRLAEDTAIARLLEQARRFDARVHVLHLSSADALPLLAEARADGVRVTVETCPHYLTLTAEEVPDGASEFKCCPPIRESANQDLLWRALADGTVDCVVTDHSPSTADLKTDDFATAWGGISGLQLSLPAVWTEARRRGHTLEDVVRWMATRTARLAGLDARKGAVAPGHDADFAVLAPDESFTVDPAALQHRNRVTAYAGRTLYGVVRSTWLRGRRILADGEFTAPKGLLLTRTD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCCCGACGTCGAACTGGTGCTGCGCTCGACACGCGTCGTCACCCCCGAGGGAACGCGCGCCGCGTCCGTCGCCGTCGCCGACGGCACCATCACGGCCGTCCTGCCGTACGACGCCCCCGTCCCCGAGGGTGCCCGCCTGGAGGACCTCGGTGAAGACGTCCTGCTGCCCGGCCTGGTCGACACCCACGTACACGTCAACGACCCCGGCCGCACCGAGTGGGAAGGCTTCTGGACCGCCACCCGCGCGGCCGCCGCCGGCGGCATCACCACGCTGGTCGACATGCCGCTCAACTCCCTCCCGCCCACCACGACGGTGGACCACCTGCGCGTCAAACGGAAGACCGCCGCCGACAAGGCACACGTCGACGTCGGCTTCTGGGGCGGCGCCCTCCCCGACAACGTCGCGGACCTGCGCCCGCTGCACGAGGCGGGAGTCTTCGGCTTCAAGGCCTTCCTCTCACCGTCCGGCGTGGACGAGTTCCCGCACCTGGACGAGGAACAACTGGCACGCTCCCTCGCGGAGATCGCCGCCTTCGACGGCCTGCTGATCGTGCACGCCGAGGACCCCGGGCACCTCGCCGGCGCCCCGCAGCGGGGCGGCCCCCGGTACGCCGACTTCCTCGCCTCCCGCCCGCGCCTGGCCGAGGACACCGCGATCGCCCGGCTCCTGGAGCAGGCGCGGCGGTTCGACGCCCGGGTGCACGTGCTCCACCTCTCCTCCGCCGACGCGCTGCCCCTCCTCGCCGAGGCCCGGGCGGACGGCGTCCGCGTCACCGTCGAGACCTGCCCCCACTACCTCACCCTCACCGCGGAGGAAGTCCCGGACGGGGCCAGCGAGTTCAAGTGCTGCCCGCCCATCCGCGAGTCCGCCAACCAGGATTTGCTCTGGCGGGCCCTGGCGGACGGCACCGTCGACTGCGTCGTCACCGACCACTCCCCGTCCACCGCCGACCTCAAGACGGACGACTTCGCGACCGCCTGGGGCGGCATCTCCGGCCTCCAGCTCAGCCTCCCGGCCGTCTGGACCGAGGCCCGCAGGCGCGGCCACACCCTGGAGGACGTGGTCCGCTGGATGGCGACGCGCACCGCCCGGCTGGCCGGACTCGACGCCCGCAAGGGCGCCGTCGCGCCCGGCCACGACGCCGACTTCGCCGTCCTGGCCCCCGACGAGAGCTTCACCGTCGACCCGGCCGCCCTCCAGCACCGTAACCGGGTGACCGCGTACGCCGGCCGCACCCTGTACGGCGTCGTCAGGTCCACCTGGCTGCGCGGCCGGCGGATCCTGGCCGACGGAGAGTTCACCGCACCGAAGGGCCTGCTCCTCACCCGAACCGACTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 32782,
                        "end": 33588,
                        "strand": 1,
                        "locus_tag": "ctg1_33",
                        "type": "regulatory",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_33</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_33</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,782 - 33,588,\n (total: 807 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1195:IclR family transcriptional regulator (Score: 278; E-value: 9.3e-85)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF09339.10 (IclR helix-turn-helix domain): [21:73](score: 64.2, e-value: 6.8e-18)<br>\n \n  PF01614.18 (Bacterial transcriptional regulator): [134:257](score: 106.5, e-value: 8.6e-31)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF09339.10: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF09339.10: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of transcription, DNA-templated<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VPTSSASTTDSARSAASGGVQSLERAFDLLERMADAGGEVGLSELSASSGLPLPTIHRLMRTLVACGYVRQQPNRRYALGPRLIRLGESASRLLGTWARPYLARLVEETGETANMALLDGDEIVYVAQVPSKHSMRMFTEVGRRVLPHSTGVGKALLAGFPPEEVRALLGRTGMPAATEKTITTADGFLAALEEVRRQGYAIDDNEQEIGVRCLAVPVPDAPTAAAISISGPAGRVTEAATERIVPVLQQIATELSEALTTPGAGPNA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=22782&amp;to=43588\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_33_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VPTSSASTTDSARSAASGGVQSLERAFDLLERMADAGGEVGLSELSASSGLPLPTIHRLMRTLVACGYVRQQPNRRYALGPRLIRLGESASRLLGTWARPYLARLVEETGETANMALLDGDEIVYVAQVPSKHSMRMFTEVGRRVLPHSTGVGKALLAGFPPEEVRALLGRTGMPAATEKTITTADGFLAALEEVRRQGYAIDDNEQEIGVRCLAVPVPDAPTAAAISISGPAGRVTEAATERIVPVLQQIATELSEALTTPGAGPNA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCCGACGTCCAGCGCCAGCACCACCGACTCCGCCCGTTCCGCCGCCAGTGGCGGCGTGCAGTCCCTCGAGCGCGCCTTCGACCTGCTGGAACGGATGGCGGACGCGGGGGGCGAGGTCGGTCTGAGCGAGCTGTCCGCGAGCAGCGGCCTGCCCCTGCCGACGATCCACCGGCTGATGCGCACCCTCGTCGCCTGCGGGTACGTGCGCCAGCAGCCCAACCGGCGGTACGCGCTCGGCCCGCGCCTGATCCGTCTCGGCGAGTCGGCGTCCCGCCTGCTGGGCACCTGGGCCCGGCCGTACCTGGCGCGCCTGGTGGAGGAGACCGGCGAGACGGCGAACATGGCCCTGCTGGACGGGGACGAGATCGTGTACGTGGCGCAGGTGCCGTCCAAGCACTCGATGCGGATGTTCACCGAGGTGGGGCGGCGCGTGCTGCCGCACTCCACGGGCGTGGGCAAGGCCCTGCTGGCCGGCTTCCCGCCGGAGGAGGTGCGGGCCCTGCTGGGCCGCACCGGCATGCCGGCCGCGACGGAGAAGACCATCACGACGGCGGACGGCTTCCTCGCGGCGCTGGAGGAGGTCCGGCGGCAGGGGTACGCCATCGACGACAACGAGCAGGAGATCGGCGTCCGCTGCCTTGCGGTGCCGGTGCCGGACGCCCCGACGGCGGCGGCCATTTCCATCTCCGGCCCGGCGGGCCGGGTGACGGAGGCGGCGACGGAGAGGATCGTGCCGGTGCTCCAGCAGATCGCGACGGAGCTGTCGGAGGCCCTGACGACCCCGGGCGCGGGCCCGAACGCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 33727,
                        "end": 33987,
                        "strand": -1,
                        "locus_tag": "ctg1_34",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_34</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_34</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,727 - 33,987,\n (total: 261 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTELRSAVSRLRRQLAAHRAEFRDRSVAEEALATLAGLAAADDPDIPRLRRSLLLVAGAIGSVSALGQGVRELREAVDLFGPPPRP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=23727&amp;to=43987\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_34_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTELRSAVSRLRRQLAAHRAEFRDRSVAEEALATLAGLAAADDPDIPRLRRSLLLVAGAIGSVSALGQGVRELREAVDLFGPPPRP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACGGAGCTGCGCTCCGCCGTCTCCCGGTTACGCCGCCAACTCGCCGCCCATCGCGCTGAGTTCCGGGACCGGAGCGTCGCGGAGGAGGCGCTCGCGACACTGGCCGGCCTGGCCGCCGCCGACGACCCCGACATCCCGCGCCTGCGCCGCTCCCTGCTGCTGGTCGCCGGTGCGATCGGCTCGGTGAGCGCGCTCGGGCAGGGCGTACGGGAACTCCGCGAGGCGGTCGACCTCTTCGGCCCGCCCCCTCGCCCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 34236,
                        "end": 34847,
                        "strand": 1,
                        "locus_tag": "ctg1_35",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_35</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_35</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,236 - 34,847,\n (total: 612 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF12804.7 (MobA-like NTP transferase domain): [13:178](score: 122.5, e-value: 2.1e-35)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MQDLMTDDENRVVGLLLAAGGGRRLGGHPKALLTHRGRPLVEHAARVLRAGGCAGVHVVLGARADEVRARAVLPDCVLVDNPDWEQGMGSSLRAGLHSLAGTGAGAALVLLVDQPGIGPEAVARVRGRYRSPQSLVSAAYEGVRGHPVLFGAAHWAGIAATATGDRGARAYLREHADRVERVECGDIAQAYDIDTEADLTHLE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=24236&amp;to=44847\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_35_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MQDLMTDDENRVVGLLLAAGGGRRLGGHPKALLTHRGRPLVEHAARVLRAGGCAGVHVVLGARADEVRARAVLPDCVLVDNPDWEQGMGSSLRAGLHSLAGTGAGAALVLLVDQPGIGPEAVARVRGRYRSPQSLVSAAYEGVRGHPVLFGAAHWAGIAATATGDRGARAYLREHADRVERVECGDIAQAYDIDTEADLTHLE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCAGGACCTCATGACGGACGACGAGAACCGGGTGGTCGGCCTGCTGCTGGCCGCGGGCGGCGGGCGCAGGCTCGGCGGGCACCCCAAGGCACTGCTCACGCACCGGGGGCGCCCCCTCGTGGAGCACGCGGCGCGAGTGCTGCGCGCGGGTGGCTGCGCGGGCGTGCACGTGGTGCTGGGGGCGCGCGCGGACGAGGTGCGCGCCCGCGCCGTACTCCCGGACTGCGTGCTGGTGGACAACCCGGACTGGGAGCAGGGCATGGGGTCCTCCCTGCGGGCGGGGCTGCACTCCCTGGCAGGCACCGGCGCCGGGGCCGCGCTGGTCCTGCTGGTGGACCAGCCGGGAATCGGCCCGGAGGCGGTCGCCCGGGTGCGCGGCCGGTACCGGTCGCCGCAGTCGCTGGTCTCGGCGGCCTACGAGGGCGTACGCGGCCATCCGGTGCTGTTCGGCGCCGCGCACTGGGCGGGGATCGCGGCGACCGCCACCGGCGACCGAGGAGCGCGCGCCTATCTGAGGGAGCACGCGGACCGGGTCGAACGCGTCGAGTGCGGCGACATCGCGCAGGCGTACGACATCGACACCGAGGCCGATCTGACGCACCTTGAATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 34844,
                        "end": 34963,
                        "strand": 1,
                        "locus_tag": "ctg1_36",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_36</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_36</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,844 - 34,963,\n (total: 120 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSRCAPPGRARHPAPSSLDPEILDINKTLNFHHEETTIH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=24844&amp;to=44963\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSRCAPPGRARHPAPSSLDPEILDINKTLNFHHEETTIH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCCGGTGCGCCCCGCCGGGGCGGGCGAGGCACCCCGCGCCATCGTCCCTCGACCCGGAGATTCTCGACATCAACAAAACATTGAACTTCCACCATGAGGAAACTACTATCCACTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 35058,
                        "end": 36683,
                        "strand": 1,
                        "locus_tag": "ctg1_37",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_37</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_37</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 35,058 - 36,683,\n (total: 1626 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01274.22 (Malate synthase): [17:539](score: 688.1, e-value: 5.7e-207)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR01344 (malate_syn_A: malate synthase A): [22:539](score: 853.2, e-value: 1.1e-257)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01274.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004474' target='_blank'>GO:0004474</a>: malate synthase activity<br>\n  \n   PF01274.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006097' target='_blank'>GO:0006097</a>: glyoxylate cycle<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSAPAPSPLAIVDAEPLPRQEEVLTDTALAFVAELHRRFTPRRDELLARRAERRAGIARTATLDFLPETAAIRADDSWKVAPAPPALEDRRVEITGPTDRKMTINALNSGAKVWLADFEDASAPTWENVVTGQLNLIDAYTRAIDFTDPGSGKSYALRPEEELATVVTRPRGWHLDERHLTDPEGTPVPGALVDFGLYFFHNAKRLIDLGKGPYFYLPKTESHLEARLWNDVFVFAQDYLGIPRGTVRATVLIETITAAYEMEEILYELRDHASGLNAGRWDYLFSIVKNFRDGGEKFVLPDRNAVTMTAPFMRAYTELLVRTCHKRGAHAIGGMAAFIPSRRDAEVNKVAFEKVRADKDREANDGFDGSWVAHPDLVPIAMESFDQVLGDKPNQKDRLREDVDVKAADLIAVDSLDARPTYAGLVNAVQVGIRYIEAWLRGLGAVAIFNLMEDAATAEISRSQIWQWINAGVVLDNGERVTAELAREVAAEELANIRAEAGEEAFAAGNWQQAHDLLLKVALDEDYADFLTLPAYEQLKG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=25058&amp;to=46683\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_37_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSAPAPSPLAIVDAEPLPRQEEVLTDTALAFVAELHRRFTPRRDELLARRAERRAGIARTATLDFLPETAAIRADDSWKVAPAPPALEDRRVEITGPTDRKMTINALNSGAKVWLADFEDASAPTWENVVTGQLNLIDAYTRAIDFTDPGSGKSYALRPEEELATVVTRPRGWHLDERHLTDPEGTPVPGALVDFGLYFFHNAKRLIDLGKGPYFYLPKTESHLEARLWNDVFVFAQDYLGIPRGTVRATVLIETITAAYEMEEILYELRDHASGLNAGRWDYLFSIVKNFRDGGEKFVLPDRNAVTMTAPFMRAYTELLVRTCHKRGAHAIGGMAAFIPSRRDAEVNKVAFEKVRADKDREANDGFDGSWVAHPDLVPIAMESFDQVLGDKPNQKDRLREDVDVKAADLIAVDSLDARPTYAGLVNAVQVGIRYIEAWLRGLGAVAIFNLMEDAATAEISRSQIWQWINAGVVLDNGERVTAELAREVAAEELANIRAEAGEEAFAAGNWQQAHDLLLKVALDEDYADFLTLPAYEQLKG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCCGCACCAGCGCCGTCCCCGCTGGCCATCGTCGACGCCGAGCCCCTGCCGCGGCAGGAGGAGGTCCTCACCGACACGGCGCTCGCCTTCGTGGCCGAGCTGCACCGGCGGTTCACGCCCCGGCGTGACGAGCTGCTCGCCCGCCGCGCGGAGCGCCGCGCCGGGATCGCCCGCACCGCCACCCTCGACTTCCTCCCCGAGACGGCCGCGATCCGCGCCGACGACTCCTGGAAGGTGGCCCCGGCTCCCCCGGCCCTGGAGGACCGCCGCGTCGAGATCACCGGCCCGACCGACCGCAAGATGACCATCAACGCGCTCAACTCCGGCGCGAAGGTGTGGCTCGCGGACTTCGAGGACGCGTCCGCGCCCACCTGGGAGAACGTGGTCACCGGCCAGCTGAACCTGATCGACGCCTACACGCGCGCCATCGACTTCACCGACCCGGGGTCCGGCAAGTCCTACGCCCTGCGCCCCGAGGAGGAGCTGGCGACGGTCGTCACGCGGCCACGCGGCTGGCACCTGGACGAGCGGCACCTCACCGACCCGGAGGGCACCCCGGTGCCCGGCGCGCTCGTCGACTTCGGCCTGTACTTCTTCCACAACGCCAAGCGGCTGATCGACCTCGGCAAGGGCCCGTACTTCTACCTGCCGAAGACGGAGTCGCACCTCGAGGCCCGGCTGTGGAACGACGTGTTCGTGTTCGCGCAGGACTACCTGGGCATCCCCCGGGGCACCGTCCGCGCCACCGTGCTCATCGAGACGATCACGGCCGCCTACGAGATGGAGGAGATCCTCTACGAGCTGCGCGACCACGCCTCCGGGCTGAACGCCGGCCGCTGGGACTACCTCTTCTCCATCGTCAAGAACTTCCGTGACGGCGGCGAGAAGTTCGTGCTGCCCGACCGCAACGCGGTCACCATGACCGCCCCGTTCATGCGCGCGTACACCGAACTGCTCGTCCGCACCTGCCACAAGCGCGGCGCGCACGCGATCGGCGGCATGGCGGCGTTCATCCCGTCCCGCCGGGACGCCGAGGTCAACAAGGTCGCCTTCGAGAAGGTCCGCGCCGACAAGGACCGCGAGGCGAACGACGGCTTCGACGGCTCCTGGGTGGCCCACCCGGACCTGGTGCCGATCGCCATGGAGTCCTTCGACCAGGTGCTCGGCGACAAGCCGAACCAGAAGGACCGGCTGCGCGAGGACGTCGACGTCAAGGCCGCGGACCTCATCGCCGTCGACTCCCTCGACGCCAGGCCGACGTACGCGGGCCTGGTCAACGCCGTGCAGGTGGGCATCCGCTACATCGAGGCGTGGCTGCGCGGCCTGGGCGCGGTGGCCATCTTCAACCTGATGGAGGACGCGGCCACCGCCGAGATCTCCCGCTCCCAGATCTGGCAGTGGATCAACGCGGGCGTCGTCCTCGACAACGGCGAGCGGGTCACCGCCGAGCTGGCGCGCGAGGTCGCCGCGGAGGAACTGGCGAACATCCGCGCGGAGGCCGGCGAGGAGGCGTTCGCGGCGGGCAACTGGCAGCAGGCGCACGACCTGCTGCTGAAGGTCGCCCTCGACGAGGACTACGCCGACTTCCTCACCTTGCCGGCGTACGAGCAGCTCAAGGGCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 36711,
                        "end": 36989,
                        "strand": -1,
                        "locus_tag": "ctg1_38",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_38</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_38</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,711 - 36,989,\n (total: 279 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF10262.9 (Rdx family): [6:79](score: 99.0, e-value: 1.3e-28)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR02174 (CXXU_selWTH: selT/selW/selH selenoprotein domain): [7:78](score: 72.9, e-value: 4.4e-21)<br>\n \n <br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTTGARRVEIEYCTQCRWLPRAAWLAQELLTTFEQELTELALRPGTGGVFVVRVGDEVVWDRREQGFPEPTAVKRAVRDRVAPGKPLGHSDK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=26711&amp;to=46989\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTTGARRVEIEYCTQCRWLPRAAWLAQELLTTFEQELTELALRPGTGGVFVVRVGDEVVWDRREQGFPEPTAVKRAVRDRVAPGKPLGHSDK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGACCGGCGCGCGGCGCGTGGAGATCGAGTACTGCACCCAGTGCCGCTGGCTGCCCCGGGCCGCCTGGCTGGCGCAGGAGCTGCTGACCACGTTCGAGCAGGAGCTGACCGAGCTGGCGCTCAGGCCCGGCACCGGCGGTGTCTTCGTGGTCCGCGTCGGGGACGAGGTGGTCTGGGACCGGCGCGAGCAGGGCTTCCCGGAGCCGACGGCGGTGAAGCGGGCCGTACGCGACCGAGTGGCCCCGGGAAAACCCCTGGGCCACTCGGACAAGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 36986,
                        "end": 37951,
                        "strand": -1,
                        "locus_tag": "ctg1_39",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_39</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_39</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,986 - 37,951,\n (total: 966 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLILCRRPASKGRTVTDGLRSVTTTRYVTPLHSGGSVPGVFEADDLGTYVVKFTGSAQGRKALVAEVIVGELARALGLRFPELVLVDFDPAIADAEPHQEVRELHASSAGTNLGMDYLPGARDFTPEVAERFAVDRLEAGRIVWLDALTANVDRTVHSSNLLLWPTLGVAPPRLWLIDHGAALVFHHRWAAGDPEKAYDFRHHALGRYGPDVRAADAELAPRVTEELLRSVVDQVPDAWLDGEPGFDSPEAVRAAYVSHLHARARASGAWLPLDFPTADQVAAENALRAARTQQGRPDWLKQVPDLHGRPAVEQDGTVHLR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=26986&amp;to=47951\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_39_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLILCRRPASKGRTVTDGLRSVTTTRYVTPLHSGGSVPGVFEADDLGTYVVKFTGSAQGRKALVAEVIVGELARALGLRFPELVLVDFDPAIADAEPHQEVRELHASSAGTNLGMDYLPGARDFTPEVAERFAVDRLEAGRIVWLDALTANVDRTVHSSNLLLWPTLGVAPPRLWLIDHGAALVFHHRWAAGDPEKAYDFRHHALGRYGPDVRAADAELAPRVTEELLRSVVDQVPDAWLDGEPGFDSPEAVRAAYVSHLHARARASGAWLPLDFPTADQVAAENALRAARTQQGRPDWLKQVPDLHGRPAVEQDGTVHLR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTCATTTTGTGCCGGAGGCCGGCAAGTAAGGGGCGCACCGTGACCGACGGGCTGAGAAGTGTGACCACCACGCGCTACGTCACGCCTCTGCACTCCGGGGGGTCCGTCCCCGGGGTGTTCGAGGCCGACGACCTCGGGACGTACGTCGTGAAGTTCACCGGCTCCGCGCAGGGCCGCAAGGCGCTGGTCGCCGAGGTGATCGTCGGGGAACTGGCGCGGGCGCTCGGTCTGCGTTTCCCCGAGCTGGTGCTGGTGGACTTCGACCCGGCGATCGCGGACGCCGAACCCCACCAGGAGGTGCGTGAGCTGCACGCCTCCAGCGCCGGGACCAACCTCGGCATGGACTACCTGCCGGGAGCGCGCGACTTCACCCCCGAGGTGGCCGAGAGGTTCGCCGTCGACCGGCTGGAGGCCGGTCGGATCGTGTGGCTCGACGCGCTGACGGCGAACGTCGACCGCACCGTGCACAGCTCCAACCTGCTCCTGTGGCCGACCCTCGGTGTCGCCCCGCCCCGGCTGTGGCTGATCGACCACGGCGCGGCGCTCGTCTTCCACCACCGCTGGGCCGCCGGCGACCCCGAGAAGGCGTACGACTTCCGGCATCACGCCCTCGGCCGGTACGGCCCCGACGTGCGCGCCGCCGACGCGGAGCTCGCGCCCCGGGTGACGGAGGAGCTGCTGCGGTCGGTCGTGGACCAGGTGCCCGACGCCTGGCTGGACGGCGAGCCGGGGTTCGATTCGCCCGAGGCGGTCCGCGCCGCCTACGTGAGCCATCTGCACGCGCGGGCGCGGGCCTCCGGCGCGTGGCTGCCCCTCGACTTCCCCACGGCCGACCAGGTCGCCGCGGAGAACGCCCTTCGCGCGGCACGGACGCAACAGGGCCGCCCGGACTGGCTCAAGCAGGTACCCGACCTGCACGGCCGGCCGGCGGTGGAACAGGACGGGACGGTGCACCTGCGATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 38012,
                        "end": 39130,
                        "strand": -1,
                        "locus_tag": "ctg1_40",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_40</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_40</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 38,012 - 39,130,\n (total: 1119 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1217:NADH:flavin oxidoreductase/NADH oxidase (Score: 334.5; E-value: 1.1e-101)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00724.20 (NADH:flavin oxidoreductase / NADH oxidase family): [14:357](score: 201.5, e-value: 2.1e-59)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00724.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0010181' target='_blank'>GO:0010181</a>: FMN binding<br>\n  \n   PF00724.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n   PF00724.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055114' target='_blank'>GO:0055114</a>: oxidation-reduction process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSAHPLDRVRDILARPFSVGGLNLPNRVVMAPMTREFSPGGVPGEDVARYYARRAAGGVGLLVTEGSYIDHASAGNSARVPHFYGDKALAGWSAVAEAVHREGGRIMPQLWHVGMDRATGNPPVPDAPRIGPSGIALDGSHSGREMTQADIDNVVAAYASAAASAEALGFDGVEIHGGHGYLVDQFLWAHTNRRTDGYGGDVARRTRFAAEIVAACRAAVSDDFPISFRLSQWKVNHYGARIAETPQELETVLGLLAEAGADVFHCSTRRFHLPEFEGSDLNLAGWAKKLSGKPAVSVGSVGMSNEFLDVFQGEQAAVTDIGNLLDRMERDEFDLIAVGRALLGDPEWLTKILSGRTGELTPFHVSRIRTLH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=28012&amp;to=49130\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_40_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSAHPLDRVRDILARPFSVGGLNLPNRVVMAPMTREFSPGGVPGEDVARYYARRAAGGVGLLVTEGSYIDHASAGNSARVPHFYGDKALAGWSAVAEAVHREGGRIMPQLWHVGMDRATGNPPVPDAPRIGPSGIALDGSHSGREMTQADIDNVVAAYASAAASAEALGFDGVEIHGGHGYLVDQFLWAHTNRRTDGYGGDVARRTRFAAEIVAACRAAVSDDFPISFRLSQWKVNHYGARIAETPQELETVLGLLAEAGADVFHCSTRRFHLPEFEGSDLNLAGWAKKLSGKPAVSVGSVGMSNEFLDVFQGEQAAVTDIGNLLDRMERDEFDLIAVGRALLGDPEWLTKILSGRTGELTPFHVSRIRTLH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCAGCACACCCCCTGGACCGCGTCCGGGACATCCTGGCCCGCCCGTTCTCCGTCGGCGGCCTCAACCTGCCCAACCGGGTCGTGATGGCGCCCATGACCCGGGAGTTCTCCCCGGGCGGGGTCCCCGGCGAGGACGTGGCGCGCTACTACGCCAGGCGGGCGGCGGGCGGCGTCGGTCTGCTCGTCACCGAGGGCAGCTACATCGACCACGCCTCGGCCGGCAACAGCGCCCGGGTGCCGCACTTCTACGGTGACAAGGCGCTGGCCGGGTGGTCCGCCGTGGCCGAGGCGGTCCACCGGGAGGGCGGCAGGATCATGCCCCAGCTGTGGCACGTCGGCATGGACCGCGCCACGGGCAATCCGCCCGTGCCGGACGCCCCGAGGATCGGTCCCTCCGGCATCGCCCTGGACGGTTCGCACTCGGGCCGGGAGATGACCCAGGCCGACATCGACAACGTGGTGGCGGCCTACGCGTCCGCCGCCGCGTCGGCCGAGGCCCTCGGGTTCGACGGCGTGGAGATCCACGGCGGCCACGGCTACCTGGTCGACCAGTTCCTGTGGGCCCACACCAACCGGCGCACCGACGGCTACGGCGGTGACGTCGCCCGGCGCACCCGGTTCGCCGCGGAGATCGTGGCGGCCTGCCGTGCGGCCGTGTCCGACGACTTCCCGATCTCGTTCCGGCTGTCCCAGTGGAAGGTGAACCACTACGGGGCGCGGATCGCCGAGACCCCGCAGGAGCTGGAGACCGTGCTCGGGCTGCTGGCCGAGGCGGGTGCCGACGTCTTCCACTGCTCCACCCGGCGCTTCCACCTGCCGGAGTTCGAGGGTTCGGACCTCAACCTCGCGGGCTGGGCGAAGAAGCTCTCCGGGAAGCCCGCCGTCAGCGTGGGCTCGGTGGGCATGAGCAACGAGTTCCTCGACGTGTTCCAGGGCGAGCAGGCGGCCGTCACGGACATCGGAAACCTGCTCGACCGCATGGAGCGCGACGAGTTCGACCTGATCGCGGTGGGCCGTGCCCTCCTCGGCGACCCGGAGTGGCTGACCAAGATCCTCTCGGGCCGCACCGGCGAGTTGACCCCCTTCCACGTGAGCCGGATCCGCACCCTCCACTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 39310,
                        "end": 40878,
                        "strand": -1,
                        "locus_tag": "ctg1_41",
                        "type": "transport",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_41</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_41</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 39,310 - 40,878,\n (total: 1569 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1005:Drug resistance transporter, EmrB/QacA (Score: 384.5; E-value: 8.7e-117)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF07690.16 (Major Facilitator Superfamily): [24:417](score: 158.9, e-value: 1.5e-46)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR00711 (efflux_EmrB: drug resistance MFS transporter, drug:H+ antiporter-2 (14 Spanner) (DHA2) family): [21:430](score: 246.6, e-value: 1.1e-73)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF07690.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTDRPTAAPTAPDRAGLPRLGVFGLMLGIFLATLDGQIVSTALPTIVGDLGGLELFSWSVTAYLLTMAASTPLWGKLGDLYGRKGAYTNSVVLFLIGTVLCGLARNMEQLIAFRAVQGLGAGGLMVGALSVIGVLVPPEGRGRIQSMVGVMMPVAFVGGPLLGGLVTEHLDWRWAFYVNVPVGLVALLAVAKGVRLPAQRVTGHVDYAGAALLTSGVLALTLLAGWAGTTYAWLSWQITALAALVAVSLAWFVRVERRAAEPITPPRLFARREFTLAQVLSLLVGAILISVVNYLPQYMQFVQGASPTASGMLILPLMLGMLSAQLTTGRLMDRGGLDRIVPLTGASVTVAGALLLLLLGSATPVAAASALTLVVGIGVGMLMQSTLLTTMNNADPRDMGAATGTVTLVRTIGGSLGVAVLGAVHSSRTSDVLAGRLGEGTEQRLTVGGELTPAALEGMPRAVRDAVAQAVSSGLHGVVTGAALLAVCAFAAAWFVRAAPDAPRPDSPPAAEKNALRPSPAD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=29310&amp;to=50878\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_41_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%0AMTDRPTAAPTAPDRAGLPRLGVFGLMLGIFLATLDGQIVSTALPTIVGDLGGLELFSWSVTAYLLTMAASTPLWGKLGDLYGRKGAYTNSVVLFLIGTVLCGLARNMEQLIAFRAVQGLGAGGLMVGALSVIGVLVPPEGRGRIQSMVGVMMPVAFVGGPLLGGLVTEHLDWRWAFYVNVPVGLVALLAVAKGVRLPAQRVTGHVDYAGAALLTSGVLALTLLAGWAGTTYAWLSWQITALAALVAVSLAWFVRVERRAAEPITPPRLFARREFTLAQVLSLLVGAILISVVNYLPQYMQFVQGASPTASGMLILPLMLGMLSAQLTTGRLMDRGGLDRIVPLTGASVTVAGALLLLLLGSATPVAAASALTLVVGIGVGMLMQSTLLTTMNNADPRDMGAATGTVTLVRTIGGSLGVAVLGAVHSSRTSDVLAGRLGEGTEQRLTVGGELTPAALEGMPRAVRDAVAQAVSSGLHGVVTGAALLAVCAFAAAWFVRAAPDAPRPDSPPAAEKNALRPSPAD\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTDRPTAAPTAPDRAGLPRLGVFGLMLGIFLATLDGQIVSTALPTIVGDLGGLELFSWSVTAYLLTMAASTPLWGKLGDLYGRKGAYTNSVVLFLIGTVLCGLARNMEQLIAFRAVQGLGAGGLMVGALSVIGVLVPPEGRGRIQSMVGVMMPVAFVGGPLLGGLVTEHLDWRWAFYVNVPVGLVALLAVAKGVRLPAQRVTGHVDYAGAALLTSGVLALTLLAGWAGTTYAWLSWQITALAALVAVSLAWFVRVERRAAEPITPPRLFARREFTLAQVLSLLVGAILISVVNYLPQYMQFVQGASPTASGMLILPLMLGMLSAQLTTGRLMDRGGLDRIVPLTGASVTVAGALLLLLLGSATPVAAASALTLVVGIGVGMLMQSTLLTTMNNADPRDMGAATGTVTLVRTIGGSLGVAVLGAVHSSRTSDVLAGRLGEGTEQRLTVGGELTPAALEGMPRAVRDAVAQAVSSGLHGVVTGAALLAVCAFAAAWFVRAAPDAPRPDSPPAAEKNALRPSPAD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGGACCGTCCGACCGCAGCACCCACCGCACCCGACCGCGCCGGCCTGCCCCGACTCGGCGTCTTCGGTCTGATGCTGGGCATCTTCCTGGCGACCCTCGACGGGCAGATCGTCAGCACGGCACTGCCCACCATCGTGGGCGACCTCGGCGGACTCGAACTCTTCTCGTGGTCGGTGACGGCCTACCTGCTCACCATGGCGGCCTCCACCCCGTTGTGGGGCAAACTCGGTGACCTGTACGGCCGCAAGGGCGCCTACACCAACTCCGTGGTGCTCTTCCTGATCGGCACGGTGCTGTGCGGCCTGGCGCGGAACATGGAACAGCTCATCGCCTTCCGGGCCGTGCAAGGCCTCGGGGCCGGCGGGCTGATGGTGGGCGCGCTCTCGGTGATCGGCGTCCTGGTGCCCCCGGAGGGACGCGGCCGCATCCAGTCGATGGTGGGCGTCATGATGCCCGTCGCCTTCGTCGGCGGCCCCCTGCTCGGCGGACTCGTCACCGAGCACCTGGACTGGCGCTGGGCGTTCTACGTCAACGTGCCCGTGGGTCTCGTCGCCCTGCTGGCCGTCGCCAAAGGCGTACGGCTGCCCGCACAGCGTGTCACGGGACACGTCGACTACGCCGGGGCCGCTCTTCTCACCAGCGGCGTCCTCGCCCTCACCCTGCTCGCCGGGTGGGCCGGCACCACGTACGCATGGCTGTCCTGGCAGATCACCGCACTTGCCGCCCTGGTCGCGGTGAGCCTGGCCTGGTTCGTCCGGGTGGAGCGGCGCGCCGCCGAGCCGATCACGCCACCCAGGCTGTTCGCCCGGCGGGAGTTCACCCTGGCGCAGGTGCTCAGTCTCCTGGTCGGCGCGATCCTCATCTCCGTCGTCAACTACCTTCCGCAGTACATGCAGTTCGTCCAGGGCGCGTCACCCACCGCCAGCGGCATGCTGATCCTGCCGCTGATGCTCGGCATGCTGTCGGCCCAACTGACCACCGGGCGGCTCATGGACCGCGGCGGCCTGGACCGAATCGTGCCGCTCACCGGCGCCTCCGTCACCGTCGCGGGCGCGCTGCTGTTGCTCCTGCTGGGCAGCGCCACCCCCGTCGCCGCGGCCTCGGCGCTCACCCTCGTGGTCGGCATCGGCGTCGGGATGCTGATGCAGAGCACCCTGCTCACCACCATGAACAACGCCGACCCCCGTGACATGGGGGCCGCCACCGGCACCGTCACGCTCGTGCGCACCATCGGCGGCTCCCTCGGCGTCGCCGTGCTCGGCGCCGTGCACAGCAGCCGCACGTCCGACGTCCTCGCCGGGAGGCTCGGTGAAGGAACGGAACAACGACTGACTGTCGGCGGCGAGTTGACACCCGCCGCGCTGGAGGGCATGCCCCGGGCGGTGCGTGACGCCGTCGCGCAGGCGGTCAGCAGCGGGCTGCACGGCGTCGTGACCGGCGCGGCTCTCCTGGCGGTGTGCGCGTTCGCCGCGGCGTGGTTCGTCCGCGCGGCACCGGACGCCCCACGGCCGGACAGCCCGCCGGCCGCCGAGAAGAACGCGCTGCGCCCCTCACCGGCGGACTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 40907,
                        "end": 41506,
                        "strand": -1,
                        "locus_tag": "ctg1_42",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_42</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_42</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 40,907 - 41,506,\n (total: 600 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF03358.15 (NADPH-dependent FMN reductase): [9:155](score: 125.8, e-value: 1.2e-36)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF03358.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MAGTSDRPLRTAVIIGSTRDGRFGPVVTDWITGHMSERECMTVDVIDLVATPLPTVFPAFGQPPSDEVVVQLGEVTPRLAAADAFVIVTPEYNHSFPAALKNAIDWHNEQWHAKPVGFVSYGGLSGGLRAVEQLRVVLAEVHAVTIRNTVSFHNYGEVFGSDGKPTDPGCDVAAKAMLDQLTWWGHAVREAKAVRPYAV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=30907&amp;to=51506\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_42_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MAGTSDRPLRTAVIIGSTRDGRFGPVVTDWITGHMSERECMTVDVIDLVATPLPTVFPAFGQPPSDEVVVQLGEVTPRLAAADAFVIVTPEYNHSFPAALKNAIDWHNEQWHAKPVGFVSYGGLSGGLRAVEQLRVVLAEVHAVTIRNTVSFHNYGEVFGSDGKPTDPGCDVAAKAMLDQLTWWGHAVREAKAVRPYAV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCTGGCACCAGTGACCGTCCCCTGCGGACCGCGGTGATCATCGGCAGTACCCGGGACGGCCGGTTCGGCCCCGTCGTCACGGACTGGATCACGGGGCACATGTCCGAGCGGGAGTGCATGACGGTCGACGTGATCGACCTCGTCGCCACGCCGCTCCCCACCGTCTTCCCCGCCTTCGGCCAACCGCCCTCCGACGAGGTGGTGGTGCAGCTCGGCGAGGTGACACCGCGGCTGGCCGCGGCCGACGCCTTCGTGATCGTCACCCCGGAGTACAACCACAGCTTCCCGGCCGCGCTGAAGAACGCCATCGACTGGCACAACGAACAGTGGCACGCCAAGCCGGTCGGATTCGTCTCCTACGGTGGTCTGTCCGGAGGGCTGCGCGCCGTCGAACAGCTCCGCGTCGTCCTGGCCGAAGTGCACGCCGTGACGATCCGCAACACGGTCAGCTTCCACAACTACGGCGAGGTCTTCGGGAGCGACGGGAAGCCGACGGACCCCGGCTGTGACGTCGCCGCCAAGGCGATGCTCGACCAGCTCACCTGGTGGGGCCACGCGGTGCGCGAGGCCAAGGCCGTCAGGCCCTACGCCGTCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 41637,
                        "end": 42374,
                        "strand": 1,
                        "locus_tag": "ctg1_43",
                        "type": "regulatory",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_43</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_43</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 41,637 - 42,374,\n (total: 738 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1239:TetR family transcriptional regulator (Score: 207.1; E-value: 4.9e-63)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00440.23 (Bacterial regulatory proteins, tetR family): [38:82](score: 32.5, e-value: 5.5e-08)<br>\n \n  PF02909.17 (Tetracyclin repressor-like, C-terminal domain): [93:242](score: 67.4, e-value: 1.2e-18)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00440.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF02909.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0045892' target='_blank'>GO:0045892</a>: negative regulation of transcription, DNA-templated<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPSQERQTQAHDKDHVSVWERLERPAPAPRTTLTPRRIARAAVTLADAEGLDAVTMRRLATELGVAPMAAYRYVTGKDELIELMVDFVYAEMELPQDTDSWRTTMHTLAQRIRDVLLRHSWVTRATWCAPTPNQLAVPEAALAALDGLGLDADTAMVVYSTVTSYVHGAVNAEVGVTQLLRVHGWSSREEARSGLASQMAWLLSTGRFPMYERYIGEAGRKDDLEWQFETGLECVLDGISERLKI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=31637&amp;to=52374\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_43_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPSQERQTQAHDKDHVSVWERLERPAPAPRTTLTPRRIARAAVTLADAEGLDAVTMRRLATELGVAPMAAYRYVTGKDELIELMVDFVYAEMELPQDTDSWRTTMHTLAQRIRDVLLRHSWVTRATWCAPTPNQLAVPEAALAALDGLGLDADTAMVVYSTVTSYVHGAVNAEVGVTQLLRVHGWSSREEARSGLASQMAWLLSTGRFPMYERYIGEAGRKDDLEWQFETGLECVLDGISERLKI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCCTCCCAGGAGCGACAGACACAGGCCCACGACAAGGACCACGTCTCCGTGTGGGAGCGCCTGGAACGGCCGGCACCCGCGCCCCGCACCACGCTCACGCCCCGGCGCATCGCCAGGGCAGCGGTGACCCTGGCCGACGCGGAGGGCCTGGACGCGGTCACGATGCGGCGCCTGGCCACCGAACTGGGCGTCGCGCCCATGGCCGCGTACCGCTATGTGACCGGCAAGGACGAGCTCATCGAGCTCATGGTCGACTTCGTCTACGCGGAGATGGAGCTGCCGCAGGACACCGACAGCTGGCGCACGACCATGCACACGCTCGCCCAGCGCATCAGGGACGTCCTGCTCCGGCACTCCTGGGTCACCCGCGCCACCTGGTGCGCCCCGACCCCCAACCAGCTGGCCGTGCCGGAGGCCGCCCTGGCCGCACTCGACGGCCTCGGGCTGGACGCGGACACGGCGATGGTGGTCTACAGCACCGTCACCTCGTACGTGCACGGCGCGGTCAACGCGGAGGTCGGCGTGACCCAGCTGCTGCGCGTGCACGGGTGGTCCAGCCGGGAGGAGGCCCGGTCGGGACTCGCCTCGCAGATGGCCTGGCTGCTGAGCACGGGCCGTTTCCCGATGTACGAGCGCTACATCGGCGAGGCCGGACGCAAGGACGACCTGGAGTGGCAGTTCGAAACCGGCCTGGAGTGCGTTCTGGACGGCATCTCCGAGCGCCTGAAGATCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 42783,
                        "end": 43364,
                        "strand": 1,
                        "locus_tag": "ctg1_44",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_44</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_44</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 42,783 - 43,364,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPFNTEAAEVRSAIVGTLRAWASLVKEERRVGAPPDTVAHTAGFLLLHIDWLVAHPAVAALSAEVARCVRRARRVIEPTPGRRVPVGDCVVPNCDGTLTAAVRPGPGDTVEVACDAESAHRWSGQEWLRRSDRSTRQEPAVRWMTARDIARLWGLAPGSVYRRASEDRWRRQAHGGRTYYHGEDVSTSLGTHA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=32783&amp;to=53364\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_44_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPFNTEAAEVRSAIVGTLRAWASLVKEERRVGAPPDTVAHTAGFLLLHIDWLVAHPAVAALSAEVARCVRRARRVIEPTPGRRVPVGDCVVPNCDGTLTAAVRPGPGDTVEVACDAESAHRWSGQEWLRRSDRSTRQEPAVRWMTARDIARLWGLAPGSVYRRASEDRWRRQAHGGRTYYHGEDVSTSLGTHA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCCTTCAACACGGAGGCGGCGGAGGTCCGGTCGGCCATCGTCGGGACGCTGCGGGCCTGGGCCTCGCTCGTCAAGGAGGAACGGCGGGTGGGCGCTCCGCCGGACACCGTCGCGCACACCGCCGGCTTCCTTCTCCTGCACATCGACTGGCTCGTCGCCCACCCGGCCGTGGCCGCCCTTTCCGCCGAGGTCGCACGGTGTGTGCGTCGGGCGCGCCGGGTGATCGAACCCACGCCGGGACGCCGCGTCCCGGTCGGCGACTGCGTCGTTCCGAACTGTGACGGGACGCTGACGGCGGCGGTGCGGCCCGGCCCGGGCGACACGGTCGAGGTGGCCTGCGACGCCGAGTCCGCGCACCGCTGGTCCGGGCAGGAGTGGCTCCGCCGCAGCGACCGGTCCACGCGACAGGAGCCGGCCGTGCGCTGGATGACGGCACGGGACATCGCCCGGCTGTGGGGCCTCGCCCCGGGCAGCGTCTACCGCCGCGCCAGCGAGGACCGGTGGCGCCGGCAGGCTCACGGCGGGCGTACGTACTACCACGGGGAGGACGTCAGCACCTCCCTCGGAACACACGCGTAA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 43730,
                        "end": 45217,
                        "strand": 1,
                        "locus_tag": "ctg1_45",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_45</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_45</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 43,730 - 45,217,\n (total: 1488 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1050:monooxygenase FAD-binding (Score: 568.3; E-value: 2.8e-172)<br>\n \n  biosynthetic-additional (t2pks) OXY (Score: 610.9; E-value: 3.8e-186)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01494.19 (FAD binding domain): [2:334](score: 328.5, e-value: 5.1e-98)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01494.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0071949' target='_blank'>GO:0071949</a>: FAD binding<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MDASVIVAGAGPAGLMLAGELRLAGVDVIVLDRLMERTGESRGLGFTTRTMEVFDQRGLLHRFGDMGTSNAGHFGGLPVDFGVLDSVHEAAKTVPQSDTETMLEGWVRELGADIRRGHEMVTLHDHGDHVEAEVRGPGGEEIRLTAPFLVGCDGGRSTVRKAAGFDFPGTAATLEMYLADIKGVDLQPRLIGETFPGGMVMCGPLGNRGVTRIIVCERGTPPRRRTEPPSYAEVAAAWQRITGIDISHAEHEWVSAFGDATRLVTEYRRGRVLLAGDAAHIHLPAGGQGMNTGIQDAVNLGWKLAAVVRGTAPEELLDTYHAERYPVGERLMMNTKAQGLLFLTGEEVQPLRDVLAELIRYEEVSRHLAGMVSGLEIRYDVGPGPHPLLGLRMPHLELVGERRKTSSTALLGPARGVLLDLEDNAVLRERAAGWSDRVDVVTAEPHGVRPGTPLAGTAAVLVRPDGHVAWAAPGSHHDLPMALERWFGPSRIQQP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=33730&amp;to=55217\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_45_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MDASVIVAGAGPAGLMLAGELRLAGVDVIVLDRLMERTGESRGLGFTTRTMEVFDQRGLLHRFGDMGTSNAGHFGGLPVDFGVLDSVHEAAKTVPQSDTETMLEGWVRELGADIRRGHEMVTLHDHGDHVEAEVRGPGGEEIRLTAPFLVGCDGGRSTVRKAAGFDFPGTAATLEMYLADIKGVDLQPRLIGETFPGGMVMCGPLGNRGVTRIIVCERGTPPRRRTEPPSYAEVAAAWQRITGIDISHAEHEWVSAFGDATRLVTEYRRGRVLLAGDAAHIHLPAGGQGMNTGIQDAVNLGWKLAAVVRGTAPEELLDTYHAERYPVGERLMMNTKAQGLLFLTGEEVQPLRDVLAELIRYEEVSRHLAGMVSGLEIRYDVGPGPHPLLGLRMPHLELVGERRKTSSTALLGPARGVLLDLEDNAVLRERAAGWSDRVDVVTAEPHGVRPGTPLAGTAAVLVRPDGHVAWAAPGSHHDLPMALERWFGPSRIQQP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGACGCTTCCGTCATCGTCGCCGGCGCGGGTCCCGCCGGACTCATGCTCGCCGGGGAACTACGGCTCGCGGGGGTCGACGTCATCGTGCTGGACCGGCTCATGGAGCGCACCGGCGAGTCCCGGGGACTGGGCTTCACCACCCGCACCATGGAGGTCTTCGACCAGCGCGGACTGCTCCACCGCTTCGGTGACATGGGCACCAGCAACGCCGGGCACTTCGGCGGCCTGCCGGTCGACTTCGGTGTCCTCGACAGTGTCCACGAGGCCGCCAAGACCGTGCCGCAGTCGGACACCGAGACGATGCTGGAGGGCTGGGTCCGCGAACTGGGCGCCGACATCCGGCGCGGCCACGAAATGGTCACCCTGCACGACCACGGTGACCACGTCGAGGCCGAGGTACGCGGCCCCGGGGGCGAGGAGATTCGGCTCACCGCGCCCTTCCTCGTCGGGTGCGACGGCGGACGCAGCACCGTGCGCAAGGCCGCCGGGTTCGACTTCCCGGGCACCGCGGCGACGCTGGAGATGTACCTCGCGGACATCAAGGGCGTGGATCTGCAGCCGCGGCTGATCGGCGAGACCTTCCCCGGCGGCATGGTGATGTGCGGCCCGCTCGGCAACCGGGGCGTCACCCGCATCATCGTCTGTGAACGCGGCACCCCGCCCCGCCGGCGTACCGAACCCCCCTCCTACGCGGAGGTGGCGGCCGCCTGGCAGCGGATCACCGGCATCGACATCTCGCACGCCGAACACGAGTGGGTCAGCGCCTTCGGTGACGCCACCCGGCTCGTCACCGAGTACCGCCGAGGTCGCGTGCTGCTCGCCGGGGACGCCGCGCACATCCATCTGCCCGCAGGCGGCCAGGGGATGAACACCGGCATCCAGGACGCCGTGAACCTGGGCTGGAAACTGGCCGCCGTGGTCCGCGGCACCGCCCCGGAGGAACTGCTGGACACCTACCACGCCGAGCGGTACCCGGTCGGCGAGCGGCTGATGATGAACACCAAGGCCCAGGGACTGCTCTTCCTCACCGGCGAGGAGGTCCAGCCGCTGCGCGACGTCCTCGCGGAGCTCATCCGCTACGAGGAGGTCAGCCGTCACCTCGCCGGCATGGTGAGCGGCCTGGAGATCCGCTACGACGTCGGCCCTGGCCCGCACCCGCTCCTGGGTCTGCGCATGCCGCACCTGGAGCTCGTGGGCGAACGGCGCAAGACCAGCAGCACCGCACTGCTCGGGCCGGCCCGTGGCGTGCTGCTCGACCTGGAGGACAACGCCGTCCTCCGGGAGCGCGCGGCCGGCTGGTCGGACCGGGTGGACGTCGTCACGGCGGAGCCCCACGGCGTCCGGCCCGGTACTCCCCTCGCGGGCACGGCGGCGGTCCTGGTGCGGCCCGACGGACATGTGGCCTGGGCGGCACCGGGCAGCCATCACGACCTGCCCATGGCACTGGAGCGCTGGTTCGGTCCGTCCCGGATCCAGCAGCCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 45231,
                        "end": 45557,
                        "strand": 1,
                        "locus_tag": "ctg1_46",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_46</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_46</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,231 - 45,557,\n (total: 327 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1225:Polyketide synthesis cyclase (Score: 162.7; E-value: 3.9e-50)<br>\n \n  biosynthetic-additional (t2pks) CYC C4-C17/C2-C19 (Score: 202.5; E-value: 1.4e-62)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF04673.12 (Polyketide synthesis cyclase): [1:106](score: 148.1, e-value: 8.3e-44)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF04673.12: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030639' target='_blank'>GO:0030639</a>: polyketide biosynthetic process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MHSTLIVARMEPRSAEDVARLFGEFDGTEMPHRMGTRRRQLFSYRGLYFHLQDFDTEDGGERIEAAKTDPRFVGISEDLKPFITAYDPATWRSPADAMAQRFYHWTAR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=35231&amp;to=55557\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_46_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MHSTLIVARMEPRSAEDVARLFGEFDGTEMPHRMGTRRRQLFSYRGLYFHLQDFDTEDGGERIEAAKTDPRFVGISEDLKPFITAYDPATWRSPADAMAQRFYHWTAR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCACAGCACGTTGATCGTGGCCAGGATGGAACCCCGTTCCGCCGAGGACGTGGCCCGCCTCTTCGGCGAGTTCGACGGCACGGAGATGCCCCACCGGATGGGCACCCGGCGCCGGCAGCTCTTCTCGTACCGCGGCCTCTACTTCCACCTGCAGGACTTCGACACCGAGGACGGCGGCGAGCGGATCGAGGCCGCGAAGACCGACCCGCGCTTCGTGGGGATCAGCGAGGACCTCAAGCCGTTCATCACCGCCTACGACCCGGCCACCTGGCGCTCGCCCGCCGACGCGATGGCGCAGCGCTTCTACCACTGGACCGCCCGGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 45554,
                        "end": 46834,
                        "strand": 1,
                        "locus_tag": "ctg1_47",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_47</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_47</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,554 - 46,834,\n (total: 1281 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) T2PKS: t2ks<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 504.6; E-value: 3.7e-153)<br>\n \n  biosynthetic-additional (t2pks) KS (Score: 795.9; E-value: 1.8e-242)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-ctg1_47 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>PKS_KS</strong> (8..418)</dt>\n   <dd>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00109.26 (Beta-ketoacyl synthase, N-terminal domain): [6:254](score: 185.1, e-value: 1.7e-54)<br>\n \n  PF02801.22 (Beta-ketoacyl synthase, C-terminal domain): [263:378](score: 123.1, e-value: 5.8e-36)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VSGAYPRRVVITGIGVTAPGGVGVKNFWNTLSGGHTATRRITFFDPSPFRSQVAAEVDFDAELLGLSAQEIRRMDRAAQFAVVTARDAVADSGLEFTALDPHRTGVTIGSAVGATMGLDQEYRTVSDSGRLDLVDHTYAVPHLYNHLVPSSFAAEVAWAVGAEGPATVVSTGCTSGLDAVGYAADLIREGSADVMVAGATDAPISPITVACFDAIKATTPRNDDPEHASRPFDGTRNGFVLGEGSAVFVLEELGSARRRGAHVYAEIAGYATRSNAFHMTGLRPDGREMAEAIRVALDEARLAPGAIDYVNAHGSGTKQNDRHETAAFKRSLGEHAYAVPVSSIKSMVGHSLGAIGSIEIAASALAMEHGVVPPTANLHTPDPECDLDYVPLTAREWPTDAVLSVGSGFGGFQSAMVLARPDRRTA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=35554&amp;to=56834\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_47_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VSGAYPRRVVITGIGVTAPGGVGVKNFWNTLSGGHTATRRITFFDPSPFRSQVAAEVDFDAELLGLSAQEIRRMDRAAQFAVVTARDAVADSGLEFTALDPHRTGVTIGSAVGATMGLDQEYRTVSDSGRLDLVDHTYAVPHLYNHLVPSSFAAEVAWAVGAEGPATVVSTGCTSGLDAVGYAADLIREGSADVMVAGATDAPISPITVACFDAIKATTPRNDDPEHASRPFDGTRNGFVLGEGSAVFVLEELGSARRRGAHVYAEIAGYATRSNAFHMTGLRPDGREMAEAIRVALDEARLAPGAIDYVNAHGSGTKQNDRHETAAFKRSLGEHAYAVPVSSIKSMVGHSLGAIGSIEIAASALAMEHGVVPPTANLHTPDPECDLDYVPLTAREWPTDAVLSVGSGFGGFQSAMVLARPDRRTA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGAGCGGCGCGTACCCCCGGCGCGTGGTGATCACCGGCATCGGAGTCACCGCCCCCGGCGGCGTGGGCGTCAAGAACTTCTGGAACACGCTGTCCGGCGGGCACACCGCGACCCGTCGCATCACCTTCTTCGATCCCTCCCCCTTCCGCTCCCAAGTCGCCGCGGAGGTGGACTTCGACGCGGAGCTGCTGGGACTGAGCGCCCAGGAGATCCGGCGGATGGACCGCGCCGCCCAGTTCGCCGTGGTCACAGCCCGGGACGCGGTGGCCGACAGCGGCCTGGAGTTCACCGCCCTGGACCCGCACCGTACCGGCGTCACCATCGGCAGCGCGGTCGGCGCCACGATGGGACTGGACCAGGAGTACCGCACGGTCAGCGACAGCGGCCGGCTCGACCTGGTCGACCACACCTACGCGGTTCCGCACCTGTACAACCACCTGGTCCCCAGTTCCTTCGCCGCGGAGGTGGCCTGGGCGGTGGGCGCGGAGGGGCCGGCCACCGTGGTGTCCACCGGCTGCACCTCCGGGCTGGACGCCGTGGGCTACGCCGCCGACCTGATCCGGGAAGGCTCGGCCGACGTCATGGTGGCCGGCGCCACCGACGCTCCCATCTCCCCCATCACGGTGGCCTGCTTCGACGCGATCAAGGCGACGACCCCGCGCAACGACGACCCCGAGCACGCCTCACGCCCCTTCGACGGCACCCGTAACGGCTTCGTGCTGGGCGAGGGTTCGGCCGTGTTCGTCCTGGAGGAACTCGGCAGCGCCCGGCGGCGCGGCGCCCACGTCTACGCGGAGATCGCCGGTTACGCCACGCGCAGCAACGCCTTCCACATGACGGGCCTGCGCCCCGACGGCCGGGAGATGGCCGAGGCCATCCGCGTCGCGCTGGACGAGGCACGCCTGGCCCCCGGGGCCATCGACTACGTCAACGCGCACGGTTCGGGCACCAAGCAGAACGACCGCCACGAGACCGCCGCGTTCAAGCGCAGCCTCGGAGAGCACGCCTACGCCGTGCCGGTCAGCTCCATCAAGTCGATGGTGGGCCACTCGCTGGGAGCCATCGGCTCCATCGAGATCGCGGCGAGCGCGCTGGCCATGGAGCACGGCGTCGTACCGCCCACCGCCAACCTGCACACCCCGGACCCCGAGTGCGACCTGGACTACGTCCCGCTCACCGCGCGGGAGTGGCCCACCGACGCCGTGCTGTCGGTGGGCAGCGGCTTCGGCGGTTTCCAGAGCGCCATGGTGCTCGCCCGTCCCGATCGGAGGACCGCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 46831,
                        "end": 48051,
                        "strand": 1,
                        "locus_tag": "ctg1_48",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_48</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_48</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 46,831 - 48,051,\n (total: 1221 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) T2PKS: t2clf<br>\n \n  biosynthetic-additional (smcogs) SMCOG1093:Beta-ketoacyl synthase (Score: 668.7; E-value: 4e-203)<br>\n \n  biosynthetic-additional (t2pks) CLF 8|9 (Score: 717.1; E-value: 1.2e-218)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00109.26 (Beta-ketoacyl synthase, N-terminal domain): [8:247](score: 140.5, e-value: 6.7e-41)<br>\n \n  PF02801.22 (Beta-ketoacyl synthase, C-terminal domain): [254:364](score: 69.8, e-value: 1.9e-19)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSATDVRAAVTGLGVVAPNGLGTEAYWTATRKGVSGIGRVTRFVPDQYPAQLAGEIDGFDAHEHLPGRLLPQTDRMTQLALVAADWAFQDAAVRPEDLPGFEMGVITAGSSGGFEFGQRELQALWSKGSRYVSAYQSFAWFYAVNSGQISIRNGMRGPSGVVVSDQAGGLDAVAQARRQLRKGTRLVMSGAVDASICPWGWVAQMTSNRLSTGRDPARAYLPFDDAAAGHVPGEGGALLVMEDLQQARARGARIYGEIAGYGATLDPRPGSGRPPGLRKAVELALADAGAAPGDIDVVFADAAALPDLDRIEAETITAVFGARAVPVTAPKTMTGRLYSGAAPLDLAAAFLAMRDEVIPPSVGVTPSPGHDLDLVVGQERPAPVRSALVLARGHGGFNSAAVVRAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=36831&amp;to=58051\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_48_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSATDVRAAVTGLGVVAPNGLGTEAYWTATRKGVSGIGRVTRFVPDQYPAQLAGEIDGFDAHEHLPGRLLPQTDRMTQLALVAADWAFQDAAVRPEDLPGFEMGVITAGSSGGFEFGQRELQALWSKGSRYVSAYQSFAWFYAVNSGQISIRNGMRGPSGVVVSDQAGGLDAVAQARRQLRKGTRLVMSGAVDASICPWGWVAQMTSNRLSTGRDPARAYLPFDDAAAGHVPGEGGALLVMEDLQQARARGARIYGEIAGYGATLDPRPGSGRPPGLRKAVELALADAGAAPGDIDVVFADAAALPDLDRIEAETITAVFGARAVPVTAPKTMTGRLYSGAAPLDLAAAFLAMRDEVIPPSVGVTPSPGHDLDLVVGQERPAPVRSALVLARGHGGFNSAAVVRAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCGCGACGGACGTCCGGGCCGCCGTCACCGGACTGGGTGTCGTCGCGCCCAACGGGCTCGGCACGGAGGCCTACTGGACCGCCACCCGCAAGGGGGTCAGCGGCATCGGACGCGTCACGCGTTTCGTGCCCGACCAGTATCCCGCCCAACTGGCGGGCGAGATCGACGGGTTCGACGCGCACGAGCACCTGCCGGGCCGGCTGCTGCCGCAGACCGACCGGATGACCCAGCTCGCGCTGGTGGCCGCGGACTGGGCCTTCCAGGACGCCGCGGTCCGGCCGGAGGACCTTCCCGGGTTCGAGATGGGCGTCATCACCGCCGGCTCGTCCGGGGGCTTCGAGTTCGGCCAGCGGGAGCTGCAGGCCCTGTGGAGCAAGGGCAGCAGGTACGTCAGCGCCTACCAGTCCTTCGCCTGGTTCTACGCCGTCAACAGCGGTCAGATATCCATCCGCAACGGCATGCGCGGTCCCAGCGGTGTGGTCGTCAGCGACCAGGCCGGCGGGCTCGACGCGGTCGCCCAGGCACGTCGGCAGCTCCGCAAGGGCACGCGTCTGGTGATGTCGGGCGCCGTCGACGCCTCGATCTGTCCCTGGGGCTGGGTCGCCCAGATGACGAGCAACCGGCTGAGCACCGGCCGTGACCCGGCACGCGCCTACCTCCCCTTCGACGACGCGGCGGCCGGACACGTGCCCGGTGAGGGCGGCGCCCTGCTCGTCATGGAAGACCTGCAGCAGGCACGGGCCCGGGGGGCGCGGATCTACGGCGAGATCGCGGGATACGGCGCCACGCTGGACCCGCGGCCGGGCAGCGGACGGCCTCCCGGCCTGCGCAAGGCCGTCGAACTCGCCCTGGCCGACGCCGGTGCGGCGCCCGGTGACATCGACGTGGTGTTCGCCGACGCGGCCGCCCTGCCCGACCTCGACCGGATCGAGGCGGAGACGATCACGGCGGTGTTCGGCGCCCGGGCCGTGCCCGTGACGGCCCCCAAGACGATGACCGGGCGGCTCTACTCGGGGGCGGCGCCGCTGGACCTGGCCGCGGCGTTCCTCGCCATGCGGGACGAGGTGATTCCGCCGTCCGTCGGTGTCACCCCCTCCCCCGGTCACGACCTGGACCTGGTCGTCGGCCAGGAACGGCCGGCCCCGGTGCGCTCCGCCCTGGTACTCGCCCGCGGCCACGGCGGTTTCAACTCCGCGGCCGTGGTGCGCGCGGCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 48129,
                        "end": 48398,
                        "strand": 1,
                        "locus_tag": "ctg1_49",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_49</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_49</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 48,129 - 48,398,\n (total: 270 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1129:acyl carrier protein (Score: 116.5; E-value: 7.2e-36)<br>\n \n  biosynthetic-additional (t2pks) ACP (Score: 136.1; E-value: 7e-43)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-ctg1_49 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>ACP</strong> (12..81)</dt>\n   <dd>\n   \n    found active site serine: True<br>\n   \n    non-beta-branching ACP<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00550.25 (Phosphopantetheine attachment site): [22:79](score: 37.8, e-value: 1.8e-09)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPAHEFTLEDLKRILREGAGADEGVDLDGDILDTDFGLLGYESLALLETGGRIEREFGITLDDETLTDAATPRSLLEAVNALLVPAEVG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=38129&amp;to=58398\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_49_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPAHEFTLEDLKRILREGAGADEGVDLDGDILDTDFGLLGYESLALLETGGRIEREFGITLDDETLTDAATPRSLLEAVNALLVPAEVG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCCGCCCATGAGTTCACACTTGAGGACCTCAAGCGCATTCTGCGCGAGGGGGCCGGCGCGGACGAAGGCGTCGATCTCGACGGCGACATCCTCGACACCGACTTCGGACTGCTGGGCTACGAGTCCCTGGCGCTGCTGGAGACCGGCGGCAGGATCGAGCGCGAGTTCGGTATCACCCTCGACGACGAGACGCTGACCGACGCCGCGACCCCGCGGTCGCTGCTGGAGGCCGTCAACGCCCTGCTGGTGCCGGCCGAGGTCGGCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 48595,
                        "end": 49380,
                        "strand": 1,
                        "locus_tag": "ctg1_50",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_50</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_50</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 48,595 - 49,380,\n (total: 786 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 269.2; E-value: 5.6e-82)<br>\n \n  biosynthetic-additional (t2pks) KR C9 (Score: 496.0; E-value: 5.1e-152)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00106.25 (short chain dehydrogenase): [7:201](score: 221.7, e-value: 5.8e-66)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTQQNPRVALVTGATSGIGLAVTRRLARQGHRVFLCARTETGVTRTVKDLLDEGLDVDGAPCDVRSGADVKRFVEQAVDRFGTIDVLVNNAGRSGGGVTADISDDLWSDVIDTNLNSVFRMTREVLTTGGMREKDRGRIINVASTAGKQGVVLGAPYSASKHGVVGFTKALGNELAPTGITVNAVCPGYVETPMAQRVRQGYAAAYDTTEDAILEKFQAKIPLGRYSTPEEVAGLVGYLASDTAASITSQALNVCGGLGNF&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=38595&amp;to=59380\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_50_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTQQNPRVALVTGATSGIGLAVTRRLARQGHRVFLCARTETGVTRTVKDLLDEGLDVDGAPCDVRSGADVKRFVEQAVDRFGTIDVLVNNAGRSGGGVTADISDDLWSDVIDTNLNSVFRMTREVLTTGGMREKDRGRIINVASTAGKQGVVLGAPYSASKHGVVGFTKALGNELAPTGITVNAVCPGYVETPMAQRVRQGYAAAYDTTEDAILEKFQAKIPLGRYSTPEEVAGLVGYLASDTAASITSQALNVCGGLGNF\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGCAGCAGAACCCGAGGGTCGCCCTCGTCACGGGCGCGACCAGCGGCATCGGCCTGGCGGTGACCAGGCGGCTGGCCCGCCAGGGCCACCGGGTGTTCCTCTGCGCCCGCACCGAGACCGGCGTGACCCGCACGGTCAAGGACCTGCTGGACGAGGGACTGGACGTGGACGGCGCCCCGTGCGACGTACGCTCCGGTGCCGACGTCAAGCGGTTCGTGGAGCAGGCCGTCGACCGCTTCGGCACCATCGACGTACTCGTCAACAACGCGGGCAGGTCGGGCGGCGGAGTCACCGCCGACATCTCCGACGACCTCTGGTCCGACGTGATCGACACCAATCTCAACAGCGTCTTCCGCATGACGCGTGAGGTGCTCACCACGGGCGGCATGCGCGAGAAGGACCGGGGCCGGATCATCAACGTCGCCTCCACCGCGGGCAAGCAGGGCGTGGTGCTCGGCGCCCCCTACTCGGCCTCCAAGCACGGCGTGGTCGGGTTCACCAAGGCACTCGGCAACGAACTCGCGCCCACCGGCATCACCGTCAACGCCGTCTGCCCCGGTTACGTCGAGACACCGATGGCCCAGCGGGTGCGCCAGGGCTACGCGGCCGCCTACGACACCACCGAGGACGCGATCCTCGAGAAGTTCCAGGCGAAGATCCCGCTCGGCCGTTACTCGACCCCCGAGGAGGTCGCGGGCCTGGTCGGCTACCTGGCCTCCGACACCGCCGCCTCCATCACCTCCCAGGCGCTGAACGTCTGCGGCGGCCTGGGCAACTTCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 49401,
                        "end": 50336,
                        "strand": 1,
                        "locus_tag": "ctg1_51",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_51</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_51</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 49,401 - 50,336,\n (total: 936 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1128:cyclase/dehydrase (Score: 470.9; E-value: 3e-143)<br>\n \n  biosynthetic-additional (t2pks) CYC C7-C12 (Score: 504.3; E-value: 2.4e-154)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF10604.9 (Polyketide cyclase / dehydrase and lipid transport): [3:146](score: 45.8, e-value: 7.3e-12)<br>\n \n  PF10604.9 (Polyketide cyclase / dehydrase and lipid transport): [155:298](score: 30.7, e-value: 3.3e-07)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTTRQVEHEITVEAPAAAVYRLIAEVENWPRIFPPTIHVDHVERSTGEERIRIWATANGEAKNWTSRRTLDPERLRITFRQEVSTPPVAAMGGAWVIEPLSGDSARIRLLHDYRAVDDDPAGLRWIDEAVDRNSRAELAALKTNVELAHAAEDLTFSFEDTVHITGSAKDAYDFVDEAGLWAERLPHVASVRFTEDTPGLQTLEMDTRAKDGSTHTTKSYRVTFPHHRIAYKQVTLPALMTLHTGLWTFTENESGVTATSQHTVTLDTENIARVLGPDATVADARAYVQGALSANSLATLGHAKDHAEKRR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=39401&amp;to=60336\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_51_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTTRQVEHEITVEAPAAAVYRLIAEVENWPRIFPPTIHVDHVERSTGEERIRIWATANGEAKNWTSRRTLDPERLRITFRQEVSTPPVAAMGGAWVIEPLSGDSARIRLLHDYRAVDDDPAGLRWIDEAVDRNSRAELAALKTNVELAHAAEDLTFSFEDTVHITGSAKDAYDFVDEAGLWAERLPHVASVRFTEDTPGLQTLEMDTRAKDGSTHTTKSYRVTFPHHRIAYKQVTLPALMTLHTGLWTFTENESGVTATSQHTVTLDTENIARVLGPDATVADARAYVQGALSANSLATLGHAKDHAEKRR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGACCCGTCAGGTCGAGCACGAGATCACCGTCGAGGCCCCGGCCGCCGCCGTCTACCGGCTGATCGCCGAGGTGGAGAACTGGCCGCGGATCTTTCCTCCCACCATCCATGTCGACCATGTCGAGCGCTCCACGGGCGAGGAGCGCATCCGGATCTGGGCGACCGCCAACGGCGAGGCGAAGAACTGGACCTCGCGCCGCACACTGGACCCGGAGCGTCTGCGGATCACCTTCCGGCAGGAGGTGTCGACCCCACCGGTGGCCGCCATGGGCGGCGCGTGGGTCATCGAGCCGCTGTCGGGCGACTCGGCCCGGATCCGGCTGCTGCACGACTACCGGGCCGTCGACGACGACCCCGCGGGCCTGCGCTGGATCGACGAGGCCGTCGACCGCAACTCCCGCGCCGAGCTGGCCGCGCTCAAGACCAACGTGGAACTGGCCCACGCCGCCGAGGACCTCACCTTCTCCTTCGAGGACACCGTGCACATCACCGGCTCCGCCAAGGACGCCTACGACTTCGTCGACGAGGCGGGGCTGTGGGCGGAGCGGCTGCCTCACGTGGCCTCGGTCCGCTTCACGGAGGACACCCCCGGGCTGCAGACGCTGGAGATGGACACCCGGGCCAAGGACGGCTCGACGCACACCACGAAGTCGTACCGGGTGACGTTCCCGCACCACAGGATCGCCTACAAGCAGGTGACCCTGCCCGCGTTGATGACCCTGCACACCGGCCTGTGGACGTTCACGGAGAACGAGAGCGGGGTCACCGCCACCTCCCAGCACACCGTCACCCTCGACACGGAGAACATCGCCCGGGTCCTCGGCCCCGACGCGACCGTGGCCGATGCCCGCGCGTACGTCCAGGGCGCGCTGAGCGCCAACAGCCTGGCCACCCTCGGCCATGCCAAGGACCACGCCGAGAAGCGGCGCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 50338,
                        "end": 52326,
                        "strand": 1,
                        "locus_tag": "ctg1_52",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_52</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_52</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 50,338 - 52,326,\n (total: 1989 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1050:monooxygenase FAD-binding (Score: 423; E-value: 3.1e-128)<br>\n \n  biosynthetic-additional (t2pks) OXY (Score: 605.1; E-value: 2.3e-184)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01494.19 (FAD binding domain): [4:334](score: 223.9, e-value: 3.3e-66)<br>\n \n  PF13561.6 (Enoyl-(Acyl carrier protein) reductase): [420:657](score: 157.2, e-value: 5e-46)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01494.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0071949' target='_blank'>GO:0071949</a>: FAD binding<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MAAPDTDVIVVGAGPSGLVLAGDLRAGGARVTVLERLARPTTESRASVLHARTLHLLAERGLLRRFGQLPAAGPGHFGGIPLDLSEAGDSPYAGQWKAPQTHVEAVLAAWATELGAEVRRGLTVTGLTRSSDRVRVVAVAPGGRRLRLDASYVVGCDGEDSAVRRLGGFGFPGAAATKELLRADLAGIELRERRFERHPRGVANARRGPDGVTRIMVHAFDRTPGPSRTPAFDDVCAVWARVTGEDITGARPVWLNAFDNARRQADGYRDGRVFLAGDAAHVQLPVGGQALNLGLQDAMDLGPKLAAHLAGRAGDEVLDTYDTVRRPVGARVLTNIEAQAQLLFGGPEVDPLRAVFRELLDLPAARRHLAAMVSGLDGGRPAWAGTGGPGKPAAPAPTRQDIRHRRITMGKLFGKTALVSGSSRGIGRATALRLARDGALVAVHCSSNREAAEETVAAIEKDGGRGFSVLAELGVPGDVHELFLALERELKERTGDTTLDILVNNAGVMGGVDPEELTPEQFDRLFAVNAKAPYFLVQRALANLPDGGRIINISSGLTRVANPQEVAYAMTKGAVDQLTLHFAKHLGPRGITVNSVGPGITDNGSPVFDDPEAVAAMAGYSVFNRVGETRDIADVVAFLASDDSRWITGSYLDASGGTLLGG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=40338&amp;to=62326\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_52_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MAAPDTDVIVVGAGPSGLVLAGDLRAGGARVTVLERLARPTTESRASVLHARTLHLLAERGLLRRFGQLPAAGPGHFGGIPLDLSEAGDSPYAGQWKAPQTHVEAVLAAWATELGAEVRRGLTVTGLTRSSDRVRVVAVAPGGRRLRLDASYVVGCDGEDSAVRRLGGFGFPGAAATKELLRADLAGIELRERRFERHPRGVANARRGPDGVTRIMVHAFDRTPGPSRTPAFDDVCAVWARVTGEDITGARPVWLNAFDNARRQADGYRDGRVFLAGDAAHVQLPVGGQALNLGLQDAMDLGPKLAAHLAGRAGDEVLDTYDTVRRPVGARVLTNIEAQAQLLFGGPEVDPLRAVFRELLDLPAARRHLAAMVSGLDGGRPAWAGTGGPGKPAAPAPTRQDIRHRRITMGKLFGKTALVSGSSRGIGRATALRLARDGALVAVHCSSNREAAEETVAAIEKDGGRGFSVLAELGVPGDVHELFLALERELKERTGDTTLDILVNNAGVMGGVDPEELTPEQFDRLFAVNAKAPYFLVQRALANLPDGGRIINISSGLTRVANPQEVAYAMTKGAVDQLTLHFAKHLGPRGITVNSVGPGITDNGSPVFDDPEAVAAMAGYSVFNRVGETRDIADVVAFLASDDSRWITGSYLDASGGTLLGG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCGGCGCCGGACACCGATGTGATCGTCGTGGGAGCCGGGCCGTCCGGGCTCGTGCTCGCCGGGGACCTGCGGGCCGGCGGGGCGCGGGTGACCGTACTGGAACGGCTGGCGCGGCCCACCACCGAGTCCCGGGCGTCGGTCCTGCACGCACGCACCCTGCACCTGCTGGCCGAACGGGGTCTGCTGCGACGGTTCGGTCAGCTGCCCGCGGCCGGACCCGGTCACTTCGGCGGCATCCCTCTCGACCTGAGCGAGGCCGGGGACAGCCCGTACGCCGGACAGTGGAAGGCGCCTCAGACCCACGTCGAAGCCGTCCTCGCCGCATGGGCCACGGAACTCGGCGCCGAGGTGCGGCGGGGACTCACGGTGACCGGCCTGACCCGGAGCTCCGACCGGGTGCGTGTCGTCGCCGTCGCACCGGGCGGGCGGCGCCTGCGGCTGGACGCCTCCTACGTCGTCGGCTGCGACGGCGAGGACAGCGCCGTACGGCGGCTGGGCGGCTTCGGCTTCCCGGGGGCCGCGGCCACCAAGGAACTGCTGCGCGCCGACCTGGCCGGCATCGAACTGCGGGAGCGGCGTTTCGAGCGTCACCCCCGGGGCGTGGCCAACGCCCGCCGCGGGCCGGACGGCGTCACCCGCATCATGGTCCACGCCTTCGACCGGACCCCCGGACCGTCCCGTACCCCCGCCTTCGACGACGTCTGCGCGGTGTGGGCGCGCGTCACCGGCGAGGACATCACCGGCGCCCGGCCCGTCTGGCTCAACGCCTTCGACAACGCACGCCGGCAGGCGGACGGGTACCGCGACGGCCGGGTGTTCCTCGCCGGGGACGCGGCGCACGTCCAGCTGCCGGTGGGTGGCCAGGCACTCAACCTCGGTCTGCAGGACGCCATGGACCTGGGTCCGAAGCTCGCCGCTCACCTGGCCGGCCGGGCCGGTGACGAGGTGCTGGACACCTACGACACGGTCCGTCGTCCGGTGGGCGCCCGCGTCCTCACCAACATCGAGGCCCAGGCGCAGCTGTTGTTCGGCGGGCCCGAAGTGGATCCGTTGCGGGCGGTTTTCCGTGAATTGCTGGACCTCCCGGCGGCCCGCCGTCATCTGGCCGCCATGGTCAGCGGGCTCGACGGCGGCCGTCCGGCGTGGGCCGGCACCGGCGGGCCGGGGAAGCCGGCCGCCCCCGCCCCGACTCGTCAGGACATCAGGCACAGGAGGATCACCATGGGCAAGCTCTTCGGCAAGACCGCACTCGTCTCCGGCTCCAGCCGGGGCATCGGACGGGCCACGGCCCTCCGGCTGGCCCGCGACGGGGCGCTGGTCGCGGTGCACTGCTCCAGCAACCGGGAGGCGGCCGAGGAGACGGTCGCGGCCATCGAGAAGGACGGTGGCCGCGGGTTCTCCGTGCTGGCCGAACTCGGGGTGCCCGGTGATGTGCACGAGCTGTTCCTGGCCCTGGAAAGGGAGCTGAAGGAACGCACCGGAGACACCACGCTCGACATCCTGGTGAACAACGCCGGGGTGATGGGCGGGGTGGATCCCGAGGAACTGACCCCCGAGCAGTTCGACCGCCTCTTCGCCGTCAACGCGAAGGCACCGTACTTCCTGGTGCAGCGCGCCCTGGCCAACCTCCCCGACGGCGGGCGGATCATCAACATCTCCTCGGGGCTGACCCGGGTCGCGAACCCCCAGGAGGTGGCGTACGCGATGACCAAGGGCGCCGTCGACCAGCTCACCCTGCACTTCGCCAAACACCTCGGCCCGCGCGGCATCACCGTCAACAGTGTGGGCCCGGGCATCACCGACAACGGGTCACCCGTGTTCGACGACCCGGAGGCGGTGGCCGCGATGGCGGGCTACTCGGTGTTCAACCGGGTCGGTGAGACCCGCGACATCGCCGATGTGGTGGCTTTCCTGGCGAGCGACGACTCCCGCTGGATCACCGGCTCCTACCTGGACGCCAGCGGCGGCACCCTGCTCGGCGGCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 52343,
                        "end": 53581,
                        "strand": 1,
                        "locus_tag": "ctg1_53",
                        "type": "transport",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_53</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_53</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 52,343 - 53,581,\n (total: 1239 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1005:Drug resistance transporter, EmrB/QacA (Score: 133; E-value: 1.7e-40)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF07690.16 (Major Facilitator Superfamily): [34:369](score: 133.5, e-value: 8.5e-39)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF07690.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPTPFASLSTLFTSPRPDRAGAGRRALLFVLAGNMLIDALEVSVVLVALPAMGRDLGLSMYGGQWMMSGFAAGFAALLLLGPRLAARWGRRRVYLAALTVFIAASLAGGLTDEGAVLAATRVVKGMCAALTAPTGLAIIGTVFRPGPEQSRAVSVYSLFGAAGFTVGLLSSGALTELSWRWNPVFPAPFAVLLLLAGVRLVPGDTGRTSAEPLRPAMARLVRNGPFVRSALCAATLNGTYLGLLLLLTHWLHDTWGWSSWETALAFLPACVPLALALPFAGRMVARFGTGPLIAAGGCATALGCATALLTGAPGTYVTGVLPVLLCVEAGFVLSFAALNLQAVSGIPAERRSTAVPVYQTAVQLGPLLSLPAVAAAAGSGYRPALLILTALSTTGAVIACAPSRRARADTAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=42343&amp;to=63581\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_53_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%0AMPTPFASLSTLFTSPRPDRAGAGRRALLFVLAGNMLIDALEVSVVLVALPAMGRDLGLSMYGGQWMMSGFAAGFAALLLLGPRLAARWGRRRVYLAALTVFIAASLAGGLTDEGAVLAATRVVKGMCAALTAPTGLAIIGTVFRPGPEQSRAVSVYSLFGAAGFTVGLLSSGALTELSWRWNPVFPAPFAVLLLLAGVRLVPGDTGRTSAEPLRPAMARLVRNGPFVRSALCAATLNGTYLGLLLLLTHWLHDTWGWSSWETALAFLPACVPLALALPFAGRMVARFGTGPLIAAGGCATALGCATALLTGAPGTYVTGVLPVLLCVEAGFVLSFAALNLQAVSGIPAERRSTAVPVYQTAVQLGPLLSLPAVAAAAGSGYRPALLILTALSTTGAVIACAPSRRARADTAA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPTPFASLSTLFTSPRPDRAGAGRRALLFVLAGNMLIDALEVSVVLVALPAMGRDLGLSMYGGQWMMSGFAAGFAALLLLGPRLAARWGRRRVYLAALTVFIAASLAGGLTDEGAVLAATRVVKGMCAALTAPTGLAIIGTVFRPGPEQSRAVSVYSLFGAAGFTVGLLSSGALTELSWRWNPVFPAPFAVLLLLAGVRLVPGDTGRTSAEPLRPAMARLVRNGPFVRSALCAATLNGTYLGLLLLLTHWLHDTWGWSSWETALAFLPACVPLALALPFAGRMVARFGTGPLIAAGGCATALGCATALLTGAPGTYVTGVLPVLLCVEAGFVLSFAALNLQAVSGIPAERRSTAVPVYQTAVQLGPLLSLPAVAAAAGSGYRPALLILTALSTTGAVIACAPSRRARADTAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCGACGCCCTTCGCTTCGCTGTCGACGCTCTTCACCTCACCGCGCCCGGACCGCGCCGGTGCCGGGCGGCGGGCCCTTCTGTTCGTCCTCGCCGGCAACATGCTCATCGACGCCCTGGAGGTGTCCGTCGTCCTGGTCGCCCTGCCGGCCATGGGGCGGGACCTGGGGCTGTCCATGTACGGCGGACAGTGGATGATGAGCGGCTTCGCCGCGGGGTTCGCTGCCCTGCTGCTGCTCGGCCCGCGTCTGGCCGCCCGGTGGGGACGACGACGCGTGTACCTCGCCGCGCTGACGGTGTTCATCGCCGCCTCGCTGGCCGGTGGCCTGACCGACGAAGGCGCCGTGCTGGCCGCGACCAGGGTGGTGAAGGGCATGTGCGCGGCGCTGACCGCGCCCACCGGGCTGGCCATCATCGGCACCGTCTTCCGGCCGGGACCCGAGCAGAGCCGGGCGGTGTCCGTGTACTCCCTCTTCGGCGCGGCGGGATTCACCGTGGGCCTGCTCTCCTCCGGTGCGCTCACCGAGCTCAGCTGGCGCTGGAACCCCGTGTTCCCGGCGCCGTTCGCCGTCCTCCTGCTGCTGGCCGGTGTCCGGCTCGTTCCCGGGGACACCGGCCGGACGTCCGCCGAGCCGCTGCGGCCGGCCATGGCCCGGCTGGTGCGCAACGGGCCGTTCGTACGGTCGGCGCTGTGCGCGGCGACGCTGAACGGCACCTACCTCGGGCTGCTGCTGCTCCTCACCCACTGGCTGCACGACACGTGGGGGTGGAGCTCCTGGGAAACGGCGCTGGCGTTCCTGCCGGCCTGTGTGCCGCTGGCGCTCGCCCTGCCGTTCGCCGGCCGGATGGTGGCGCGTTTCGGCACCGGACCGCTGATCGCGGCCGGAGGGTGCGCGACGGCGCTGGGCTGTGCGACGGCTCTGCTGACCGGAGCGCCCGGGACCTACGTCACCGGGGTGCTGCCGGTGCTCCTGTGCGTCGAGGCCGGTTTCGTCCTGTCCTTCGCGGCCCTCAACCTGCAGGCAGTGTCGGGCATCCCGGCCGAGCGGCGGAGCACGGCGGTGCCGGTCTACCAGACGGCGGTTCAGCTCGGTCCCCTGCTGTCCCTGCCGGCGGTGGCCGCGGCGGCCGGCTCGGGCTACCGCCCGGCCCTGCTGATCCTTACAGCGCTGTCGACGACCGGAGCCGTGATCGCCTGCGCCCCGTCTCGCCGCGCCCGCGCCGACACCGCGGCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 53622,
                        "end": 54914,
                        "strand": 1,
                        "locus_tag": "ctg1_54",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_54</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_54</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 53,622 - 54,914,\n (total: 1293 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) oligosaccharide: MGT<br>\n \n  biosynthetic-additional (smcogs) SMCOG1062:glycosyltransferase, MGT family (Score: 369.1; E-value: 5.4e-112)<br>\n \n  biosynthetic-additional (t2pks) GT (Score: 456.7; E-value: 2e-139)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF06722.12 (Protein of unknown function (DUF1205)): [230:313](score: 52.4, e-value: 4.1e-14)<br>\n \n  PF00201.18 (UDP-glucoronosyl and UDP-glucosyl transferase): [305:398](score: 25.1, e-value: 7.1e-06)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR04516 (glycosyl_450act: glycosyltransferase, activator-dependent family): [0:430](score: 447.0, e-value: 1.7e-134)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00201.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016758' target='_blank'>GO:0016758</a>: transferase activity, transferring hexosyl groups<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRVLFTIFPATAHLYPVVPLAWALQSAGHEVVVASHAGVVDPGVIDNIAAAGLTAVPLGTPDELPEALGPHTGDAEPDRPSLGFDAFEPEETGSWRTTRAILTGMFRLHYPEPSEPGGRRPVLDNLVDFARDWRPDLVLWDPLMFPAPVAARVSGAAHARLLWGMDNIGVIHERTKRELADPSSDLTEHPWLGWFGPVLERHGLEFGDEMLLGQWTLDLTQSRMQAPLDQTRIPVRRVPYTGAGRLPGWLHTRPERPRVVLSLGVSRRKIFGRYSGFPMREFFASVSELDIEVVATLNSQQLDAAGTLPGNVRAVEYVPLNQVLPTASAIIHHGGGGTFSSAVAHQVPQLVMPLVMWDEMVTARYVRDMGAGLVADPDALDVAEMHKQLVRLLEDPSFPLGARRLHDEMLAAPAPKEIVPLLERLTAERR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=43622&amp;to=64914\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_54_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\"html/ctg1_54_searchgtr.html\" target=\"_new\">SEARCHGTr on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRVLFTIFPATAHLYPVVPLAWALQSAGHEVVVASHAGVVDPGVIDNIAAAGLTAVPLGTPDELPEALGPHTGDAEPDRPSLGFDAFEPEETGSWRTTRAILTGMFRLHYPEPSEPGGRRPVLDNLVDFARDWRPDLVLWDPLMFPAPVAARVSGAAHARLLWGMDNIGVIHERTKRELADPSSDLTEHPWLGWFGPVLERHGLEFGDEMLLGQWTLDLTQSRMQAPLDQTRIPVRRVPYTGAGRLPGWLHTRPERPRVVLSLGVSRRKIFGRYSGFPMREFFASVSELDIEVVATLNSQQLDAAGTLPGNVRAVEYVPLNQVLPTASAIIHHGGGGTFSSAVAHQVPQLVMPLVMWDEMVTARYVRDMGAGLVADPDALDVAEMHKQLVRLLEDPSFPLGARRLHDEMLAAPAPKEIVPLLERLTAERR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCGTGTCCTGTTCACCATCTTCCCGGCGACGGCACACCTGTATCCGGTGGTGCCGCTGGCCTGGGCGCTGCAGAGCGCCGGGCACGAGGTCGTCGTGGCGAGTCACGCGGGCGTCGTGGACCCGGGGGTGATCGACAACATCGCCGCGGCGGGGCTCACGGCCGTACCGCTGGGCACGCCGGACGAACTGCCGGAAGCTCTCGGCCCGCACACGGGCGACGCCGAGCCGGACCGGCCCTCCCTGGGATTCGACGCCTTCGAACCGGAGGAGACGGGGTCCTGGCGCACCACCCGCGCCATTCTCACCGGCATGTTCCGGTTGCACTATCCGGAGCCTTCGGAGCCGGGCGGCCGCCGGCCGGTGCTGGACAACCTGGTCGACTTCGCCCGTGACTGGCGTCCCGACCTGGTGCTGTGGGACCCGCTGATGTTCCCCGCCCCGGTCGCCGCCCGGGTCAGCGGCGCGGCGCACGCCCGGCTGCTGTGGGGCATGGACAACATCGGTGTGATCCACGAGCGCACGAAACGTGAACTGGCCGACCCCTCGTCGGACCTGACGGAACATCCGTGGCTGGGCTGGTTCGGCCCGGTTCTGGAGCGTCACGGGCTGGAGTTCGGCGACGAGATGCTGCTGGGCCAGTGGACGCTGGACCTGACCCAGTCCCGGATGCAGGCTCCGCTCGACCAGACACGCATACCGGTGCGCAGGGTCCCGTACACCGGCGCGGGCCGGCTGCCCGGCTGGCTGCACACCCGTCCCGAGCGCCCCCGAGTGGTGCTGTCCCTGGGCGTGAGCCGGCGCAAGATCTTCGGCAGGTACAGCGGCTTCCCGATGCGGGAGTTCTTCGCGTCGGTGTCGGAACTGGACATCGAGGTCGTCGCCACCCTGAACAGCCAGCAGCTCGACGCGGCGGGAACACTGCCCGGCAACGTACGCGCGGTGGAGTACGTCCCGCTCAACCAGGTCCTCCCGACCGCTTCCGCGATCATCCACCACGGCGGCGGCGGCACGTTCTCCTCCGCCGTCGCCCACCAGGTGCCGCAGCTGGTGATGCCGCTGGTCATGTGGGACGAGATGGTCACCGCCCGCTACGTACGGGACATGGGTGCGGGTCTGGTCGCCGACCCGGACGCCCTGGACGTCGCGGAGATGCACAAGCAGCTCGTACGGCTGCTGGAGGACCCGTCCTTCCCGTTGGGCGCCCGACGCCTGCACGACGAGATGCTCGCCGCGCCGGCGCCCAAGGAGATCGTTCCGCTGCTGGAGCGGCTGACCGCCGAACGCCGCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 54944,
                        "end": 56140,
                        "strand": 1,
                        "locus_tag": "ctg1_55",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_55</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_55</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 54,944 - 56,140,\n (total: 1197 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) oligosaccharide: MGT<br>\n \n  biosynthetic-additional (smcogs) SMCOG1062:glycosyltransferase, MGT family (Score: 308.1; E-value: 1.9e-93)<br>\n \n  biosynthetic-additional (t2pks) GT (Score: 426.5; E-value: 2.9e-130)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF06722.12 (Protein of unknown function (DUF1205)): [176:272](score: 43.9, e-value: 2e-11)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRVLVISTPVPTHFLPLVPLLWALRSAGHEVTVLAQPDVVGAVRACGLTAIPAGEPFEVNGMLLKGLGRDRRPLQARPRPAPELLGGYGRLWWAHAASMLSRYSDVAEGYRPDIVLADPLEYCSLIIGARLGVPVVHHRWTVDAISGPARAFVRPGARELCERLGLPGLPDPDVLLDPCPPTLRLPGGEPGTPIRYVPYSGGGEVPAWVRADDGPRAGRRRVAVSLGNTLALHGVGFTRALLRALAASPGTEILVTLPEPYRSRIGPLPDTVTAVDPLPLHLFLGTCDAMVHHGGAGTAMTATSFGLPQLVLPQLADHFPVGDRLAATGAGLSFDTAERQDDPRTVGAALDDLLSDPRYAEAARGLAAEMAAMPSPAVAAAELERRARAGTRPRKASV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=44944&amp;to=66140\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_55_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\"html/ctg1_55_searchgtr.html\" target=\"_new\">SEARCHGTr on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRVLVISTPVPTHFLPLVPLLWALRSAGHEVTVLAQPDVVGAVRACGLTAIPAGEPFEVNGMLLKGLGRDRRPLQARPRPAPELLGGYGRLWWAHAASMLSRYSDVAEGYRPDIVLADPLEYCSLIIGARLGVPVVHHRWTVDAISGPARAFVRPGARELCERLGLPGLPDPDVLLDPCPPTLRLPGGEPGTPIRYVPYSGGGEVPAWVRADDGPRAGRRRVAVSLGNTLALHGVGFTRALLRALAASPGTEILVTLPEPYRSRIGPLPDTVTAVDPLPLHLFLGTCDAMVHHGGAGTAMTATSFGLPQLVLPQLADHFPVGDRLAATGAGLSFDTAERQDDPRTVGAALDDLLSDPRYAEAARGLAAEMAAMPSPAVAAAELERRARAGTRPRKASV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCGCGTACTGGTGATCTCCACTCCCGTTCCCACTCACTTCCTTCCGCTGGTACCGCTGCTGTGGGCGCTGCGCTCGGCCGGTCACGAGGTGACCGTGCTGGCTCAGCCCGATGTGGTCGGAGCCGTGCGGGCCTGCGGTCTGACGGCGATCCCGGCGGGCGAGCCGTTCGAGGTGAACGGGATGCTGCTGAAGGGGCTGGGACGGGACCGACGTCCGCTGCAGGCCCGGCCCCGGCCGGCTCCCGAACTGCTCGGCGGATACGGCAGGTTGTGGTGGGCCCATGCGGCCTCGATGCTCAGCCGCTACAGCGACGTGGCCGAGGGGTACCGGCCGGACATCGTCCTCGCCGATCCGCTGGAGTACTGCTCGCTGATCATCGGGGCACGGCTGGGTGTGCCGGTGGTGCACCACCGGTGGACGGTGGATGCCATCTCGGGGCCCGCCCGTGCCTTCGTCCGCCCCGGCGCACGTGAGCTGTGCGAGCGGCTCGGCCTTCCTGGCCTGCCCGACCCGGACGTGCTGCTCGATCCGTGTCCGCCCACCCTGCGGCTGCCGGGCGGCGAGCCGGGCACGCCCATCCGGTACGTGCCGTACAGCGGCGGCGGTGAGGTTCCCGCCTGGGTCCGGGCGGATGACGGACCGAGGGCCGGACGGCGACGGGTGGCCGTATCGCTGGGCAACACCCTGGCCCTGCACGGCGTGGGCTTCACCCGCGCTCTGCTGCGGGCCCTCGCCGCATCGCCCGGTACCGAGATCCTCGTGACGCTGCCCGAGCCGTACCGTTCCCGGATCGGCCCGCTGCCGGACACGGTGACGGCGGTCGACCCGCTCCCCCTCCATCTGTTCCTCGGGACCTGTGACGCGATGGTCCACCACGGGGGAGCCGGCACGGCCATGACGGCGACCTCCTTCGGACTCCCCCAGTTGGTGCTCCCTCAGCTGGCGGACCACTTCCCGGTGGGCGACCGGCTCGCCGCGACCGGAGCCGGGCTGTCCTTCGACACGGCGGAGCGGCAGGACGACCCGCGGACCGTCGGCGCGGCCCTGGACGACCTGCTGTCCGACCCCCGGTACGCGGAGGCGGCCCGTGGACTGGCAGCGGAGATGGCCGCGATGCCGTCCCCCGCCGTCGCGGCCGCCGAACTGGAGCGGCGAGCCCGGGCGGGCACCCGACCGAGAAAGGCGAGTGTCTAG\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 56140,
                        "end": 56721,
                        "strand": 1,
                        "locus_tag": "ctg1_56",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_56</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_56</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 56,140 - 56,721,\n (total: 582 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) dTDP_sugar_isom<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00908.17 (dTDP-4-dehydrorhamnose 3,5-epimerase): [5:176](score: 171.8, e-value: 9.5e-51)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00908.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008830' target='_blank'>GO:0008830</a>: dTDP-4-dehydrorhamnose 3,5-epimerase activity<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VRIEELPLPGTYVITPELIPDPRGSFYEAMRGDLLEEATGVPFLPRQINYSVSRRHTLRGIHSVRIPPGQAKYVTCVRGALRDIVVDLRIGSPTFGEHRVNVLDADSGRSVYVPEGVGHGFLALTDDACICYVVSSTYVPGTQIDINPLDPDLGLPWDCPEPPLISDKDAKAPTVAEAVRAGLLPRFDKAGTP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=46140&amp;to=66721\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_56_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VRIEELPLPGTYVITPELIPDPRGSFYEAMRGDLLEEATGVPFLPRQINYSVSRRHTLRGIHSVRIPPGQAKYVTCVRGALRDIVVDLRIGSPTFGEHRVNVLDADSGRSVYVPEGVGHGFLALTDDACICYVVSSTYVPGTQIDINPLDPDLGLPWDCPEPPLISDKDAKAPTVAEAVRAGLLPRFDKAGTP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCGCATCGAGGAACTGCCCCTCCCGGGCACGTACGTGATCACACCCGAGCTGATCCCCGACCCACGGGGGTCGTTCTACGAGGCGATGCGCGGCGACCTGCTGGAAGAAGCCACCGGTGTTCCCTTCCTGCCTCGGCAGATCAACTACTCGGTCTCCCGGCGCCACACACTGCGCGGCATCCACAGCGTGCGCATCCCGCCCGGGCAGGCCAAGTACGTCACCTGCGTACGGGGCGCGCTGCGCGACATCGTCGTGGACCTGCGGATCGGCTCCCCCACCTTCGGGGAGCACCGGGTGAACGTGCTGGACGCGGACTCCGGGCGTTCGGTGTACGTGCCGGAGGGCGTGGGGCACGGGTTCCTCGCGCTGACCGACGACGCGTGCATCTGCTACGTCGTGTCCTCCACCTATGTGCCGGGCACGCAGATCGACATCAATCCGCTCGACCCGGATCTCGGGCTGCCCTGGGACTGCCCGGAGCCCCCTCTCATCTCCGACAAGGACGCCAAGGCCCCCACCGTGGCCGAGGCCGTACGGGCAGGTCTGCTGCCCCGATTCGACAAGGCAGGGACACCGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 56724,
                        "end": 57854,
                        "strand": 1,
                        "locus_tag": "ctg1_57",
                        "type": "biosynthetic",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_57</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_57</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 56,724 - 57,854,\n (total: 1131 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) oligosaccharide: MGT<br>\n \n  biosynthetic-additional (smcogs) SMCOG1062:glycosyltransferase, MGT family (Score: 267.5; E-value: 4e-81)<br>\n \n  biosynthetic-additional (t2pks) GT (Score: 404.1; E-value: 1.9e-123)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF06722.12 (Protein of unknown function (DUF1205)): [168:263](score: 63.1, e-value: 1.9e-17)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLFVAAGSPATVFALAPLATAARNAGHQVVMAANDDMVPYITSSGLPGVATTDLPIRHFITTDRAGRPEAIPSHPVEQALFTGRWFARMAASSLPRMLDLCRSWRPDLIVGGTMSYVAPLLALHLGVPHVRQTWDAIEADGIHPGADAELLPELEPFGLDRLPEPDVFVDICPPSLRPAGAAPAQPMRYVPANAQRRLETWMVTRGERRRILVTSGSRVAKESYDKNFDFLRGLTADVASWDVELIVAAPDGTADALRDGLPGARVGWVPLDLVAPTCDLLVHHAGGVSTLTGLNAGVPQLLIPKGAVLERPALRVAEHGAAITLLPGEDSADAIADSCQELLAKDTYREGAGALSREIAAMPSPASVVATLGDLA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=46724&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_57_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\"html/ctg1_57_searchgtr.html\" target=\"_new\">SEARCHGTr on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLFVAAGSPATVFALAPLATAARNAGHQVVMAANDDMVPYITSSGLPGVATTDLPIRHFITTDRAGRPEAIPSHPVEQALFTGRWFARMAASSLPRMLDLCRSWRPDLIVGGTMSYVAPLLALHLGVPHVRQTWDAIEADGIHPGADAELLPELEPFGLDRLPEPDVFVDICPPSLRPAGAAPAQPMRYVPANAQRRLETWMVTRGERRRILVTSGSRVAKESYDKNFDFLRGLTADVASWDVELIVAAPDGTADALRDGLPGARVGWVPLDLVAPTCDLLVHHAGGVSTLTGLNAGVPQLLIPKGAVLERPALRVAEHGAAITLLPGEDSADAIADSCQELLAKDTYREGAGALSREIAAMPSPASVVATLGDLA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTCTTCGTCGCCGCGGGAAGCCCGGCGACCGTGTTCGCCCTGGCCCCGCTGGCCACCGCCGCGCGCAACGCGGGACACCAGGTCGTGATGGCCGCGAACGACGACATGGTCCCGTACATCACGTCGTCGGGCCTGCCGGGCGTGGCCACCACCGATCTGCCGATCCGGCACTTCATCACCACCGACCGGGCCGGCCGTCCGGAGGCCATCCCCTCCCACCCGGTGGAGCAGGCGCTGTTCACCGGGCGCTGGTTCGCACGCATGGCCGCCTCGAGCCTGCCCCGGATGCTGGACCTCTGCCGGTCCTGGCGGCCCGATCTGATCGTCGGCGGCACGATGAGCTACGTCGCCCCGCTGCTCGCCCTGCACCTCGGCGTGCCCCACGTGCGGCAGACCTGGGACGCCATCGAGGCGGACGGCATCCACCCCGGCGCGGACGCGGAACTGCTGCCGGAGCTGGAACCGTTCGGGCTGGACCGGCTGCCCGAGCCGGACGTGTTCGTGGACATCTGCCCGCCGAGCCTGCGTCCCGCGGGTGCCGCCCCCGCACAGCCCATGCGCTACGTCCCGGCGAACGCCCAGCGGCGGCTGGAGACCTGGATGGTCACCCGCGGCGAGCGCCGCAGGATCCTCGTCACCTCGGGCAGCCGGGTCGCGAAGGAGAGCTACGACAAGAACTTCGACTTCCTGCGCGGCCTCACCGCGGACGTCGCCTCGTGGGACGTCGAGCTGATCGTCGCGGCGCCCGACGGGACCGCCGACGCGTTGCGCGACGGCCTGCCGGGGGCCCGCGTCGGCTGGGTGCCGCTGGATCTGGTGGCGCCCACCTGTGACCTGCTGGTGCACCACGCCGGCGGGGTGAGCACGCTGACCGGCCTGAACGCCGGTGTGCCTCAACTCCTCATTCCCAAGGGCGCCGTGCTGGAGAGGCCCGCCCTGCGCGTCGCCGAACACGGCGCGGCGATCACGCTGCTGCCGGGCGAGGACTCGGCCGACGCGATCGCGGACTCCTGTCAGGAGCTGCTGGCCAAGGACACCTACCGGGAGGGTGCGGGCGCCCTTTCCCGCGAGATCGCCGCCATGCCCTCCCCCGCGAGCGTGGTCGCCACGCTCGGAGATCTGGCGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 57883,
                        "end": 58950,
                        "strand": 1,
                        "locus_tag": "ctg1_58",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_58</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_58</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 57,883 - 58,950,\n (total: 1068 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1064:glucose-1-phosphate adenylyl/thymidylyltransferase (Score: 331.3; E-value: 8.6e-101)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00483.23 (Nucleotidyl transferase): [1:235](score: 168.3, e-value: 2.1e-49)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR01208 (rmlA_long: glucose-1-phosphate thymidylyltransferase): [1:352](score: 409.0, e-value: 3.3e-123)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00483.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016779' target='_blank'>GO:0016779</a>: nucleotidyltransferase activity<br>\n  \n   PF00483.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKALVLAGGSGTRLRPFSYSMPKQLIPIANTPVLVHVLDSVRELGVTEVGVIVGNRGPEIEAVLGDGSRFGVRITYIPQDEPRGLAHTVVIARDFLGPDDFVMYLGDNMLPDGIAETAAEFVRHRPAAHVVVHKVADPRSFGVAELGPDGEVRRLVEKPREPRSDLALIGVYFFTAAIHEAVASIEPSARGELEITDAVQWLLSSGADVRASRYDGYWKDTGKVEDVLECNSHLLDGLTRRVDGRVDDASVLVGRVVIEAGARVVRSRVEGPAIIGAGTVLEDSHIGPHTSIGRDCLVADSRLEGSIALDEATVTGVHGLRNSLIGRAASVGTTGRGTGHHCLVVGDHTRVEVAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=47883&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_58_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKALVLAGGSGTRLRPFSYSMPKQLIPIANTPVLVHVLDSVRELGVTEVGVIVGNRGPEIEAVLGDGSRFGVRITYIPQDEPRGLAHTVVIARDFLGPDDFVMYLGDNMLPDGIAETAAEFVRHRPAAHVVVHKVADPRSFGVAELGPDGEVRRLVEKPREPRSDLALIGVYFFTAAIHEAVASIEPSARGELEITDAVQWLLSSGADVRASRYDGYWKDTGKVEDVLECNSHLLDGLTRRVDGRVDDASVLVGRVVIEAGARVVRSRVEGPAIIGAGTVLEDSHIGPHTSIGRDCLVADSRLEGSIALDEATVTGVHGLRNSLIGRAASVGTTGRGTGHHCLVVGDHTRVEVAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAGCTCTGGTGCTCGCAGGCGGGTCCGGTACCCGGCTGCGGCCTTTCAGCTATTCGATGCCCAAACAACTCATCCCCATCGCCAACACACCCGTCCTGGTGCACGTGCTCGACTCCGTCCGGGAGTTGGGCGTGACCGAGGTGGGGGTCATCGTCGGCAACCGCGGTCCGGAGATCGAGGCGGTCCTCGGTGACGGCTCCCGGTTCGGTGTGCGGATCACCTACATCCCCCAGGACGAACCGCGGGGACTGGCCCACACCGTGGTGATCGCGCGGGACTTCCTCGGTCCGGACGACTTCGTGATGTACCTGGGCGACAACATGCTGCCCGACGGGATCGCCGAGACCGCCGCGGAGTTCGTCCGGCACCGCCCGGCCGCGCACGTCGTCGTGCACAAGGTCGCGGACCCTCGCTCGTTCGGTGTCGCCGAACTGGGGCCCGACGGCGAGGTGCGGCGCCTGGTGGAGAAGCCCCGTGAGCCGCGCAGCGACCTGGCGTTGATCGGCGTCTACTTCTTCACCGCCGCCATCCACGAGGCGGTGGCGTCGATCGAGCCGAGCGCCCGCGGCGAACTGGAGATCACCGATGCCGTGCAGTGGCTCCTGTCCTCCGGGGCGGACGTGCGTGCCAGCCGCTACGACGGTTACTGGAAGGACACCGGGAAGGTCGAGGACGTCCTGGAGTGCAACAGCCATCTCCTCGACGGCCTGACCCGGCGCGTCGACGGACGGGTCGACGACGCCAGCGTGCTCGTCGGCCGGGTCGTGATCGAGGCCGGGGCACGCGTCGTCAGGTCCCGGGTGGAGGGTCCGGCGATCATCGGCGCGGGCACGGTGCTGGAGGACAGTCACATCGGCCCGCACACCTCCATCGGGCGGGACTGCCTGGTGGCGGACAGCCGGCTCGAGGGGTCGATCGCCCTGGACGAGGCGACCGTCACCGGTGTCCACGGCCTGCGCAACTCGCTCATCGGGCGCGCCGCGTCCGTGGGCACCACCGGACGGGGCACCGGCCATCACTGCCTCGTCGTGGGAGATCACACCCGAGTGGAGGTCGCGGCATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 58947,
                        "end": 59930,
                        "strand": 1,
                        "locus_tag": "ctg1_59",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_59</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_59</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 58,947 - 59,930,\n (total: 984 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) NAD_binding_4<br>\n \n  biosynthetic-additional (rule-based-clusters) Polysacc_synt_2<br>\n \n  biosynthetic-additional (rule-based-clusters) RmlD_sub_bind<br>\n \n  biosynthetic-additional (smcogs) SMCOG1010:NAD-dependent epimerase/dehydratase (Score: 355.4; E-value: 4.9e-108)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01370.21 (NAD dependent epimerase/dehydratase family): [2:241](score: 222.4, e-value: 6e-66)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR01181 (dTDP_gluc_dehyt: dTDP-glucose 4,6-dehydratase): [1:319](score: 421.1, e-value: 5.9e-127)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01370.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF01370.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0050662' target='_blank'>GO:0050662</a>: coenzyme binding<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRILVTGAAGFIGSHFVRSLLADEYRGWEGAQVTALDKLTYAGNRENLPASHERLVFVRGDVCDRSLLRELLPGHDAVVHFAAESHVDRSLEGAGEFFRTNVLGTQTVLDAVLESGVERVVHVSTDEVYGSITEGSWTEEWPLAPNSPYAASKAGSDLVARAYWRTHGVDLSITRCSNNYGPYQHPEKVIPLFVTNLLEGGQVPLYGDGRNVREWLHVADHCRGIHLVLNEGRAGEIYNIGGGNEYTNLDLTRKLLELTGAGEEKIRRVADRKAHDLRYSIDESKIREELGYAPRIGFEEGLAETVAWYRDNPDWWKAVKHGTGRAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=48947&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_59_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRILVTGAAGFIGSHFVRSLLADEYRGWEGAQVTALDKLTYAGNRENLPASHERLVFVRGDVCDRSLLRELLPGHDAVVHFAAESHVDRSLEGAGEFFRTNVLGTQTVLDAVLESGVERVVHVSTDEVYGSITEGSWTEEWPLAPNSPYAASKAGSDLVARAYWRTHGVDLSITRCSNNYGPYQHPEKVIPLFVTNLLEGGQVPLYGDGRNVREWLHVADHCRGIHLVLNEGRAGEIYNIGGGNEYTNLDLTRKLLELTGAGEEKIRRVADRKAHDLRYSIDESKIREELGYAPRIGFEEGLAETVAWYRDNPDWWKAVKHGTGRAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGGATTCTTGTCACCGGAGCGGCGGGCTTCATCGGCTCGCACTTCGTCCGCAGTCTGCTGGCGGACGAGTACCGCGGCTGGGAAGGCGCCCAGGTCACCGCCCTGGACAAGCTGACCTACGCCGGCAACCGGGAGAACCTGCCCGCCTCGCACGAGCGCCTGGTGTTCGTCCGCGGCGACGTGTGCGACCGGTCCCTGCTCCGCGAACTGCTGCCCGGCCACGACGCCGTGGTGCACTTCGCGGCCGAGTCCCACGTGGACCGGTCCCTGGAGGGGGCCGGGGAGTTCTTCCGGACGAACGTGCTGGGCACCCAGACCGTGCTGGACGCCGTGCTGGAGAGCGGGGTCGAGCGGGTGGTGCACGTCTCCACCGACGAGGTCTACGGCTCGATCACGGAGGGCTCCTGGACGGAGGAGTGGCCGCTGGCGCCCAACTCGCCCTACGCGGCCTCGAAGGCGGGCTCGGACCTGGTCGCCCGCGCCTACTGGCGGACGCACGGCGTGGACCTGTCGATCACCCGCTGCTCCAACAACTACGGCCCCTACCAGCACCCCGAGAAGGTCATTCCGCTCTTCGTGACCAATCTGCTGGAGGGCGGTCAAGTCCCGCTGTACGGGGACGGACGCAACGTGCGCGAGTGGCTCCACGTGGCCGACCACTGCCGCGGCATCCACCTGGTGCTGAACGAGGGCCGGGCCGGGGAGATCTACAACATCGGCGGCGGCAACGAGTACACCAACCTCGATCTCACCCGGAAGCTGCTGGAACTGACCGGCGCCGGCGAGGAGAAGATCCGCCGGGTGGCCGATCGCAAGGCGCACGACCTGCGGTACTCGATCGACGAGTCGAAGATCCGGGAGGAACTCGGCTACGCGCCCCGGATCGGGTTCGAGGAGGGTCTGGCGGAGACCGTGGCCTGGTACCGCGACAACCCCGACTGGTGGAAGGCCGTCAAGCACGGGACGGGCCGTGCGGCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 59920,
                        "end": 60978,
                        "strand": 1,
                        "locus_tag": "ctg1_60",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_60</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_60</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 59,920 - 60,978,\n (total: 1059 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) RmlD_sub_bind<br>\n \n  biosynthetic-additional (smcogs) SMCOG1010:NAD-dependent epimerase/dehydratase (Score: 149.1; E-value: 3.1e-45)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01370.21 (NAD dependent epimerase/dehydratase family): [12:258](score: 105.7, e-value: 2.5e-30)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01370.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF01370.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0050662' target='_blank'>GO:0050662</a>: coenzyme binding<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VRPDRGRVPGLSVVVLGSGGFLGRGLGAAFASRGARVHLFSRGGPPPVTGPPAGRTTTATRLDLLTADAKELRTALAAARPDVVVNAAGRAWRADEAEMAAGNATLVERVVTALAALPGPPVRLVQLGSVHEYGAGDPAGATGEDHRPEPVTPYGRTKLLGTRAVLRGAREGSVEGVVLRLANVIGAGVPEGSLFGRVAAHLGEAAAARARGEHVAALRLPPLRAARDLVDAGDVADAVVAVATAPSAAVNGQVINVGRGEAVAMRALIDRMIALSGLDVPVTEAAEAPAARTDVARQCLDISRARRLLGWRPSRGLDDSLRNLLASVLPPERPSHSTPLGITAGVPAGEGK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=49920&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_60_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VRPDRGRVPGLSVVVLGSGGFLGRGLGAAFASRGARVHLFSRGGPPPVTGPPAGRTTTATRLDLLTADAKELRTALAAARPDVVVNAAGRAWRADEAEMAAGNATLVERVVTALAALPGPPVRLVQLGSVHEYGAGDPAGATGEDHRPEPVTPYGRTKLLGTRAVLRGAREGSVEGVVLRLANVIGAGVPEGSLFGRVAAHLGEAAAARARGEHVAALRLPPLRAARDLVDAGDVADAVVAVATAPSAAVNGQVINVGRGEAVAMRALIDRMIALSGLDVPVTEAAEAPAARTDVARQCLDISRARRLLGWRPSRGLDDSLRNLLASVLPPERPSHSTPLGITAGVPAGEGK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCGGCCTGACCGCGGGCGCGTGCCGGGGCTGTCGGTCGTGGTCCTGGGGAGCGGCGGGTTCCTGGGCCGTGGGCTCGGCGCGGCGTTCGCCTCGCGGGGTGCGCGGGTGCACCTGTTCTCCCGCGGCGGTCCGCCGCCGGTCACCGGTCCGCCCGCGGGCCGGACCACGACGGCCACGCGCCTGGACCTGCTGACGGCGGACGCGAAGGAGCTGCGGACGGCCTTGGCGGCGGCCCGCCCGGACGTCGTGGTGAACGCGGCGGGCCGGGCCTGGCGGGCCGACGAGGCGGAGATGGCCGCCGGCAACGCCACGCTCGTCGAGCGGGTCGTGACCGCCCTCGCCGCGCTCCCCGGCCCTCCGGTACGGCTGGTGCAGCTGGGCAGCGTCCACGAGTACGGAGCCGGCGACCCGGCCGGCGCCACGGGCGAGGACCACCGCCCCGAACCGGTCACGCCCTACGGCCGCACCAAACTCCTCGGGACGCGGGCCGTGCTGCGCGGGGCGCGGGAGGGAAGCGTCGAAGGGGTGGTGCTCCGGCTCGCCAACGTGATCGGCGCCGGGGTTCCCGAGGGCAGTCTCTTCGGCAGGGTGGCGGCCCATCTGGGTGAGGCGGCGGCGGCGCGGGCTCGCGGCGAGCACGTCGCCGCCCTCCGGCTGCCGCCGCTGCGCGCGGCCCGCGACCTGGTGGACGCCGGTGACGTCGCCGACGCGGTGGTGGCCGTGGCCACGGCCCCGTCGGCGGCCGTCAACGGTCAGGTGATCAACGTGGGCCGCGGCGAGGCGGTGGCCATGCGCGCGCTGATCGACCGGATGATCGCGCTCAGCGGCCTGGACGTCCCCGTGACCGAGGCCGCGGAGGCGCCGGCGGCCCGTACCGACGTGGCCCGTCAGTGTCTGGACATCTCCCGGGCCCGGCGCCTGCTGGGCTGGCGCCCCTCGCGCGGACTCGACGACTCCTTGCGGAACCTCCTGGCCTCCGTGCTGCCGCCGGAGCGTCCGTCGCACAGCACACCACTCGGCATCACGGCCGGAGTCCCGGCCGGAGAAGGGAAATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 60975,
                        "end": 62285,
                        "strand": 1,
                        "locus_tag": "ctg1_61",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_61</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_61</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 60,975 - 62,285,\n (total: 1311 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) DegT_DnrJ_EryC1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1056:DegT/DnrJ/EryC1/StrS aminotransferase (Score: 374.1; E-value: 1.3e-113)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01041.17 (DegT/DnrJ/EryC1/StrS aminotransferase family): [45:428](score: 313.0, e-value: 2.9e-93)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIMSERKGRILEEVRAYHRETAPAREFVPGTTEIWPSGAVLEDADRVALVEAALELRIAAGTSSRKFESQFARRLKRRKAHLTNSGSSANLLAVSALMSHALEERRLKPGDEVITVAAGFPTTVNPILQNGLIPVFVDVDLGTYNATADRVAAAIGPKTRAVIIAHALGNPFEVTEIAQLCEQHDLFLIEDNCDAVGSLYDGKLTGTFGDMTTVSFYPAHHLTMGEGGCVLTSNLALARIVESLRDWGRDCWCEPGENDRCLKRFTYQMGTLPAGYDHKYIFSHVGYNLKATDIQAALGLTQLAKLDSFIEARRRNWQRLREGLDGVPGLLLPEATPRSEPSWFGFVITVDPEAPFSRAELVDFLEGRKIGTRRLFAGNLTRHPAYIDQPHRIVGDLANSDVITEHTFWIGVYPALTDEMLDYVTASIKEFVAARG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=50975&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_61_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIMSERKGRILEEVRAYHRETAPAREFVPGTTEIWPSGAVLEDADRVALVEAALELRIAAGTSSRKFESQFARRLKRRKAHLTNSGSSANLLAVSALMSHALEERRLKPGDEVITVAAGFPTTVNPILQNGLIPVFVDVDLGTYNATADRVAAAIGPKTRAVIIAHALGNPFEVTEIAQLCEQHDLFLIEDNCDAVGSLYDGKLTGTFGDMTTVSFYPAHHLTMGEGGCVLTSNLALARIVESLRDWGRDCWCEPGENDRCLKRFTYQMGTLPAGYDHKYIFSHVGYNLKATDIQAALGLTQLAKLDSFIEARRRNWQRLREGLDGVPGLLLPEATPRSEPSWFGFVITVDPEAPFSRAELVDFLEGRKIGTRRLFAGNLTRHPAYIDQPHRIVGDLANSDVITEHTFWIGVYPALTDEMLDYVTASIKEFVAARG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATCATGAGCGAGCGCAAGGGTCGGATTCTCGAAGAGGTCCGCGCGTATCACCGGGAGACCGCCCCGGCACGCGAGTTCGTCCCGGGGACGACGGAGATCTGGCCGTCCGGCGCGGTACTGGAGGACGCGGACCGAGTGGCGCTGGTGGAGGCCGCGCTGGAGCTGCGCATCGCCGCCGGGACCAGCTCCCGCAAGTTCGAGTCACAGTTCGCACGACGCCTCAAGCGCCGCAAGGCGCATCTGACCAACTCCGGTTCGTCGGCGAACCTGCTGGCCGTGTCGGCGCTGATGTCGCACGCACTGGAGGAGCGGCGGCTGAAGCCGGGCGACGAGGTCATCACGGTCGCGGCGGGCTTCCCCACCACGGTCAACCCGATCCTGCAGAACGGTCTCATCCCGGTCTTCGTGGACGTCGACCTCGGCACCTACAACGCGACGGCCGACCGGGTGGCCGCGGCGATCGGCCCCAAGACCCGCGCCGTCATCATCGCGCACGCGCTGGGCAACCCCTTCGAGGTCACGGAGATCGCCCAGCTCTGCGAACAGCACGACCTGTTCCTGATCGAGGACAACTGCGACGCGGTCGGCTCCCTCTACGACGGGAAGCTCACCGGCACCTTCGGCGACATGACGACGGTCAGCTTCTACCCGGCGCACCACTTGACCATGGGCGAGGGCGGCTGTGTGCTCACCTCCAACCTGGCCCTGGCCCGCATCGTGGAGTCGTTGCGCGACTGGGGGCGGGACTGCTGGTGCGAACCCGGTGAGAACGACCGCTGCCTGAAGCGGTTCACGTACCAGATGGGCACGCTGCCGGCCGGGTACGACCACAAGTACATCTTCTCCCACGTGGGGTACAACCTGAAGGCCACGGACATCCAGGCCGCACTCGGGCTCACGCAGCTGGCCAAGCTGGACTCCTTCATCGAGGCGCGGCGGCGCAACTGGCAGCGGCTGCGGGAGGGACTGGACGGGGTCCCGGGCCTGCTGCTGCCCGAGGCCACGCCCCGCTCCGAGCCCAGCTGGTTCGGCTTCGTCATCACCGTGGACCCCGAAGCGCCGTTCAGCCGCGCCGAGCTGGTCGACTTCCTGGAGGGCCGCAAGATCGGCACGCGTCGGCTCTTCGCCGGGAACCTGACCCGTCACCCGGCCTACATCGACCAGCCGCACCGGATCGTGGGCGACCTGGCCAACAGCGACGTCATCACCGAGCACACCTTCTGGATCGGGGTCTACCCGGCGCTCACGGACGAGATGCTGGACTACGTCACCGCCTCGATCAAGGAGTTCGTGGCCGCGCGCGGCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 62336,
                        "end": 63100,
                        "strand": 1,
                        "locus_tag": "ctg1_62",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_62</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_62</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 62,336 - 63,100,\n (total: 765 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) RmlD_sub_bind<br>\n \n  biosynthetic-additional (smcogs) SMCOG1010:NAD-dependent epimerase/dehydratase (Score: 84; E-value: 2.1e-25)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01370.21 (NAD dependent epimerase/dehydratase family): [18:177](score: 63.6, e-value: 1.9e-17)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01370.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF01370.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0050662' target='_blank'>GO:0050662</a>: coenzyme binding<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MDIVGTGFLARNLRPLAGRHPDTVALAAGVSWASGTSDADFAREAALLREVAGRCRDTGRRLLFFSTAATGMYGLADGPGREDVPVTPCTPYGAHKLALEGVLRDSGADHLILRLGHLVGPHQPEHQLLPTLVRQLREGMVRVHRGAARDLIGVEDVITVVDHLLAAGPRAETVNVASGFAVPVEDVVGHLEQALGLRARREFVETGGRQHVISTEKLRSLVPQTAHMGFGPSYYRRILGDFAASVASGATAPA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=52336&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_62_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MDIVGTGFLARNLRPLAGRHPDTVALAAGVSWASGTSDADFAREAALLREVAGRCRDTGRRLLFFSTAATGMYGLADGPGREDVPVTPCTPYGAHKLALEGVLRDSGADHLILRLGHLVGPHQPEHQLLPTLVRQLREGMVRVHRGAARDLIGVEDVITVVDHLLAAGPRAETVNVASGFAVPVEDVVGHLEQALGLRARREFVETGGRQHVISTEKLRSLVPQTAHMGFGPSYYRRILGDFAASVASGATAPA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGACATTGTGGGAACCGGTTTCCTGGCGCGGAACCTGCGCCCGCTGGCCGGCCGGCATCCGGACACCGTGGCTTTGGCGGCCGGGGTGTCGTGGGCGAGCGGCACCTCCGACGCGGACTTCGCCCGCGAGGCGGCGCTGTTGCGCGAGGTCGCCGGCCGGTGCCGCGACACCGGCCGGCGGCTGCTCTTCTTCTCCACCGCGGCGACCGGCATGTACGGACTCGCCGACGGGCCCGGCCGGGAGGACGTCCCGGTGACCCCCTGTACCCCTTACGGCGCGCACAAGCTCGCCCTGGAAGGAGTGCTGCGCGACTCCGGCGCCGACCATCTGATCCTCCGGCTGGGGCACCTGGTCGGCCCGCACCAGCCCGAGCACCAGCTGCTGCCCACCCTGGTACGGCAGCTGCGCGAGGGGATGGTCCGGGTGCACCGGGGCGCGGCCCGGGATCTGATCGGCGTGGAGGACGTCATCACCGTCGTCGACCATCTCCTCGCCGCCGGTCCGCGCGCCGAGACGGTCAACGTGGCGTCCGGTTTCGCCGTACCGGTGGAGGACGTCGTCGGCCACCTCGAGCAGGCGCTCGGACTGCGGGCGCGCCGGGAGTTCGTCGAGACGGGCGGCCGCCAGCACGTCATCTCGACGGAGAAGCTGCGCTCCCTCGTGCCGCAGACCGCGCACATGGGGTTCGGCCCCTCCTACTACCGGCGGATCCTCGGGGACTTCGCGGCCTCCGTGGCGTCCGGCGCCACCGCACCTGCCTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 63127,
                        "end": 64080,
                        "strand": 1,
                        "locus_tag": "ctg1_63",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_63</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_63</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 63,127 - 64,080,\n (total: 954 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTHHRNRTRNDRRRTVRRAVALAGAALLLAGLHGPAPAAPAPPVSAADASYTAGAPATVDLVSTATEFTAPATTRPGPTTFRASTTQSGKGWIGLARLKDGKGWDDFLDVLSRALSDTPSDVPRGAKDLDETAVLLGGLVIHPGQPGTFTQHLRPGRYLLFDYLTAGDAEPRHRWLTVTGEASGRFPEPTATVVARNVPGVGPRFEVRGSLRAGRPLRYVNRIPGQVNELLFVKIAEGTTEAELKAWFDALPDDGTFPPDSPFRSVSLGSLHLSTGRSSVVRVPLEPDRYAAITYSKDATDGIKLVKKGLFAVVDVH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=53127&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_63_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTHHRNRTRNDRRRTVRRAVALAGAALLLAGLHGPAPAAPAPPVSAADASYTAGAPATVDLVSTATEFTAPATTRPGPTTFRASTTQSGKGWIGLARLKDGKGWDDFLDVLSRALSDTPSDVPRGAKDLDETAVLLGGLVIHPGQPGTFTQHLRPGRYLLFDYLTAGDAEPRHRWLTVTGEASGRFPEPTATVVARNVPGVGPRFEVRGSLRAGRPLRYVNRIPGQVNELLFVKIAEGTTEAELKAWFDALPDDGTFPPDSPFRSVSLGSLHLSTGRSSVVRVPLEPDRYAAITYSKDATDGIKLVKKGLFAVVDVH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACGCACCACAGGAACCGGACGAGGAACGACCGTCGGCGCACCGTGCGCCGAGCGGTCGCGCTGGCCGGTGCCGCACTTCTGCTGGCCGGACTGCACGGGCCCGCCCCCGCGGCCCCCGCGCCCCCGGTGAGCGCGGCGGACGCCTCGTACACCGCCGGGGCGCCGGCCACGGTGGACCTCGTCTCGACCGCGACGGAGTTCACCGCACCGGCCACCACCCGCCCGGGACCGACCACGTTCCGCGCCTCGACCACCCAGTCGGGCAAGGGCTGGATCGGGCTGGCCCGGCTGAAGGACGGCAAGGGCTGGGACGACTTCCTGGACGTTCTCTCCCGCGCGCTGTCCGACACCCCGTCCGACGTTCCGCGGGGTGCCAAGGACCTGGACGAGACCGCCGTTCTGCTCGGAGGGCTGGTGATCCACCCCGGACAGCCCGGGACGTTCACGCAGCACCTGCGTCCGGGACGGTATCTGCTGTTCGACTACCTCACGGCCGGCGACGCCGAGCCTCGGCACCGCTGGCTGACGGTCACCGGCGAAGCCTCCGGCCGGTTCCCGGAGCCGACCGCGACCGTCGTGGCGAGGAACGTCCCCGGCGTCGGTCCGCGCTTCGAGGTCCGTGGCAGTCTCCGCGCCGGCCGGCCGCTGCGCTACGTCAACCGGATCCCCGGGCAGGTGAACGAACTGCTTTTCGTGAAGATCGCGGAGGGGACCACCGAGGCGGAGCTCAAGGCCTGGTTCGACGCCCTGCCCGACGACGGCACCTTCCCGCCCGATTCTCCGTTCCGCTCGGTCAGTCTCGGCAGCCTGCACCTGTCCACGGGCCGCTCGTCCGTCGTGCGGGTCCCGCTGGAGCCCGACCGGTACGCGGCGATCACCTACTCGAAGGACGCCACCGACGGCATCAAGCTCGTCAAGAAGGGCCTGTTCGCCGTCGTCGACGTGCACTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 64135,
                        "end": 65538,
                        "strand": 1,
                        "locus_tag": "ctg1_64",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_64</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_64</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 64,135 - 65,538,\n (total: 1404 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF03559.14 (NDP-hexose 2,3-dehydratase): [34:242](score: 288.8, e-value: 1.7e-86)<br>\n \n  PF03559.14 (NDP-hexose 2,3-dehydratase): [256:459](score: 263.9, e-value: 7.5e-79)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTPPSLPQARANTRRVTERLGLSAATSRGAHLPTDRFSAWLAERGSANAFRVDRIPFAELDGWSFEETTGNLVHRSGRFFTVEGMRVTERDEPYGDGPFAEWHQPVIKQPEVGILGILAKEFDGVLHFLMQAKMEPGNPNLLQLSPTVQATRSNYTKAHQGADVKYIQHFVGPGRGRVVADALQSEHGSWFFRKANRNMIVEATGDVPLLDDFCWLTLGQIAELLHRDNVVNMDSRTVLSCLPVPETADGALHSDVELLSWITGERARHDVHAERVPLAGLPGWHRHETAIEHEEGRYFKVVAVSVQAGNREVTSWTQPLFEPVGQGVTAFLTRTFDGVPHVLVHARVEGGFLDTVELGPTVQYTPANYAHLPEKERPPYLDTVLEAPAERIRYEAVHAEEGGRFLNAESRYLLVDADERDAPLDPPPGYAWVTPDQLTWLVRHGHYLNVQARTLLACLNARAAVAR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=54135&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_64_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTPPSLPQARANTRRVTERLGLSAATSRGAHLPTDRFSAWLAERGSANAFRVDRIPFAELDGWSFEETTGNLVHRSGRFFTVEGMRVTERDEPYGDGPFAEWHQPVIKQPEVGILGILAKEFDGVLHFLMQAKMEPGNPNLLQLSPTVQATRSNYTKAHQGADVKYIQHFVGPGRGRVVADALQSEHGSWFFRKANRNMIVEATGDVPLLDDFCWLTLGQIAELLHRDNVVNMDSRTVLSCLPVPETADGALHSDVELLSWITGERARHDVHAERVPLAGLPGWHRHETAIEHEEGRYFKVVAVSVQAGNREVTSWTQPLFEPVGQGVTAFLTRTFDGVPHVLVHARVEGGFLDTVELGPTVQYTPANYAHLPEKERPPYLDTVLEAPAERIRYEAVHAEEGGRFLNAESRYLLVDADERDAPLDPPPGYAWVTPDQLTWLVRHGHYLNVQARTLLACLNARAAVAR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACGCCACCTTCCCTCCCGCAGGCCCGCGCCAACACGCGGCGGGTGACGGAACGCCTCGGGCTGTCCGCCGCCACCTCCCGGGGCGCTCACCTGCCGACCGACCGCTTCTCCGCATGGCTCGCCGAACGTGGCAGCGCCAACGCCTTCCGCGTGGACCGGATCCCCTTCGCCGAGCTGGACGGCTGGTCGTTCGAGGAGACCACCGGCAATCTCGTGCACCGCAGCGGCAGGTTCTTCACGGTCGAGGGCATGCGGGTGACCGAGCGGGACGAACCCTACGGCGACGGCCCGTTCGCCGAGTGGCACCAGCCCGTGATCAAGCAGCCCGAGGTGGGCATCCTGGGCATCCTGGCCAAGGAGTTCGACGGGGTCCTGCACTTCCTCATGCAGGCGAAGATGGAGCCCGGCAATCCCAACCTGCTCCAGCTCTCCCCCACGGTGCAGGCCACTCGCAGCAACTACACCAAGGCCCATCAGGGCGCGGATGTGAAGTACATACAGCACTTCGTCGGTCCCGGGCGTGGCCGGGTCGTCGCGGACGCCCTGCAGTCCGAGCACGGTTCGTGGTTCTTCCGCAAGGCCAACCGCAACATGATCGTGGAGGCCACCGGCGACGTGCCGCTCCTCGACGACTTCTGCTGGCTCACCCTGGGACAGATCGCCGAACTGCTGCACCGGGACAATGTCGTCAACATGGACTCGCGGACGGTCCTGTCCTGCCTCCCGGTCCCGGAGACGGCGGACGGCGCCCTGCACTCCGACGTCGAGCTGCTGTCCTGGATCACCGGTGAGCGCGCCCGGCACGATGTGCACGCCGAACGTGTCCCGCTGGCCGGGCTGCCCGGCTGGCACCGCCATGAGACGGCCATCGAGCACGAGGAGGGCCGGTACTTCAAAGTGGTGGCCGTGTCCGTACAGGCGGGCAACCGCGAGGTCACCAGCTGGACCCAGCCGCTGTTCGAGCCGGTCGGCCAGGGGGTGACCGCGTTCCTCACCCGCACCTTCGACGGCGTCCCGCACGTGCTGGTGCACGCCCGGGTCGAGGGGGGCTTCCTCGACACCGTCGAACTGGGCCCCACGGTCCAGTACACCCCCGCCAACTACGCCCACCTGCCGGAGAAGGAACGCCCGCCGTACCTCGACACCGTGCTGGAGGCCCCGGCGGAGCGGATCCGCTACGAGGCCGTGCACGCGGAGGAGGGGGGCCGGTTCCTCAACGCCGAGAGCCGGTACCTGCTCGTCGACGCCGACGAACGGGACGCTCCCCTCGACCCGCCGCCCGGATACGCGTGGGTCACTCCCGACCAGCTGACCTGGCTGGTCCGTCACGGCCACTACCTGAACGTCCAGGCGCGCACGCTGCTCGCCTGCCTCAACGCCCGTGCGGCGGTCGCCCGATGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 65535,
                        "end": 66494,
                        "strand": 1,
                        "locus_tag": "ctg1_65",
                        "type": "biosynthetic-additional",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_65</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_65</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 65,535 - 66,494,\n (total: 960 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1079:oxidoreductase (Score: 267; E-value: 4.6e-81)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01408.22 (Oxidoreductase family, NAD-binding Rossmann fold): [4:122](score: 79.8, e-value: 2.8e-22)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01408.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSAPVRIGVLGCADIAVRRMLPAFTASPDVEVAAVASRDRGRAERTAGRFGCRPVHGYAELLDRDDVQAVYVPLPAALHAHWVEAALEAGKHVLAEKPLTTDPDTTERLLELAGKQGVALMENVMFLHHPRHEAVRRLVADGRIGEPRSLHAAFTIPPLPDSDIRYDPGLGGGALADVGLYPLRAALHFLGPELEVIGARLARGPGRRVETSGAALLGTPDGVTAHVTFGMEHAYLSRYELWGSEGRITVDRAFTPPADFVPLVGLHTSAGTEEIRLTPADQVAATVAAFVASVRAGHAPGADTLRQAVLLDAVRHRSG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=55535&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_65_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSAPVRIGVLGCADIAVRRMLPAFTASPDVEVAAVASRDRGRAERTAGRFGCRPVHGYAELLDRDDVQAVYVPLPAALHAHWVEAALEAGKHVLAEKPLTTDPDTTERLLELAGKQGVALMENVMFLHHPRHEAVRRLVADGRIGEPRSLHAAFTIPPLPDSDIRYDPGLGGGALADVGLYPLRAALHFLGPELEVIGARLARGPGRRVETSGAALLGTPDGVTAHVTFGMEHAYLSRYELWGSEGRITVDRAFTPPADFVPLVGLHTSAGTEEIRLTPADQVAATVAAFVASVRAGHAPGADTLRQAVLLDAVRHRSG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCGCGCCGGTGCGTATCGGGGTGCTCGGCTGCGCCGACATCGCGGTACGGCGGATGCTCCCCGCGTTCACCGCCTCCCCGGACGTCGAGGTCGCAGCCGTCGCCAGCCGTGACCGGGGCAGGGCGGAGAGGACGGCGGGGCGCTTCGGCTGCCGGCCCGTCCACGGGTACGCGGAGCTGCTGGACCGCGACGACGTGCAGGCGGTGTACGTGCCGCTGCCGGCCGCCCTGCACGCGCACTGGGTGGAGGCGGCACTCGAGGCCGGCAAGCACGTGCTCGCCGAGAAGCCCCTGACGACGGACCCGGACACCACCGAACGCCTGCTGGAGCTGGCCGGCAAGCAGGGCGTGGCGCTGATGGAGAACGTGATGTTCCTTCATCATCCCCGGCACGAGGCGGTACGGCGCCTCGTCGCCGACGGGCGGATCGGCGAACCGAGGTCGCTGCACGCGGCGTTCACCATCCCTCCGCTCCCCGACAGCGACATCCGGTACGACCCCGGCCTGGGCGGCGGCGCGCTGGCGGACGTCGGCCTCTACCCGCTCCGGGCCGCACTGCACTTCCTGGGCCCTGAGCTCGAAGTGATCGGCGCCCGGCTCGCCCGGGGTCCCGGTCGGCGGGTCGAGACGTCCGGCGCGGCACTGCTGGGCACCCCCGACGGAGTCACCGCGCACGTCACGTTCGGCATGGAGCACGCCTATCTGTCGCGGTACGAACTGTGGGGCAGCGAGGGACGGATCACCGTTGACCGGGCGTTCACCCCGCCGGCCGACTTCGTCCCCCTGGTCGGCCTGCACACGTCCGCGGGTACGGAGGAGATCCGGCTGACGCCCGCCGACCAGGTCGCGGCGACGGTCGCCGCGTTCGTCGCCTCGGTCAGGGCCGGTCACGCGCCGGGCGCGGACACTCTGCGGCAGGCCGTTCTGCTGGACGCCGTACGCCACAGGTCCGGGTGA\">Copy to clipboard</span><br>\n</div>"
                    },
                    {
                        "start": 66559,
                        "end": 66753,
                        "strand": 1,
                        "locus_tag": "ctg1_66",
                        "type": "other",
                        "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_66</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_66</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 66,559 - 66,753,\n (total: 195 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01039.22 (Carboxyl transferase domain): [23:63](score: 40.4, e-value: 1.4e-10)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTVELHEIRAQALAGPSEKATRAQHAKGKLTARERIELLLDAGSFREVEQLRRHRATGFGLEEKK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=56559&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_66_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTVELHEIRAQALAGPSEKATRAQHAKGKLTARERIELLLDAGSFREVEQLRRHRATGFGLEEKK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGGTCGAGCTGCACGAGATCCGTGCCCAGGCACTGGCCGGCCCGAGCGAGAAGGCGACCCGGGCGCAGCACGCCAAGGGGAAGCTGACCGCGCGGGAGCGCATCGAACTGCTGCTGGACGCGGGGTCGTTCCGTGAGGTGGAGCAGTTGCGGCGGCACCGGGCGACCGGTTTCGGTCTGGAGGAGAAGAAG\">Copy to clipboard</span><br>\n</div>"
                    }
                ],
                "clusters": [
                    {
                        "start": 1,
                        "end": 66752,
                        "tool": "",
                        "neighbouring_start": 0,
                        "neighbouring_end": 66753,
                        "product": "CC 1: neighbouring",
                        "kind": "candidatecluster",
                        "prefix": "",
                        "height": 0
                    },
                    {
                        "start": 1,
                        "end": 17111,
                        "tool": "",
                        "neighbouring_start": 0,
                        "neighbouring_end": 17112,
                        "product": "CC 2: single",
                        "kind": "candidatecluster",
                        "prefix": "",
                        "height": 1
                    },
                    {
                        "start": 10554,
                        "end": 66752,
                        "tool": "",
                        "neighbouring_start": 10553,
                        "neighbouring_end": 66753,
                        "product": "CC 3: single",
                        "kind": "candidatecluster",
                        "prefix": "",
                        "height": 2
                    },
                    {
                        "start": 43622,
                        "end": 66752,
                        "tool": "",
                        "neighbouring_start": 43621,
                        "neighbouring_end": 66753,
                        "product": "CC 4: single",
                        "kind": "candidatecluster",
                        "prefix": "",
                        "height": 1
                    },
                    {
                        "start": 6620,
                        "end": 7112,
                        "tool": "rule-based-clusters",
                        "neighbouring_start": 0,
                        "neighbouring_end": 17112,
                        "product": "phenazine",
                        "height": 4,
                        "kind": "protocluster",
                        "prefix": ""
                    },
                    {
                        "start": 45553,
                        "end": 48051,
                        "tool": "rule-based-clusters",
                        "neighbouring_start": 10553,
                        "neighbouring_end": 66753,
                        "product": "T2PKS",
                        "height": 6,
                        "kind": "protocluster",
                        "prefix": ""
                    },
                    {
                        "start": 53621,
                        "end": 57854,
                        "tool": "rule-based-clusters",
                        "neighbouring_start": 43621,
                        "neighbouring_end": 66753,
                        "product": "oligosaccharide",
                        "height": 4,
                        "kind": "protocluster",
                        "prefix": ""
                    }
                ],
                "ttaCodons": [
                    {
                        "start": 1618,
                        "end": 1620,
                        "strand": -1,
                        "containedBy": [
                            "ctg1_2"
                        ]
                    },
                    {
                        "start": 14998,
                        "end": 15000,
                        "strand": 1,
                        "containedBy": [
                            "ctg1_16"
                        ]
                    },
                    {
                        "start": 24848,
                        "end": 24850,
                        "strand": 1,
                        "containedBy": [
                            "ctg1_24"
                        ]
                    },
                    {
                        "start": 33955,
                        "end": 33957,
                        "strand": -1,
                        "containedBy": [
                            "ctg1_34"
                        ]
                    }
                ],
                "type": "T2PKS,oligosaccharide,phenazine",
                "products": [
                    "phenazine",
                    "T2PKS",
                    "oligosaccharide"
                ],
                "anchor": "r1c1"
            }
        ]
    }
];
var all_regions = {
    "order": [
        "r1c1"
    ],
    "r1c1": {
        "start": 1,
        "end": 66753,
        "idx": 1,
        "orfs": [
            {
                "start": 2,
                "end": 127,
                "strand": 1,
                "locus_tag": "ctg1_1",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_1</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_1</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2 - 127,\n (total: 126 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=HYGVLAGRLGAAGVAPTTTMLGVTRLAIPGQMVELEGTAVA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=10127\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"HYGVLAGRLGAAGVAPTTTMLGVTRLAIPGQMVELEGTAVA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"CACTACGGCGTGCTGGCCGGGCGTCTGGGAGCGGCCGGTGTCGCCCCGACCACCACCATGCTCGGCGTGACCCGCCTGGCCATCCCCGGCCAGATGGTCGAACTCGAAGGCACCGCCGTCGCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 274,
                "end": 1653,
                "strand": -1,
                "locus_tag": "ctg1_2",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_2</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_2</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 274 - 1,653,\n (total: 1380 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00004.29 (ATPase family associated with various cellular activities (AAA)): [72:178](score: 57.5, e-value: 1.9e-15)<br>\n \n  PF16193.5 (AAA C-terminal domain): [208:284](score: 77.4, e-value: 8e-22)<br>\n \n  PF12002.8 (MgsA AAA+ ATPase C terminal): [284:450](score: 224.9, e-value: 5.5e-67)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00004.29: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTSTEDDGLFALPEPEPAPPHPPGADSATARPGAPLAVRMRPRSLAEVVGQTHLLRPGAPLRLLAEGGDATSVLLYGPPGTGKTTLARLTAAVADRHFVALSALTSGVKELRDVMSEARRRRDRQGRRTVLFIDEVHRFSRTQQDALLGAVEDGQVLLVAATTENPSFSVVSPLLSRLLVLRLQPLTEDELRELLRRAVKDERGLDGAVLLEPEAEDVLVRLAAGDARSALTALEASAEGVTGTGGSAVDVAAVERAVSGTTVRYDRQGDQHHDVVSAFIKSIRGSDPDAALHYLARMLVAGEDPRFIARRLLVHASEDVGLADPTALQAAVAAAQTVQFIGMPEARLALAQATVHLATAPKSNTVLVGIDEAMSDVRAGAVGEVPPHLRHSRYTGAKELGNGVGYRYPHRTPEGVLPQQYPPGDLVGRDYYRPTDRGGERDLRERLSRLRRVVRGGEG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=11653\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTSTEDDGLFALPEPEPAPPHPPGADSATARPGAPLAVRMRPRSLAEVVGQTHLLRPGAPLRLLAEGGDATSVLLYGPPGTGKTTLARLTAAVADRHFVALSALTSGVKELRDVMSEARRRRDRQGRRTVLFIDEVHRFSRTQQDALLGAVEDGQVLLVAATTENPSFSVVSPLLSRLLVLRLQPLTEDELRELLRRAVKDERGLDGAVLLEPEAEDVLVRLAAGDARSALTALEASAEGVTGTGGSAVDVAAVERAVSGTTVRYDRQGDQHHDVVSAFIKSIRGSDPDAALHYLARMLVAGEDPRFIARRLLVHASEDVGLADPTALQAAVAAAQTVQFIGMPEARLALAQATVHLATAPKSNTVLVGIDEAMSDVRAGAVGEVPPHLRHSRYTGAKELGNGVGYRYPHRTPEGVLPQQYPPGDLVGRDYYRPTDRGGERDLRERLSRLRRVVRGGEG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACGAGCACCGAGGACGACGGACTGTTCGCGTTACCCGAACCGGAGCCGGCCCCACCGCACCCGCCCGGCGCGGACTCCGCGACCGCACGCCCCGGCGCCCCGCTCGCCGTACGGATGCGGCCACGCTCGCTCGCGGAAGTCGTCGGCCAGACACACCTGTTGCGTCCCGGCGCACCTCTGCGACTGCTGGCCGAGGGAGGGGACGCGACGTCGGTGCTGTTGTACGGCCCGCCGGGGACGGGGAAGACCACCCTGGCGCGTCTGACGGCCGCCGTCGCCGACCGCCACTTCGTCGCTCTCTCGGCACTCACCAGCGGCGTCAAGGAACTGCGGGACGTGATGAGCGAGGCGCGCCGCCGCCGGGACCGCCAGGGCAGGCGAACCGTCCTGTTCATCGACGAGGTGCACCGCTTCTCCAGGACCCAGCAGGACGCGCTGCTCGGCGCCGTGGAGGACGGACAGGTCCTGCTCGTCGCCGCGACCACGGAGAACCCGTCGTTCTCGGTGGTGTCCCCACTGCTCTCCCGTCTGCTCGTACTGCGGCTTCAGCCCCTGACCGAGGACGAGCTGCGCGAACTGCTGCGCCGCGCGGTGAAGGACGAGCGAGGCCTCGACGGCGCGGTCCTCCTGGAACCCGAGGCGGAGGACGTCCTGGTGCGCCTCGCGGCCGGCGACGCCCGGAGCGCACTGACCGCACTGGAGGCGAGCGCCGAAGGGGTGACGGGCACCGGAGGCAGCGCGGTCGATGTCGCCGCCGTGGAGCGTGCCGTGTCCGGGACCACGGTGCGCTACGACCGGCAGGGCGACCAACACCATGACGTCGTCAGCGCGTTCATCAAGTCGATCCGGGGGTCGGACCCGGACGCCGCGCTGCACTACCTGGCCCGCATGCTCGTCGCGGGAGAGGATCCGCGCTTCATCGCGCGTCGGCTGCTGGTGCACGCGAGCGAGGACGTCGGACTCGCCGACCCGACGGCGCTGCAGGCCGCCGTCGCGGCGGCCCAGACGGTGCAGTTCATCGGCATGCCCGAGGCGCGCCTGGCTCTCGCCCAGGCAACGGTCCACCTGGCGACGGCGCCGAAGTCGAACACGGTGCTCGTCGGGATCGACGAGGCCATGTCCGACGTCCGCGCGGGCGCCGTGGGGGAGGTCCCCCCGCACCTGCGGCACAGCCGTTACACCGGTGCCAAGGAGCTCGGCAACGGGGTCGGCTACCGGTATCCCCACAGGACCCCCGAGGGAGTGCTGCCACAGCAGTACCCGCCGGGTGACCTCGTGGGCAGGGACTACTACCGGCCCACGGACCGGGGCGGGGAGCGCGACCTGCGGGAACGCCTGAGCAGGCTCCGTCGCGTGGTCCGGGGCGGGGAGGGATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 1875,
                "end": 2732,
                "strand": -1,
                "locus_tag": "ctg1_3",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_3</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_3</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 1,875 - 2,732,\n (total: 858 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF02567.16 (Phenazine biosynthesis-like protein): [9:277](score: 238.3, e-value: 1.2e-70)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR00654 (PhzF_family: phenazine biosynthesis protein, PhzF family): [3:281](score: 183.0, e-value: 1.9e-54)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF02567.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF02567.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MGRYEYVVADVFTDVPLEGNPTAVFLDASGLSPGRMQQIAQEMHLSETVFVLPAENDGDVRVRIFTPVNELPFAGHPTLGAAVVLGESHDAKELRMETAKGTVTFELERDDDGRTVAAAMWQPLPVWRTYDRTDELLAALDLVDTGSTLPVEVYDNGPRHVFVGLDGVPALSSLEPDQRILARLPDMAANCFTGSGNRWRLRMFSPAYGVVEDAATGSAAGSIAVHLARYGLAPFGEWIDIRQGIEMGRPSTMRARVTGTPDRIDAVQVAGSAVVVARATLFVQP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=12732\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_3_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MGRYEYVVADVFTDVPLEGNPTAVFLDASGLSPGRMQQIAQEMHLSETVFVLPAENDGDVRVRIFTPVNELPFAGHPTLGAAVVLGESHDAKELRMETAKGTVTFELERDDDGRTVAAAMWQPLPVWRTYDRTDELLAALDLVDTGSTLPVEVYDNGPRHVFVGLDGVPALSSLEPDQRILARLPDMAANCFTGSGNRWRLRMFSPAYGVVEDAATGSAAGSIAVHLARYGLAPFGEWIDIRQGIEMGRPSTMRARVTGTPDRIDAVQVAGSAVVVARATLFVQP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGGCAGGTACGAGTACGTGGTGGCCGATGTCTTCACCGACGTCCCGCTGGAAGGCAACCCCACCGCGGTCTTCCTCGACGCCTCGGGCCTCTCGCCCGGGCGCATGCAGCAGATCGCCCAGGAGATGCATCTGTCGGAGACCGTCTTCGTCCTCCCGGCGGAGAACGACGGCGATGTGCGGGTCCGCATCTTCACGCCCGTCAACGAACTCCCCTTCGCCGGGCATCCGACCCTGGGCGCGGCCGTCGTGCTCGGCGAGTCGCACGACGCCAAGGAACTGCGGATGGAGACCGCCAAAGGCACCGTGACGTTCGAGCTGGAGCGGGACGACGACGGCCGGACCGTCGCGGCAGCCATGTGGCAGCCCCTGCCGGTCTGGCGGACCTACGACCGGACGGACGAACTCCTCGCCGCGCTCGACCTGGTGGACACGGGCAGCACCCTGCCCGTGGAGGTCTACGACAACGGGCCACGGCATGTGTTCGTCGGCCTGGACGGCGTGCCCGCGCTCTCCTCCCTGGAGCCGGACCAGCGGATCCTCGCGCGTCTGCCCGACATGGCGGCCAACTGCTTCACCGGTTCCGGAAACCGGTGGCGGCTGCGCATGTTCTCGCCCGCGTACGGGGTGGTGGAGGACGCCGCGACCGGTTCGGCCGCGGGATCGATCGCGGTACATTTGGCGCGGTACGGCCTGGCCCCGTTCGGCGAGTGGATCGACATCCGTCAGGGCATCGAGATGGGACGCCCCTCGACAATGCGGGCTCGGGTGACGGGGACGCCGGACCGGATCGACGCGGTGCAGGTGGCGGGATCCGCCGTCGTCGTCGCCCGGGCCACGCTGTTCGTCCAGCCCTAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 2806,
                "end": 4482,
                "strand": -1,
                "locus_tag": "ctg1_4",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_4</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_4</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 2,806 - 4,482,\n (total: 1677 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00710.20 (Asparaginase, N-terminal): [229:330](score: 27.7, e-value: 1.7e-06)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTGDMRAAGVPRPRIAVFAGPTATILNTPDLVTSNKARARHGLPLRPGRFDALRPQRLAAPATLYVEAFSAHPLEQDAAGLYAPPDGWLDADGTFHAERPPGDAKPVHVVELDPADGLYPLPYMARQADGSAWEETSAAPYADPAGARQTFHPDARRLYEEIERFGLADHGGPVELGSVADFEFFRAAPSGGYTSGPASERLGRDFFVYYPYHLQTEPSLAHLALATNHVQEVLGSGEFTGAQWLEGSPTVDETLYWLGLLVDTKVPLVGHAAQRRHQSLSADGDRNVVDGVKFIASGVALDERGEDRVGACVVVDELVYSARDVTKVDARPGGYEVTGGHGGVVADLGGYGPPQLTYLPTRRHTHRSEVRLTVLPGTVTGVMGSLGGGVTRAEVRTKDADGLVPTAMPHVSITKYSRYAATGTGADDPPVAEEEVEILARIDANLARFPLAGFVCEGMSPFGMADPMKNAALGVAVFAGMPVVRTGRGTTGGMAYRTDPAFVSGNNLTATKARMLLMAALLRFGALPPAADPFDPTPDERAATEKAVAQYQSLFDTH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=14482\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTGDMRAAGVPRPRIAVFAGPTATILNTPDLVTSNKARARHGLPLRPGRFDALRPQRLAAPATLYVEAFSAHPLEQDAAGLYAPPDGWLDADGTFHAERPPGDAKPVHVVELDPADGLYPLPYMARQADGSAWEETSAAPYADPAGARQTFHPDARRLYEEIERFGLADHGGPVELGSVADFEFFRAAPSGGYTSGPASERLGRDFFVYYPYHLQTEPSLAHLALATNHVQEVLGSGEFTGAQWLEGSPTVDETLYWLGLLVDTKVPLVGHAAQRRHQSLSADGDRNVVDGVKFIASGVALDERGEDRVGACVVVDELVYSARDVTKVDARPGGYEVTGGHGGVVADLGGYGPPQLTYLPTRRHTHRSEVRLTVLPGTVTGVMGSLGGGVTRAEVRTKDADGLVPTAMPHVSITKYSRYAATGTGADDPPVAEEEVEILARIDANLARFPLAGFVCEGMSPFGMADPMKNAALGVAVFAGMPVVRTGRGTTGGMAYRTDPAFVSGNNLTATKARMLLMAALLRFGALPPAADPFDPTPDERAATEKAVAQYQSLFDTH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACGGGCGACATGCGGGCGGCCGGCGTCCCGCGCCCCAGGATCGCCGTCTTCGCCGGCCCGACCGCGACGATCCTGAACACCCCGGACCTCGTCACGTCCAACAAGGCACGCGCACGTCACGGCCTGCCGCTCCGGCCCGGCCGCTTCGACGCCCTGCGCCCCCAACGCCTCGCGGCGCCCGCGACGTTGTACGTCGAGGCCTTCAGCGCCCACCCGCTCGAACAGGACGCCGCCGGCCTGTACGCCCCGCCCGACGGCTGGCTCGACGCGGACGGCACCTTCCACGCCGAGCGGCCGCCCGGCGACGCCAAGCCGGTCCACGTCGTCGAACTCGACCCCGCCGACGGCCTGTACCCCCTTCCCTACATGGCACGGCAGGCGGACGGCTCCGCCTGGGAGGAGACCTCGGCAGCGCCGTACGCGGATCCGGCCGGCGCACGGCAGACCTTCCACCCGGACGCCCGGCGCCTCTACGAGGAGATCGAGCGGTTCGGCCTCGCCGACCACGGCGGTCCCGTGGAGCTGGGTTCCGTCGCCGACTTCGAGTTCTTCCGCGCGGCACCCTCGGGCGGGTACACCTCGGGTCCCGCTTCCGAGCGCCTGGGACGGGACTTCTTCGTCTACTACCCCTACCACCTCCAGACCGAGCCGAGCCTCGCGCACCTGGCCCTGGCCACCAATCACGTCCAAGAGGTCCTCGGCTCGGGCGAGTTCACCGGCGCGCAGTGGCTGGAGGGAAGCCCGACCGTCGACGAGACCCTGTACTGGCTCGGACTCCTCGTCGACACCAAGGTGCCGCTCGTCGGACACGCCGCGCAGCGTCGCCACCAGTCGCTGAGCGCCGACGGCGACCGCAACGTGGTGGACGGCGTCAAGTTCATCGCCTCCGGGGTCGCCCTGGACGAACGGGGTGAGGACCGCGTCGGTGCCTGCGTCGTCGTCGACGAACTCGTCTACTCGGCCCGGGACGTGACCAAGGTCGACGCCCGTCCGGGCGGTTACGAGGTCACCGGTGGCCACGGGGGAGTCGTCGCCGACCTCGGCGGCTACGGCCCGCCCCAGCTCACCTACCTGCCCACCCGCAGGCACACCCACCGTTCCGAGGTGCGCCTCACGGTGCTGCCCGGGACCGTGACCGGCGTCATGGGGAGCCTCGGCGGCGGCGTGACCCGGGCCGAGGTCCGGACCAAGGACGCCGACGGGCTGGTACCCACGGCCATGCCGCACGTCTCGATCACCAAGTACAGCAGGTACGCGGCGACGGGCACGGGCGCCGACGACCCGCCCGTCGCCGAGGAGGAGGTCGAGATCCTCGCCCGGATCGACGCCAACCTCGCGCGGTTCCCGCTCGCGGGCTTCGTGTGCGAGGGGATGTCCCCCTTCGGGATGGCCGACCCGATGAAGAACGCGGCGCTGGGCGTCGCCGTCTTCGCCGGCATGCCCGTGGTCCGCACCGGGCGCGGCACCACCGGAGGCATGGCGTACCGCACCGACCCCGCCTTCGTCTCCGGCAACAACCTGACGGCCACCAAGGCACGCATGCTCCTCATGGCCGCGCTGCTCAGGTTCGGTGCCCTGCCGCCGGCCGCCGACCCGTTCGACCCGACTCCCGACGAACGCGCCGCCACCGAGAAGGCGGTCGCCCAGTACCAGTCCCTGTTCGACACACACTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 4479,
                "end": 4964,
                "strand": -1,
                "locus_tag": "ctg1_5",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_5</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_5</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 4,479 - 4,964,\n (total: 486 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF04343.13 (Protein of unknown function, DUF488): [13:147](score: 59.9, e-value: 3.6e-16)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VPRLATIGVYGFDVDSYLERLRQADVRLLLDVRQRRGVRGPDYAWANSRRLQAALAEAGIAYEHRRELAPTTELRQLQYAEDARLGVGKRSRSELAAAYTRRYTAEILDPADLGPIVAGLPSRGTTALFCVERDPEACHRSLVARRLSELHDITVEHLRPL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=14964\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VPRLATIGVYGFDVDSYLERLRQADVRLLLDVRQRRGVRGPDYAWANSRRLQAALAEAGIAYEHRRELAPTTELRQLQYAEDARLGVGKRSRSELAAAYTRRYTAEILDPADLGPIVAGLPSRGTTALFCVERDPEACHRSLVARRLSELHDITVEHLRPL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCCCAGACTGGCAACGATCGGCGTCTACGGCTTCGACGTCGATTCCTACCTCGAACGACTGCGGCAGGCAGACGTGCGCCTGCTGCTCGACGTACGACAGCGGCGCGGGGTCCGCGGCCCCGACTACGCCTGGGCCAACTCCCGACGGCTGCAGGCGGCCCTCGCCGAAGCCGGGATCGCGTACGAGCACCGACGGGAACTCGCCCCGACGACCGAACTGCGGCAGCTCCAGTACGCCGAGGACGCCCGCCTGGGCGTCGGCAAGCGCTCCCGCAGCGAGCTCGCCGCCGCGTACACCCGCCGCTACACGGCCGAGATCCTCGATCCGGCCGACCTCGGCCCGATCGTGGCGGGGCTGCCGAGCCGCGGGACCACGGCGCTCTTCTGCGTCGAACGCGACCCGGAGGCATGTCACCGGTCACTGGTCGCCCGCCGGCTCTCCGAACTCCACGACATCACCGTCGAACACCTGAGGCCGCTGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 5032,
                "end": 6042,
                "strand": -1,
                "locus_tag": "ctg1_6",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_6</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_6</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 5,032 - 6,042,\n (total: 1011 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1042:O-methyltransferase (Score: 264.3; E-value: 2.6e-80)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF16864.5 (Dimerisation domain): [10:86](score: 31.9, e-value: 9.7e-08)<br>\n \n  PF00891.18 (O-methyltransferase domain): [108:314](score: 105.4, e-value: 2.4e-30)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00891.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008171' target='_blank'>GO:0008171</a>: O-methyltransferase activity<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTVDVQATRDVVDIITGGWRAQALYTAVRLGLPDHVAAGRDNDAELAKATGASEGGVHRLMRLLVAMEVFTGSDATGYRGTRMSAALVDGPRSLRDMCLLYGEEFYSAWDHAHHAISTESSGFEIAYGRPFYDYLGEAPATARRFRRTMNAASMFFHRVPAVFDFAGKKVVDVGGGGGQLLATVLTAAPTATGTLFDREHMAAKAREHLEAAVGPGRVQVVGGDMFAGVPEGGDVYILCRVLAGHDDEDVVRVFEHCRRGMTDASARLLILDRFVEDENPTVLPALWDLHLLMTTGGEHRTVERITRLLARAGLSVERTAHLPMETTALVALPRTA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=16042\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_6_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTVDVQATRDVVDIITGGWRAQALYTAVRLGLPDHVAAGRDNDAELAKATGASEGGVHRLMRLLVAMEVFTGSDATGYRGTRMSAALVDGPRSLRDMCLLYGEEFYSAWDHAHHAISTESSGFEIAYGRPFYDYLGEAPATARRFRRTMNAASMFFHRVPAVFDFAGKKVVDVGGGGGQLLATVLTAAPTATGTLFDREHMAAKAREHLEAAVGPGRVQVVGGDMFAGVPEGGDVYILCRVLAGHDDEDVVRVFEHCRRGMTDASARLLILDRFVEDENPTVLPALWDLHLLMTTGGEHRTVERITRLLARAGLSVERTAHLPMETTALVALPRTA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACAGTCGACGTGCAGGCCACTCGCGACGTGGTCGACATCATCACCGGTGGGTGGCGGGCGCAGGCGCTCTACACCGCGGTCAGGCTCGGGCTGCCCGACCACGTCGCGGCCGGCCGGGACAACGACGCGGAACTCGCCAAGGCGACAGGGGCGAGCGAGGGCGGCGTGCACCGTCTGATGCGTCTGCTGGTGGCCATGGAGGTCTTCACGGGCAGCGACGCCACCGGCTACCGCGGCACCCGGATGAGCGCGGCCCTCGTCGACGGGCCCCGGTCGCTGCGCGACATGTGCCTGCTGTACGGCGAGGAGTTCTACTCCGCCTGGGACCACGCCCACCACGCCATCAGCACGGAGAGCTCAGGCTTCGAGATCGCCTACGGCCGGCCGTTCTACGACTACTTGGGTGAGGCCCCCGCCACCGCCCGCCGCTTCCGGCGCACCATGAACGCCGCCAGCATGTTCTTCCACCGCGTACCCGCGGTCTTCGATTTCGCGGGCAAGAAGGTCGTGGACGTGGGCGGAGGAGGCGGGCAGCTGCTCGCGACCGTCCTCACGGCCGCGCCCACCGCCACGGGCACGCTGTTCGACCGCGAGCACATGGCCGCCAAGGCCCGCGAGCATCTGGAGGCCGCCGTCGGCCCGGGCCGCGTGCAGGTGGTCGGCGGCGACATGTTCGCCGGGGTCCCGGAGGGAGGCGACGTCTACATCCTGTGCCGGGTCCTGGCGGGCCACGACGACGAGGACGTCGTCCGGGTCTTCGAGCACTGCCGCCGCGGCATGACGGACGCCTCGGCCCGGCTGCTGATCCTCGACCGTTTCGTCGAGGACGAGAACCCCACCGTGCTGCCCGCGCTGTGGGACCTGCATCTGCTCATGACCACCGGGGGCGAGCACCGTACCGTCGAGCGGATCACTCGGCTGCTGGCACGGGCCGGCCTGTCCGTCGAGCGCACCGCGCACCTGCCGATGGAGACGACCGCCCTGGTCGCCCTGCCACGCACCGCGTAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 6165,
                "end": 6611,
                "strand": -1,
                "locus_tag": "ctg1_7",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_7</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_7</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,165 - 6,611,\n (total: 447 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF06983.13 (3-demethylubiquinone-9 3-methyltransferase): [17:142](score: 30.8, e-value: 3.5e-07)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MNDVVRTYSKGHQMASQLNPYLAFDGDARQALEFYHQVLGGTLDLGTYGDFGSAELPDPDKIMHATLTTADGFTLMAWDVPERVPFTPGTNVALYLGGDDPRLREHFEKLSAGGTVTLPLEKQMWGDEAGTLVDRFGITWMVNIRQNA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=16611\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_7_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MNDVVRTYSKGHQMASQLNPYLAFDGDARQALEFYHQVLGGTLDLGTYGDFGSAELPDPDKIMHATLTTADGFTLMAWDVPERVPFTPGTNVALYLGGDDPRLREHFEKLSAGGTVTLPLEKQMWGDEAGTLVDRFGITWMVNIRQNA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAACGACGTCGTCCGCACGTACAGCAAGGGACATCAGATGGCATCCCAGCTCAACCCGTACCTCGCCTTCGACGGCGACGCGCGCCAGGCCCTGGAGTTCTACCACCAGGTCCTCGGCGGCACGCTGGACCTGGGCACCTACGGTGACTTCGGGTCGGCGGAGCTGCCCGACCCCGACAAGATCATGCACGCGACGCTGACCACCGCCGACGGCTTCACGCTGATGGCGTGGGACGTCCCGGAGCGGGTCCCCTTCACACCGGGCACCAACGTCGCCCTCTATCTCGGCGGCGACGATCCGCGCCTGCGCGAGCACTTCGAGAAGCTGTCCGCGGGAGGCACCGTGACCCTGCCCCTCGAGAAACAGATGTGGGGCGACGAGGCCGGCACGCTCGTGGACAGGTTCGGAATCACCTGGATGGTCAACATCCGGCAGAACGCGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 6621,
                "end": 7112,
                "strand": -1,
                "locus_tag": "ctg1_8",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_8</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_8</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 6,621 - 7,112,\n (total: 492 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) phenazine: phzB<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF03284.13 (Phenazine biosynthesis protein A/B): [17:163](score: 243.3, e-value: 7.4e-73)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF03284.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0017000' target='_blank'>GO:0017000</a>: antibiotic biosynthetic process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MGTDHARTEGLHAGPGPRARHRAVVADYMTRKGENRLTRYLLFTEDGSAGLYTSDTGEPVVSVGHEKLKAHGEWSLRMFPDWEWKNVEIFETQDPNRFWVECDGEGRILYPDYPPGYYKNHFLHSFELEDGRIKRQREFMNPFEQLRALGIEVPKINRGGIPT&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=17112\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_8_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MGTDHARTEGLHAGPGPRARHRAVVADYMTRKGENRLTRYLLFTEDGSAGLYTSDTGEPVVSVGHEKLKAHGEWSLRMFPDWEWKNVEIFETQDPNRFWVECDGEGRILYPDYPPGYYKNHFLHSFELEDGRIKRQREFMNPFEQLRALGIEVPKINRGGIPT\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGGAACGGACCACGCCCGGACGGAAGGGCTCCACGCCGGACCCGGCCCGCGCGCCCGGCATCGTGCCGTCGTCGCGGACTACATGACCCGCAAGGGAGAGAACCGGCTCACGCGCTACCTGCTCTTCACCGAGGACGGCAGCGCCGGCCTGTACACGAGCGACACCGGTGAGCCGGTCGTCTCCGTGGGACACGAGAAGCTCAAGGCGCACGGCGAGTGGTCGTTGCGCATGTTCCCCGACTGGGAATGGAAGAACGTCGAGATCTTCGAGACGCAGGACCCGAACCGGTTCTGGGTCGAGTGCGACGGCGAAGGACGGATCCTCTACCCGGACTACCCGCCCGGCTACTACAAGAACCACTTCCTCCACTCCTTCGAACTCGAGGACGGCAGGATCAAGCGGCAGCGGGAGTTCATGAACCCGTTCGAGCAACTGCGCGCGCTGGGCATCGAGGTGCCGAAGATCAACCGGGGCGGGATCCCCACCTAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 7142,
                "end": 8998,
                "strand": -1,
                "locus_tag": "ctg1_9",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_9</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_9</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 7,142 - 8,998,\n (total: 1857 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) Asn_synthase<br>\n \n  biosynthetic-additional (rule-based-clusters) GATase_7<br>\n \n  biosynthetic-additional (smcogs) SMCOG1177:asparagine synthase (glutamine-hydrolyzing) (Score: 615.1; E-value: 2.3e-186)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF13537.6 (Glutamine amidotransferase domain): [47:169](score: 160.1, e-value: 2e-47)<br>\n \n  PF00733.21 (Asparagine synthase): [239:608](score: 286.8, e-value: 3.4e-85)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR01536 (asn_synth_AEB: asparagine synthase (glutamine-hydrolyzing)): [1:545](score: 493.0, e-value: 2.9e-148)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00733.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004066' target='_blank'>GO:0004066</a>: asparagine synthase (glutamine-hydrolyzing) activity<br>\n  \n   PF00733.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006529' target='_blank'>GO:0006529</a>: asparagine biosynthetic process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MCGITGWVSFDRDLTQQRAQLDGMTRTMACRGPDADGMWLDRHAALGHRRLAVIDIEGGTQPMVLPTDDGPVAITYSGEVYNYTELRGELLRRGHRFETRSDTEVVLHGYAEWGEAVAERLNGMFAFAIWDARVEKLVLIRDRMGVKPLYYSATDDGVLFGSEPKAILANPLADRAVDLAGLRELVSFTQTPGSAVWCGMNEVVPGGLLSADRSGLREHRYWTLPTRPHTDDRETTVATVRELLEDIVSRQTVSDVPRCTLLSGGLDSSVITALAAAKLGRPGEHGEAGEKVRSFAVDFVGRENDFVADELRGTTDAPYAREVAAHVGSLHEAIVLDHAAIADPDVRRAVITARDSPLSLGDMDTSLYLLFQAIKEQSTVALSGESADEVFGGYRWFHQPEVQAAQTFPWMAVFVSGARAQVSDRFNADITAALDLPTYIKDRYAEAVREVERAEGESDHEMRMRVMCHLHLTRFVRMLLERKDRISMAVGLEVRVPFCDHRLVEYVYNTPWSLKTFDGREKSLLRAATADLLPRSVLERVKAPYPATLDPHYTGALLQQSKELLTTDDPVFDLVDRDWLEAITRHDPATMPIDVRNGMERVLDLSTWLDVYRPELRL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=18998\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_9_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MCGITGWVSFDRDLTQQRAQLDGMTRTMACRGPDADGMWLDRHAALGHRRLAVIDIEGGTQPMVLPTDDGPVAITYSGEVYNYTELRGELLRRGHRFETRSDTEVVLHGYAEWGEAVAERLNGMFAFAIWDARVEKLVLIRDRMGVKPLYYSATDDGVLFGSEPKAILANPLADRAVDLAGLRELVSFTQTPGSAVWCGMNEVVPGGLLSADRSGLREHRYWTLPTRPHTDDRETTVATVRELLEDIVSRQTVSDVPRCTLLSGGLDSSVITALAAAKLGRPGEHGEAGEKVRSFAVDFVGRENDFVADELRGTTDAPYAREVAAHVGSLHEAIVLDHAAIADPDVRRAVITARDSPLSLGDMDTSLYLLFQAIKEQSTVALSGESADEVFGGYRWFHQPEVQAAQTFPWMAVFVSGARAQVSDRFNADITAALDLPTYIKDRYAEAVREVERAEGESDHEMRMRVMCHLHLTRFVRMLLERKDRISMAVGLEVRVPFCDHRLVEYVYNTPWSLKTFDGREKSLLRAATADLLPRSVLERVKAPYPATLDPHYTGALLQQSKELLTTDDPVFDLVDRDWLEAITRHDPATMPIDVRNGMERVLDLSTWLDVYRPELRL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTGTGGAATCACGGGCTGGGTCTCGTTCGACCGGGATCTGACTCAACAGCGCGCGCAACTGGACGGGATGACCCGGACCATGGCCTGCCGGGGCCCGGACGCCGACGGCATGTGGCTGGACCGGCACGCGGCACTCGGTCATCGCCGGCTGGCGGTCATCGACATCGAGGGCGGCACCCAGCCGATGGTGCTGCCCACGGACGACGGACCGGTGGCGATCACCTACAGCGGTGAGGTCTACAACTACACCGAACTGCGCGGCGAACTGCTGCGCCGCGGCCACCGCTTCGAGACCCGCAGCGACACCGAGGTGGTCCTCCACGGCTATGCGGAGTGGGGCGAGGCGGTCGCCGAACGGCTCAACGGCATGTTCGCCTTCGCGATCTGGGACGCGCGGGTCGAGAAGCTGGTCCTGATCCGCGACCGGATGGGCGTGAAACCGCTCTACTACTCCGCCACCGACGACGGCGTGCTGTTCGGGTCAGAGCCCAAGGCGATCCTCGCCAACCCGCTCGCCGACCGGGCCGTCGACCTCGCCGGGCTGCGGGAGCTGGTCAGTTTCACCCAGACGCCGGGCAGCGCCGTGTGGTGCGGGATGAACGAGGTCGTCCCCGGCGGCCTGCTCTCCGCCGACCGGTCCGGGCTGCGCGAGCACCGTTACTGGACGCTCCCCACCCGCCCGCACACCGACGACCGGGAAACGACCGTCGCCACCGTGCGTGAACTGCTCGAGGACATCGTCAGCCGGCAGACGGTCTCCGACGTCCCCCGCTGCACCCTGCTGTCCGGCGGCCTCGACTCCAGTGTGATCACCGCGCTGGCCGCAGCGAAGCTGGGCCGCCCCGGCGAACACGGCGAGGCCGGCGAGAAGGTCCGCAGTTTCGCGGTGGACTTCGTCGGCCGCGAGAACGACTTCGTCGCCGATGAACTGAGGGGCACCACGGACGCCCCGTACGCCCGGGAGGTGGCAGCGCACGTCGGCTCGCTGCACGAGGCCATCGTCCTCGACCACGCCGCGATCGCCGACCCGGACGTCCGACGGGCCGTCATCACCGCCCGGGACAGCCCTCTCAGCCTCGGCGACATGGACACCTCGCTGTACCTGCTGTTCCAGGCCATCAAGGAACAGTCGACGGTCGCCCTGTCCGGGGAGTCCGCCGACGAGGTCTTCGGCGGGTACCGGTGGTTCCACCAGCCGGAGGTCCAGGCCGCGCAGACCTTCCCCTGGATGGCGGTGTTCGTCAGCGGCGCGCGCGCGCAGGTGTCGGACCGGTTCAACGCCGACATCACCGCCGCGCTCGACCTGCCCACGTACATCAAGGACCGGTACGCCGAGGCGGTCCGGGAGGTGGAGCGCGCCGAGGGCGAGAGCGACCACGAGATGCGCATGCGGGTGATGTGCCACCTGCACCTGACGCGTTTCGTGCGGATGCTGCTGGAGCGCAAGGACCGCATCAGCATGGCCGTCGGTCTGGAGGTCCGGGTGCCCTTCTGCGACCACCGTCTCGTCGAGTACGTCTACAACACCCCGTGGTCGCTGAAGACCTTCGACGGGCGGGAGAAGAGCCTGCTCCGCGCCGCGACCGCCGACCTGCTGCCGCGGTCGGTGCTGGAACGGGTGAAGGCGCCCTACCCGGCCACGCTGGACCCGCACTACACCGGTGCGCTGCTCCAGCAGTCCAAGGAACTGCTGACGACCGACGACCCGGTCTTCGACCTGGTCGACCGCGACTGGCTGGAGGCCATCACCCGGCACGATCCGGCCACCATGCCGATCGACGTCCGCAACGGCATGGAGCGCGTGCTCGACCTGAGCACCTGGCTGGACGTCTACCGGCCCGAACTGCGGCTCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 9042,
                "end": 9662,
                "strand": -1,
                "locus_tag": "ctg1_10",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_10</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_10</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,042 - 9,662,\n (total: 621 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01243.20 (Pyridoxamine 5&#39;-phosphate oxidase): [28:114](score: 50.8, e-value: 1.4e-13)<br>\n \n  PF10590.9 (Pyridoxine 5&#39;-phosphate oxidase C-terminal dimerisation region): [164:206](score: 44.9, e-value: 9.1e-12)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR00558 (pdxH: pyridoxamine 5&#39;-phosphate oxidase): [16:206](score: 150.7, e-value: 9.9e-45)<br>\n \n <br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSAPRPPMTADVFAVPPDDPLQLLRSWFDSAVADAVQQPGALALATVDARRRVSNRIVQVLHVRPAGLVFASHTDSRKGRELAGTPWASGVLYWREVGRQVSVSGPARPLPAGESDALWDARPVSTHPMSVAAHQSAPLLDEEALRERARELGRNGSALPRPDRWTGYLLEPEAVEFWQSEPQDGLHRRLRYEREGSSWLTRRLQP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=19662\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_10_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSAPRPPMTADVFAVPPDDPLQLLRSWFDSAVADAVQQPGALALATVDARRRVSNRIVQVLHVRPAGLVFASHTDSRKGRELAGTPWASGVLYWREVGRQVSVSGPARPLPAGESDALWDARPVSTHPMSVAAHQSAPLLDEEALRERARELGRNGSALPRPDRWTGYLLEPEAVEFWQSEPQDGLHRRLRYEREGSSWLTRRLQP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCGCACCCCGTCCCCCCATGACGGCCGACGTGTTCGCGGTTCCGCCCGACGATCCCCTGCAACTGCTGCGGAGCTGGTTCGACAGCGCCGTCGCGGACGCGGTCCAGCAGCCGGGCGCCCTGGCCCTGGCCACCGTCGACGCCCGCCGCCGGGTCTCCAACCGGATCGTCCAGGTCCTCCACGTGCGTCCGGCCGGCCTGGTGTTCGCCAGCCACACCGACAGCCGCAAGGGACGCGAGCTGGCCGGGACACCTTGGGCGTCCGGCGTCCTGTACTGGCGCGAGGTCGGCCGGCAGGTGAGCGTGAGCGGACCGGCCCGGCCGCTGCCCGCCGGGGAATCGGACGCCCTGTGGGACGCCCGTCCCGTCAGCACGCACCCGATGTCGGTCGCGGCGCACCAGAGCGCGCCGCTGCTCGACGAAGAGGCACTGCGCGAACGTGCCCGTGAACTGGGACGGAACGGCTCGGCGCTGCCCCGCCCGGACCGATGGACCGGCTATCTCCTGGAGCCGGAGGCGGTGGAGTTCTGGCAGTCCGAGCCGCAGGACGGGCTGCACCGAAGACTGCGGTACGAGCGTGAGGGTTCCAGCTGGCTCACCCGCCGGCTCCAACCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 9659,
                "end": 10006,
                "strand": -1,
                "locus_tag": "ctg1_11",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_11</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_11</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 9,659 - 10,006,\n (total: 348 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) thio_amide<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKATISWWDLTRSDQTIESLRVYLRDEGVEPWTEVHGMRLKFWISDRETNRWGAVMLWDTEADLTAPMPPNRATELIGYPPTVRMLSDVEAVVEGLHTGAAAERGLAFDSFGTPS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=0&amp;to=20006\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_11_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKATISWWDLTRSDQTIESLRVYLRDEGVEPWTEVHGMRLKFWISDRETNRWGAVMLWDTEADLTAPMPPNRATELIGYPPTVRMLSDVEAVVEGLHTGAAAERGLAFDSFGTPS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAGCCACCATCTCCTGGTGGGATCTCACCCGGTCGGACCAGACGATCGAGTCGCTCCGCGTCTACCTGCGCGACGAGGGCGTGGAGCCGTGGACGGAGGTCCACGGGATGCGGCTGAAGTTCTGGATCTCCGACCGGGAGACCAACCGCTGGGGCGCCGTGATGCTCTGGGACACGGAGGCCGACCTGACGGCGCCGATGCCCCCGAACCGGGCGACCGAACTCATCGGCTACCCGCCGACCGTCCGCATGCTGTCCGACGTCGAGGCCGTCGTCGAAGGACTGCACACCGGAGCGGCGGCCGAACGCGGCCTGGCCTTCGACAGCTTCGGGACACCGTCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 10003,
                "end": 11907,
                "strand": -1,
                "locus_tag": "ctg1_12",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_12</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_12</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 10,003 - 11,907,\n (total: 1905 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1018:isochorismate synthase (Score: 305.5; E-value: 1.4e-92)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00425.18 (chorismate binding enzyme): [122:387](score: 146.5, e-value: 9.9e-43)<br>\n \n  PF00117.28 (Glutamine amidotransferase class-I): [442:621](score: 70.7, e-value: 1.3e-19)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSASRLLEHVLGSDPGPFALLHRPETLGPDHVDVLLGRLDTPARLADIRSPEAAGRAGEARHETLVLVPHRQIAERGFAVTEDDSPLLAMEVTHQGLITTSEALSALPDEPIALAGGRFDIDDDAYADIVSDVLDREIGTGEGSNFVIKRSFVTGITGYSTRSALSLFRRLLTRESGAYWTFIVHTGTRTFVGATPERHVSLRDGVAAMTPISGTYRYPATGPALPEVLEFLTDGKETDELYMVLDEELKMMARVCRRGGRVKGPYLREMTWLAHTEYTIEGDSDLDPRDVLRETMFAPTVTGSPLENACRVIARHEPAGRGYYGGIVALIGRDAAGAHAMDSAILIRTADIDSSGTDGTADVRVGVGATLVRHSDPEAETAETRTKAAGVLAALGGPERLDVHPLVRQALERRNTTIANFWLDDADKRARPHPVLAGRRALIVDAEDTFSAMLAHQLRAVGLSVTPTRFDEPLHFAGHDLVVMGPGPGDPRQTDHPRMARLTSAVEELLDRRIPFLAVCLSHQLLSRRLGLGIRRRDVPNQGAQREIDLFGSPARVGFYNSFSARALSSRLRCPGVGEVDVCLDADTGEVHALRGPHFASVQFHLESVLTQDSERVLAELLVPLMETTEVLKA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=3&amp;to=21907\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_12_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSASRLLEHVLGSDPGPFALLHRPETLGPDHVDVLLGRLDTPARLADIRSPEAAGRAGEARHETLVLVPHRQIAERGFAVTEDDSPLLAMEVTHQGLITTSEALSALPDEPIALAGGRFDIDDDAYADIVSDVLDREIGTGEGSNFVIKRSFVTGITGYSTRSALSLFRRLLTRESGAYWTFIVHTGTRTFVGATPERHVSLRDGVAAMTPISGTYRYPATGPALPEVLEFLTDGKETDELYMVLDEELKMMARVCRRGGRVKGPYLREMTWLAHTEYTIEGDSDLDPRDVLRETMFAPTVTGSPLENACRVIARHEPAGRGYYGGIVALIGRDAAGAHAMDSAILIRTADIDSSGTDGTADVRVGVGATLVRHSDPEAETAETRTKAAGVLAALGGPERLDVHPLVRQALERRNTTIANFWLDDADKRARPHPVLAGRRALIVDAEDTFSAMLAHQLRAVGLSVTPTRFDEPLHFAGHDLVVMGPGPGDPRQTDHPRMARLTSAVEELLDRRIPFLAVCLSHQLLSRRLGLGIRRRDVPNQGAQREIDLFGSPARVGFYNSFSARALSSRLRCPGVGEVDVCLDADTGEVHALRGPHFASVQFHLESVLTQDSERVLAELLVPLMETTEVLKA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCGCGTCGCGTCTTCTGGAGCACGTGCTGGGCAGCGATCCGGGCCCCTTCGCCCTGCTGCACCGCCCCGAGACCCTGGGCCCGGACCACGTGGACGTCCTGCTGGGCAGGCTCGACACCCCCGCCCGGCTCGCCGACATCCGGTCGCCCGAAGCGGCCGGACGAGCCGGCGAGGCCCGGCACGAGACGCTGGTCCTGGTGCCGCACCGGCAGATCGCGGAGCGGGGCTTCGCCGTCACCGAGGACGACTCCCCGCTGCTGGCCATGGAGGTGACCCATCAGGGGCTGATCACCACCTCCGAGGCGCTTTCCGCCCTCCCCGACGAACCGATCGCCCTGGCCGGGGGACGCTTCGACATCGACGACGACGCCTACGCGGACATCGTCAGCGACGTCCTCGACCGCGAGATCGGCACCGGCGAGGGTTCCAACTTCGTCATCAAACGGTCCTTCGTCACCGGCATCACCGGCTACTCCACGCGCAGCGCCCTCAGCCTCTTCCGCCGCCTGCTCACCCGGGAGAGCGGCGCCTACTGGACGTTCATCGTGCACACCGGCACCCGCACCTTCGTCGGCGCCACACCGGAACGCCACGTCAGCCTGCGCGACGGCGTCGCCGCGATGACCCCGATCAGCGGCACCTACCGCTATCCCGCGACAGGACCGGCCCTGCCGGAGGTGCTGGAGTTCCTCACCGACGGCAAGGAGACCGACGAGCTGTACATGGTCCTCGACGAGGAACTCAAGATGATGGCGCGGGTCTGCCGCCGGGGCGGCCGCGTGAAAGGGCCGTACCTGCGGGAGATGACCTGGCTCGCGCACACCGAGTACACCATCGAGGGTGACAGCGACCTCGACCCCCGGGACGTCCTGCGGGAGACGATGTTCGCTCCCACCGTGACCGGCAGCCCGCTGGAGAACGCCTGCCGGGTGATCGCCCGCCACGAGCCCGCCGGCCGTGGGTACTACGGCGGGATCGTCGCCCTGATCGGCCGCGATGCCGCCGGTGCGCACGCCATGGACTCGGCCATCCTCATCCGTACCGCGGACATCGACAGCTCGGGGACCGACGGCACCGCGGACGTCCGGGTCGGCGTGGGGGCCACCTTGGTCCGGCACTCCGACCCGGAAGCCGAGACCGCGGAGACACGTACGAAGGCGGCGGGCGTCCTCGCGGCCCTGGGAGGCCCGGAGCGGCTCGACGTCCACCCCCTCGTCCGCCAGGCCCTGGAGCGGCGCAACACCACGATCGCGAACTTCTGGCTGGACGACGCGGACAAGCGCGCACGGCCCCATCCGGTGCTGGCCGGCCGCCGGGCGCTGATCGTCGACGCCGAGGACACCTTCAGCGCGATGCTCGCCCATCAGCTTCGCGCCGTCGGGCTGAGCGTGACACCGACCCGCTTCGACGAGCCCCTTCACTTCGCCGGTCACGACCTCGTCGTCATGGGGCCAGGACCCGGCGACCCGAGGCAGACCGACCACCCCAGGATGGCCCGCCTCACCTCGGCCGTGGAGGAACTGCTGGACCGCCGCATCCCCTTCCTCGCCGTGTGCCTGAGCCACCAGCTGCTCAGCCGGCGCCTGGGGCTCGGCATCCGGCGTCGGGACGTGCCGAACCAGGGCGCCCAGCGCGAGATCGACCTGTTCGGCTCGCCCGCCCGGGTCGGCTTCTACAACTCCTTCTCGGCCCGCGCCCTGAGCAGCCGGCTGCGGTGCCCCGGTGTCGGAGAGGTGGACGTCTGCCTCGACGCGGACACGGGCGAGGTGCACGCCCTGCGGGGGCCGCACTTCGCCTCGGTGCAGTTCCACCTCGAATCCGTGCTCACCCAGGACAGCGAGCGGGTCCTGGCGGAGCTGCTCGTACCGCTGATGGAGACCACGGAGGTACTGAAAGCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 11904,
                "end": 12527,
                "strand": -1,
                "locus_tag": "ctg1_13",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_13</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_13</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 11,904 - 12,527,\n (total: 624 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1027:isochorismatase (Score: 277.4; E-value: 1.5e-84)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00857.20 (Isochorismatase family): [32:204](score: 136.7, e-value: 8.8e-40)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00857.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VPGLAPISAYPLPRAADLPPTTARWGLDHNRAALLVHDMQRYFLAPFPPAVRDPLVRHCAQLRRRCAALGVPVFYTAQPGGMTDEERGLLKDFWGPGMRVDPEDRRIVEELTPAPADQVLTKWRYSAFFRSDLLTQLRTRGRDQLIVCGVYAHVGVLATALEAFTNDIQPFLVADALGDFSADYHRLALDYAAERCAVVTTTEEVFR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=1904&amp;to=22527\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_13_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VPGLAPISAYPLPRAADLPPTTARWGLDHNRAALLVHDMQRYFLAPFPPAVRDPLVRHCAQLRRRCAALGVPVFYTAQPGGMTDEERGLLKDFWGPGMRVDPEDRRIVEELTPAPADQVLTKWRYSAFFRSDLLTQLRTRGRDQLIVCGVYAHVGVLATALEAFTNDIQPFLVADALGDFSADYHRLALDYAAERCAVVTTTEEVFR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCCGGGCCTAGCTCCGATATCCGCCTACCCCCTGCCCCGGGCCGCCGATCTGCCGCCCACGACGGCACGTTGGGGACTCGACCACAACCGCGCGGCCCTGCTCGTGCACGACATGCAGAGGTACTTCCTCGCTCCCTTCCCGCCGGCGGTGCGGGATCCGCTCGTGCGTCACTGCGCACAACTGCGCAGGCGGTGCGCCGCACTCGGCGTCCCCGTGTTCTACACCGCGCAGCCCGGAGGCATGACGGACGAGGAACGCGGGCTGCTCAAGGACTTCTGGGGTCCGGGCATGCGCGTCGATCCGGAGGACCGCCGGATCGTCGAGGAACTCACCCCCGCGCCGGCGGACCAGGTACTCACCAAATGGCGCTACAGCGCCTTCTTCCGCTCGGACCTGCTCACCCAGCTGCGCACCCGCGGCCGCGACCAGCTGATCGTCTGCGGGGTGTACGCCCACGTCGGCGTGCTGGCGACCGCACTCGAGGCGTTCACCAACGACATCCAGCCGTTCCTGGTAGCCGACGCCCTCGGTGACTTCTCCGCCGACTACCACCGGCTGGCCCTCGACTACGCAGCCGAACGATGCGCCGTGGTCACCACCACGGAGGAGGTCTTCCGATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 12515,
                "end": 13639,
                "strand": -1,
                "locus_tag": "ctg1_14",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_14</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_14</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 12,515 - 13,639,\n (total: 1125 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01474.16 (Class-II DAHP synthetase family): [1:136](score: 148.9, e-value: 1.6e-43)<br>\n \n  PF01474.16 (Class-II DAHP synthetase family): [149:354](score: 256.9, e-value: 2.6e-76)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01474.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003849' target='_blank'>GO:0003849</a>: 3-deoxy-7-phosphoheptulonate synthase activity<br>\n  \n   PF01474.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009073' target='_blank'>GO:0009073</a>: aromatic amino acid family biosynthetic process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VRNMLAELPGLVDPASLDRLRNRLAAVAAGQALVVQAGDCAEDFAECTAGDVKRRADLLDVLAGVMNEITHRPVIKVGRIGGQYAKPRSATTETVAGVELPVYRGHMVNGAEPDPEARRPDPRRLLTGYHAAHQVFAHLCPTPRDRVDPAVWTSHEALLLDYEVPMVRADREGRLALTSTHWPWIGERTRQPDGAHVALLSEVVNPVACKIGPRTTTTELLDLCARLDPARTPGRLTLIARMGAGAAAELLPPLVRAVRTAGHPVIWLADPMHGNTVTTAEGRKTRVVETVVREVTAFQDAVRSAGATPGGIHLETTPDAVTECADVPEATDHIGDKYTSLCDPRLNPRQAISVVSAWQPQSTTNRAEGESCRA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=2515&amp;to=23639\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_14_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VRNMLAELPGLVDPASLDRLRNRLAAVAAGQALVVQAGDCAEDFAECTAGDVKRRADLLDVLAGVMNEITHRPVIKVGRIGGQYAKPRSATTETVAGVELPVYRGHMVNGAEPDPEARRPDPRRLLTGYHAAHQVFAHLCPTPRDRVDPAVWTSHEALLLDYEVPMVRADREGRLALTSTHWPWIGERTRQPDGAHVALLSEVVNPVACKIGPRTTTTELLDLCARLDPARTPGRLTLIARMGAGAAAELLPPLVRAVRTAGHPVIWLADPMHGNTVTTAEGRKTRVVETVVREVTAFQDAVRSAGATPGGIHLETTPDAVTECADVPEATDHIGDKYTSLCDPRLNPRQAISVVSAWQPQSTTNRAEGESCRA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCGGAACATGCTGGCGGAGCTGCCCGGGCTGGTGGATCCGGCATCACTCGACCGGCTCAGGAATCGTCTGGCCGCGGTAGCCGCCGGGCAGGCGCTGGTGGTGCAAGCGGGGGACTGCGCCGAAGACTTCGCCGAATGCACCGCGGGGGACGTGAAGCGGAGGGCGGATCTCCTCGACGTGCTCGCCGGCGTCATGAACGAGATCACCCACCGGCCGGTCATCAAGGTCGGCCGGATCGGAGGTCAGTACGCCAAGCCGCGGTCGGCGACCACCGAAACGGTGGCCGGTGTCGAACTCCCCGTCTACCGGGGGCACATGGTGAACGGCGCCGAGCCGGACCCCGAGGCGAGGCGACCCGACCCCCGACGTCTGCTGACCGGTTACCACGCCGCCCACCAGGTGTTCGCCCACCTCTGCCCGACCCCGCGGGACCGCGTCGACCCCGCGGTGTGGACCAGTCACGAGGCGCTGCTCCTCGACTACGAGGTTCCGATGGTACGGGCCGACCGGGAAGGCAGGCTCGCGCTCACCTCGACCCACTGGCCGTGGATCGGCGAGCGGACCCGGCAGCCCGACGGAGCCCACGTCGCGTTGCTGTCCGAGGTGGTGAATCCGGTGGCCTGCAAGATCGGTCCCCGCACGACGACCACGGAGCTGCTCGATCTCTGCGCCCGGCTCGACCCCGCGAGGACGCCGGGCAGGCTCACCCTGATCGCACGGATGGGTGCCGGCGCGGCGGCGGAGCTGCTGCCGCCCCTGGTCCGGGCCGTCCGAACCGCCGGGCATCCGGTGATCTGGCTGGCCGACCCCATGCACGGGAACACCGTGACCACCGCGGAGGGACGCAAGACCCGCGTCGTGGAGACCGTCGTCCGTGAGGTCACCGCCTTCCAGGACGCCGTCCGCTCGGCCGGCGCGACCCCGGGCGGGATCCACCTGGAGACCACGCCGGACGCGGTGACCGAGTGCGCCGACGTCCCGGAGGCCACCGACCACATCGGGGACAAGTACACGTCGCTGTGCGATCCGCGGCTCAACCCTCGCCAGGCGATCTCGGTGGTGTCGGCCTGGCAGCCGCAGTCCACCACGAACCGAGCCGAGGGAGAGTCGTGCCGGGCCTAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 13988,
                "end": 14635,
                "strand": -1,
                "locus_tag": "ctg1_15",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_15</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_15</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 13,988 - 14,635,\n (total: 648 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSKIKHTLPIAAAAIVMTAGSIAGPGMIVTEPAVAEASTVTKGASAGEAPSAVRAASVESGSKARPGARAAATSPEQLLKMLGERIVAKDIDGIIALHEPEAAIVDWDGSVIRGRAAIRTFYLEWFASNPVLTVNPRQTVIAGGWRAWDNKVRQRTAAIMGDYSLEQDAADGTRESFTGNFCDTVQEQLDGTWLYVQDNPYPPHGDAAASRTAHH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=3988&amp;to=24635\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSKIKHTLPIAAAAIVMTAGSIAGPGMIVTEPAVAEASTVTKGASAGEAPSAVRAASVESGSKARPGARAAATSPEQLLKMLGERIVAKDIDGIIALHEPEAAIVDWDGSVIRGRAAIRTFYLEWFASNPVLTVNPRQTVIAGGWRAWDNKVRQRTAAIMGDYSLEQDAADGTRESFTGNFCDTVQEQLDGTWLYVQDNPYPPHGDAAASRTAHH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGTAAGATCAAACACACGCTTCCGATAGCCGCCGCGGCCATTGTGATGACGGCCGGAAGTATCGCCGGTCCGGGAATGATCGTGACCGAGCCGGCGGTCGCGGAGGCGTCCACCGTCACCAAGGGTGCGTCCGCGGGCGAAGCGCCGTCGGCGGTCAGGGCGGCTTCCGTGGAGTCCGGCTCCAAGGCCAGGCCGGGGGCCCGAGCTGCGGCCACGTCCCCCGAGCAGCTGCTGAAGATGCTCGGCGAGCGCATCGTGGCCAAGGACATCGACGGCATCATCGCGCTCCATGAACCCGAGGCGGCCATCGTCGACTGGGACGGATCCGTCATCCGTGGCCGTGCGGCGATCCGTACGTTCTACCTCGAGTGGTTCGCGTCGAACCCGGTGCTCACCGTCAACCCCCGCCAGACCGTGATCGCGGGCGGCTGGCGTGCGTGGGACAACAAGGTGCGCCAGCGCACGGCGGCCATCATGGGCGACTACAGCCTGGAGCAGGACGCGGCGGACGGCACCCGGGAGAGCTTCACCGGTAATTTCTGCGACACCGTCCAGGAACAGCTGGACGGCACCTGGCTCTATGTGCAGGACAATCCATACCCTCCCCACGGGGATGCGGCCGCCTCGAGGACGGCCCATCACTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 14836,
                "end": 15060,
                "strand": 1,
                "locus_tag": "ctg1_16",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_16</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_16</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 14,836 - 15,060,\n (total: 225 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPPSLPAHHVHSGTPTGGVAAPDPPDRPSPSVRRKRLAGHQRVKKEESEIPSPALVVQLKIKITAQRCSGHVNG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=4836&amp;to=25060\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPPSLPAHHVHSGTPTGGVAAPDPPDRPSPSVRRKRLAGHQRVKKEESEIPSPALVVQLKIKITAQRCSGHVNG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCACCGTCACTGCCTGCGCATCACGTGCACAGCGGAACGCCGACCGGCGGCGTTGCGGCACCGGACCCCCCGGACCGGCCATCACCGAGCGTCAGAAGAAAGCGCCTCGCAGGCCACCAGAGAGTAAAGAAAGAGGAAAGCGAGATTCCATCACCCGCCTTAGTGGTTCAACTCAAAATTAAAATCACGGCTCAACGATGTTCCGGCCACGTGAATGGCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 15370,
                "end": 15744,
                "strand": 1,
                "locus_tag": "ctg1_17",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_17</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_17</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,370 - 15,744,\n (total: 375 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VATVEVSLKDIMTVVEGALGAAVVDYSSGMALGTLGGGKDLDLTVAAAGNTDVIRAKVRTMELLGLTGQIEDILITLESQYHLIRLVTGRSGNGLFLYLVLDKSRSNLAMARHQLKRIEEQLEV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=5370&amp;to=25744\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VATVEVSLKDIMTVVEGALGAAVVDYSSGMALGTLGGGKDLDLTVAAAGNTDVIRAKVRTMELLGLTGQIEDILITLESQYHLIRLVTGRSGNGLFLYLVLDKSRSNLAMARHQLKRIEEQLEV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGGCAACTGTGGAAGTGTCGCTGAAGGACATCATGACCGTCGTCGAAGGAGCCCTGGGAGCGGCCGTCGTCGACTACTCGAGCGGCATGGCGCTGGGAACGCTGGGCGGGGGGAAGGACCTGGACCTCACCGTCGCGGCGGCCGGCAACACGGATGTGATCCGCGCCAAGGTGCGCACGATGGAACTGCTGGGCCTCACCGGCCAGATCGAGGACATCCTCATCACGCTGGAGTCCCAGTACCACCTGATCCGCCTGGTCACCGGCCGCAGCGGCAACGGGCTGTTCCTGTACCTCGTGCTGGACAAGTCCCGCTCGAACCTGGCGATGGCCCGCCACCAGCTCAAGCGGATCGAGGAACAGCTGGAAGTGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 15948,
                "end": 16313,
                "strand": 1,
                "locus_tag": "ctg1_18",
                "type": "regulatory",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_18</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_18</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 15,948 - 16,313,\n (total: 366 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1058:ArsR family transcriptional regulator (Score: 60.5; E-value: 1.9e-18)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01022.20 (Bacterial regulatory protein, arsR family): [17:62](score: 33.7, e-value: 2.3e-08)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01022.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity<br>\n  \n   PF01022.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of transcription, DNA-templated<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MQVPLYQAKAEFFRMLGHPVRIRVLELLQHGPVPVRDLLADIDIEPSSLSQQLAVLRRSGIVVSVREGSTVTYALAGGDVAELLRAARRILTELLAGQSELLAELRQVDVPVPTASASGDG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=5948&amp;to=26313\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_18_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MQVPLYQAKAEFFRMLGHPVRIRVLELLQHGPVPVRDLLADIDIEPSSLSQQLAVLRRSGIVVSVREGSTVTYALAGGDVAELLRAARRILTELLAGQSELLAELRQVDVPVPTASASGDG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCAAGTCCCCCTCTACCAGGCCAAGGCAGAGTTCTTCCGGATGCTGGGGCACCCGGTGCGCATCCGGGTCCTGGAGCTGTTGCAGCACGGGCCCGTGCCGGTGCGGGACCTGCTCGCCGACATCGACATCGAGCCGTCCAGCCTGTCGCAGCAGTTGGCCGTGCTACGCAGGTCCGGCATCGTCGTCTCGGTACGGGAGGGCTCCACCGTGACCTACGCCCTCGCGGGCGGCGACGTCGCCGAACTGCTCCGCGCGGCCCGCAGGATCCTCACGGAACTCCTGGCCGGGCAGAGCGAGCTGCTGGCGGAGCTGCGGCAGGTCGACGTGCCGGTGCCGACGGCGTCCGCGAGCGGGGACGGTTAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 16383,
                "end": 18746,
                "strand": -1,
                "locus_tag": "ctg1_19",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_19</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_19</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 16,383 - 18,746,\n (total: 2364 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF04434.17 (SWIM zinc finger): [505:525](score: 25.0, e-value: 1e-05)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF04434.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTPRPSEEAREALRAARARVTGGEGPGQERPASEDAFARGGRAEGEPSRDGSRSGPLDESRDGAPGESRGGSSAGEEPSPVREASPAPSAPRPSDAAREALQRALRARRGASAETRPEPRSRPRPEPHPEPRPGPESGAEVSAEAADEPRPAADAVAGEVTGEVPPYADSTATGAMEATDTTEDTAAEGSSPAEGGTPAATGPDAAETPAPPPAPADNADSAPGADVTPPTTGDGTEPSAHRPGDIAREALRAAREEAARARAREQVDEAKRTRRAQAPAPRVPRTTRGDREADRRAREIRETLADAFRMPDTTDDPAPDAPADVPSGRPDAQPPAREDTAPGTARGTRTTGEPAAAPPVAPSSMAAPARDGDLRRTFPPFPPRSSDGAEQFAETWWGRAWVTALEDGALDPARLARGRGYAEQGHVDAITVTPGLVLAYVRGSRARPYRVQVRLRTFDDADWERFLDAAADRPGHIAALLDKEMPQSLADCGVPLLPGPGDLAPRCSCPDSGHPCKHAAALCYQTARLLDADPFVLLLLRGRSERQVIDALSRLSAARAARAAQNREPEPLPGIRATDALSRRGPGLPPPPAPLPPPPHPEQPPVYPASPGGPDPFALDQLATDAAARAHALLTTGRDPVGPLTLWHDAVRLAAARPGSGLTAGTRALYSSLARAAGRTPGDLARAVAAWRQGGPTGLAVLEEPWDPPAGRFDRARPLLLAADLPAFRPWRNRLTHPRGHVQLRLGRDHLWYAYESEPDQDDWWPRGTPDPDPVGALTGLDTLGDL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=6383&amp;to=28746\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_19_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTPRPSEEAREALRAARARVTGGEGPGQERPASEDAFARGGRAEGEPSRDGSRSGPLDESRDGAPGESRGGSSAGEEPSPVREASPAPSAPRPSDAAREALQRALRARRGASAETRPEPRSRPRPEPHPEPRPGPESGAEVSAEAADEPRPAADAVAGEVTGEVPPYADSTATGAMEATDTTEDTAAEGSSPAEGGTPAATGPDAAETPAPPPAPADNADSAPGADVTPPTTGDGTEPSAHRPGDIAREALRAAREEAARARAREQVDEAKRTRRAQAPAPRVPRTTRGDREADRRAREIRETLADAFRMPDTTDDPAPDAPADVPSGRPDAQPPAREDTAPGTARGTRTTGEPAAAPPVAPSSMAAPARDGDLRRTFPPFPPRSSDGAEQFAETWWGRAWVTALEDGALDPARLARGRGYAEQGHVDAITVTPGLVLAYVRGSRARPYRVQVRLRTFDDADWERFLDAAADRPGHIAALLDKEMPQSLADCGVPLLPGPGDLAPRCSCPDSGHPCKHAAALCYQTARLLDADPFVLLLLRGRSERQVIDALSRLSAARAARAAQNREPEPLPGIRATDALSRRGPGLPPPPAPLPPPPHPEQPPVYPASPGGPDPFALDQLATDAAARAHALLTTGRDPVGPLTLWHDAVRLAAARPGSGLTAGTRALYSSLARAAGRTPGDLARAVAAWRQGGPTGLAVLEEPWDPPAGRFDRARPLLLAADLPAFRPWRNRLTHPRGHVQLRLGRDHLWYAYESEPDQDDWWPRGTPDPDPVGALTGLDTLGDL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACACCCCGGCCGTCGGAGGAGGCACGGGAGGCGCTGCGCGCGGCTCGGGCACGGGTGACCGGGGGAGAGGGGCCGGGGCAGGAGCGCCCGGCCTCCGAGGATGCGTTCGCGCGAGGCGGCCGGGCGGAGGGGGAGCCTTCGCGGGACGGGTCACGGAGCGGGCCGCTGGACGAGTCGCGGGATGGGGCGCCGGGAGAGTCGCGGGGCGGGTCGTCAGCGGGGGAGGAGCCGTCGCCGGTCCGGGAGGCGTCCCCGGCGCCCTCGGCCCCGCGTCCGTCCGACGCGGCCCGTGAGGCCCTCCAGCGTGCGCTGCGGGCACGGCGGGGTGCGTCCGCCGAGACGCGACCCGAGCCGCGCTCCAGGCCGCGACCCGAGCCGCACCCCGAGCCGCGCCCCGGGCCGGAGTCCGGCGCCGAGGTCTCCGCCGAGGCGGCCGACGAGCCGCGGCCGGCCGCGGACGCGGTGGCCGGTGAAGTGACGGGCGAGGTGCCCCCGTACGCGGACTCGACGGCCACGGGTGCCATGGAGGCCACGGACACCACGGAGGACACGGCGGCCGAGGGTTCGTCCCCTGCCGAGGGAGGAACACCCGCCGCGACGGGACCGGACGCAGCCGAGACCCCCGCCCCCCCCCCCGCCCCGGCGGACAACGCCGACTCCGCGCCCGGAGCGGATGTCACGCCCCCCACCACCGGCGACGGCACGGAGCCGTCGGCCCACCGCCCCGGTGACATCGCCCGGGAGGCGCTGCGCGCCGCACGGGAGGAAGCCGCGCGGGCCCGCGCCCGCGAGCAGGTGGACGAGGCCAAGCGCACCCGACGGGCGCAGGCCCCCGCGCCCCGGGTTCCGCGCACCACGCGCGGCGACCGTGAAGCCGACCGCCGCGCGCGGGAGATCCGGGAAACCCTCGCCGACGCCTTCCGCATGCCCGACACGACGGACGACCCGGCCCCGGACGCACCCGCCGACGTACCCAGCGGCAGGCCGGATGCACAGCCGCCGGCCCGTGAGGACACCGCACCCGGGACGGCGCGAGGCACACGAACCACCGGCGAACCGGCGGCGGCGCCTCCCGTCGCCCCGTCCTCCATGGCCGCCCCCGCGCGGGACGGTGACCTGCGCCGTACCTTCCCGCCGTTCCCGCCCCGCTCCTCGGACGGCGCCGAGCAGTTCGCCGAGACCTGGTGGGGCAGGGCGTGGGTCACCGCGCTGGAGGACGGCGCGCTGGACCCCGCCCGGCTCGCCCGCGGACGCGGCTACGCCGAACAGGGACACGTCGACGCCATCACCGTCACGCCCGGCCTGGTCCTCGCGTACGTCCGGGGCAGCCGTGCCCGGCCCTACCGGGTGCAGGTGCGGCTGCGGACGTTCGACGACGCCGACTGGGAGCGGTTCCTGGACGCCGCCGCCGACCGCCCCGGCCACATCGCGGCACTGCTGGACAAGGAGATGCCGCAGTCCCTCGCCGACTGCGGGGTCCCGCTGCTGCCGGGCCCCGGCGACCTCGCCCCACGGTGCAGCTGTCCCGACTCCGGGCACCCTTGCAAGCACGCGGCGGCCCTCTGCTACCAGACCGCCCGGCTGCTCGACGCGGACCCGTTCGTGCTGCTCCTGCTGCGCGGGCGGAGCGAGCGCCAGGTGATCGACGCGCTGTCCCGGCTCAGCGCGGCCCGCGCCGCCCGCGCCGCCCAGAACAGGGAACCGGAGCCGCTGCCCGGCATACGGGCCACCGACGCCCTGTCCCGGCGCGGGCCCGGACTCCCGCCGCCACCCGCGCCGTTGCCCCCGCCGCCGCACCCGGAGCAGCCCCCCGTCTACCCCGCGTCGCCCGGCGGACCCGACCCGTTCGCGCTGGACCAGCTCGCCACCGACGCCGCCGCCCGCGCACACGCCCTGCTCACCACCGGCCGTGACCCGGTCGGCCCACTCACCCTGTGGCACGACGCGGTGCGACTGGCCGCCGCCCGCCCCGGCTCCGGACTGACCGCGGGCACCCGCGCGCTGTACTCCTCCCTCGCCCGGGCCGCCGGCCGCACCCCCGGCGACCTGGCGCGGGCGGTGGCGGCATGGCGCCAGGGAGGCCCGACCGGGCTGGCCGTGCTGGAGGAGCCGTGGGATCCCCCGGCCGGCCGCTTCGACCGCGCCCGCCCGCTGCTGCTCGCCGCCGACCTGCCCGCCTTCCGGCCCTGGCGCAACCGCCTCACCCACCCCCGCGGCCATGTCCAGCTCCGCCTCGGCCGCGACCACCTCTGGTACGCGTACGAGTCGGAGCCGGACCAGGACGACTGGTGGCCCCGGGGCACCCCCGACCCGGACCCGGTCGGCGCCCTGACCGGCCTCGACACCCTCGGCGACCTCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 18743,
                "end": 21610,
                "strand": -1,
                "locus_tag": "ctg1_20",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_20</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_20</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 18,743 - 21,610,\n (total: 2868 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF12419.8 (SNF2 Helicase protein): [318:447](score: 113.2, e-value: 7.8e-33)<br>\n \n  PF00176.23 (SNF2 family N-terminal domain): [509:765](score: 167.1, e-value: 4.3e-49)<br>\n \n  PF00271.31 (Helicase conserved C-terminal domain): [783:895](score: 59.2, e-value: 4.4e-16)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00176.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSEATVTAVSGTSDGRVASSRLPAVFLPAPLPRDGRIAFYDPEGADTPSQEGDGDRRTDLTVVRPHGAGARRRTVPALSLPVDEALPLLVAARYDPAAHPATACWGAAALHALRLTARGRLLPGLTAEGYDAWRAGPLEPDDVAHLRAVAAALPYEGHAVPLPGPGPLRLPTPEALVRAFLDAVADALPRTPAAPYASGLPFAARRPQRLPDARDWAAEVAAGMDAGVRISLRLDLSAHDLFDSGETAGGEGGGARGAGAAIVQVHSLSDPTLVADAAALWSGEADHGFGPRARVDAALAVRRAARVWPPLDRLADQDVPDVLALSEDELSDLLGVAATRLAAAGVAVHWPRDLAQDLTATAVVRPAPGSATDGTGFFESEDLLRFGWQIALGGDPLGEAEMDALAEAHRPVVRLRDQWVLVDPALVRKARKRDLGLLDPVDALSVALTGEAEVDGETVQAVPAGTLAALRDRLTAGVRPAAPPPGLDATLRDYQLRGLAWLDLMTSLGLGGCLADDMGLGKTVTLIALHLKRARPEPTLVVCPASLLGNWQREITRFAPGVPVRRFHGPDRTLEELDGGFVLTTYGTMRSAAPTLAEQRWGMVVADEAQHVKNPHSATAKALRTIPAPARVALTGTPVENNLSELWALLDWTTPGLLGPLKSFRARHARAVETGEDEQAVERLARLVRPFLLRRKKSDPGIVPELPPKTETDHPVPLTREQAALYEAVVRESMVAIETAQGMGRRGLVLKLLTALKQICDHPALYLKEEHAPAGDGLAARSGKLALLDELLDTVLAEDGSALVFTQYVGMARLITRHLAERAVPVDLLHGGTPVPERERMVDRFQSGAVPVLVLSLKAAGTGLNLTRAGHVVHFDRWWNPAVEEQATDRAYRIGQTQPVQVHRLVTEGTVEDRIAEMLQSKRALADAILGSGESALTELSDRDLSDLVSLRRSA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=8743&amp;to=31610\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_20_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSEATVTAVSGTSDGRVASSRLPAVFLPAPLPRDGRIAFYDPEGADTPSQEGDGDRRTDLTVVRPHGAGARRRTVPALSLPVDEALPLLVAARYDPAAHPATACWGAAALHALRLTARGRLLPGLTAEGYDAWRAGPLEPDDVAHLRAVAAALPYEGHAVPLPGPGPLRLPTPEALVRAFLDAVADALPRTPAAPYASGLPFAARRPQRLPDARDWAAEVAAGMDAGVRISLRLDLSAHDLFDSGETAGGEGGGARGAGAAIVQVHSLSDPTLVADAAALWSGEADHGFGPRARVDAALAVRRAARVWPPLDRLADQDVPDVLALSEDELSDLLGVAATRLAAAGVAVHWPRDLAQDLTATAVVRPAPGSATDGTGFFESEDLLRFGWQIALGGDPLGEAEMDALAEAHRPVVRLRDQWVLVDPALVRKARKRDLGLLDPVDALSVALTGEAEVDGETVQAVPAGTLAALRDRLTAGVRPAAPPPGLDATLRDYQLRGLAWLDLMTSLGLGGCLADDMGLGKTVTLIALHLKRARPEPTLVVCPASLLGNWQREITRFAPGVPVRRFHGPDRTLEELDGGFVLTTYGTMRSAAPTLAEQRWGMVVADEAQHVKNPHSATAKALRTIPAPARVALTGTPVENNLSELWALLDWTTPGLLGPLKSFRARHARAVETGEDEQAVERLARLVRPFLLRRKKSDPGIVPELPPKTETDHPVPLTREQAALYEAVVRESMVAIETAQGMGRRGLVLKLLTALKQICDHPALYLKEEHAPAGDGLAARSGKLALLDELLDTVLAEDGSALVFTQYVGMARLITRHLAERAVPVDLLHGGTPVPERERMVDRFQSGAVPVLVLSLKAAGTGLNLTRAGHVVHFDRWWNPAVEEQATDRAYRIGQTQPVQVHRLVTEGTVEDRIAEMLQSKRALADAILGSGESALTELSDRDLSDLVSLRRSA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCGAGGCGACCGTGACGGCGGTGTCCGGGACGAGTGACGGACGCGTCGCGTCGTCGCGCCTCCCGGCCGTGTTCCTGCCCGCACCCCTCCCGCGCGACGGGCGGATCGCCTTCTACGACCCCGAGGGCGCGGACACGCCCTCGCAGGAGGGGGACGGCGACCGGCGTACGGACCTCACCGTCGTCCGGCCGCACGGCGCGGGAGCGCGCCGGCGCACCGTCCCCGCGCTGTCCCTGCCCGTGGACGAGGCCCTGCCCCTGCTCGTCGCCGCCCGGTACGACCCCGCGGCCCACCCGGCCACCGCCTGCTGGGGCGCCGCCGCCCTGCACGCGCTGCGGCTCACCGCCCGTGGGCGCCTGCTGCCCGGCCTCACCGCCGAGGGGTACGACGCCTGGCGGGCCGGCCCGCTCGAACCGGACGACGTGGCACACCTGCGCGCGGTGGCCGCCGCCCTCCCCTACGAGGGCCACGCGGTGCCGCTGCCCGGACCCGGCCCCCTGCGTCTGCCCACGCCCGAGGCGCTCGTCCGTGCCTTCCTGGACGCGGTCGCCGACGCCCTGCCCCGCACCCCCGCCGCCCCCTACGCCTCCGGCCTGCCGTTCGCCGCGCGGCGGCCCCAGCGGCTTCCCGACGCCCGGGACTGGGCCGCCGAGGTCGCCGCCGGCATGGACGCGGGCGTGCGGATCTCGCTCCGCCTCGACCTGTCCGCCCACGACCTCTTCGACTCCGGGGAGACCGCCGGCGGCGAGGGCGGCGGCGCGCGCGGCGCGGGCGCCGCGATCGTGCAGGTGCACAGCCTCTCCGACCCGACGCTGGTGGCCGACGCGGCCGCCCTGTGGTCGGGCGAGGCGGACCACGGCTTCGGGCCGCGCGCCCGGGTGGACGCCGCCCTCGCCGTGCGCCGGGCGGCCCGTGTCTGGCCCCCGCTCGACCGGCTCGCCGACCAGGACGTGCCGGACGTACTGGCCCTGTCCGAGGACGAGTTGAGCGATCTGCTCGGGGTGGCGGCCACCCGGCTGGCGGCGGCCGGCGTCGCCGTGCACTGGCCCCGCGACCTCGCGCAGGACCTCACCGCCACGGCCGTCGTCCGGCCCGCGCCCGGCTCGGCGACCGACGGCACCGGCTTCTTCGAGAGCGAGGACCTGCTGCGCTTCGGCTGGCAGATCGCCCTGGGCGGCGACCCGCTCGGCGAGGCCGAGATGGACGCCCTGGCCGAGGCGCACCGCCCGGTCGTCCGGTTGCGCGACCAGTGGGTGCTGGTCGACCCCGCCCTGGTCCGCAAGGCCCGCAAGCGCGACCTGGGGCTGCTCGATCCCGTCGACGCCCTGTCCGTCGCCCTCACCGGGGAGGCGGAGGTCGACGGCGAGACGGTGCAGGCGGTGCCCGCGGGGACGCTGGCCGCCCTCCGCGACCGCCTGACCGCCGGGGTGCGGCCCGCGGCGCCTCCTCCCGGCCTGGACGCCACCCTGCGCGACTACCAGCTGCGCGGCCTGGCCTGGCTCGACCTCATGACCTCCCTCGGCCTCGGCGGCTGCCTCGCCGACGACATGGGCCTCGGCAAGACCGTCACCCTGATCGCCCTGCACCTGAAGCGGGCCCGCCCCGAACCCACCCTGGTGGTCTGCCCCGCGTCCCTGCTCGGCAACTGGCAGCGGGAGATCACCCGGTTCGCCCCCGGCGTCCCCGTGCGCCGCTTCCACGGCCCGGACCGCACCCTGGAGGAGCTGGACGGCGGTTTCGTCCTCACCACCTACGGCACCATGCGCTCCGCCGCGCCCACTTTGGCGGAACAGCGCTGGGGCATGGTCGTCGCCGACGAGGCGCAGCACGTCAAGAACCCGCACTCGGCGACCGCCAAGGCGCTGCGCACCATCCCGGCCCCGGCCAGGGTCGCCCTCACCGGCACCCCCGTGGAGAACAACCTCTCCGAGCTGTGGGCCCTCCTGGACTGGACGACCCCCGGGCTCCTCGGACCGCTGAAGTCCTTCCGCGCCCGTCACGCGCGCGCGGTGGAGACCGGCGAGGACGAGCAGGCGGTCGAGCGGCTGGCCCGGCTCGTCCGCCCCTTCCTGCTCCGGCGCAAGAAGTCCGACCCGGGCATCGTCCCCGAGCTCCCGCCCAAGACGGAGACGGACCACCCGGTGCCGCTCACCCGCGAACAGGCAGCGCTGTACGAGGCGGTGGTGCGCGAGTCGATGGTCGCCATCGAGACCGCGCAGGGCATGGGGCGCCGCGGGCTGGTGCTCAAGCTGCTCACCGCGCTCAAGCAGATCTGCGACCACCCCGCGCTGTACCTGAAGGAGGAACACGCCCCGGCCGGCGACGGCCTCGCCGCCCGCTCCGGCAAACTCGCCCTGCTGGACGAACTGTTGGACACGGTGCTCGCCGAGGACGGCTCGGCCCTCGTCTTCACCCAGTACGTCGGCATGGCCCGCCTGATCACCCGCCACCTCGCCGAGCGCGCCGTCCCGGTCGACCTGCTCCACGGCGGTACGCCGGTGCCCGAGCGGGAGCGGATGGTGGACCGCTTCCAGAGCGGTGCGGTGCCGGTCCTCGTGCTCTCGCTCAAGGCGGCGGGGACGGGACTGAACCTGACCCGGGCGGGTCATGTCGTCCACTTCGACCGCTGGTGGAACCCGGCGGTGGAGGAACAGGCCACCGACCGCGCGTACCGCATCGGCCAGACCCAGCCCGTCCAGGTCCACCGGCTGGTCACCGAGGGCACGGTCGAGGACCGCATCGCGGAGATGCTCCAGTCCAAGCGGGCCCTCGCCGACGCGATCCTCGGCTCGGGCGAGTCCGCGCTCACCGAGCTGTCCGACCGTGATCTGTCCGACCTGGTGTCCCTGCGGAGGTCGGCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 21698,
                "end": 22303,
                "strand": -1,
                "locus_tag": "ctg1_21",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_21</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_21</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 21,698 - 22,303,\n (total: 606 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTGELPPLTGDPGHPGGPGGAGGSQPGEDRRHMIRRRALTLLIIVLLIGVPAGYLVISANQSRASGKDKEAKYSATGLTEGWPSKLQRRIYQVPIPHPAWWVASYETNNWKTSRLYVEFETSDAGLTAFLTSMGMAEKDLKKDRLTIGDRDRDVTGWTFDGPGTWSGLVHEQENPAPTHDVVVNHDKPGYPRVYVVARTVP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=11698&amp;to=32303\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTGELPPLTGDPGHPGGPGGAGGSQPGEDRRHMIRRRALTLLIIVLLIGVPAGYLVISANQSRASGKDKEAKYSATGLTEGWPSKLQRRIYQVPIPHPAWWVASYETNNWKTSRLYVEFETSDAGLTAFLTSMGMAEKDLKKDRLTIGDRDRDVTGWTFDGPGTWSGLVHEQENPAPTHDVVVNHDKPGYPRVYVVARTVP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACGGGCGAGCTTCCCCCGCTGACGGGCGACCCCGGCCACCCCGGCGGGCCGGGCGGCGCGGGCGGGTCGCAGCCGGGCGAGGACCGGCGGCACATGATCCGCCGCCGCGCCCTCACCCTGCTGATCATCGTGCTGCTCATCGGAGTCCCGGCCGGCTACCTGGTGATCTCCGCGAACCAGAGCCGGGCCAGCGGCAAGGACAAGGAGGCGAAGTACTCCGCGACCGGCCTGACCGAGGGCTGGCCGTCCAAGCTCCAGCGCCGCATCTACCAGGTGCCGATACCGCATCCGGCGTGGTGGGTGGCCTCGTACGAGACCAACAACTGGAAGACCAGCCGCCTGTACGTCGAGTTCGAGACCAGCGACGCGGGCCTGACCGCCTTCCTCACCAGCATGGGCATGGCGGAGAAGGACCTGAAGAAGGACCGCCTCACCATCGGCGACCGCGACCGCGACGTCACCGGCTGGACCTTCGACGGACCCGGCACCTGGTCCGGCCTGGTGCACGAGCAGGAGAACCCGGCGCCCACCCACGACGTGGTCGTCAACCACGACAAGCCCGGCTACCCCCGGGTGTACGTCGTGGCCCGCACCGTGCCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 22300,
                "end": 23448,
                "strand": -1,
                "locus_tag": "ctg1_22",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_22</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_22</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 22,300 - 23,448,\n (total: 1149 nt)<br>\n <br>\n \n  other (smcogs) SMCOG1108:ROK family protein (Score: 335.4; E-value: 6.9e-102)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00480.20 (ROK family): [37:348](score: 271.4, e-value: 9.8e-81)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR00744 (ROK_glcA_fam: ROK family protein (putative glucokinase)): [38:348](score: 311.4, e-value: 1.6e-93)<br>\n \n <br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSTYRDFTAPIGSRRATVLRTVGTRERRSHLSAPRVPTVGIDIGGTKVMAGVVDADGNILEKLRTETPDKSKSPKVVEDTIVELVLDLSDRHDVHAVGIGAAGWVDADRNRVLFAPHLSWRNEPLRDRLADRLAVPVLVDNDANSAAWAEWRFGAGSGEDNLVMITLGTGIGGAILEDGKVKRGKYGVAGEFGHMQVVPGGHRCPCGNRGCWEQYSSGNALVREAKELAAADSPVAYGIIEHVKGNIADISGPMITELAREGDAMCIELLQDIGQWLGVGIANLAAALDPSCFVIGGGVSAADDLLIGPARDAFKRQLTGRGYRPEARIVRAQLGPEAGMVGAADLARLVARRFRRAKRRRVERYERYERFAEARRTSSESL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=12300&amp;to=33448\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_22_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSTYRDFTAPIGSRRATVLRTVGTRERRSHLSAPRVPTVGIDIGGTKVMAGVVDADGNILEKLRTETPDKSKSPKVVEDTIVELVLDLSDRHDVHAVGIGAAGWVDADRNRVLFAPHLSWRNEPLRDRLADRLAVPVLVDNDANSAAWAEWRFGAGSGEDNLVMITLGTGIGGAILEDGKVKRGKYGVAGEFGHMQVVPGGHRCPCGNRGCWEQYSSGNALVREAKELAAADSPVAYGIIEHVKGNIADISGPMITELAREGDAMCIELLQDIGQWLGVGIANLAAALDPSCFVIGGGVSAADDLLIGPARDAFKRQLTGRGYRPEARIVRAQLGPEAGMVGAADLARLVARRFRRAKRRRVERYERYERFAEARRTSSESL\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCACCTACCGCGACTTCACCGCCCCCATCGGATCCCGGCGCGCCACCGTCCTGAGAACGGTCGGCACCCGGGAGCGCCGTTCCCACCTGTCGGCCCCCCGGGTCCCGACCGTGGGGATCGACATCGGCGGCACCAAAGTGATGGCGGGCGTCGTGGACGCCGACGGCAACATCCTGGAGAAGCTCCGCACGGAGACCCCGGACAAGTCCAAGAGCCCGAAGGTCGTCGAGGACACCATCGTGGAGCTGGTGCTGGACCTGTCCGACCGGCACGACGTGCACGCCGTCGGCATCGGCGCGGCCGGCTGGGTCGACGCCGACCGCAACCGCGTGCTGTTCGCCCCCCACCTGTCCTGGCGCAACGAACCCCTCCGGGACCGCCTCGCCGACCGCCTCGCCGTCCCGGTCCTCGTCGACAACGACGCCAACTCCGCCGCCTGGGCCGAATGGCGCTTCGGCGCCGGCAGCGGCGAGGACAACCTCGTCATGATCACGCTCGGCACCGGCATCGGCGGCGCGATCCTGGAGGACGGCAAGGTCAAGCGCGGCAAGTACGGCGTCGCCGGCGAGTTCGGCCACATGCAGGTCGTCCCCGGGGGCCACCGCTGCCCGTGCGGCAACCGCGGCTGCTGGGAGCAGTACAGCTCCGGCAACGCCCTGGTCCGCGAGGCAAAGGAACTGGCCGCCGCCGACTCCCCGGTCGCCTACGGGATCATCGAGCACGTCAAGGGCAACATCGCCGACATCAGCGGCCCGATGATCACCGAGCTGGCCCGCGAGGGCGACGCCATGTGCATCGAGCTGCTCCAGGACATCGGCCAGTGGCTCGGCGTGGGCATCGCCAACCTGGCCGCCGCCCTCGACCCCTCCTGCTTCGTCATCGGCGGCGGTGTCTCCGCGGCCGACGACCTGCTCATCGGCCCCGCGCGGGACGCCTTCAAGCGGCAGCTCACCGGCCGCGGCTACCGCCCGGAGGCCCGTATCGTCCGCGCCCAGCTCGGACCCGAGGCCGGCATGGTCGGCGCCGCCGACCTCGCCCGCCTCGTCGCCCGCCGCTTCCGCCGCGCCAAGCGCCGCCGTGTCGAGCGGTACGAGCGCTACGAGCGCTTCGCGGAGGCCCGCCGTACGAGCTCGGAGTCGCTGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 23682,
                "end": 24446,
                "strand": -1,
                "locus_tag": "ctg1_23",
                "type": "regulatory",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_23</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_23</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 23,682 - 24,446,\n (total: 765 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1136:GntR family transcriptional regulator (Score: 247.9; E-value: 1.6e-75)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00392.21 (Bacterial regulatory proteins, gntR family): [24:87](score: 57.7, e-value: 6.6e-16)<br>\n \n  PF07702.13 (UTRA domain): [107:244](score: 136.7, e-value: 4.8e-40)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00392.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity<br>\n  \n   PF00392.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of transcription, DNA-templated<br>\n  \n   PF07702.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF07702.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of transcription, DNA-templated<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VPKPEVDPTVQLELSVDRGSPVPLYFQLSQQLESAIEHGTLTPGTLLGNEIELAARLGLSRPTVRQAIQSLVDKGLLVRRRGVGTQVVHSQVKRPLELSSLYDDLESAGQRPTTAVLVNTMVTASAEVAAALGVTEGTEVHRIERLRSAHGEPIAYLCNYIPPALLDLDTGQLEATGLYRLMRAAGITLHSARQTIGARAATAAEAERLREQPGAPLLTMQRVTFDDTGRAVEYGTHTYRPSRYSFEFQLLVRS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=13682&amp;to=34446\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_23_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VPKPEVDPTVQLELSVDRGSPVPLYFQLSQQLESAIEHGTLTPGTLLGNEIELAARLGLSRPTVRQAIQSLVDKGLLVRRRGVGTQVVHSQVKRPLELSSLYDDLESAGQRPTTAVLVNTMVTASAEVAAALGVTEGTEVHRIERLRSAHGEPIAYLCNYIPPALLDLDTGQLEATGLYRLMRAAGITLHSARQTIGARAATAAEAERLREQPGAPLLTMQRVTFDDTGRAVEYGTHTYRPSRYSFEFQLLVRS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCCGAAACCAGAAGTGGACCCGACCGTGCAGCTGGAGCTCAGCGTGGACCGCGGCTCCCCCGTGCCGTTGTACTTCCAGCTGTCCCAGCAGCTGGAGTCCGCCATCGAGCACGGCACCCTCACTCCCGGCACCCTGCTGGGCAACGAGATCGAGCTGGCCGCACGGCTCGGCCTGTCCCGGCCGACCGTCCGCCAGGCCATCCAGTCGCTCGTCGACAAGGGCCTCCTGGTGCGCCGCCGCGGGGTCGGCACCCAGGTGGTGCACAGCCAGGTCAAACGCCCCCTGGAGCTCAGCAGCCTCTACGACGACCTGGAGTCCGCCGGACAGCGGCCCACCACGGCCGTGCTGGTCAACACCATGGTCACCGCGTCCGCCGAGGTCGCCGCCGCGCTCGGGGTGACGGAGGGCACGGAGGTGCACCGCATCGAACGTCTGCGGTCCGCGCACGGCGAACCCATCGCGTACCTGTGCAACTACATCCCGCCCGCCCTGCTCGACCTGGACACCGGCCAGCTGGAGGCGACCGGCCTGTACCGGCTGATGCGGGCCGCCGGGATCACCCTGCACAGCGCGCGGCAGACCATCGGCGCGCGGGCCGCCACCGCCGCCGAGGCCGAGCGGCTGCGCGAGCAGCCCGGCGCCCCGCTGCTCACGATGCAGCGGGTGACCTTCGACGACACCGGCCGCGCGGTGGAGTACGGCACGCACACCTACCGGCCCTCGCGGTACTCCTTCGAGTTCCAGCTGCTGGTGCGCAGCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 24548,
                "end": 25570,
                "strand": 1,
                "locus_tag": "ctg1_24",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_24</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_24</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 24,548 - 25,570,\n (total: 1023 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1079:oxidoreductase (Score: 200.3; E-value: 8.6e-61)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01408.22 (Oxidoreductase family, NAD-binding Rossmann fold): [0:118](score: 64.9, e-value: 1.1e-17)<br>\n \n  PF02894.17 (Oxidoreductase family, C-terminal alpha/beta domain): [129:227](score: 29.5, e-value: 6.1e-07)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01408.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n   PF02894.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n   PF02894.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055114' target='_blank'>GO:0055114</a>: oxidation-reduction process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRIGVIGTGRIGTIHAHTLSRHREVGSLILTDVDPARAQALAHRLGETAAPGVDEIYTWGVDAVVITAATSAHADLIGRAARAGLPVFCEKPIALDLAGTLQAITEVETAGTVLQMGFQRRFDRGYTGAREAVRAGRLGRLHTVRAMTSDAEPPAPSRLAQSGGLYRDTLIHDFDVLRWVTGREVVDVYAGGSDAGPPMFREAGDVDTGAALLTLDDGTLATVTGTRLNGAGYDVRMELAGELDQIVVGLDDRTPIASTEPTGPPAADKPWTGFLERFGPAYEAELVAFVEVVRGERPNPCDGREALRALLVAEACERSRRERRAVRPAELLSSATEALT&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=14548&amp;to=35570\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_24_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRIGVIGTGRIGTIHAHTLSRHREVGSLILTDVDPARAQALAHRLGETAAPGVDEIYTWGVDAVVITAATSAHADLIGRAARAGLPVFCEKPIALDLAGTLQAITEVETAGTVLQMGFQRRFDRGYTGAREAVRAGRLGRLHTVRAMTSDAEPPAPSRLAQSGGLYRDTLIHDFDVLRWVTGREVVDVYAGGSDAGPPMFREAGDVDTGAALLTLDDGTLATVTGTRLNGAGYDVRMELAGELDQIVVGLDDRTPIASTEPTGPPAADKPWTGFLERFGPAYEAELVAFVEVVRGERPNPCDGREALRALLVAEACERSRRERRAVRPAELLSSATEALT\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCGCATCGGGGTCATCGGTACGGGCCGGATCGGCACCATTCACGCCCACACACTCAGCAGGCACCGCGAGGTCGGGTCCTTGATCCTCACGGACGTCGATCCGGCGCGGGCCCAGGCCCTCGCCCACCGGCTCGGCGAGACGGCGGCGCCGGGGGTGGACGAGATCTACACCTGGGGAGTGGACGCCGTGGTGATCACCGCGGCCACGTCCGCCCACGCCGATCTGATCGGCCGGGCGGCCCGTGCGGGGCTGCCGGTCTTCTGCGAGAAGCCCATCGCCCTGGATCTCGCCGGGACGTTACAGGCGATCACGGAGGTGGAGACCGCCGGGACGGTGCTTCAGATGGGCTTCCAGCGGCGGTTCGACCGGGGATACACGGGCGCCCGTGAGGCGGTGCGGGCGGGCAGGCTGGGGCGGCTGCACACGGTGCGGGCGATGACGAGCGACGCGGAGCCCCCGGCCCCCTCACGTCTGGCGCAGTCCGGCGGGCTGTACCGGGACACACTGATCCACGACTTCGACGTCCTGCGCTGGGTGACCGGCCGGGAGGTCGTGGACGTCTACGCCGGCGGGTCGGACGCCGGTCCCCCGATGTTCCGCGAGGCGGGCGACGTCGACACCGGCGCGGCGCTCCTCACCCTCGACGACGGCACCCTCGCCACGGTCACCGGGACCCGGCTGAACGGCGCCGGCTACGACGTACGCATGGAACTCGCCGGGGAGCTGGACCAGATCGTGGTCGGCCTGGACGACCGTACGCCGATCGCCTCCACGGAACCGACCGGGCCGCCGGCCGCGGACAAGCCGTGGACGGGCTTCCTGGAGCGGTTCGGGCCCGCCTACGAGGCCGAACTGGTCGCGTTCGTGGAGGTGGTGCGGGGCGAGCGGCCCAACCCCTGCGACGGCCGTGAGGCCCTGCGGGCGCTGCTGGTCGCGGAGGCCTGCGAGCGGTCCCGCCGGGAGCGCAGAGCGGTCCGCCCCGCGGAACTGCTGAGCAGCGCCACGGAGGCCCTGACCTAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 25578,
                "end": 26084,
                "strand": -1,
                "locus_tag": "ctg1_25",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_25</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_25</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 25,578 - 26,084,\n (total: 507 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF03061.22 (Thioesterase superfamily): [50:102](score: 27.3, e-value: 3.5e-06)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR00369 (unchar_dom_1: uncharacterized domain 1): [21:102](score: 42.2, e-value: 1.7e-11)<br>\n \n <br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTPPPELDLAAARRLLDAQPFSRLLGARLTDFGDGGATLEIDIREDLHQQNGFLHGGVLAYAADNALTFAAGAVLGPAVLTGGFSVQYLRPATGRALRARARRPRGPAPGRDPLRPAHRGAGRHGDPVRGGPGNGPAGRRQDIVNGFPPGHLGPVPPRHPEPVPVRAP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=15578&amp;to=36084\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTPPPELDLAAARRLLDAQPFSRLLGARLTDFGDGGATLEIDIREDLHQQNGFLHGGVLAYAADNALTFAAGAVLGPAVLTGGFSVQYLRPATGRALRARARRPRGPAPGRDPLRPAHRGAGRHGDPVRGGPGNGPAGRRQDIVNGFPPGHLGPVPPRHPEPVPVRAP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCCCGCCCCCCGAGCTCGACCTCGCCGCCGCACGGCGGCTGCTGGACGCCCAGCCCTTCAGCAGGCTGCTGGGCGCCCGGCTCACGGACTTCGGCGACGGCGGGGCGACCCTGGAGATCGACATCCGCGAGGACCTGCACCAGCAGAACGGCTTCCTGCACGGCGGGGTCCTCGCCTACGCGGCGGACAACGCGCTCACCTTCGCCGCCGGCGCCGTCCTCGGCCCGGCCGTGCTGACCGGCGGGTTCTCCGTCCAGTACCTCCGCCCGGCCACCGGCCGCGCCCTGCGTGCCCGCGCACGTCGTCCACGCGGGCCGGCGCCAGGCCGTGACCCGCTGCGACCTGCTCACCGTGGCGCAGGACGGCACGGAGACCCTGTGCGCGGTGGCCCAGGGAACGGTCCTGCCGGTCGCCGCCAGGACATCGTGAACGGGTTCCCGCCCGGACACCTCGGACCCGTTCCGCCGCGACACCCCGAACCCGTTCCCGTCAGGGCACCGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 26138,
                "end": 26812,
                "strand": -1,
                "locus_tag": "ctg1_26",
                "type": "regulatory",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_26</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_26</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,138 - 26,812,\n (total: 675 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1016:LuxR family DNA-binding response regulator (Score: 183.2; E-value: 6.1e-56)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00072.24 (Response regulator receiver domain): [5:118](score: 93.5, e-value: 8.6e-27)<br>\n \n  PF00196.19 (Bacterial regulatory proteins, luxR family): [157:212](score: 50.6, e-value: 1e-13)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00072.24: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system<br>\n  \n   PF00196.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of transcription, DNA-templated<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTAIRVLLVDDDPLVRAGLSFMLGGAGDIEIVGEAADGGEVGALVDRTRPDVVLMDIRMPSVDGLTATESLRTREDAPQVVVLTTFHADDQVLRALRAGAAGFVLKDTPPTEIVAAVRRVAAGDPVLSPAVTRQLMAHAAGTAGGTRRARARERVTGLNDREREVAVAVGRGLANAEIAAELYMSVATVKTHVSRILAKLGLNNRVQIALLAHDAGLLEETGSS&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=16138&amp;to=36812\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_26_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTAIRVLLVDDDPLVRAGLSFMLGGAGDIEIVGEAADGGEVGALVDRTRPDVVLMDIRMPSVDGLTATESLRTREDAPQVVVLTTFHADDQVLRALRAGAAGFVLKDTPPTEIVAAVRRVAAGDPVLSPAVTRQLMAHAAGTAGGTRRARARERVTGLNDREREVAVAVGRGLANAEIAAELYMSVATVKTHVSRILAKLGLNNRVQIALLAHDAGLLEETGSS\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACTGCGATCCGCGTGCTTCTCGTCGACGACGACCCGCTGGTGCGGGCCGGGTTGTCCTTCATGCTGGGCGGGGCCGGCGACATCGAGATCGTCGGCGAGGCCGCCGACGGCGGCGAGGTGGGGGCGCTCGTCGACCGCACCCGCCCGGACGTCGTCCTCATGGACATCCGGATGCCGTCCGTCGACGGGCTCACCGCGACCGAGTCGCTGCGGACCCGCGAGGACGCCCCCCAGGTCGTGGTGCTGACCACCTTCCACGCCGACGACCAGGTGCTGCGGGCCCTGCGCGCGGGCGCCGCCGGGTTCGTCCTCAAGGACACCCCGCCCACCGAGATCGTCGCCGCGGTACGGCGCGTCGCGGCCGGGGACCCGGTGCTGTCGCCCGCGGTCACCCGGCAGCTGATGGCCCACGCGGCCGGCACCGCCGGCGGCACGCGGCGGGCCCGGGCCCGGGAGCGCGTCACCGGGCTCAACGACCGCGAGCGCGAGGTCGCCGTCGCGGTCGGCCGCGGCCTGGCCAACGCGGAGATCGCCGCCGAGCTGTACATGAGCGTGGCCACCGTCAAGACGCACGTCTCCCGCATCCTGGCCAAGCTCGGCCTGAACAACCGCGTGCAGATCGCCCTGCTCGCCCATGACGCGGGGCTGCTGGAGGAGACCGGGAGCTCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 26871,
                "end": 28121,
                "strand": -1,
                "locus_tag": "ctg1_27",
                "type": "regulatory",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_27</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_27</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 26,871 - 28,121,\n (total: 1251 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1048:sensor histidine kinase (Score: 244.4; E-value: 3.7e-74)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF07730.13 (Histidine kinase): [214:278](score: 53.5, e-value: 2.6e-14)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF07730.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000155' target='_blank'>GO:0000155</a>: phosphorelay sensor kinase activity<br>\n  \n   PF07730.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046983' target='_blank'>GO:0046983</a>: protein dimerization activity<br>\n  \n   PF07730.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system<br>\n  \n   PF07730.13: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016021' target='_blank'>GO:0016021</a>: integral component of membrane<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTDDKAARTAPVFAGPRWFFPSALIHDLDPDAARSGRGPRRTARDWAVDFSCFLLAVLIGLLGAETLDNTPDLPRFVSVADQVLGALSCAAVWLRRRWPFALAAVMVPVSFVSETSGGVAVIALFTLAVHRPFRYVAWVAGVQLALVPLYFWWRPDPDLPYAAAVVLLVVLTVAVVGWGMFVRSKRQLMLSLRDRARRAETEARLRAEQAQRLAREAIAREMHDVLAHRLTLLSVHAGALEFRPDAPREEVARAAGVIRESAHEALQDLREIIGVLRAGESEDGGRPQPTLAALDSLVAESRQAGMKVTLEQRVTDPAGVPASVGRTAYRIAQEGLTNARKHAPGTEVTVSVAGGPGEDLAVTVRNPAPEGDVPAVPGAGQGLIGLTERATLAGGTLEHGPAPDGGFEVRARLPWR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=16871&amp;to=38121\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_27_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTDDKAARTAPVFAGPRWFFPSALIHDLDPDAARSGRGPRRTARDWAVDFSCFLLAVLIGLLGAETLDNTPDLPRFVSVADQVLGALSCAAVWLRRRWPFALAAVMVPVSFVSETSGGVAVIALFTLAVHRPFRYVAWVAGVQLALVPLYFWWRPDPDLPYAAAVVLLVVLTVAVVGWGMFVRSKRQLMLSLRDRARRAETEARLRAEQAQRLAREAIAREMHDVLAHRLTLLSVHAGALEFRPDAPREEVARAAGVIRESAHEALQDLREIIGVLRAGESEDGGRPQPTLAALDSLVAESRQAGMKVTLEQRVTDPAGVPASVGRTAYRIAQEGLTNARKHAPGTEVTVSVAGGPGEDLAVTVRNPAPEGDVPAVPGAGQGLIGLTERATLAGGTLEHGPAPDGGFEVRARLPWR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACTGATGACAAGGCGGCGCGGACCGCCCCGGTGTTCGCGGGGCCCAGGTGGTTCTTCCCGTCCGCCCTCATCCACGACCTCGACCCGGACGCCGCCCGCTCGGGGCGCGGGCCCCGGCGCACCGCCCGCGACTGGGCCGTCGACTTCTCCTGCTTCCTGCTCGCCGTGCTGATCGGGCTGCTCGGCGCGGAGACGCTCGACAACACCCCCGACCTTCCCCGGTTCGTGAGCGTGGCCGACCAGGTGCTGGGCGCGCTGTCCTGCGCCGCGGTCTGGCTGCGCCGGCGGTGGCCGTTCGCCCTGGCCGCCGTCATGGTGCCGGTCAGCTTCGTCTCGGAGACCTCCGGCGGCGTGGCGGTCATCGCCCTGTTCACGCTCGCCGTGCACCGGCCCTTCCGGTACGTGGCCTGGGTGGCAGGCGTCCAGCTGGCGCTCGTACCGCTGTACTTCTGGTGGCGTCCCGACCCGGACCTGCCGTATGCCGCCGCGGTCGTCCTGCTCGTCGTGCTGACGGTCGCCGTCGTCGGCTGGGGCATGTTCGTCCGCTCCAAGCGGCAGCTCATGCTGAGCCTCAGGGACCGCGCCCGGCGGGCCGAGACGGAGGCGCGGCTGCGGGCCGAGCAGGCGCAGCGGCTGGCCCGCGAGGCCATCGCGCGCGAGATGCACGACGTGCTGGCGCACCGGCTGACGCTGCTCAGTGTGCACGCGGGCGCCCTGGAGTTCCGGCCCGACGCCCCGCGCGAGGAGGTCGCGCGGGCGGCCGGCGTGATCCGGGAAAGCGCCCACGAGGCGCTGCAGGACCTGAGGGAGATCATCGGGGTGCTGCGGGCCGGTGAGAGCGAGGACGGCGGCCGGCCGCAGCCGACGCTCGCGGCGCTCGACTCCCTCGTCGCCGAGTCCCGGCAGGCGGGCATGAAGGTCACCCTGGAGCAGCGGGTCACCGACCCGGCCGGCGTCCCCGCGTCCGTCGGCCGCACCGCCTACCGGATCGCCCAGGAGGGCCTGACCAACGCCCGCAAGCACGCGCCCGGCACGGAGGTCACCGTGTCGGTCGCCGGCGGGCCGGGGGAGGACCTCGCGGTGACCGTGCGCAACCCCGCCCCGGAGGGGGACGTACCGGCCGTGCCGGGTGCCGGGCAGGGACTGATCGGGCTCACCGAGCGGGCCACCCTGGCCGGCGGCACGCTGGAGCACGGCCCCGCCCCCGACGGCGGCTTCGAGGTACGGGCACGGCTGCCATGGCGATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 28301,
                "end": 28504,
                "strand": 1,
                "locus_tag": "ctg1_28",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_28</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_28</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,301 - 28,504,\n (total: 204 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRKLLEALGFVAVLQGAAGLVTEFADRDWGLVRRTGFFDGYEIYASVALLVLGIALFAVAESRKPGG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=18301&amp;to=38504\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRKLLEALGFVAVLQGAAGLVTEFADRDWGLVRRTGFFDGYEIYASVALLVLGIALFAVAESRKPGG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGGAAACTGCTGGAGGCGCTGGGCTTCGTGGCCGTGCTGCAGGGTGCGGCCGGCCTGGTGACGGAGTTCGCCGACCGGGACTGGGGCCTGGTGCGGCGGACCGGGTTCTTCGACGGCTACGAGATCTACGCGAGCGTCGCCCTGCTGGTGCTGGGGATCGCCCTGTTCGCCGTCGCGGAGAGCCGGAAGCCGGGCGGGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 28557,
                "end": 28925,
                "strand": -1,
                "locus_tag": "ctg1_29",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_29</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_29</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 28,557 - 28,925,\n (total: 369 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00545.20 (ribonuclease): [36:116](score: 98.4, e-value: 3e-28)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00545.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding<br>\n  \n   PF00545.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004521' target='_blank'>GO:0004521</a>: endoribonuclease activity<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VLGGGGALAAPAAHAAPAAPVAAASVLAVGDICASDLPAEAHDTLDLIDQGGPFPFEQDGTVFQNREGILPDRSSGYYHEYTVITPGSPTRGARRIVTGEEYQEDYYTADHYASFDLVDHTC&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=18557&amp;to=38925\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_29_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VLGGGGALAAPAAHAAPAAPVAAASVLAVGDICASDLPAEAHDTLDLIDQGGPFPFEQDGTVFQNREGILPDRSSGYYHEYTVITPGSPTRGARRIVTGEEYQEDYYTADHYASFDLVDHTC\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCTGGGCGGCGGCGGAGCCCTCGCCGCGCCGGCGGCCCATGCCGCCCCCGCCGCCCCCGTGGCCGCGGCGTCCGTCCTCGCGGTCGGTGACATATGTGCGAGCGACCTGCCCGCCGAGGCGCACGACACCCTCGACCTGATCGACCAGGGCGGCCCCTTCCCCTTCGAGCAGGACGGCACCGTCTTCCAGAACCGGGAAGGCATCCTGCCGGACCGGTCGAGCGGCTACTACCACGAGTACACGGTGATCACGCCCGGTTCCCCCACCCGTGGCGCCCGCCGGATCGTGACCGGTGAGGAGTACCAGGAGGACTACTACACCGCCGACCACTACGCGTCGTTCGACCTGGTCGACCACACCTGCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 29166,
                "end": 29918,
                "strand": 1,
                "locus_tag": "ctg1_30",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_30</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_30</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 29,166 - 29,918,\n (total: 753 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 208.9; E-value: 1.4e-63)<br>\n \n  biosynthetic-additional (t2pks) KR (Score: 177.4; E-value: 9.7e-55)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF13561.6 (Enoyl-(Acyl carrier protein) reductase): [21:247](score: 192.2, e-value: 9.5e-57)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTTNTMEKTLLGKAALVTGGGRGIGAATALRLAREGADVAVTYVNGKEAAEDVVRAVEALGRRAVALRADAGDPQEASGAVGAAVRELGRLDVLVNNAGVGLLGPLETLSPADVDRVLAVNVRGVFLASRAAAAVLPRGGRIVTVGTCMTQRVPGPGGTLYAMSKAALVGLTKALARELGERGITANIVHPGPIDTDMNPADGPYAAGQAAATALGRFGTAAEVAETIVHLAGAAYVTGAEFAVDGGHAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=19166&amp;to=39918\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_30_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTTNTMEKTLLGKAALVTGGGRGIGAATALRLAREGADVAVTYVNGKEAAEDVVRAVEALGRRAVALRADAGDPQEASGAVGAAVRELGRLDVLVNNAGVGLLGPLETLSPADVDRVLAVNVRGVFLASRAAAAVLPRGGRIVTVGTCMTQRVPGPGGTLYAMSKAALVGLTKALARELGERGITANIVHPGPIDTDMNPADGPYAAGQAAATALGRFGTAAEVAETIVHLAGAAYVTGAEFAVDGGHAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACCACGAACACGATGGAGAAGACCCTGCTCGGCAAGGCGGCGCTGGTGACCGGCGGCGGCCGCGGCATCGGCGCCGCGACGGCGCTCCGGCTGGCGCGGGAGGGCGCCGACGTCGCGGTGACGTATGTGAACGGCAAGGAGGCCGCGGAGGACGTCGTACGGGCCGTCGAGGCCCTGGGGCGGCGCGCGGTGGCACTCCGGGCGGACGCCGGCGACCCGCAGGAGGCGTCGGGGGCGGTGGGCGCCGCGGTCCGTGAACTGGGGCGTCTGGACGTCCTCGTGAACAACGCGGGCGTCGGCCTGCTCGGCCCGCTGGAGACCCTCTCCCCCGCCGACGTGGACCGGGTGCTCGCGGTGAACGTCCGCGGTGTCTTCCTGGCCTCGCGCGCGGCGGCCGCCGTGCTGCCACGCGGGGGCCGGATCGTCACCGTGGGCACGTGCATGACGCAGCGGGTGCCCGGCCCCGGCGGGACGCTCTACGCCATGAGCAAGGCGGCGCTGGTGGGGCTGACCAAGGCGCTGGCACGGGAGTTGGGCGAGCGCGGGATCACGGCGAACATCGTCCACCCCGGGCCGATCGACACGGACATGAACCCGGCCGACGGCCCGTACGCGGCCGGGCAGGCGGCGGCGACCGCGCTGGGGCGCTTCGGCACGGCCGCGGAGGTGGCGGAGACGATCGTCCATCTCGCGGGCGCGGCGTACGTGACCGGGGCGGAGTTCGCGGTGGACGGGGGGCACGCGGCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 30056,
                "end": 31171,
                "strand": -1,
                "locus_tag": "ctg1_31",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_31</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_31</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 30,056 - 31,171,\n (total: 1116 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF03561.15 (Allantoicase repeat): [41:201](score: 156.4, e-value: 4.6e-46)<br>\n \n  PF03561.15 (Allantoicase repeat): [223:352](score: 117.5, e-value: 4.4e-34)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR02961 (allantoicase: allantoicase): [32:352](score: 410.3, e-value: 9.4e-124)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF03561.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004037' target='_blank'>GO:0004037</a>: allantoicase activity<br>\n  \n   PF03561.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000256' target='_blank'>GO:0000256</a>: allantoin catabolic process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTAIETFSGDAHPYGGGDPYADYRTADFPFTHLADLADRRLGAGVIAANDEFFAQRENLLLPGRAVFDPERFGHKGKIMDGWETRRRRGTSAGHPWPTDDDHDWALIRLGTPGVVRGVVVDTAHFRGNYPQAVSVEGTAVDGSPSPEDLLADDVKWTTLVPRTAIGGHAANGFAVTAEQRFTHLRLNQHPDGGIARLRVYGEVVPDLAWLTALGTFDVVALENGGRVEDASDRFYSPAANTIRPGRSQKMDDGWETRRRRDHGHDWITYRLVAQSQIRALEIDTAYLKGNAAGWASVSVRDGEDGDWREILPRTRLQPDTNHRFVLPDPAVGTHARVDIHPDGGISRLRLFGSLTDQGEVALDARRQELGG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=20056&amp;to=41171\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTAIETFSGDAHPYGGGDPYADYRTADFPFTHLADLADRRLGAGVIAANDEFFAQRENLLLPGRAVFDPERFGHKGKIMDGWETRRRRGTSAGHPWPTDDDHDWALIRLGTPGVVRGVVVDTAHFRGNYPQAVSVEGTAVDGSPSPEDLLADDVKWTTLVPRTAIGGHAANGFAVTAEQRFTHLRLNQHPDGGIARLRVYGEVVPDLAWLTALGTFDVVALENGGRVEDASDRFYSPAANTIRPGRSQKMDDGWETRRRRDHGHDWITYRLVAQSQIRALEIDTAYLKGNAAGWASVSVRDGEDGDWREILPRTRLQPDTNHRFVLPDPAVGTHARVDIHPDGGISRLRLFGSLTDQGEVALDARRQELGG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACGGCGATCGAGACCTTCTCCGGCGACGCCCACCCCTACGGCGGGGGCGACCCGTACGCGGACTACCGCACCGCCGACTTCCCCTTCACCCACCTCGCCGACCTCGCCGACCGCCGGCTCGGCGCCGGTGTGATCGCCGCCAACGACGAGTTCTTCGCCCAGCGCGAGAACCTCCTGCTGCCCGGACGCGCCGTCTTCGACCCCGAACGCTTCGGACACAAGGGCAAGATCATGGACGGCTGGGAGACCCGCCGGCGGCGCGGCACCTCCGCCGGGCACCCCTGGCCGACGGACGACGACCACGACTGGGCGCTGATCCGCCTCGGCACGCCCGGCGTCGTCCGCGGCGTCGTCGTCGACACCGCCCACTTCCGCGGCAACTACCCGCAGGCGGTGTCGGTCGAAGGCACCGCGGTGGACGGCTCCCCGTCCCCCGAGGACCTGCTCGCGGACGACGTGAAGTGGACGACGCTGGTACCGCGCACCGCCATCGGCGGCCACGCGGCCAACGGCTTCGCCGTCACGGCCGAACAGCGCTTCACCCACCTGCGCCTCAACCAGCACCCCGACGGCGGCATCGCCCGCCTCCGCGTGTACGGCGAGGTCGTCCCGGATCTGGCGTGGCTCACCGCGCTCGGCACCTTCGACGTCGTCGCCCTGGAGAACGGCGGCCGCGTCGAGGACGCCTCCGACCGCTTCTACTCGCCCGCCGCCAACACCATCCGGCCCGGCCGTTCCCAGAAGATGGACGACGGCTGGGAGACCCGGCGCCGCCGCGACCACGGCCACGACTGGATCACGTACCGCCTGGTCGCCCAGTCGCAGATCCGCGCGCTGGAGATCGACACCGCCTACCTCAAGGGCAACGCCGCCGGCTGGGCGTCGGTGTCCGTGCGGGACGGCGAGGACGGCGACTGGCGGGAGATCCTGCCCCGCACCCGCCTCCAGCCCGACACCAACCACCGCTTCGTCCTCCCGGACCCGGCGGTGGGCACCCACGCGCGCGTGGACATCCACCCCGACGGCGGCATCTCCCGCCTGCGCCTGTTCGGCTCCCTGACCGACCAGGGCGAGGTGGCCCTGGACGCCCGCCGGCAGGAGCTCGGCGGCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 31203,
                "end": 32543,
                "strand": -1,
                "locus_tag": "ctg1_32",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_32</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_32</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 31,203 - 32,543,\n (total: 1341 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01979.20 (Amidohydrolase family): [53:426](score: 90.9, e-value: 9.5e-26)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR03178 (allantoinase: allantoinase): [4:443](score: 637.2, e-value: 3.2e-192)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01979.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016787' target='_blank'>GO:0016787</a>: hydrolase activity<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VPDVELVLRSTRVVTPEGTRAASVAVADGTITAVLPYDAPVPEGARLEDLGEDVLLPGLVDTHVHVNDPGRTEWEGFWTATRAAAAGGITTLVDMPLNSLPPTTTVDHLRVKRKTAADKAHVDVGFWGGALPDNVADLRPLHEAGVFGFKAFLSPSGVDEFPHLDEEQLARSLAEIAAFDGLLIVHAEDPGHLAGAPQRGGPRYADFLASRPRLAEDTAIARLLEQARRFDARVHVLHLSSADALPLLAEARADGVRVTVETCPHYLTLTAEEVPDGASEFKCCPPIRESANQDLLWRALADGTVDCVVTDHSPSTADLKTDDFATAWGGISGLQLSLPAVWTEARRRGHTLEDVVRWMATRTARLAGLDARKGAVAPGHDADFAVLAPDESFTVDPAALQHRNRVTAYAGRTLYGVVRSTWLRGRRILADGEFTAPKGLLLTRTD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=21203&amp;to=42543\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_32_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VPDVELVLRSTRVVTPEGTRAASVAVADGTITAVLPYDAPVPEGARLEDLGEDVLLPGLVDTHVHVNDPGRTEWEGFWTATRAAAAGGITTLVDMPLNSLPPTTTVDHLRVKRKTAADKAHVDVGFWGGALPDNVADLRPLHEAGVFGFKAFLSPSGVDEFPHLDEEQLARSLAEIAAFDGLLIVHAEDPGHLAGAPQRGGPRYADFLASRPRLAEDTAIARLLEQARRFDARVHVLHLSSADALPLLAEARADGVRVTVETCPHYLTLTAEEVPDGASEFKCCPPIRESANQDLLWRALADGTVDCVVTDHSPSTADLKTDDFATAWGGISGLQLSLPAVWTEARRRGHTLEDVVRWMATRTARLAGLDARKGAVAPGHDADFAVLAPDESFTVDPAALQHRNRVTAYAGRTLYGVVRSTWLRGRRILADGEFTAPKGLLLTRTD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCCCGACGTCGAACTGGTGCTGCGCTCGACACGCGTCGTCACCCCCGAGGGAACGCGCGCCGCGTCCGTCGCCGTCGCCGACGGCACCATCACGGCCGTCCTGCCGTACGACGCCCCCGTCCCCGAGGGTGCCCGCCTGGAGGACCTCGGTGAAGACGTCCTGCTGCCCGGCCTGGTCGACACCCACGTACACGTCAACGACCCCGGCCGCACCGAGTGGGAAGGCTTCTGGACCGCCACCCGCGCGGCCGCCGCCGGCGGCATCACCACGCTGGTCGACATGCCGCTCAACTCCCTCCCGCCCACCACGACGGTGGACCACCTGCGCGTCAAACGGAAGACCGCCGCCGACAAGGCACACGTCGACGTCGGCTTCTGGGGCGGCGCCCTCCCCGACAACGTCGCGGACCTGCGCCCGCTGCACGAGGCGGGAGTCTTCGGCTTCAAGGCCTTCCTCTCACCGTCCGGCGTGGACGAGTTCCCGCACCTGGACGAGGAACAACTGGCACGCTCCCTCGCGGAGATCGCCGCCTTCGACGGCCTGCTGATCGTGCACGCCGAGGACCCCGGGCACCTCGCCGGCGCCCCGCAGCGGGGCGGCCCCCGGTACGCCGACTTCCTCGCCTCCCGCCCGCGCCTGGCCGAGGACACCGCGATCGCCCGGCTCCTGGAGCAGGCGCGGCGGTTCGACGCCCGGGTGCACGTGCTCCACCTCTCCTCCGCCGACGCGCTGCCCCTCCTCGCCGAGGCCCGGGCGGACGGCGTCCGCGTCACCGTCGAGACCTGCCCCCACTACCTCACCCTCACCGCGGAGGAAGTCCCGGACGGGGCCAGCGAGTTCAAGTGCTGCCCGCCCATCCGCGAGTCCGCCAACCAGGATTTGCTCTGGCGGGCCCTGGCGGACGGCACCGTCGACTGCGTCGTCACCGACCACTCCCCGTCCACCGCCGACCTCAAGACGGACGACTTCGCGACCGCCTGGGGCGGCATCTCCGGCCTCCAGCTCAGCCTCCCGGCCGTCTGGACCGAGGCCCGCAGGCGCGGCCACACCCTGGAGGACGTGGTCCGCTGGATGGCGACGCGCACCGCCCGGCTGGCCGGACTCGACGCCCGCAAGGGCGCCGTCGCGCCCGGCCACGACGCCGACTTCGCCGTCCTGGCCCCCGACGAGAGCTTCACCGTCGACCCGGCCGCCCTCCAGCACCGTAACCGGGTGACCGCGTACGCCGGCCGCACCCTGTACGGCGTCGTCAGGTCCACCTGGCTGCGCGGCCGGCGGATCCTGGCCGACGGAGAGTTCACCGCACCGAAGGGCCTGCTCCTCACCCGAACCGACTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 32782,
                "end": 33588,
                "strand": 1,
                "locus_tag": "ctg1_33",
                "type": "regulatory",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_33</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_33</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 32,782 - 33,588,\n (total: 807 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1195:IclR family transcriptional regulator (Score: 278; E-value: 9.3e-85)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF09339.10 (IclR helix-turn-helix domain): [21:73](score: 64.2, e-value: 6.8e-18)<br>\n \n  PF01614.18 (Bacterial transcriptional regulator): [134:257](score: 106.5, e-value: 8.6e-31)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF09339.10: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF09339.10: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of transcription, DNA-templated<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VPTSSASTTDSARSAASGGVQSLERAFDLLERMADAGGEVGLSELSASSGLPLPTIHRLMRTLVACGYVRQQPNRRYALGPRLIRLGESASRLLGTWARPYLARLVEETGETANMALLDGDEIVYVAQVPSKHSMRMFTEVGRRVLPHSTGVGKALLAGFPPEEVRALLGRTGMPAATEKTITTADGFLAALEEVRRQGYAIDDNEQEIGVRCLAVPVPDAPTAAAISISGPAGRVTEAATERIVPVLQQIATELSEALTTPGAGPNA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=22782&amp;to=43588\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_33_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VPTSSASTTDSARSAASGGVQSLERAFDLLERMADAGGEVGLSELSASSGLPLPTIHRLMRTLVACGYVRQQPNRRYALGPRLIRLGESASRLLGTWARPYLARLVEETGETANMALLDGDEIVYVAQVPSKHSMRMFTEVGRRVLPHSTGVGKALLAGFPPEEVRALLGRTGMPAATEKTITTADGFLAALEEVRRQGYAIDDNEQEIGVRCLAVPVPDAPTAAAISISGPAGRVTEAATERIVPVLQQIATELSEALTTPGAGPNA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCCGACGTCCAGCGCCAGCACCACCGACTCCGCCCGTTCCGCCGCCAGTGGCGGCGTGCAGTCCCTCGAGCGCGCCTTCGACCTGCTGGAACGGATGGCGGACGCGGGGGGCGAGGTCGGTCTGAGCGAGCTGTCCGCGAGCAGCGGCCTGCCCCTGCCGACGATCCACCGGCTGATGCGCACCCTCGTCGCCTGCGGGTACGTGCGCCAGCAGCCCAACCGGCGGTACGCGCTCGGCCCGCGCCTGATCCGTCTCGGCGAGTCGGCGTCCCGCCTGCTGGGCACCTGGGCCCGGCCGTACCTGGCGCGCCTGGTGGAGGAGACCGGCGAGACGGCGAACATGGCCCTGCTGGACGGGGACGAGATCGTGTACGTGGCGCAGGTGCCGTCCAAGCACTCGATGCGGATGTTCACCGAGGTGGGGCGGCGCGTGCTGCCGCACTCCACGGGCGTGGGCAAGGCCCTGCTGGCCGGCTTCCCGCCGGAGGAGGTGCGGGCCCTGCTGGGCCGCACCGGCATGCCGGCCGCGACGGAGAAGACCATCACGACGGCGGACGGCTTCCTCGCGGCGCTGGAGGAGGTCCGGCGGCAGGGGTACGCCATCGACGACAACGAGCAGGAGATCGGCGTCCGCTGCCTTGCGGTGCCGGTGCCGGACGCCCCGACGGCGGCGGCCATTTCCATCTCCGGCCCGGCGGGCCGGGTGACGGAGGCGGCGACGGAGAGGATCGTGCCGGTGCTCCAGCAGATCGCGACGGAGCTGTCGGAGGCCCTGACGACCCCGGGCGCGGGCCCGAACGCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 33727,
                "end": 33987,
                "strand": -1,
                "locus_tag": "ctg1_34",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_34</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_34</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 33,727 - 33,987,\n (total: 261 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTELRSAVSRLRRQLAAHRAEFRDRSVAEEALATLAGLAAADDPDIPRLRRSLLLVAGAIGSVSALGQGVRELREAVDLFGPPPRP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=23727&amp;to=43987\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_34_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTELRSAVSRLRRQLAAHRAEFRDRSVAEEALATLAGLAAADDPDIPRLRRSLLLVAGAIGSVSALGQGVRELREAVDLFGPPPRP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACGGAGCTGCGCTCCGCCGTCTCCCGGTTACGCCGCCAACTCGCCGCCCATCGCGCTGAGTTCCGGGACCGGAGCGTCGCGGAGGAGGCGCTCGCGACACTGGCCGGCCTGGCCGCCGCCGACGACCCCGACATCCCGCGCCTGCGCCGCTCCCTGCTGCTGGTCGCCGGTGCGATCGGCTCGGTGAGCGCGCTCGGGCAGGGCGTACGGGAACTCCGCGAGGCGGTCGACCTCTTCGGCCCGCCCCCTCGCCCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 34236,
                "end": 34847,
                "strand": 1,
                "locus_tag": "ctg1_35",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_35</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_35</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,236 - 34,847,\n (total: 612 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF12804.7 (MobA-like NTP transferase domain): [13:178](score: 122.5, e-value: 2.1e-35)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MQDLMTDDENRVVGLLLAAGGGRRLGGHPKALLTHRGRPLVEHAARVLRAGGCAGVHVVLGARADEVRARAVLPDCVLVDNPDWEQGMGSSLRAGLHSLAGTGAGAALVLLVDQPGIGPEAVARVRGRYRSPQSLVSAAYEGVRGHPVLFGAAHWAGIAATATGDRGARAYLREHADRVERVECGDIAQAYDIDTEADLTHLE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=24236&amp;to=44847\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_35_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MQDLMTDDENRVVGLLLAAGGGRRLGGHPKALLTHRGRPLVEHAARVLRAGGCAGVHVVLGARADEVRARAVLPDCVLVDNPDWEQGMGSSLRAGLHSLAGTGAGAALVLLVDQPGIGPEAVARVRGRYRSPQSLVSAAYEGVRGHPVLFGAAHWAGIAATATGDRGARAYLREHADRVERVECGDIAQAYDIDTEADLTHLE\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCAGGACCTCATGACGGACGACGAGAACCGGGTGGTCGGCCTGCTGCTGGCCGCGGGCGGCGGGCGCAGGCTCGGCGGGCACCCCAAGGCACTGCTCACGCACCGGGGGCGCCCCCTCGTGGAGCACGCGGCGCGAGTGCTGCGCGCGGGTGGCTGCGCGGGCGTGCACGTGGTGCTGGGGGCGCGCGCGGACGAGGTGCGCGCCCGCGCCGTACTCCCGGACTGCGTGCTGGTGGACAACCCGGACTGGGAGCAGGGCATGGGGTCCTCCCTGCGGGCGGGGCTGCACTCCCTGGCAGGCACCGGCGCCGGGGCCGCGCTGGTCCTGCTGGTGGACCAGCCGGGAATCGGCCCGGAGGCGGTCGCCCGGGTGCGCGGCCGGTACCGGTCGCCGCAGTCGCTGGTCTCGGCGGCCTACGAGGGCGTACGCGGCCATCCGGTGCTGTTCGGCGCCGCGCACTGGGCGGGGATCGCGGCGACCGCCACCGGCGACCGAGGAGCGCGCGCCTATCTGAGGGAGCACGCGGACCGGGTCGAACGCGTCGAGTGCGGCGACATCGCGCAGGCGTACGACATCGACACCGAGGCCGATCTGACGCACCTTGAATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 34844,
                "end": 34963,
                "strand": 1,
                "locus_tag": "ctg1_36",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_36</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_36</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 34,844 - 34,963,\n (total: 120 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSRCAPPGRARHPAPSSLDPEILDINKTLNFHHEETTIH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=24844&amp;to=44963\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSRCAPPGRARHPAPSSLDPEILDINKTLNFHHEETTIH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCCGGTGCGCCCCGCCGGGGCGGGCGAGGCACCCCGCGCCATCGTCCCTCGACCCGGAGATTCTCGACATCAACAAAACATTGAACTTCCACCATGAGGAAACTACTATCCACTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 35058,
                "end": 36683,
                "strand": 1,
                "locus_tag": "ctg1_37",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_37</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_37</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 35,058 - 36,683,\n (total: 1626 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01274.22 (Malate synthase): [17:539](score: 688.1, e-value: 5.7e-207)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR01344 (malate_syn_A: malate synthase A): [22:539](score: 853.2, e-value: 1.1e-257)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01274.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004474' target='_blank'>GO:0004474</a>: malate synthase activity<br>\n  \n   PF01274.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006097' target='_blank'>GO:0006097</a>: glyoxylate cycle<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSAPAPSPLAIVDAEPLPRQEEVLTDTALAFVAELHRRFTPRRDELLARRAERRAGIARTATLDFLPETAAIRADDSWKVAPAPPALEDRRVEITGPTDRKMTINALNSGAKVWLADFEDASAPTWENVVTGQLNLIDAYTRAIDFTDPGSGKSYALRPEEELATVVTRPRGWHLDERHLTDPEGTPVPGALVDFGLYFFHNAKRLIDLGKGPYFYLPKTESHLEARLWNDVFVFAQDYLGIPRGTVRATVLIETITAAYEMEEILYELRDHASGLNAGRWDYLFSIVKNFRDGGEKFVLPDRNAVTMTAPFMRAYTELLVRTCHKRGAHAIGGMAAFIPSRRDAEVNKVAFEKVRADKDREANDGFDGSWVAHPDLVPIAMESFDQVLGDKPNQKDRLREDVDVKAADLIAVDSLDARPTYAGLVNAVQVGIRYIEAWLRGLGAVAIFNLMEDAATAEISRSQIWQWINAGVVLDNGERVTAELAREVAAEELANIRAEAGEEAFAAGNWQQAHDLLLKVALDEDYADFLTLPAYEQLKG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=25058&amp;to=46683\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_37_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSAPAPSPLAIVDAEPLPRQEEVLTDTALAFVAELHRRFTPRRDELLARRAERRAGIARTATLDFLPETAAIRADDSWKVAPAPPALEDRRVEITGPTDRKMTINALNSGAKVWLADFEDASAPTWENVVTGQLNLIDAYTRAIDFTDPGSGKSYALRPEEELATVVTRPRGWHLDERHLTDPEGTPVPGALVDFGLYFFHNAKRLIDLGKGPYFYLPKTESHLEARLWNDVFVFAQDYLGIPRGTVRATVLIETITAAYEMEEILYELRDHASGLNAGRWDYLFSIVKNFRDGGEKFVLPDRNAVTMTAPFMRAYTELLVRTCHKRGAHAIGGMAAFIPSRRDAEVNKVAFEKVRADKDREANDGFDGSWVAHPDLVPIAMESFDQVLGDKPNQKDRLREDVDVKAADLIAVDSLDARPTYAGLVNAVQVGIRYIEAWLRGLGAVAIFNLMEDAATAEISRSQIWQWINAGVVLDNGERVTAELAREVAAEELANIRAEAGEEAFAAGNWQQAHDLLLKVALDEDYADFLTLPAYEQLKG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCCGCACCAGCGCCGTCCCCGCTGGCCATCGTCGACGCCGAGCCCCTGCCGCGGCAGGAGGAGGTCCTCACCGACACGGCGCTCGCCTTCGTGGCCGAGCTGCACCGGCGGTTCACGCCCCGGCGTGACGAGCTGCTCGCCCGCCGCGCGGAGCGCCGCGCCGGGATCGCCCGCACCGCCACCCTCGACTTCCTCCCCGAGACGGCCGCGATCCGCGCCGACGACTCCTGGAAGGTGGCCCCGGCTCCCCCGGCCCTGGAGGACCGCCGCGTCGAGATCACCGGCCCGACCGACCGCAAGATGACCATCAACGCGCTCAACTCCGGCGCGAAGGTGTGGCTCGCGGACTTCGAGGACGCGTCCGCGCCCACCTGGGAGAACGTGGTCACCGGCCAGCTGAACCTGATCGACGCCTACACGCGCGCCATCGACTTCACCGACCCGGGGTCCGGCAAGTCCTACGCCCTGCGCCCCGAGGAGGAGCTGGCGACGGTCGTCACGCGGCCACGCGGCTGGCACCTGGACGAGCGGCACCTCACCGACCCGGAGGGCACCCCGGTGCCCGGCGCGCTCGTCGACTTCGGCCTGTACTTCTTCCACAACGCCAAGCGGCTGATCGACCTCGGCAAGGGCCCGTACTTCTACCTGCCGAAGACGGAGTCGCACCTCGAGGCCCGGCTGTGGAACGACGTGTTCGTGTTCGCGCAGGACTACCTGGGCATCCCCCGGGGCACCGTCCGCGCCACCGTGCTCATCGAGACGATCACGGCCGCCTACGAGATGGAGGAGATCCTCTACGAGCTGCGCGACCACGCCTCCGGGCTGAACGCCGGCCGCTGGGACTACCTCTTCTCCATCGTCAAGAACTTCCGTGACGGCGGCGAGAAGTTCGTGCTGCCCGACCGCAACGCGGTCACCATGACCGCCCCGTTCATGCGCGCGTACACCGAACTGCTCGTCCGCACCTGCCACAAGCGCGGCGCGCACGCGATCGGCGGCATGGCGGCGTTCATCCCGTCCCGCCGGGACGCCGAGGTCAACAAGGTCGCCTTCGAGAAGGTCCGCGCCGACAAGGACCGCGAGGCGAACGACGGCTTCGACGGCTCCTGGGTGGCCCACCCGGACCTGGTGCCGATCGCCATGGAGTCCTTCGACCAGGTGCTCGGCGACAAGCCGAACCAGAAGGACCGGCTGCGCGAGGACGTCGACGTCAAGGCCGCGGACCTCATCGCCGTCGACTCCCTCGACGCCAGGCCGACGTACGCGGGCCTGGTCAACGCCGTGCAGGTGGGCATCCGCTACATCGAGGCGTGGCTGCGCGGCCTGGGCGCGGTGGCCATCTTCAACCTGATGGAGGACGCGGCCACCGCCGAGATCTCCCGCTCCCAGATCTGGCAGTGGATCAACGCGGGCGTCGTCCTCGACAACGGCGAGCGGGTCACCGCCGAGCTGGCGCGCGAGGTCGCCGCGGAGGAACTGGCGAACATCCGCGCGGAGGCCGGCGAGGAGGCGTTCGCGGCGGGCAACTGGCAGCAGGCGCACGACCTGCTGCTGAAGGTCGCCCTCGACGAGGACTACGCCGACTTCCTCACCTTGCCGGCGTACGAGCAGCTCAAGGGCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 36711,
                "end": 36989,
                "strand": -1,
                "locus_tag": "ctg1_38",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_38</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_38</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,711 - 36,989,\n (total: 279 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF10262.9 (Rdx family): [6:79](score: 99.0, e-value: 1.3e-28)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR02174 (CXXU_selWTH: selT/selW/selH selenoprotein domain): [7:78](score: 72.9, e-value: 4.4e-21)<br>\n \n <br>\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTTGARRVEIEYCTQCRWLPRAAWLAQELLTTFEQELTELALRPGTGGVFVVRVGDEVVWDRREQGFPEPTAVKRAVRDRVAPGKPLGHSDK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=26711&amp;to=46989\" target=\"_new\">View genomic context</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTTGARRVEIEYCTQCRWLPRAAWLAQELLTTFEQELTELALRPGTGGVFVVRVGDEVVWDRREQGFPEPTAVKRAVRDRVAPGKPLGHSDK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGACCGGCGCGCGGCGCGTGGAGATCGAGTACTGCACCCAGTGCCGCTGGCTGCCCCGGGCCGCCTGGCTGGCGCAGGAGCTGCTGACCACGTTCGAGCAGGAGCTGACCGAGCTGGCGCTCAGGCCCGGCACCGGCGGTGTCTTCGTGGTCCGCGTCGGGGACGAGGTGGTCTGGGACCGGCGCGAGCAGGGCTTCCCGGAGCCGACGGCGGTGAAGCGGGCCGTACGCGACCGAGTGGCCCCGGGAAAACCCCTGGGCCACTCGGACAAGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 36986,
                "end": 37951,
                "strand": -1,
                "locus_tag": "ctg1_39",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_39</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_39</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 36,986 - 37,951,\n (total: 966 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLILCRRPASKGRTVTDGLRSVTTTRYVTPLHSGGSVPGVFEADDLGTYVVKFTGSAQGRKALVAEVIVGELARALGLRFPELVLVDFDPAIADAEPHQEVRELHASSAGTNLGMDYLPGARDFTPEVAERFAVDRLEAGRIVWLDALTANVDRTVHSSNLLLWPTLGVAPPRLWLIDHGAALVFHHRWAAGDPEKAYDFRHHALGRYGPDVRAADAELAPRVTEELLRSVVDQVPDAWLDGEPGFDSPEAVRAAYVSHLHARARASGAWLPLDFPTADQVAAENALRAARTQQGRPDWLKQVPDLHGRPAVEQDGTVHLR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=26986&amp;to=47951\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_39_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLILCRRPASKGRTVTDGLRSVTTTRYVTPLHSGGSVPGVFEADDLGTYVVKFTGSAQGRKALVAEVIVGELARALGLRFPELVLVDFDPAIADAEPHQEVRELHASSAGTNLGMDYLPGARDFTPEVAERFAVDRLEAGRIVWLDALTANVDRTVHSSNLLLWPTLGVAPPRLWLIDHGAALVFHHRWAAGDPEKAYDFRHHALGRYGPDVRAADAELAPRVTEELLRSVVDQVPDAWLDGEPGFDSPEAVRAAYVSHLHARARASGAWLPLDFPTADQVAAENALRAARTQQGRPDWLKQVPDLHGRPAVEQDGTVHLR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTCATTTTGTGCCGGAGGCCGGCAAGTAAGGGGCGCACCGTGACCGACGGGCTGAGAAGTGTGACCACCACGCGCTACGTCACGCCTCTGCACTCCGGGGGGTCCGTCCCCGGGGTGTTCGAGGCCGACGACCTCGGGACGTACGTCGTGAAGTTCACCGGCTCCGCGCAGGGCCGCAAGGCGCTGGTCGCCGAGGTGATCGTCGGGGAACTGGCGCGGGCGCTCGGTCTGCGTTTCCCCGAGCTGGTGCTGGTGGACTTCGACCCGGCGATCGCGGACGCCGAACCCCACCAGGAGGTGCGTGAGCTGCACGCCTCCAGCGCCGGGACCAACCTCGGCATGGACTACCTGCCGGGAGCGCGCGACTTCACCCCCGAGGTGGCCGAGAGGTTCGCCGTCGACCGGCTGGAGGCCGGTCGGATCGTGTGGCTCGACGCGCTGACGGCGAACGTCGACCGCACCGTGCACAGCTCCAACCTGCTCCTGTGGCCGACCCTCGGTGTCGCCCCGCCCCGGCTGTGGCTGATCGACCACGGCGCGGCGCTCGTCTTCCACCACCGCTGGGCCGCCGGCGACCCCGAGAAGGCGTACGACTTCCGGCATCACGCCCTCGGCCGGTACGGCCCCGACGTGCGCGCCGCCGACGCGGAGCTCGCGCCCCGGGTGACGGAGGAGCTGCTGCGGTCGGTCGTGGACCAGGTGCCCGACGCCTGGCTGGACGGCGAGCCGGGGTTCGATTCGCCCGAGGCGGTCCGCGCCGCCTACGTGAGCCATCTGCACGCGCGGGCGCGGGCCTCCGGCGCGTGGCTGCCCCTCGACTTCCCCACGGCCGACCAGGTCGCCGCGGAGAACGCCCTTCGCGCGGCACGGACGCAACAGGGCCGCCCGGACTGGCTCAAGCAGGTACCCGACCTGCACGGCCGGCCGGCGGTGGAACAGGACGGGACGGTGCACCTGCGATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 38012,
                "end": 39130,
                "strand": -1,
                "locus_tag": "ctg1_40",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_40</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_40</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 38,012 - 39,130,\n (total: 1119 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1217:NADH:flavin oxidoreductase/NADH oxidase (Score: 334.5; E-value: 1.1e-101)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00724.20 (NADH:flavin oxidoreductase / NADH oxidase family): [14:357](score: 201.5, e-value: 2.1e-59)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00724.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0010181' target='_blank'>GO:0010181</a>: FMN binding<br>\n  \n   PF00724.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n   PF00724.20: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055114' target='_blank'>GO:0055114</a>: oxidation-reduction process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSAHPLDRVRDILARPFSVGGLNLPNRVVMAPMTREFSPGGVPGEDVARYYARRAAGGVGLLVTEGSYIDHASAGNSARVPHFYGDKALAGWSAVAEAVHREGGRIMPQLWHVGMDRATGNPPVPDAPRIGPSGIALDGSHSGREMTQADIDNVVAAYASAAASAEALGFDGVEIHGGHGYLVDQFLWAHTNRRTDGYGGDVARRTRFAAEIVAACRAAVSDDFPISFRLSQWKVNHYGARIAETPQELETVLGLLAEAGADVFHCSTRRFHLPEFEGSDLNLAGWAKKLSGKPAVSVGSVGMSNEFLDVFQGEQAAVTDIGNLLDRMERDEFDLIAVGRALLGDPEWLTKILSGRTGELTPFHVSRIRTLH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=28012&amp;to=49130\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_40_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSAHPLDRVRDILARPFSVGGLNLPNRVVMAPMTREFSPGGVPGEDVARYYARRAAGGVGLLVTEGSYIDHASAGNSARVPHFYGDKALAGWSAVAEAVHREGGRIMPQLWHVGMDRATGNPPVPDAPRIGPSGIALDGSHSGREMTQADIDNVVAAYASAAASAEALGFDGVEIHGGHGYLVDQFLWAHTNRRTDGYGGDVARRTRFAAEIVAACRAAVSDDFPISFRLSQWKVNHYGARIAETPQELETVLGLLAEAGADVFHCSTRRFHLPEFEGSDLNLAGWAKKLSGKPAVSVGSVGMSNEFLDVFQGEQAAVTDIGNLLDRMERDEFDLIAVGRALLGDPEWLTKILSGRTGELTPFHVSRIRTLH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGTCAGCACACCCCCTGGACCGCGTCCGGGACATCCTGGCCCGCCCGTTCTCCGTCGGCGGCCTCAACCTGCCCAACCGGGTCGTGATGGCGCCCATGACCCGGGAGTTCTCCCCGGGCGGGGTCCCCGGCGAGGACGTGGCGCGCTACTACGCCAGGCGGGCGGCGGGCGGCGTCGGTCTGCTCGTCACCGAGGGCAGCTACATCGACCACGCCTCGGCCGGCAACAGCGCCCGGGTGCCGCACTTCTACGGTGACAAGGCGCTGGCCGGGTGGTCCGCCGTGGCCGAGGCGGTCCACCGGGAGGGCGGCAGGATCATGCCCCAGCTGTGGCACGTCGGCATGGACCGCGCCACGGGCAATCCGCCCGTGCCGGACGCCCCGAGGATCGGTCCCTCCGGCATCGCCCTGGACGGTTCGCACTCGGGCCGGGAGATGACCCAGGCCGACATCGACAACGTGGTGGCGGCCTACGCGTCCGCCGCCGCGTCGGCCGAGGCCCTCGGGTTCGACGGCGTGGAGATCCACGGCGGCCACGGCTACCTGGTCGACCAGTTCCTGTGGGCCCACACCAACCGGCGCACCGACGGCTACGGCGGTGACGTCGCCCGGCGCACCCGGTTCGCCGCGGAGATCGTGGCGGCCTGCCGTGCGGCCGTGTCCGACGACTTCCCGATCTCGTTCCGGCTGTCCCAGTGGAAGGTGAACCACTACGGGGCGCGGATCGCCGAGACCCCGCAGGAGCTGGAGACCGTGCTCGGGCTGCTGGCCGAGGCGGGTGCCGACGTCTTCCACTGCTCCACCCGGCGCTTCCACCTGCCGGAGTTCGAGGGTTCGGACCTCAACCTCGCGGGCTGGGCGAAGAAGCTCTCCGGGAAGCCCGCCGTCAGCGTGGGCTCGGTGGGCATGAGCAACGAGTTCCTCGACGTGTTCCAGGGCGAGCAGGCGGCCGTCACGGACATCGGAAACCTGCTCGACCGCATGGAGCGCGACGAGTTCGACCTGATCGCGGTGGGCCGTGCCCTCCTCGGCGACCCGGAGTGGCTGACCAAGATCCTCTCGGGCCGCACCGGCGAGTTGACCCCCTTCCACGTGAGCCGGATCCGCACCCTCCACTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 39310,
                "end": 40878,
                "strand": -1,
                "locus_tag": "ctg1_41",
                "type": "transport",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_41</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_41</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 39,310 - 40,878,\n (total: 1569 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1005:Drug resistance transporter, EmrB/QacA (Score: 384.5; E-value: 8.7e-117)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF07690.16 (Major Facilitator Superfamily): [24:417](score: 158.9, e-value: 1.5e-46)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR00711 (efflux_EmrB: drug resistance MFS transporter, drug:H+ antiporter-2 (14 Spanner) (DHA2) family): [21:430](score: 246.6, e-value: 1.1e-73)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF07690.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTDRPTAAPTAPDRAGLPRLGVFGLMLGIFLATLDGQIVSTALPTIVGDLGGLELFSWSVTAYLLTMAASTPLWGKLGDLYGRKGAYTNSVVLFLIGTVLCGLARNMEQLIAFRAVQGLGAGGLMVGALSVIGVLVPPEGRGRIQSMVGVMMPVAFVGGPLLGGLVTEHLDWRWAFYVNVPVGLVALLAVAKGVRLPAQRVTGHVDYAGAALLTSGVLALTLLAGWAGTTYAWLSWQITALAALVAVSLAWFVRVERRAAEPITPPRLFARREFTLAQVLSLLVGAILISVVNYLPQYMQFVQGASPTASGMLILPLMLGMLSAQLTTGRLMDRGGLDRIVPLTGASVTVAGALLLLLLGSATPVAAASALTLVVGIGVGMLMQSTLLTTMNNADPRDMGAATGTVTLVRTIGGSLGVAVLGAVHSSRTSDVLAGRLGEGTEQRLTVGGELTPAALEGMPRAVRDAVAQAVSSGLHGVVTGAALLAVCAFAAAWFVRAAPDAPRPDSPPAAEKNALRPSPAD&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=29310&amp;to=50878\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_41_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%0AMTDRPTAAPTAPDRAGLPRLGVFGLMLGIFLATLDGQIVSTALPTIVGDLGGLELFSWSVTAYLLTMAASTPLWGKLGDLYGRKGAYTNSVVLFLIGTVLCGLARNMEQLIAFRAVQGLGAGGLMVGALSVIGVLVPPEGRGRIQSMVGVMMPVAFVGGPLLGGLVTEHLDWRWAFYVNVPVGLVALLAVAKGVRLPAQRVTGHVDYAGAALLTSGVLALTLLAGWAGTTYAWLSWQITALAALVAVSLAWFVRVERRAAEPITPPRLFARREFTLAQVLSLLVGAILISVVNYLPQYMQFVQGASPTASGMLILPLMLGMLSAQLTTGRLMDRGGLDRIVPLTGASVTVAGALLLLLLGSATPVAAASALTLVVGIGVGMLMQSTLLTTMNNADPRDMGAATGTVTLVRTIGGSLGVAVLGAVHSSRTSDVLAGRLGEGTEQRLTVGGELTPAALEGMPRAVRDAVAQAVSSGLHGVVTGAALLAVCAFAAAWFVRAAPDAPRPDSPPAAEKNALRPSPAD\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTDRPTAAPTAPDRAGLPRLGVFGLMLGIFLATLDGQIVSTALPTIVGDLGGLELFSWSVTAYLLTMAASTPLWGKLGDLYGRKGAYTNSVVLFLIGTVLCGLARNMEQLIAFRAVQGLGAGGLMVGALSVIGVLVPPEGRGRIQSMVGVMMPVAFVGGPLLGGLVTEHLDWRWAFYVNVPVGLVALLAVAKGVRLPAQRVTGHVDYAGAALLTSGVLALTLLAGWAGTTYAWLSWQITALAALVAVSLAWFVRVERRAAEPITPPRLFARREFTLAQVLSLLVGAILISVVNYLPQYMQFVQGASPTASGMLILPLMLGMLSAQLTTGRLMDRGGLDRIVPLTGASVTVAGALLLLLLGSATPVAAASALTLVVGIGVGMLMQSTLLTTMNNADPRDMGAATGTVTLVRTIGGSLGVAVLGAVHSSRTSDVLAGRLGEGTEQRLTVGGELTPAALEGMPRAVRDAVAQAVSSGLHGVVTGAALLAVCAFAAAWFVRAAPDAPRPDSPPAAEKNALRPSPAD\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGGACCGTCCGACCGCAGCACCCACCGCACCCGACCGCGCCGGCCTGCCCCGACTCGGCGTCTTCGGTCTGATGCTGGGCATCTTCCTGGCGACCCTCGACGGGCAGATCGTCAGCACGGCACTGCCCACCATCGTGGGCGACCTCGGCGGACTCGAACTCTTCTCGTGGTCGGTGACGGCCTACCTGCTCACCATGGCGGCCTCCACCCCGTTGTGGGGCAAACTCGGTGACCTGTACGGCCGCAAGGGCGCCTACACCAACTCCGTGGTGCTCTTCCTGATCGGCACGGTGCTGTGCGGCCTGGCGCGGAACATGGAACAGCTCATCGCCTTCCGGGCCGTGCAAGGCCTCGGGGCCGGCGGGCTGATGGTGGGCGCGCTCTCGGTGATCGGCGTCCTGGTGCCCCCGGAGGGACGCGGCCGCATCCAGTCGATGGTGGGCGTCATGATGCCCGTCGCCTTCGTCGGCGGCCCCCTGCTCGGCGGACTCGTCACCGAGCACCTGGACTGGCGCTGGGCGTTCTACGTCAACGTGCCCGTGGGTCTCGTCGCCCTGCTGGCCGTCGCCAAAGGCGTACGGCTGCCCGCACAGCGTGTCACGGGACACGTCGACTACGCCGGGGCCGCTCTTCTCACCAGCGGCGTCCTCGCCCTCACCCTGCTCGCCGGGTGGGCCGGCACCACGTACGCATGGCTGTCCTGGCAGATCACCGCACTTGCCGCCCTGGTCGCGGTGAGCCTGGCCTGGTTCGTCCGGGTGGAGCGGCGCGCCGCCGAGCCGATCACGCCACCCAGGCTGTTCGCCCGGCGGGAGTTCACCCTGGCGCAGGTGCTCAGTCTCCTGGTCGGCGCGATCCTCATCTCCGTCGTCAACTACCTTCCGCAGTACATGCAGTTCGTCCAGGGCGCGTCACCCACCGCCAGCGGCATGCTGATCCTGCCGCTGATGCTCGGCATGCTGTCGGCCCAACTGACCACCGGGCGGCTCATGGACCGCGGCGGCCTGGACCGAATCGTGCCGCTCACCGGCGCCTCCGTCACCGTCGCGGGCGCGCTGCTGTTGCTCCTGCTGGGCAGCGCCACCCCCGTCGCCGCGGCCTCGGCGCTCACCCTCGTGGTCGGCATCGGCGTCGGGATGCTGATGCAGAGCACCCTGCTCACCACCATGAACAACGCCGACCCCCGTGACATGGGGGCCGCCACCGGCACCGTCACGCTCGTGCGCACCATCGGCGGCTCCCTCGGCGTCGCCGTGCTCGGCGCCGTGCACAGCAGCCGCACGTCCGACGTCCTCGCCGGGAGGCTCGGTGAAGGAACGGAACAACGACTGACTGTCGGCGGCGAGTTGACACCCGCCGCGCTGGAGGGCATGCCCCGGGCGGTGCGTGACGCCGTCGCGCAGGCGGTCAGCAGCGGGCTGCACGGCGTCGTGACCGGCGCGGCTCTCCTGGCGGTGTGCGCGTTCGCCGCGGCGTGGTTCGTCCGCGCGGCACCGGACGCCCCACGGCCGGACAGCCCGCCGGCCGCCGAGAAGAACGCGCTGCGCCCCTCACCGGCGGACTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 40907,
                "end": 41506,
                "strand": -1,
                "locus_tag": "ctg1_42",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_42</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_42</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 40,907 - 41,506,\n (total: 600 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF03358.15 (NADPH-dependent FMN reductase): [9:155](score: 125.8, e-value: 1.2e-36)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF03358.15: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MAGTSDRPLRTAVIIGSTRDGRFGPVVTDWITGHMSERECMTVDVIDLVATPLPTVFPAFGQPPSDEVVVQLGEVTPRLAAADAFVIVTPEYNHSFPAALKNAIDWHNEQWHAKPVGFVSYGGLSGGLRAVEQLRVVLAEVHAVTIRNTVSFHNYGEVFGSDGKPTDPGCDVAAKAMLDQLTWWGHAVREAKAVRPYAV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=30907&amp;to=51506\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_42_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MAGTSDRPLRTAVIIGSTRDGRFGPVVTDWITGHMSERECMTVDVIDLVATPLPTVFPAFGQPPSDEVVVQLGEVTPRLAAADAFVIVTPEYNHSFPAALKNAIDWHNEQWHAKPVGFVSYGGLSGGLRAVEQLRVVLAEVHAVTIRNTVSFHNYGEVFGSDGKPTDPGCDVAAKAMLDQLTWWGHAVREAKAVRPYAV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCTGGCACCAGTGACCGTCCCCTGCGGACCGCGGTGATCATCGGCAGTACCCGGGACGGCCGGTTCGGCCCCGTCGTCACGGACTGGATCACGGGGCACATGTCCGAGCGGGAGTGCATGACGGTCGACGTGATCGACCTCGTCGCCACGCCGCTCCCCACCGTCTTCCCCGCCTTCGGCCAACCGCCCTCCGACGAGGTGGTGGTGCAGCTCGGCGAGGTGACACCGCGGCTGGCCGCGGCCGACGCCTTCGTGATCGTCACCCCGGAGTACAACCACAGCTTCCCGGCCGCGCTGAAGAACGCCATCGACTGGCACAACGAACAGTGGCACGCCAAGCCGGTCGGATTCGTCTCCTACGGTGGTCTGTCCGGAGGGCTGCGCGCCGTCGAACAGCTCCGCGTCGTCCTGGCCGAAGTGCACGCCGTGACGATCCGCAACACGGTCAGCTTCCACAACTACGGCGAGGTCTTCGGGAGCGACGGGAAGCCGACGGACCCCGGCTGTGACGTCGCCGCCAAGGCGATGCTCGACCAGCTCACCTGGTGGGGCCACGCGGTGCGCGAGGCCAAGGCCGTCAGGCCCTACGCCGTCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 41637,
                "end": 42374,
                "strand": 1,
                "locus_tag": "ctg1_43",
                "type": "regulatory",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_43</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_43</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 41,637 - 42,374,\n (total: 738 nt)<br>\n <br>\n \n  regulatory (smcogs) SMCOG1239:TetR family transcriptional regulator (Score: 207.1; E-value: 4.9e-63)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00440.23 (Bacterial regulatory proteins, tetR family): [38:82](score: 32.5, e-value: 5.5e-08)<br>\n \n  PF02909.17 (Tetracyclin repressor-like, C-terminal domain): [93:242](score: 67.4, e-value: 1.2e-18)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00440.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding<br>\n  \n   PF02909.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0045892' target='_blank'>GO:0045892</a>: negative regulation of transcription, DNA-templated<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPSQERQTQAHDKDHVSVWERLERPAPAPRTTLTPRRIARAAVTLADAEGLDAVTMRRLATELGVAPMAAYRYVTGKDELIELMVDFVYAEMELPQDTDSWRTTMHTLAQRIRDVLLRHSWVTRATWCAPTPNQLAVPEAALAALDGLGLDADTAMVVYSTVTSYVHGAVNAEVGVTQLLRVHGWSSREEARSGLASQMAWLLSTGRFPMYERYIGEAGRKDDLEWQFETGLECVLDGISERLKI&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=31637&amp;to=52374\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_43_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPSQERQTQAHDKDHVSVWERLERPAPAPRTTLTPRRIARAAVTLADAEGLDAVTMRRLATELGVAPMAAYRYVTGKDELIELMVDFVYAEMELPQDTDSWRTTMHTLAQRIRDVLLRHSWVTRATWCAPTPNQLAVPEAALAALDGLGLDADTAMVVYSTVTSYVHGAVNAEVGVTQLLRVHGWSSREEARSGLASQMAWLLSTGRFPMYERYIGEAGRKDDLEWQFETGLECVLDGISERLKI\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCCTCCCAGGAGCGACAGACACAGGCCCACGACAAGGACCACGTCTCCGTGTGGGAGCGCCTGGAACGGCCGGCACCCGCGCCCCGCACCACGCTCACGCCCCGGCGCATCGCCAGGGCAGCGGTGACCCTGGCCGACGCGGAGGGCCTGGACGCGGTCACGATGCGGCGCCTGGCCACCGAACTGGGCGTCGCGCCCATGGCCGCGTACCGCTATGTGACCGGCAAGGACGAGCTCATCGAGCTCATGGTCGACTTCGTCTACGCGGAGATGGAGCTGCCGCAGGACACCGACAGCTGGCGCACGACCATGCACACGCTCGCCCAGCGCATCAGGGACGTCCTGCTCCGGCACTCCTGGGTCACCCGCGCCACCTGGTGCGCCCCGACCCCCAACCAGCTGGCCGTGCCGGAGGCCGCCCTGGCCGCACTCGACGGCCTCGGGCTGGACGCGGACACGGCGATGGTGGTCTACAGCACCGTCACCTCGTACGTGCACGGCGCGGTCAACGCGGAGGTCGGCGTGACCCAGCTGCTGCGCGTGCACGGGTGGTCCAGCCGGGAGGAGGCCCGGTCGGGACTCGCCTCGCAGATGGCCTGGCTGCTGAGCACGGGCCGTTTCCCGATGTACGAGCGCTACATCGGCGAGGCCGGACGCAAGGACGACCTGGAGTGGCAGTTCGAAACCGGCCTGGAGTGCGTTCTGGACGGCATCTCCGAGCGCCTGAAGATCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 42783,
                "end": 43364,
                "strand": 1,
                "locus_tag": "ctg1_44",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_44</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_44</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 42,783 - 43,364,\n (total: 582 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPFNTEAAEVRSAIVGTLRAWASLVKEERRVGAPPDTVAHTAGFLLLHIDWLVAHPAVAALSAEVARCVRRARRVIEPTPGRRVPVGDCVVPNCDGTLTAAVRPGPGDTVEVACDAESAHRWSGQEWLRRSDRSTRQEPAVRWMTARDIARLWGLAPGSVYRRASEDRWRRQAHGGRTYYHGEDVSTSLGTHA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=32783&amp;to=53364\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_44_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPFNTEAAEVRSAIVGTLRAWASLVKEERRVGAPPDTVAHTAGFLLLHIDWLVAHPAVAALSAEVARCVRRARRVIEPTPGRRVPVGDCVVPNCDGTLTAAVRPGPGDTVEVACDAESAHRWSGQEWLRRSDRSTRQEPAVRWMTARDIARLWGLAPGSVYRRASEDRWRRQAHGGRTYYHGEDVSTSLGTHA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCCTTCAACACGGAGGCGGCGGAGGTCCGGTCGGCCATCGTCGGGACGCTGCGGGCCTGGGCCTCGCTCGTCAAGGAGGAACGGCGGGTGGGCGCTCCGCCGGACACCGTCGCGCACACCGCCGGCTTCCTTCTCCTGCACATCGACTGGCTCGTCGCCCACCCGGCCGTGGCCGCCCTTTCCGCCGAGGTCGCACGGTGTGTGCGTCGGGCGCGCCGGGTGATCGAACCCACGCCGGGACGCCGCGTCCCGGTCGGCGACTGCGTCGTTCCGAACTGTGACGGGACGCTGACGGCGGCGGTGCGGCCCGGCCCGGGCGACACGGTCGAGGTGGCCTGCGACGCCGAGTCCGCGCACCGCTGGTCCGGGCAGGAGTGGCTCCGCCGCAGCGACCGGTCCACGCGACAGGAGCCGGCCGTGCGCTGGATGACGGCACGGGACATCGCCCGGCTGTGGGGCCTCGCCCCGGGCAGCGTCTACCGCCGCGCCAGCGAGGACCGGTGGCGCCGGCAGGCTCACGGCGGGCGTACGTACTACCACGGGGAGGACGTCAGCACCTCCCTCGGAACACACGCGTAA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 43730,
                "end": 45217,
                "strand": 1,
                "locus_tag": "ctg1_45",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_45</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_45</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 43,730 - 45,217,\n (total: 1488 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1050:monooxygenase FAD-binding (Score: 568.3; E-value: 2.8e-172)<br>\n \n  biosynthetic-additional (t2pks) OXY (Score: 610.9; E-value: 3.8e-186)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01494.19 (FAD binding domain): [2:334](score: 328.5, e-value: 5.1e-98)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01494.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0071949' target='_blank'>GO:0071949</a>: FAD binding<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MDASVIVAGAGPAGLMLAGELRLAGVDVIVLDRLMERTGESRGLGFTTRTMEVFDQRGLLHRFGDMGTSNAGHFGGLPVDFGVLDSVHEAAKTVPQSDTETMLEGWVRELGADIRRGHEMVTLHDHGDHVEAEVRGPGGEEIRLTAPFLVGCDGGRSTVRKAAGFDFPGTAATLEMYLADIKGVDLQPRLIGETFPGGMVMCGPLGNRGVTRIIVCERGTPPRRRTEPPSYAEVAAAWQRITGIDISHAEHEWVSAFGDATRLVTEYRRGRVLLAGDAAHIHLPAGGQGMNTGIQDAVNLGWKLAAVVRGTAPEELLDTYHAERYPVGERLMMNTKAQGLLFLTGEEVQPLRDVLAELIRYEEVSRHLAGMVSGLEIRYDVGPGPHPLLGLRMPHLELVGERRKTSSTALLGPARGVLLDLEDNAVLRERAAGWSDRVDVVTAEPHGVRPGTPLAGTAAVLVRPDGHVAWAAPGSHHDLPMALERWFGPSRIQQP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=33730&amp;to=55217\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_45_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MDASVIVAGAGPAGLMLAGELRLAGVDVIVLDRLMERTGESRGLGFTTRTMEVFDQRGLLHRFGDMGTSNAGHFGGLPVDFGVLDSVHEAAKTVPQSDTETMLEGWVRELGADIRRGHEMVTLHDHGDHVEAEVRGPGGEEIRLTAPFLVGCDGGRSTVRKAAGFDFPGTAATLEMYLADIKGVDLQPRLIGETFPGGMVMCGPLGNRGVTRIIVCERGTPPRRRTEPPSYAEVAAAWQRITGIDISHAEHEWVSAFGDATRLVTEYRRGRVLLAGDAAHIHLPAGGQGMNTGIQDAVNLGWKLAAVVRGTAPEELLDTYHAERYPVGERLMMNTKAQGLLFLTGEEVQPLRDVLAELIRYEEVSRHLAGMVSGLEIRYDVGPGPHPLLGLRMPHLELVGERRKTSSTALLGPARGVLLDLEDNAVLRERAAGWSDRVDVVTAEPHGVRPGTPLAGTAAVLVRPDGHVAWAAPGSHHDLPMALERWFGPSRIQQP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGACGCTTCCGTCATCGTCGCCGGCGCGGGTCCCGCCGGACTCATGCTCGCCGGGGAACTACGGCTCGCGGGGGTCGACGTCATCGTGCTGGACCGGCTCATGGAGCGCACCGGCGAGTCCCGGGGACTGGGCTTCACCACCCGCACCATGGAGGTCTTCGACCAGCGCGGACTGCTCCACCGCTTCGGTGACATGGGCACCAGCAACGCCGGGCACTTCGGCGGCCTGCCGGTCGACTTCGGTGTCCTCGACAGTGTCCACGAGGCCGCCAAGACCGTGCCGCAGTCGGACACCGAGACGATGCTGGAGGGCTGGGTCCGCGAACTGGGCGCCGACATCCGGCGCGGCCACGAAATGGTCACCCTGCACGACCACGGTGACCACGTCGAGGCCGAGGTACGCGGCCCCGGGGGCGAGGAGATTCGGCTCACCGCGCCCTTCCTCGTCGGGTGCGACGGCGGACGCAGCACCGTGCGCAAGGCCGCCGGGTTCGACTTCCCGGGCACCGCGGCGACGCTGGAGATGTACCTCGCGGACATCAAGGGCGTGGATCTGCAGCCGCGGCTGATCGGCGAGACCTTCCCCGGCGGCATGGTGATGTGCGGCCCGCTCGGCAACCGGGGCGTCACCCGCATCATCGTCTGTGAACGCGGCACCCCGCCCCGCCGGCGTACCGAACCCCCCTCCTACGCGGAGGTGGCGGCCGCCTGGCAGCGGATCACCGGCATCGACATCTCGCACGCCGAACACGAGTGGGTCAGCGCCTTCGGTGACGCCACCCGGCTCGTCACCGAGTACCGCCGAGGTCGCGTGCTGCTCGCCGGGGACGCCGCGCACATCCATCTGCCCGCAGGCGGCCAGGGGATGAACACCGGCATCCAGGACGCCGTGAACCTGGGCTGGAAACTGGCCGCCGTGGTCCGCGGCACCGCCCCGGAGGAACTGCTGGACACCTACCACGCCGAGCGGTACCCGGTCGGCGAGCGGCTGATGATGAACACCAAGGCCCAGGGACTGCTCTTCCTCACCGGCGAGGAGGTCCAGCCGCTGCGCGACGTCCTCGCGGAGCTCATCCGCTACGAGGAGGTCAGCCGTCACCTCGCCGGCATGGTGAGCGGCCTGGAGATCCGCTACGACGTCGGCCCTGGCCCGCACCCGCTCCTGGGTCTGCGCATGCCGCACCTGGAGCTCGTGGGCGAACGGCGCAAGACCAGCAGCACCGCACTGCTCGGGCCGGCCCGTGGCGTGCTGCTCGACCTGGAGGACAACGCCGTCCTCCGGGAGCGCGCGGCCGGCTGGTCGGACCGGGTGGACGTCGTCACGGCGGAGCCCCACGGCGTCCGGCCCGGTACTCCCCTCGCGGGCACGGCGGCGGTCCTGGTGCGGCCCGACGGACATGTGGCCTGGGCGGCACCGGGCAGCCATCACGACCTGCCCATGGCACTGGAGCGCTGGTTCGGTCCGTCCCGGATCCAGCAGCCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 45231,
                "end": 45557,
                "strand": 1,
                "locus_tag": "ctg1_46",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_46</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_46</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,231 - 45,557,\n (total: 327 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1225:Polyketide synthesis cyclase (Score: 162.7; E-value: 3.9e-50)<br>\n \n  biosynthetic-additional (t2pks) CYC C4-C17/C2-C19 (Score: 202.5; E-value: 1.4e-62)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF04673.12 (Polyketide synthesis cyclase): [1:106](score: 148.1, e-value: 8.3e-44)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF04673.12: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030639' target='_blank'>GO:0030639</a>: polyketide biosynthetic process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MHSTLIVARMEPRSAEDVARLFGEFDGTEMPHRMGTRRRQLFSYRGLYFHLQDFDTEDGGERIEAAKTDPRFVGISEDLKPFITAYDPATWRSPADAMAQRFYHWTAR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=35231&amp;to=55557\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_46_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MHSTLIVARMEPRSAEDVARLFGEFDGTEMPHRMGTRRRQLFSYRGLYFHLQDFDTEDGGERIEAAKTDPRFVGISEDLKPFITAYDPATWRSPADAMAQRFYHWTAR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCACAGCACGTTGATCGTGGCCAGGATGGAACCCCGTTCCGCCGAGGACGTGGCCCGCCTCTTCGGCGAGTTCGACGGCACGGAGATGCCCCACCGGATGGGCACCCGGCGCCGGCAGCTCTTCTCGTACCGCGGCCTCTACTTCCACCTGCAGGACTTCGACACCGAGGACGGCGGCGAGCGGATCGAGGCCGCGAAGACCGACCCGCGCTTCGTGGGGATCAGCGAGGACCTCAAGCCGTTCATCACCGCCTACGACCCGGCCACCTGGCGCTCGCCCGCCGACGCGATGGCGCAGCGCTTCTACCACTGGACCGCCCGGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 45554,
                "end": 46834,
                "strand": 1,
                "locus_tag": "ctg1_47",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_47</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_47</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 45,554 - 46,834,\n (total: 1281 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) T2PKS: t2ks<br>\n \n  biosynthetic-additional (smcogs) SMCOG1022:Beta-ketoacyl synthase (Score: 504.6; E-value: 3.7e-153)<br>\n \n  biosynthetic-additional (t2pks) KS (Score: 795.9; E-value: 1.8e-242)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-ctg1_47 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>PKS_KS</strong> (8..418)</dt>\n   <dd>\n   \n    found active site histidines: True<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00109.26 (Beta-ketoacyl synthase, N-terminal domain): [6:254](score: 185.1, e-value: 1.7e-54)<br>\n \n  PF02801.22 (Beta-ketoacyl synthase, C-terminal domain): [263:378](score: 123.1, e-value: 5.8e-36)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VSGAYPRRVVITGIGVTAPGGVGVKNFWNTLSGGHTATRRITFFDPSPFRSQVAAEVDFDAELLGLSAQEIRRMDRAAQFAVVTARDAVADSGLEFTALDPHRTGVTIGSAVGATMGLDQEYRTVSDSGRLDLVDHTYAVPHLYNHLVPSSFAAEVAWAVGAEGPATVVSTGCTSGLDAVGYAADLIREGSADVMVAGATDAPISPITVACFDAIKATTPRNDDPEHASRPFDGTRNGFVLGEGSAVFVLEELGSARRRGAHVYAEIAGYATRSNAFHMTGLRPDGREMAEAIRVALDEARLAPGAIDYVNAHGSGTKQNDRHETAAFKRSLGEHAYAVPVSSIKSMVGHSLGAIGSIEIAASALAMEHGVVPPTANLHTPDPECDLDYVPLTAREWPTDAVLSVGSGFGGFQSAMVLARPDRRTA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=35554&amp;to=56834\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_47_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VSGAYPRRVVITGIGVTAPGGVGVKNFWNTLSGGHTATRRITFFDPSPFRSQVAAEVDFDAELLGLSAQEIRRMDRAAQFAVVTARDAVADSGLEFTALDPHRTGVTIGSAVGATMGLDQEYRTVSDSGRLDLVDHTYAVPHLYNHLVPSSFAAEVAWAVGAEGPATVVSTGCTSGLDAVGYAADLIREGSADVMVAGATDAPISPITVACFDAIKATTPRNDDPEHASRPFDGTRNGFVLGEGSAVFVLEELGSARRRGAHVYAEIAGYATRSNAFHMTGLRPDGREMAEAIRVALDEARLAPGAIDYVNAHGSGTKQNDRHETAAFKRSLGEHAYAVPVSSIKSMVGHSLGAIGSIEIAASALAMEHGVVPPTANLHTPDPECDLDYVPLTAREWPTDAVLSVGSGFGGFQSAMVLARPDRRTA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGAGCGGCGCGTACCCCCGGCGCGTGGTGATCACCGGCATCGGAGTCACCGCCCCCGGCGGCGTGGGCGTCAAGAACTTCTGGAACACGCTGTCCGGCGGGCACACCGCGACCCGTCGCATCACCTTCTTCGATCCCTCCCCCTTCCGCTCCCAAGTCGCCGCGGAGGTGGACTTCGACGCGGAGCTGCTGGGACTGAGCGCCCAGGAGATCCGGCGGATGGACCGCGCCGCCCAGTTCGCCGTGGTCACAGCCCGGGACGCGGTGGCCGACAGCGGCCTGGAGTTCACCGCCCTGGACCCGCACCGTACCGGCGTCACCATCGGCAGCGCGGTCGGCGCCACGATGGGACTGGACCAGGAGTACCGCACGGTCAGCGACAGCGGCCGGCTCGACCTGGTCGACCACACCTACGCGGTTCCGCACCTGTACAACCACCTGGTCCCCAGTTCCTTCGCCGCGGAGGTGGCCTGGGCGGTGGGCGCGGAGGGGCCGGCCACCGTGGTGTCCACCGGCTGCACCTCCGGGCTGGACGCCGTGGGCTACGCCGCCGACCTGATCCGGGAAGGCTCGGCCGACGTCATGGTGGCCGGCGCCACCGACGCTCCCATCTCCCCCATCACGGTGGCCTGCTTCGACGCGATCAAGGCGACGACCCCGCGCAACGACGACCCCGAGCACGCCTCACGCCCCTTCGACGGCACCCGTAACGGCTTCGTGCTGGGCGAGGGTTCGGCCGTGTTCGTCCTGGAGGAACTCGGCAGCGCCCGGCGGCGCGGCGCCCACGTCTACGCGGAGATCGCCGGTTACGCCACGCGCAGCAACGCCTTCCACATGACGGGCCTGCGCCCCGACGGCCGGGAGATGGCCGAGGCCATCCGCGTCGCGCTGGACGAGGCACGCCTGGCCCCCGGGGCCATCGACTACGTCAACGCGCACGGTTCGGGCACCAAGCAGAACGACCGCCACGAGACCGCCGCGTTCAAGCGCAGCCTCGGAGAGCACGCCTACGCCGTGCCGGTCAGCTCCATCAAGTCGATGGTGGGCCACTCGCTGGGAGCCATCGGCTCCATCGAGATCGCGGCGAGCGCGCTGGCCATGGAGCACGGCGTCGTACCGCCCACCGCCAACCTGCACACCCCGGACCCCGAGTGCGACCTGGACTACGTCCCGCTCACCGCGCGGGAGTGGCCCACCGACGCCGTGCTGTCGGTGGGCAGCGGCTTCGGCGGTTTCCAGAGCGCCATGGTGCTCGCCCGTCCCGATCGGAGGACCGCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 46831,
                "end": 48051,
                "strand": 1,
                "locus_tag": "ctg1_48",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_48</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_48</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 46,831 - 48,051,\n (total: 1221 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) T2PKS: t2clf<br>\n \n  biosynthetic-additional (smcogs) SMCOG1093:Beta-ketoacyl synthase (Score: 668.7; E-value: 4e-203)<br>\n \n  biosynthetic-additional (t2pks) CLF 8|9 (Score: 717.1; E-value: 1.2e-218)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00109.26 (Beta-ketoacyl synthase, N-terminal domain): [8:247](score: 140.5, e-value: 6.7e-41)<br>\n \n  PF02801.22 (Beta-ketoacyl synthase, C-terminal domain): [254:364](score: 69.8, e-value: 1.9e-19)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSATDVRAAVTGLGVVAPNGLGTEAYWTATRKGVSGIGRVTRFVPDQYPAQLAGEIDGFDAHEHLPGRLLPQTDRMTQLALVAADWAFQDAAVRPEDLPGFEMGVITAGSSGGFEFGQRELQALWSKGSRYVSAYQSFAWFYAVNSGQISIRNGMRGPSGVVVSDQAGGLDAVAQARRQLRKGTRLVMSGAVDASICPWGWVAQMTSNRLSTGRDPARAYLPFDDAAAGHVPGEGGALLVMEDLQQARARGARIYGEIAGYGATLDPRPGSGRPPGLRKAVELALADAGAAPGDIDVVFADAAALPDLDRIEAETITAVFGARAVPVTAPKTMTGRLYSGAAPLDLAAAFLAMRDEVIPPSVGVTPSPGHDLDLVVGQERPAPVRSALVLARGHGGFNSAAVVRAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=36831&amp;to=58051\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_48_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSATDVRAAVTGLGVVAPNGLGTEAYWTATRKGVSGIGRVTRFVPDQYPAQLAGEIDGFDAHEHLPGRLLPQTDRMTQLALVAADWAFQDAAVRPEDLPGFEMGVITAGSSGGFEFGQRELQALWSKGSRYVSAYQSFAWFYAVNSGQISIRNGMRGPSGVVVSDQAGGLDAVAQARRQLRKGTRLVMSGAVDASICPWGWVAQMTSNRLSTGRDPARAYLPFDDAAAGHVPGEGGALLVMEDLQQARARGARIYGEIAGYGATLDPRPGSGRPPGLRKAVELALADAGAAPGDIDVVFADAAALPDLDRIEAETITAVFGARAVPVTAPKTMTGRLYSGAAPLDLAAAFLAMRDEVIPPSVGVTPSPGHDLDLVVGQERPAPVRSALVLARGHGGFNSAAVVRAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCGCGACGGACGTCCGGGCCGCCGTCACCGGACTGGGTGTCGTCGCGCCCAACGGGCTCGGCACGGAGGCCTACTGGACCGCCACCCGCAAGGGGGTCAGCGGCATCGGACGCGTCACGCGTTTCGTGCCCGACCAGTATCCCGCCCAACTGGCGGGCGAGATCGACGGGTTCGACGCGCACGAGCACCTGCCGGGCCGGCTGCTGCCGCAGACCGACCGGATGACCCAGCTCGCGCTGGTGGCCGCGGACTGGGCCTTCCAGGACGCCGCGGTCCGGCCGGAGGACCTTCCCGGGTTCGAGATGGGCGTCATCACCGCCGGCTCGTCCGGGGGCTTCGAGTTCGGCCAGCGGGAGCTGCAGGCCCTGTGGAGCAAGGGCAGCAGGTACGTCAGCGCCTACCAGTCCTTCGCCTGGTTCTACGCCGTCAACAGCGGTCAGATATCCATCCGCAACGGCATGCGCGGTCCCAGCGGTGTGGTCGTCAGCGACCAGGCCGGCGGGCTCGACGCGGTCGCCCAGGCACGTCGGCAGCTCCGCAAGGGCACGCGTCTGGTGATGTCGGGCGCCGTCGACGCCTCGATCTGTCCCTGGGGCTGGGTCGCCCAGATGACGAGCAACCGGCTGAGCACCGGCCGTGACCCGGCACGCGCCTACCTCCCCTTCGACGACGCGGCGGCCGGACACGTGCCCGGTGAGGGCGGCGCCCTGCTCGTCATGGAAGACCTGCAGCAGGCACGGGCCCGGGGGGCGCGGATCTACGGCGAGATCGCGGGATACGGCGCCACGCTGGACCCGCGGCCGGGCAGCGGACGGCCTCCCGGCCTGCGCAAGGCCGTCGAACTCGCCCTGGCCGACGCCGGTGCGGCGCCCGGTGACATCGACGTGGTGTTCGCCGACGCGGCCGCCCTGCCCGACCTCGACCGGATCGAGGCGGAGACGATCACGGCGGTGTTCGGCGCCCGGGCCGTGCCCGTGACGGCCCCCAAGACGATGACCGGGCGGCTCTACTCGGGGGCGGCGCCGCTGGACCTGGCCGCGGCGTTCCTCGCCATGCGGGACGAGGTGATTCCGCCGTCCGTCGGTGTCACCCCCTCCCCCGGTCACGACCTGGACCTGGTCGTCGGCCAGGAACGGCCGGCCCCGGTGCGCTCCGCCCTGGTACTCGCCCGCGGCCACGGCGGTTTCAACTCCGCGGCCGTGGTGCGCGCGGCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 48129,
                "end": 48398,
                "strand": 1,
                "locus_tag": "ctg1_49",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_49</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_49</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 48,129 - 48,398,\n (total: 270 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) PP-binding<br>\n \n  biosynthetic-additional (smcogs) SMCOG1129:acyl carrier protein (Score: 116.5; E-value: 7.2e-36)<br>\n \n  biosynthetic-additional (t2pks) ACP (Score: 136.1; E-value: 7e-43)<br>\n \n</div>\n<div class=\"focus-info\">\n \n  Active site details: <div class=\"collapser collapser-target-ctg1_49 collapser-level-none\"> </div><div class=\"collapser-content\">\n  <dl>\n  \n   <dt><strong>ACP</strong> (12..81)</dt>\n   <dd>\n   \n    found active site serine: True<br>\n   \n    non-beta-branching ACP<br>\n   \n   </dd>\n  \n  </dl>\n  </div><br>\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00550.25 (Phosphopantetheine attachment site): [22:79](score: 37.8, e-value: 1.8e-09)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPAHEFTLEDLKRILREGAGADEGVDLDGDILDTDFGLLGYESLALLETGGRIEREFGITLDDETLTDAATPRSLLEAVNALLVPAEVG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=38129&amp;to=58398\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_49_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPAHEFTLEDLKRILREGAGADEGVDLDGDILDTDFGLLGYESLALLETGGRIEREFGITLDDETLTDAATPRSLLEAVNALLVPAEVG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCCGCCCATGAGTTCACACTTGAGGACCTCAAGCGCATTCTGCGCGAGGGGGCCGGCGCGGACGAAGGCGTCGATCTCGACGGCGACATCCTCGACACCGACTTCGGACTGCTGGGCTACGAGTCCCTGGCGCTGCTGGAGACCGGCGGCAGGATCGAGCGCGAGTTCGGTATCACCCTCGACGACGAGACGCTGACCGACGCCGCGACCCCGCGGTCGCTGCTGGAGGCCGTCAACGCCCTGCTGGTGCCGGCCGAGGTCGGCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 48595,
                "end": 49380,
                "strand": 1,
                "locus_tag": "ctg1_50",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_50</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_50</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 48,595 - 49,380,\n (total: 786 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) adh_short<br>\n \n  biosynthetic-additional (smcogs) SMCOG1001:short-chain dehydrogenase/reductase SDR (Score: 269.2; E-value: 5.6e-82)<br>\n \n  biosynthetic-additional (t2pks) KR C9 (Score: 496.0; E-value: 5.1e-152)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00106.25 (short chain dehydrogenase): [7:201](score: 221.7, e-value: 5.8e-66)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTQQNPRVALVTGATSGIGLAVTRRLARQGHRVFLCARTETGVTRTVKDLLDEGLDVDGAPCDVRSGADVKRFVEQAVDRFGTIDVLVNNAGRSGGGVTADISDDLWSDVIDTNLNSVFRMTREVLTTGGMREKDRGRIINVASTAGKQGVVLGAPYSASKHGVVGFTKALGNELAPTGITVNAVCPGYVETPMAQRVRQGYAAAYDTTEDAILEKFQAKIPLGRYSTPEEVAGLVGYLASDTAASITSQALNVCGGLGNF&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=38595&amp;to=59380\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_50_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTQQNPRVALVTGATSGIGLAVTRRLARQGHRVFLCARTETGVTRTVKDLLDEGLDVDGAPCDVRSGADVKRFVEQAVDRFGTIDVLVNNAGRSGGGVTADISDDLWSDVIDTNLNSVFRMTREVLTTGGMREKDRGRIINVASTAGKQGVVLGAPYSASKHGVVGFTKALGNELAPTGITVNAVCPGYVETPMAQRVRQGYAAAYDTTEDAILEKFQAKIPLGRYSTPEEVAGLVGYLASDTAASITSQALNVCGGLGNF\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGCAGCAGAACCCGAGGGTCGCCCTCGTCACGGGCGCGACCAGCGGCATCGGCCTGGCGGTGACCAGGCGGCTGGCCCGCCAGGGCCACCGGGTGTTCCTCTGCGCCCGCACCGAGACCGGCGTGACCCGCACGGTCAAGGACCTGCTGGACGAGGGACTGGACGTGGACGGCGCCCCGTGCGACGTACGCTCCGGTGCCGACGTCAAGCGGTTCGTGGAGCAGGCCGTCGACCGCTTCGGCACCATCGACGTACTCGTCAACAACGCGGGCAGGTCGGGCGGCGGAGTCACCGCCGACATCTCCGACGACCTCTGGTCCGACGTGATCGACACCAATCTCAACAGCGTCTTCCGCATGACGCGTGAGGTGCTCACCACGGGCGGCATGCGCGAGAAGGACCGGGGCCGGATCATCAACGTCGCCTCCACCGCGGGCAAGCAGGGCGTGGTGCTCGGCGCCCCCTACTCGGCCTCCAAGCACGGCGTGGTCGGGTTCACCAAGGCACTCGGCAACGAACTCGCGCCCACCGGCATCACCGTCAACGCCGTCTGCCCCGGTTACGTCGAGACACCGATGGCCCAGCGGGTGCGCCAGGGCTACGCGGCCGCCTACGACACCACCGAGGACGCGATCCTCGAGAAGTTCCAGGCGAAGATCCCGCTCGGCCGTTACTCGACCCCCGAGGAGGTCGCGGGCCTGGTCGGCTACCTGGCCTCCGACACCGCCGCCTCCATCACCTCCCAGGCGCTGAACGTCTGCGGCGGCCTGGGCAACTTCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 49401,
                "end": 50336,
                "strand": 1,
                "locus_tag": "ctg1_51",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_51</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_51</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 49,401 - 50,336,\n (total: 936 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1128:cyclase/dehydrase (Score: 470.9; E-value: 3e-143)<br>\n \n  biosynthetic-additional (t2pks) CYC C7-C12 (Score: 504.3; E-value: 2.4e-154)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF10604.9 (Polyketide cyclase / dehydrase and lipid transport): [3:146](score: 45.8, e-value: 7.3e-12)<br>\n \n  PF10604.9 (Polyketide cyclase / dehydrase and lipid transport): [155:298](score: 30.7, e-value: 3.3e-07)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTTRQVEHEITVEAPAAAVYRLIAEVENWPRIFPPTIHVDHVERSTGEERIRIWATANGEAKNWTSRRTLDPERLRITFRQEVSTPPVAAMGGAWVIEPLSGDSARIRLLHDYRAVDDDPAGLRWIDEAVDRNSRAELAALKTNVELAHAAEDLTFSFEDTVHITGSAKDAYDFVDEAGLWAERLPHVASVRFTEDTPGLQTLEMDTRAKDGSTHTTKSYRVTFPHHRIAYKQVTLPALMTLHTGLWTFTENESGVTATSQHTVTLDTENIARVLGPDATVADARAYVQGALSANSLATLGHAKDHAEKRR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=39401&amp;to=60336\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_51_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTTRQVEHEITVEAPAAAVYRLIAEVENWPRIFPPTIHVDHVERSTGEERIRIWATANGEAKNWTSRRTLDPERLRITFRQEVSTPPVAAMGGAWVIEPLSGDSARIRLLHDYRAVDDDPAGLRWIDEAVDRNSRAELAALKTNVELAHAAEDLTFSFEDTVHITGSAKDAYDFVDEAGLWAERLPHVASVRFTEDTPGLQTLEMDTRAKDGSTHTTKSYRVTFPHHRIAYKQVTLPALMTLHTGLWTFTENESGVTATSQHTVTLDTENIARVLGPDATVADARAYVQGALSANSLATLGHAKDHAEKRR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGACCCGTCAGGTCGAGCACGAGATCACCGTCGAGGCCCCGGCCGCCGCCGTCTACCGGCTGATCGCCGAGGTGGAGAACTGGCCGCGGATCTTTCCTCCCACCATCCATGTCGACCATGTCGAGCGCTCCACGGGCGAGGAGCGCATCCGGATCTGGGCGACCGCCAACGGCGAGGCGAAGAACTGGACCTCGCGCCGCACACTGGACCCGGAGCGTCTGCGGATCACCTTCCGGCAGGAGGTGTCGACCCCACCGGTGGCCGCCATGGGCGGCGCGTGGGTCATCGAGCCGCTGTCGGGCGACTCGGCCCGGATCCGGCTGCTGCACGACTACCGGGCCGTCGACGACGACCCCGCGGGCCTGCGCTGGATCGACGAGGCCGTCGACCGCAACTCCCGCGCCGAGCTGGCCGCGCTCAAGACCAACGTGGAACTGGCCCACGCCGCCGAGGACCTCACCTTCTCCTTCGAGGACACCGTGCACATCACCGGCTCCGCCAAGGACGCCTACGACTTCGTCGACGAGGCGGGGCTGTGGGCGGAGCGGCTGCCTCACGTGGCCTCGGTCCGCTTCACGGAGGACACCCCCGGGCTGCAGACGCTGGAGATGGACACCCGGGCCAAGGACGGCTCGACGCACACCACGAAGTCGTACCGGGTGACGTTCCCGCACCACAGGATCGCCTACAAGCAGGTGACCCTGCCCGCGTTGATGACCCTGCACACCGGCCTGTGGACGTTCACGGAGAACGAGAGCGGGGTCACCGCCACCTCCCAGCACACCGTCACCCTCGACACGGAGAACATCGCCCGGGTCCTCGGCCCCGACGCGACCGTGGCCGATGCCCGCGCGTACGTCCAGGGCGCGCTGAGCGCCAACAGCCTGGCCACCCTCGGCCATGCCAAGGACCACGCCGAGAAGCGGCGCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 50338,
                "end": 52326,
                "strand": 1,
                "locus_tag": "ctg1_52",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_52</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_52</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 50,338 - 52,326,\n (total: 1989 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1050:monooxygenase FAD-binding (Score: 423; E-value: 3.1e-128)<br>\n \n  biosynthetic-additional (t2pks) OXY (Score: 605.1; E-value: 2.3e-184)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01494.19 (FAD binding domain): [4:334](score: 223.9, e-value: 3.3e-66)<br>\n \n  PF13561.6 (Enoyl-(Acyl carrier protein) reductase): [420:657](score: 157.2, e-value: 5e-46)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01494.19: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0071949' target='_blank'>GO:0071949</a>: FAD binding<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MAAPDTDVIVVGAGPSGLVLAGDLRAGGARVTVLERLARPTTESRASVLHARTLHLLAERGLLRRFGQLPAAGPGHFGGIPLDLSEAGDSPYAGQWKAPQTHVEAVLAAWATELGAEVRRGLTVTGLTRSSDRVRVVAVAPGGRRLRLDASYVVGCDGEDSAVRRLGGFGFPGAAATKELLRADLAGIELRERRFERHPRGVANARRGPDGVTRIMVHAFDRTPGPSRTPAFDDVCAVWARVTGEDITGARPVWLNAFDNARRQADGYRDGRVFLAGDAAHVQLPVGGQALNLGLQDAMDLGPKLAAHLAGRAGDEVLDTYDTVRRPVGARVLTNIEAQAQLLFGGPEVDPLRAVFRELLDLPAARRHLAAMVSGLDGGRPAWAGTGGPGKPAAPAPTRQDIRHRRITMGKLFGKTALVSGSSRGIGRATALRLARDGALVAVHCSSNREAAEETVAAIEKDGGRGFSVLAELGVPGDVHELFLALERELKERTGDTTLDILVNNAGVMGGVDPEELTPEQFDRLFAVNAKAPYFLVQRALANLPDGGRIINISSGLTRVANPQEVAYAMTKGAVDQLTLHFAKHLGPRGITVNSVGPGITDNGSPVFDDPEAVAAMAGYSVFNRVGETRDIADVVAFLASDDSRWITGSYLDASGGTLLGG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=40338&amp;to=62326\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_52_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MAAPDTDVIVVGAGPSGLVLAGDLRAGGARVTVLERLARPTTESRASVLHARTLHLLAERGLLRRFGQLPAAGPGHFGGIPLDLSEAGDSPYAGQWKAPQTHVEAVLAAWATELGAEVRRGLTVTGLTRSSDRVRVVAVAPGGRRLRLDASYVVGCDGEDSAVRRLGGFGFPGAAATKELLRADLAGIELRERRFERHPRGVANARRGPDGVTRIMVHAFDRTPGPSRTPAFDDVCAVWARVTGEDITGARPVWLNAFDNARRQADGYRDGRVFLAGDAAHVQLPVGGQALNLGLQDAMDLGPKLAAHLAGRAGDEVLDTYDTVRRPVGARVLTNIEAQAQLLFGGPEVDPLRAVFRELLDLPAARRHLAAMVSGLDGGRPAWAGTGGPGKPAAPAPTRQDIRHRRITMGKLFGKTALVSGSSRGIGRATALRLARDGALVAVHCSSNREAAEETVAAIEKDGGRGFSVLAELGVPGDVHELFLALERELKERTGDTTLDILVNNAGVMGGVDPEELTPEQFDRLFAVNAKAPYFLVQRALANLPDGGRIINISSGLTRVANPQEVAYAMTKGAVDQLTLHFAKHLGPRGITVNSVGPGITDNGSPVFDDPEAVAAMAGYSVFNRVGETRDIADVVAFLASDDSRWITGSYLDASGGTLLGG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGCGGCGCCGGACACCGATGTGATCGTCGTGGGAGCCGGGCCGTCCGGGCTCGTGCTCGCCGGGGACCTGCGGGCCGGCGGGGCGCGGGTGACCGTACTGGAACGGCTGGCGCGGCCCACCACCGAGTCCCGGGCGTCGGTCCTGCACGCACGCACCCTGCACCTGCTGGCCGAACGGGGTCTGCTGCGACGGTTCGGTCAGCTGCCCGCGGCCGGACCCGGTCACTTCGGCGGCATCCCTCTCGACCTGAGCGAGGCCGGGGACAGCCCGTACGCCGGACAGTGGAAGGCGCCTCAGACCCACGTCGAAGCCGTCCTCGCCGCATGGGCCACGGAACTCGGCGCCGAGGTGCGGCGGGGACTCACGGTGACCGGCCTGACCCGGAGCTCCGACCGGGTGCGTGTCGTCGCCGTCGCACCGGGCGGGCGGCGCCTGCGGCTGGACGCCTCCTACGTCGTCGGCTGCGACGGCGAGGACAGCGCCGTACGGCGGCTGGGCGGCTTCGGCTTCCCGGGGGCCGCGGCCACCAAGGAACTGCTGCGCGCCGACCTGGCCGGCATCGAACTGCGGGAGCGGCGTTTCGAGCGTCACCCCCGGGGCGTGGCCAACGCCCGCCGCGGGCCGGACGGCGTCACCCGCATCATGGTCCACGCCTTCGACCGGACCCCCGGACCGTCCCGTACCCCCGCCTTCGACGACGTCTGCGCGGTGTGGGCGCGCGTCACCGGCGAGGACATCACCGGCGCCCGGCCCGTCTGGCTCAACGCCTTCGACAACGCACGCCGGCAGGCGGACGGGTACCGCGACGGCCGGGTGTTCCTCGCCGGGGACGCGGCGCACGTCCAGCTGCCGGTGGGTGGCCAGGCACTCAACCTCGGTCTGCAGGACGCCATGGACCTGGGTCCGAAGCTCGCCGCTCACCTGGCCGGCCGGGCCGGTGACGAGGTGCTGGACACCTACGACACGGTCCGTCGTCCGGTGGGCGCCCGCGTCCTCACCAACATCGAGGCCCAGGCGCAGCTGTTGTTCGGCGGGCCCGAAGTGGATCCGTTGCGGGCGGTTTTCCGTGAATTGCTGGACCTCCCGGCGGCCCGCCGTCATCTGGCCGCCATGGTCAGCGGGCTCGACGGCGGCCGTCCGGCGTGGGCCGGCACCGGCGGGCCGGGGAAGCCGGCCGCCCCCGCCCCGACTCGTCAGGACATCAGGCACAGGAGGATCACCATGGGCAAGCTCTTCGGCAAGACCGCACTCGTCTCCGGCTCCAGCCGGGGCATCGGACGGGCCACGGCCCTCCGGCTGGCCCGCGACGGGGCGCTGGTCGCGGTGCACTGCTCCAGCAACCGGGAGGCGGCCGAGGAGACGGTCGCGGCCATCGAGAAGGACGGTGGCCGCGGGTTCTCCGTGCTGGCCGAACTCGGGGTGCCCGGTGATGTGCACGAGCTGTTCCTGGCCCTGGAAAGGGAGCTGAAGGAACGCACCGGAGACACCACGCTCGACATCCTGGTGAACAACGCCGGGGTGATGGGCGGGGTGGATCCCGAGGAACTGACCCCCGAGCAGTTCGACCGCCTCTTCGCCGTCAACGCGAAGGCACCGTACTTCCTGGTGCAGCGCGCCCTGGCCAACCTCCCCGACGGCGGGCGGATCATCAACATCTCCTCGGGGCTGACCCGGGTCGCGAACCCCCAGGAGGTGGCGTACGCGATGACCAAGGGCGCCGTCGACCAGCTCACCCTGCACTTCGCCAAACACCTCGGCCCGCGCGGCATCACCGTCAACAGTGTGGGCCCGGGCATCACCGACAACGGGTCACCCGTGTTCGACGACCCGGAGGCGGTGGCCGCGATGGCGGGCTACTCGGTGTTCAACCGGGTCGGTGAGACCCGCGACATCGCCGATGTGGTGGCTTTCCTGGCGAGCGACGACTCCCGCTGGATCACCGGCTCCTACCTGGACGCCAGCGGCGGCACCCTGCTCGGCGGCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 52343,
                "end": 53581,
                "strand": 1,
                "locus_tag": "ctg1_53",
                "type": "transport",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_53</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_53</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 52,343 - 53,581,\n (total: 1239 nt)<br>\n <br>\n \n  transport (smcogs) SMCOG1005:Drug resistance transporter, EmrB/QacA (Score: 133; E-value: 1.7e-40)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF07690.16 (Major Facilitator Superfamily): [34:369](score: 133.5, e-value: 8.5e-39)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF07690.16: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MPTPFASLSTLFTSPRPDRAGAGRRALLFVLAGNMLIDALEVSVVLVALPAMGRDLGLSMYGGQWMMSGFAAGFAALLLLGPRLAARWGRRRVYLAALTVFIAASLAGGLTDEGAVLAATRVVKGMCAALTAPTGLAIIGTVFRPGPEQSRAVSVYSLFGAAGFTVGLLSSGALTELSWRWNPVFPAPFAVLLLLAGVRLVPGDTGRTSAEPLRPAMARLVRNGPFVRSALCAATLNGTYLGLLLLLTHWLHDTWGWSSWETALAFLPACVPLALALPFAGRMVARFGTGPLIAAGGCATALGCATALLTGAPGTYVTGVLPVLLCVEAGFVLSFAALNLQAVSGIPAERRSTAVPVYQTAVQLGPLLSLPAVAAAAGSGYRPALLILTALSTTGAVIACAPSRRARADTAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=42343&amp;to=63581\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_53_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n  <a href=\"http://blast.jcvi.org/er-blast/index.cgi?project=transporter;program=blastp;database=pub/transporter.pep;sequence=sequence%0AMPTPFASLSTLFTSPRPDRAGAGRRALLFVLAGNMLIDALEVSVVLVALPAMGRDLGLSMYGGQWMMSGFAAGFAALLLLGPRLAARWGRRRVYLAALTVFIAASLAGGLTDEGAVLAATRVVKGMCAALTAPTGLAIIGTVFRPGPEQSRAVSVYSLFGAAGFTVGLLSSGALTELSWRWNPVFPAPFAVLLLLAGVRLVPGDTGRTSAEPLRPAMARLVRNGPFVRSALCAATLNGTYLGLLLLLTHWLHDTWGWSSWETALAFLPACVPLALALPFAGRMVARFGTGPLIAAGGCATALGCATALLTGAPGTYVTGVLPVLLCVEAGFVLSFAALNLQAVSGIPAERRSTAVPVYQTAVQLGPLLSLPAVAAAAGSGYRPALLILTALSTTGAVIACAPSRRARADTAA\" target=\"_new\">TransportDB BLAST on this gene</a><br>\n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MPTPFASLSTLFTSPRPDRAGAGRRALLFVLAGNMLIDALEVSVVLVALPAMGRDLGLSMYGGQWMMSGFAAGFAALLLLGPRLAARWGRRRVYLAALTVFIAASLAGGLTDEGAVLAATRVVKGMCAALTAPTGLAIIGTVFRPGPEQSRAVSVYSLFGAAGFTVGLLSSGALTELSWRWNPVFPAPFAVLLLLAGVRLVPGDTGRTSAEPLRPAMARLVRNGPFVRSALCAATLNGTYLGLLLLLTHWLHDTWGWSSWETALAFLPACVPLALALPFAGRMVARFGTGPLIAAGGCATALGCATALLTGAPGTYVTGVLPVLLCVEAGFVLSFAALNLQAVSGIPAERRSTAVPVYQTAVQLGPLLSLPAVAAAAGSGYRPALLILTALSTTGAVIACAPSRRARADTAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCCGACGCCCTTCGCTTCGCTGTCGACGCTCTTCACCTCACCGCGCCCGGACCGCGCCGGTGCCGGGCGGCGGGCCCTTCTGTTCGTCCTCGCCGGCAACATGCTCATCGACGCCCTGGAGGTGTCCGTCGTCCTGGTCGCCCTGCCGGCCATGGGGCGGGACCTGGGGCTGTCCATGTACGGCGGACAGTGGATGATGAGCGGCTTCGCCGCGGGGTTCGCTGCCCTGCTGCTGCTCGGCCCGCGTCTGGCCGCCCGGTGGGGACGACGACGCGTGTACCTCGCCGCGCTGACGGTGTTCATCGCCGCCTCGCTGGCCGGTGGCCTGACCGACGAAGGCGCCGTGCTGGCCGCGACCAGGGTGGTGAAGGGCATGTGCGCGGCGCTGACCGCGCCCACCGGGCTGGCCATCATCGGCACCGTCTTCCGGCCGGGACCCGAGCAGAGCCGGGCGGTGTCCGTGTACTCCCTCTTCGGCGCGGCGGGATTCACCGTGGGCCTGCTCTCCTCCGGTGCGCTCACCGAGCTCAGCTGGCGCTGGAACCCCGTGTTCCCGGCGCCGTTCGCCGTCCTCCTGCTGCTGGCCGGTGTCCGGCTCGTTCCCGGGGACACCGGCCGGACGTCCGCCGAGCCGCTGCGGCCGGCCATGGCCCGGCTGGTGCGCAACGGGCCGTTCGTACGGTCGGCGCTGTGCGCGGCGACGCTGAACGGCACCTACCTCGGGCTGCTGCTGCTCCTCACCCACTGGCTGCACGACACGTGGGGGTGGAGCTCCTGGGAAACGGCGCTGGCGTTCCTGCCGGCCTGTGTGCCGCTGGCGCTCGCCCTGCCGTTCGCCGGCCGGATGGTGGCGCGTTTCGGCACCGGACCGCTGATCGCGGCCGGAGGGTGCGCGACGGCGCTGGGCTGTGCGACGGCTCTGCTGACCGGAGCGCCCGGGACCTACGTCACCGGGGTGCTGCCGGTGCTCCTGTGCGTCGAGGCCGGTTTCGTCCTGTCCTTCGCGGCCCTCAACCTGCAGGCAGTGTCGGGCATCCCGGCCGAGCGGCGGAGCACGGCGGTGCCGGTCTACCAGACGGCGGTTCAGCTCGGTCCCCTGCTGTCCCTGCCGGCGGTGGCCGCGGCGGCCGGCTCGGGCTACCGCCCGGCCCTGCTGATCCTTACAGCGCTGTCGACGACCGGAGCCGTGATCGCCTGCGCCCCGTCTCGCCGCGCCCGCGCCGACACCGCGGCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 53622,
                "end": 54914,
                "strand": 1,
                "locus_tag": "ctg1_54",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_54</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_54</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 53,622 - 54,914,\n (total: 1293 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) oligosaccharide: MGT<br>\n \n  biosynthetic-additional (smcogs) SMCOG1062:glycosyltransferase, MGT family (Score: 369.1; E-value: 5.4e-112)<br>\n \n  biosynthetic-additional (t2pks) GT (Score: 456.7; E-value: 2e-139)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF06722.12 (Protein of unknown function (DUF1205)): [230:313](score: 52.4, e-value: 4.1e-14)<br>\n \n  PF00201.18 (UDP-glucoronosyl and UDP-glucosyl transferase): [305:398](score: 25.1, e-value: 7.1e-06)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR04516 (glycosyl_450act: glycosyltransferase, activator-dependent family): [0:430](score: 447.0, e-value: 1.7e-134)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00201.18: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016758' target='_blank'>GO:0016758</a>: transferase activity, transferring hexosyl groups<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRVLFTIFPATAHLYPVVPLAWALQSAGHEVVVASHAGVVDPGVIDNIAAAGLTAVPLGTPDELPEALGPHTGDAEPDRPSLGFDAFEPEETGSWRTTRAILTGMFRLHYPEPSEPGGRRPVLDNLVDFARDWRPDLVLWDPLMFPAPVAARVSGAAHARLLWGMDNIGVIHERTKRELADPSSDLTEHPWLGWFGPVLERHGLEFGDEMLLGQWTLDLTQSRMQAPLDQTRIPVRRVPYTGAGRLPGWLHTRPERPRVVLSLGVSRRKIFGRYSGFPMREFFASVSELDIEVVATLNSQQLDAAGTLPGNVRAVEYVPLNQVLPTASAIIHHGGGGTFSSAVAHQVPQLVMPLVMWDEMVTARYVRDMGAGLVADPDALDVAEMHKQLVRLLEDPSFPLGARRLHDEMLAAPAPKEIVPLLERLTAERR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=43622&amp;to=64914\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_54_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\"html/ctg1_54_searchgtr.html\" target=\"_new\">SEARCHGTr on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRVLFTIFPATAHLYPVVPLAWALQSAGHEVVVASHAGVVDPGVIDNIAAAGLTAVPLGTPDELPEALGPHTGDAEPDRPSLGFDAFEPEETGSWRTTRAILTGMFRLHYPEPSEPGGRRPVLDNLVDFARDWRPDLVLWDPLMFPAPVAARVSGAAHARLLWGMDNIGVIHERTKRELADPSSDLTEHPWLGWFGPVLERHGLEFGDEMLLGQWTLDLTQSRMQAPLDQTRIPVRRVPYTGAGRLPGWLHTRPERPRVVLSLGVSRRKIFGRYSGFPMREFFASVSELDIEVVATLNSQQLDAAGTLPGNVRAVEYVPLNQVLPTASAIIHHGGGGTFSSAVAHQVPQLVMPLVMWDEMVTARYVRDMGAGLVADPDALDVAEMHKQLVRLLEDPSFPLGARRLHDEMLAAPAPKEIVPLLERLTAERR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCGTGTCCTGTTCACCATCTTCCCGGCGACGGCACACCTGTATCCGGTGGTGCCGCTGGCCTGGGCGCTGCAGAGCGCCGGGCACGAGGTCGTCGTGGCGAGTCACGCGGGCGTCGTGGACCCGGGGGTGATCGACAACATCGCCGCGGCGGGGCTCACGGCCGTACCGCTGGGCACGCCGGACGAACTGCCGGAAGCTCTCGGCCCGCACACGGGCGACGCCGAGCCGGACCGGCCCTCCCTGGGATTCGACGCCTTCGAACCGGAGGAGACGGGGTCCTGGCGCACCACCCGCGCCATTCTCACCGGCATGTTCCGGTTGCACTATCCGGAGCCTTCGGAGCCGGGCGGCCGCCGGCCGGTGCTGGACAACCTGGTCGACTTCGCCCGTGACTGGCGTCCCGACCTGGTGCTGTGGGACCCGCTGATGTTCCCCGCCCCGGTCGCCGCCCGGGTCAGCGGCGCGGCGCACGCCCGGCTGCTGTGGGGCATGGACAACATCGGTGTGATCCACGAGCGCACGAAACGTGAACTGGCCGACCCCTCGTCGGACCTGACGGAACATCCGTGGCTGGGCTGGTTCGGCCCGGTTCTGGAGCGTCACGGGCTGGAGTTCGGCGACGAGATGCTGCTGGGCCAGTGGACGCTGGACCTGACCCAGTCCCGGATGCAGGCTCCGCTCGACCAGACACGCATACCGGTGCGCAGGGTCCCGTACACCGGCGCGGGCCGGCTGCCCGGCTGGCTGCACACCCGTCCCGAGCGCCCCCGAGTGGTGCTGTCCCTGGGCGTGAGCCGGCGCAAGATCTTCGGCAGGTACAGCGGCTTCCCGATGCGGGAGTTCTTCGCGTCGGTGTCGGAACTGGACATCGAGGTCGTCGCCACCCTGAACAGCCAGCAGCTCGACGCGGCGGGAACACTGCCCGGCAACGTACGCGCGGTGGAGTACGTCCCGCTCAACCAGGTCCTCCCGACCGCTTCCGCGATCATCCACCACGGCGGCGGCGGCACGTTCTCCTCCGCCGTCGCCCACCAGGTGCCGCAGCTGGTGATGCCGCTGGTCATGTGGGACGAGATGGTCACCGCCCGCTACGTACGGGACATGGGTGCGGGTCTGGTCGCCGACCCGGACGCCCTGGACGTCGCGGAGATGCACAAGCAGCTCGTACGGCTGCTGGAGGACCCGTCCTTCCCGTTGGGCGCCCGACGCCTGCACGACGAGATGCTCGCCGCGCCGGCGCCCAAGGAGATCGTTCCGCTGCTGGAGCGGCTGACCGCCGAACGCCGCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 54944,
                "end": 56140,
                "strand": 1,
                "locus_tag": "ctg1_55",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_55</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_55</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 54,944 - 56,140,\n (total: 1197 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) oligosaccharide: MGT<br>\n \n  biosynthetic-additional (smcogs) SMCOG1062:glycosyltransferase, MGT family (Score: 308.1; E-value: 1.9e-93)<br>\n \n  biosynthetic-additional (t2pks) GT (Score: 426.5; E-value: 2.9e-130)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF06722.12 (Protein of unknown function (DUF1205)): [176:272](score: 43.9, e-value: 2e-11)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRVLVISTPVPTHFLPLVPLLWALRSAGHEVTVLAQPDVVGAVRACGLTAIPAGEPFEVNGMLLKGLGRDRRPLQARPRPAPELLGGYGRLWWAHAASMLSRYSDVAEGYRPDIVLADPLEYCSLIIGARLGVPVVHHRWTVDAISGPARAFVRPGARELCERLGLPGLPDPDVLLDPCPPTLRLPGGEPGTPIRYVPYSGGGEVPAWVRADDGPRAGRRRVAVSLGNTLALHGVGFTRALLRALAASPGTEILVTLPEPYRSRIGPLPDTVTAVDPLPLHLFLGTCDAMVHHGGAGTAMTATSFGLPQLVLPQLADHFPVGDRLAATGAGLSFDTAERQDDPRTVGAALDDLLSDPRYAEAARGLAAEMAAMPSPAVAAAELERRARAGTRPRKASV&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=44944&amp;to=66140\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_55_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\"html/ctg1_55_searchgtr.html\" target=\"_new\">SEARCHGTr on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRVLVISTPVPTHFLPLVPLLWALRSAGHEVTVLAQPDVVGAVRACGLTAIPAGEPFEVNGMLLKGLGRDRRPLQARPRPAPELLGGYGRLWWAHAASMLSRYSDVAEGYRPDIVLADPLEYCSLIIGARLGVPVVHHRWTVDAISGPARAFVRPGARELCERLGLPGLPDPDVLLDPCPPTLRLPGGEPGTPIRYVPYSGGGEVPAWVRADDGPRAGRRRVAVSLGNTLALHGVGFTRALLRALAASPGTEILVTLPEPYRSRIGPLPDTVTAVDPLPLHLFLGTCDAMVHHGGAGTAMTATSFGLPQLVLPQLADHFPVGDRLAATGAGLSFDTAERQDDPRTVGAALDDLLSDPRYAEAARGLAAEMAAMPSPAVAAAELERRARAGTRPRKASV\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCGCGTACTGGTGATCTCCACTCCCGTTCCCACTCACTTCCTTCCGCTGGTACCGCTGCTGTGGGCGCTGCGCTCGGCCGGTCACGAGGTGACCGTGCTGGCTCAGCCCGATGTGGTCGGAGCCGTGCGGGCCTGCGGTCTGACGGCGATCCCGGCGGGCGAGCCGTTCGAGGTGAACGGGATGCTGCTGAAGGGGCTGGGACGGGACCGACGTCCGCTGCAGGCCCGGCCCCGGCCGGCTCCCGAACTGCTCGGCGGATACGGCAGGTTGTGGTGGGCCCATGCGGCCTCGATGCTCAGCCGCTACAGCGACGTGGCCGAGGGGTACCGGCCGGACATCGTCCTCGCCGATCCGCTGGAGTACTGCTCGCTGATCATCGGGGCACGGCTGGGTGTGCCGGTGGTGCACCACCGGTGGACGGTGGATGCCATCTCGGGGCCCGCCCGTGCCTTCGTCCGCCCCGGCGCACGTGAGCTGTGCGAGCGGCTCGGCCTTCCTGGCCTGCCCGACCCGGACGTGCTGCTCGATCCGTGTCCGCCCACCCTGCGGCTGCCGGGCGGCGAGCCGGGCACGCCCATCCGGTACGTGCCGTACAGCGGCGGCGGTGAGGTTCCCGCCTGGGTCCGGGCGGATGACGGACCGAGGGCCGGACGGCGACGGGTGGCCGTATCGCTGGGCAACACCCTGGCCCTGCACGGCGTGGGCTTCACCCGCGCTCTGCTGCGGGCCCTCGCCGCATCGCCCGGTACCGAGATCCTCGTGACGCTGCCCGAGCCGTACCGTTCCCGGATCGGCCCGCTGCCGGACACGGTGACGGCGGTCGACCCGCTCCCCCTCCATCTGTTCCTCGGGACCTGTGACGCGATGGTCCACCACGGGGGAGCCGGCACGGCCATGACGGCGACCTCCTTCGGACTCCCCCAGTTGGTGCTCCCTCAGCTGGCGGACCACTTCCCGGTGGGCGACCGGCTCGCCGCGACCGGAGCCGGGCTGTCCTTCGACACGGCGGAGCGGCAGGACGACCCGCGGACCGTCGGCGCGGCCCTGGACGACCTGCTGTCCGACCCCCGGTACGCGGAGGCGGCCCGTGGACTGGCAGCGGAGATGGCCGCGATGCCGTCCCCCGCCGTCGCGGCCGCCGAACTGGAGCGGCGAGCCCGGGCGGGCACCCGACCGAGAAAGGCGAGTGTCTAG\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 56140,
                "end": 56721,
                "strand": 1,
                "locus_tag": "ctg1_56",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_56</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_56</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 56,140 - 56,721,\n (total: 582 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) dTDP_sugar_isom<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00908.17 (dTDP-4-dehydrorhamnose 3,5-epimerase): [5:176](score: 171.8, e-value: 9.5e-51)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00908.17: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008830' target='_blank'>GO:0008830</a>: dTDP-4-dehydrorhamnose 3,5-epimerase activity<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VRIEELPLPGTYVITPELIPDPRGSFYEAMRGDLLEEATGVPFLPRQINYSVSRRHTLRGIHSVRIPPGQAKYVTCVRGALRDIVVDLRIGSPTFGEHRVNVLDADSGRSVYVPEGVGHGFLALTDDACICYVVSSTYVPGTQIDINPLDPDLGLPWDCPEPPLISDKDAKAPTVAEAVRAGLLPRFDKAGTP&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=46140&amp;to=66721\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_56_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VRIEELPLPGTYVITPELIPDPRGSFYEAMRGDLLEEATGVPFLPRQINYSVSRRHTLRGIHSVRIPPGQAKYVTCVRGALRDIVVDLRIGSPTFGEHRVNVLDADSGRSVYVPEGVGHGFLALTDDACICYVVSSTYVPGTQIDINPLDPDLGLPWDCPEPPLISDKDAKAPTVAEAVRAGLLPRFDKAGTP\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCGCATCGAGGAACTGCCCCTCCCGGGCACGTACGTGATCACACCCGAGCTGATCCCCGACCCACGGGGGTCGTTCTACGAGGCGATGCGCGGCGACCTGCTGGAAGAAGCCACCGGTGTTCCCTTCCTGCCTCGGCAGATCAACTACTCGGTCTCCCGGCGCCACACACTGCGCGGCATCCACAGCGTGCGCATCCCGCCCGGGCAGGCCAAGTACGTCACCTGCGTACGGGGCGCGCTGCGCGACATCGTCGTGGACCTGCGGATCGGCTCCCCCACCTTCGGGGAGCACCGGGTGAACGTGCTGGACGCGGACTCCGGGCGTTCGGTGTACGTGCCGGAGGGCGTGGGGCACGGGTTCCTCGCGCTGACCGACGACGCGTGCATCTGCTACGTCGTGTCCTCCACCTATGTGCCGGGCACGCAGATCGACATCAATCCGCTCGACCCGGATCTCGGGCTGCCCTGGGACTGCCCGGAGCCCCCTCTCATCTCCGACAAGGACGCCAAGGCCCCCACCGTGGCCGAGGCCGTACGGGCAGGTCTGCTGCCCCGATTCGACAAGGCAGGGACACCGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 56724,
                "end": 57854,
                "strand": 1,
                "locus_tag": "ctg1_57",
                "type": "biosynthetic",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_57</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_57</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 56,724 - 57,854,\n (total: 1131 nt)<br>\n <br>\n \n  biosynthetic (rule-based-clusters) oligosaccharide: MGT<br>\n \n  biosynthetic-additional (smcogs) SMCOG1062:glycosyltransferase, MGT family (Score: 267.5; E-value: 4e-81)<br>\n \n  biosynthetic-additional (t2pks) GT (Score: 404.1; E-value: 1.9e-123)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF06722.12 (Protein of unknown function (DUF1205)): [168:263](score: 63.1, e-value: 1.9e-17)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MLFVAAGSPATVFALAPLATAARNAGHQVVMAANDDMVPYITSSGLPGVATTDLPIRHFITTDRAGRPEAIPSHPVEQALFTGRWFARMAASSLPRMLDLCRSWRPDLIVGGTMSYVAPLLALHLGVPHVRQTWDAIEADGIHPGADAELLPELEPFGLDRLPEPDVFVDICPPSLRPAGAAPAQPMRYVPANAQRRLETWMVTRGERRRILVTSGSRVAKESYDKNFDFLRGLTADVASWDVELIVAAPDGTADALRDGLPGARVGWVPLDLVAPTCDLLVHHAGGVSTLTGLNAGVPQLLIPKGAVLERPALRVAEHGAAITLLPGEDSADAIADSCQELLAKDTYREGAGALSREIAAMPSPASVVATLGDLA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=46724&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_57_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n  <a href=\"html/ctg1_57_searchgtr.html\" target=\"_new\">SEARCHGTr on this gene</a><br>\n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MLFVAAGSPATVFALAPLATAARNAGHQVVMAANDDMVPYITSSGLPGVATTDLPIRHFITTDRAGRPEAIPSHPVEQALFTGRWFARMAASSLPRMLDLCRSWRPDLIVGGTMSYVAPLLALHLGVPHVRQTWDAIEADGIHPGADAELLPELEPFGLDRLPEPDVFVDICPPSLRPAGAAPAQPMRYVPANAQRRLETWMVTRGERRRILVTSGSRVAKESYDKNFDFLRGLTADVASWDVELIVAAPDGTADALRDGLPGARVGWVPLDLVAPTCDLLVHHAGGVSTLTGLNAGVPQLLIPKGAVLERPALRVAEHGAAITLLPGEDSADAIADSCQELLAKDTYREGAGALSREIAAMPSPASVVATLGDLA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGCTCTTCGTCGCCGCGGGAAGCCCGGCGACCGTGTTCGCCCTGGCCCCGCTGGCCACCGCCGCGCGCAACGCGGGACACCAGGTCGTGATGGCCGCGAACGACGACATGGTCCCGTACATCACGTCGTCGGGCCTGCCGGGCGTGGCCACCACCGATCTGCCGATCCGGCACTTCATCACCACCGACCGGGCCGGCCGTCCGGAGGCCATCCCCTCCCACCCGGTGGAGCAGGCGCTGTTCACCGGGCGCTGGTTCGCACGCATGGCCGCCTCGAGCCTGCCCCGGATGCTGGACCTCTGCCGGTCCTGGCGGCCCGATCTGATCGTCGGCGGCACGATGAGCTACGTCGCCCCGCTGCTCGCCCTGCACCTCGGCGTGCCCCACGTGCGGCAGACCTGGGACGCCATCGAGGCGGACGGCATCCACCCCGGCGCGGACGCGGAACTGCTGCCGGAGCTGGAACCGTTCGGGCTGGACCGGCTGCCCGAGCCGGACGTGTTCGTGGACATCTGCCCGCCGAGCCTGCGTCCCGCGGGTGCCGCCCCCGCACAGCCCATGCGCTACGTCCCGGCGAACGCCCAGCGGCGGCTGGAGACCTGGATGGTCACCCGCGGCGAGCGCCGCAGGATCCTCGTCACCTCGGGCAGCCGGGTCGCGAAGGAGAGCTACGACAAGAACTTCGACTTCCTGCGCGGCCTCACCGCGGACGTCGCCTCGTGGGACGTCGAGCTGATCGTCGCGGCGCCCGACGGGACCGCCGACGCGTTGCGCGACGGCCTGCCGGGGGCCCGCGTCGGCTGGGTGCCGCTGGATCTGGTGGCGCCCACCTGTGACCTGCTGGTGCACCACGCCGGCGGGGTGAGCACGCTGACCGGCCTGAACGCCGGTGTGCCTCAACTCCTCATTCCCAAGGGCGCCGTGCTGGAGAGGCCCGCCCTGCGCGTCGCCGAACACGGCGCGGCGATCACGCTGCTGCCGGGCGAGGACTCGGCCGACGCGATCGCGGACTCCTGTCAGGAGCTGCTGGCCAAGGACACCTACCGGGAGGGTGCGGGCGCCCTTTCCCGCGAGATCGCCGCCATGCCCTCCCCCGCGAGCGTGGTCGCCACGCTCGGAGATCTGGCGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 57883,
                "end": 58950,
                "strand": 1,
                "locus_tag": "ctg1_58",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_58</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_58</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 57,883 - 58,950,\n (total: 1068 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1064:glucose-1-phosphate adenylyl/thymidylyltransferase (Score: 331.3; E-value: 8.6e-101)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF00483.23 (Nucleotidyl transferase): [1:235](score: 168.3, e-value: 2.1e-49)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR01208 (rmlA_long: glucose-1-phosphate thymidylyltransferase): [1:352](score: 409.0, e-value: 3.3e-123)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF00483.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016779' target='_blank'>GO:0016779</a>: nucleotidyltransferase activity<br>\n  \n   PF00483.23: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MKALVLAGGSGTRLRPFSYSMPKQLIPIANTPVLVHVLDSVRELGVTEVGVIVGNRGPEIEAVLGDGSRFGVRITYIPQDEPRGLAHTVVIARDFLGPDDFVMYLGDNMLPDGIAETAAEFVRHRPAAHVVVHKVADPRSFGVAELGPDGEVRRLVEKPREPRSDLALIGVYFFTAAIHEAVASIEPSARGELEITDAVQWLLSSGADVRASRYDGYWKDTGKVEDVLECNSHLLDGLTRRVDGRVDDASVLVGRVVIEAGARVVRSRVEGPAIIGAGTVLEDSHIGPHTSIGRDCLVADSRLEGSIALDEATVTGVHGLRNSLIGRAASVGTTGRGTGHHCLVVGDHTRVEVAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=47883&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_58_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MKALVLAGGSGTRLRPFSYSMPKQLIPIANTPVLVHVLDSVRELGVTEVGVIVGNRGPEIEAVLGDGSRFGVRITYIPQDEPRGLAHTVVIARDFLGPDDFVMYLGDNMLPDGIAETAAEFVRHRPAAHVVVHKVADPRSFGVAELGPDGEVRRLVEKPREPRSDLALIGVYFFTAAIHEAVASIEPSARGELEITDAVQWLLSSGADVRASRYDGYWKDTGKVEDVLECNSHLLDGLTRRVDGRVDDASVLVGRVVIEAGARVVRSRVEGPAIIGAGTVLEDSHIGPHTSIGRDCLVADSRLEGSIALDEATVTGVHGLRNSLIGRAASVGTTGRGTGHHCLVVGDHTRVEVAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAAAGCTCTGGTGCTCGCAGGCGGGTCCGGTACCCGGCTGCGGCCTTTCAGCTATTCGATGCCCAAACAACTCATCCCCATCGCCAACACACCCGTCCTGGTGCACGTGCTCGACTCCGTCCGGGAGTTGGGCGTGACCGAGGTGGGGGTCATCGTCGGCAACCGCGGTCCGGAGATCGAGGCGGTCCTCGGTGACGGCTCCCGGTTCGGTGTGCGGATCACCTACATCCCCCAGGACGAACCGCGGGGACTGGCCCACACCGTGGTGATCGCGCGGGACTTCCTCGGTCCGGACGACTTCGTGATGTACCTGGGCGACAACATGCTGCCCGACGGGATCGCCGAGACCGCCGCGGAGTTCGTCCGGCACCGCCCGGCCGCGCACGTCGTCGTGCACAAGGTCGCGGACCCTCGCTCGTTCGGTGTCGCCGAACTGGGGCCCGACGGCGAGGTGCGGCGCCTGGTGGAGAAGCCCCGTGAGCCGCGCAGCGACCTGGCGTTGATCGGCGTCTACTTCTTCACCGCCGCCATCCACGAGGCGGTGGCGTCGATCGAGCCGAGCGCCCGCGGCGAACTGGAGATCACCGATGCCGTGCAGTGGCTCCTGTCCTCCGGGGCGGACGTGCGTGCCAGCCGCTACGACGGTTACTGGAAGGACACCGGGAAGGTCGAGGACGTCCTGGAGTGCAACAGCCATCTCCTCGACGGCCTGACCCGGCGCGTCGACGGACGGGTCGACGACGCCAGCGTGCTCGTCGGCCGGGTCGTGATCGAGGCCGGGGCACGCGTCGTCAGGTCCCGGGTGGAGGGTCCGGCGATCATCGGCGCGGGCACGGTGCTGGAGGACAGTCACATCGGCCCGCACACCTCCATCGGGCGGGACTGCCTGGTGGCGGACAGCCGGCTCGAGGGGTCGATCGCCCTGGACGAGGCGACCGTCACCGGTGTCCACGGCCTGCGCAACTCGCTCATCGGGCGCGCCGCGTCCGTGGGCACCACCGGACGGGGCACCGGCCATCACTGCCTCGTCGTGGGAGATCACACCCGAGTGGAGGTCGCGGCATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 58947,
                "end": 59930,
                "strand": 1,
                "locus_tag": "ctg1_59",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_59</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_59</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 58,947 - 59,930,\n (total: 984 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) NAD_binding_4<br>\n \n  biosynthetic-additional (rule-based-clusters) Polysacc_synt_2<br>\n \n  biosynthetic-additional (rule-based-clusters) RmlD_sub_bind<br>\n \n  biosynthetic-additional (smcogs) SMCOG1010:NAD-dependent epimerase/dehydratase (Score: 355.4; E-value: 4.9e-108)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01370.21 (NAD dependent epimerase/dehydratase family): [2:241](score: 222.4, e-value: 6e-66)<br>\n \n <br>\n \n\n \n <br>\n <span class=\"bold\">TIGRFam hits:</span><br>\n \n  TIGR01181 (dTDP_gluc_dehyt: dTDP-glucose 4,6-dehydratase): [1:319](score: 421.1, e-value: 5.9e-127)<br>\n \n <br>\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01370.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF01370.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0050662' target='_blank'>GO:0050662</a>: coenzyme binding<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MRILVTGAAGFIGSHFVRSLLADEYRGWEGAQVTALDKLTYAGNRENLPASHERLVFVRGDVCDRSLLRELLPGHDAVVHFAAESHVDRSLEGAGEFFRTNVLGTQTVLDAVLESGVERVVHVSTDEVYGSITEGSWTEEWPLAPNSPYAASKAGSDLVARAYWRTHGVDLSITRCSNNYGPYQHPEKVIPLFVTNLLEGGQVPLYGDGRNVREWLHVADHCRGIHLVLNEGRAGEIYNIGGGNEYTNLDLTRKLLELTGAGEEKIRRVADRKAHDLRYSIDESKIREELGYAPRIGFEEGLAETVAWYRDNPDWWKAVKHGTGRAA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=48947&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_59_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MRILVTGAAGFIGSHFVRSLLADEYRGWEGAQVTALDKLTYAGNRENLPASHERLVFVRGDVCDRSLLRELLPGHDAVVHFAAESHVDRSLEGAGEFFRTNVLGTQTVLDAVLESGVERVVHVSTDEVYGSITEGSWTEEWPLAPNSPYAASKAGSDLVARAYWRTHGVDLSITRCSNNYGPYQHPEKVIPLFVTNLLEGGQVPLYGDGRNVREWLHVADHCRGIHLVLNEGRAGEIYNIGGGNEYTNLDLTRKLLELTGAGEEKIRRVADRKAHDLRYSIDESKIREELGYAPRIGFEEGLAETVAWYRDNPDWWKAVKHGTGRAA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGGATTCTTGTCACCGGAGCGGCGGGCTTCATCGGCTCGCACTTCGTCCGCAGTCTGCTGGCGGACGAGTACCGCGGCTGGGAAGGCGCCCAGGTCACCGCCCTGGACAAGCTGACCTACGCCGGCAACCGGGAGAACCTGCCCGCCTCGCACGAGCGCCTGGTGTTCGTCCGCGGCGACGTGTGCGACCGGTCCCTGCTCCGCGAACTGCTGCCCGGCCACGACGCCGTGGTGCACTTCGCGGCCGAGTCCCACGTGGACCGGTCCCTGGAGGGGGCCGGGGAGTTCTTCCGGACGAACGTGCTGGGCACCCAGACCGTGCTGGACGCCGTGCTGGAGAGCGGGGTCGAGCGGGTGGTGCACGTCTCCACCGACGAGGTCTACGGCTCGATCACGGAGGGCTCCTGGACGGAGGAGTGGCCGCTGGCGCCCAACTCGCCCTACGCGGCCTCGAAGGCGGGCTCGGACCTGGTCGCCCGCGCCTACTGGCGGACGCACGGCGTGGACCTGTCGATCACCCGCTGCTCCAACAACTACGGCCCCTACCAGCACCCCGAGAAGGTCATTCCGCTCTTCGTGACCAATCTGCTGGAGGGCGGTCAAGTCCCGCTGTACGGGGACGGACGCAACGTGCGCGAGTGGCTCCACGTGGCCGACCACTGCCGCGGCATCCACCTGGTGCTGAACGAGGGCCGGGCCGGGGAGATCTACAACATCGGCGGCGGCAACGAGTACACCAACCTCGATCTCACCCGGAAGCTGCTGGAACTGACCGGCGCCGGCGAGGAGAAGATCCGCCGGGTGGCCGATCGCAAGGCGCACGACCTGCGGTACTCGATCGACGAGTCGAAGATCCGGGAGGAACTCGGCTACGCGCCCCGGATCGGGTTCGAGGAGGGTCTGGCGGAGACCGTGGCCTGGTACCGCGACAACCCCGACTGGTGGAAGGCCGTCAAGCACGGGACGGGCCGTGCGGCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 59920,
                "end": 60978,
                "strand": 1,
                "locus_tag": "ctg1_60",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_60</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_60</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 59,920 - 60,978,\n (total: 1059 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) RmlD_sub_bind<br>\n \n  biosynthetic-additional (smcogs) SMCOG1010:NAD-dependent epimerase/dehydratase (Score: 149.1; E-value: 3.1e-45)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01370.21 (NAD dependent epimerase/dehydratase family): [12:258](score: 105.7, e-value: 2.5e-30)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01370.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF01370.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0050662' target='_blank'>GO:0050662</a>: coenzyme binding<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VRPDRGRVPGLSVVVLGSGGFLGRGLGAAFASRGARVHLFSRGGPPPVTGPPAGRTTTATRLDLLTADAKELRTALAAARPDVVVNAAGRAWRADEAEMAAGNATLVERVVTALAALPGPPVRLVQLGSVHEYGAGDPAGATGEDHRPEPVTPYGRTKLLGTRAVLRGAREGSVEGVVLRLANVIGAGVPEGSLFGRVAAHLGEAAAARARGEHVAALRLPPLRAARDLVDAGDVADAVVAVATAPSAAVNGQVINVGRGEAVAMRALIDRMIALSGLDVPVTEAAEAPAARTDVARQCLDISRARRLLGWRPSRGLDDSLRNLLASVLPPERPSHSTPLGITAGVPAGEGK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=49920&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_60_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VRPDRGRVPGLSVVVLGSGGFLGRGLGAAFASRGARVHLFSRGGPPPVTGPPAGRTTTATRLDLLTADAKELRTALAAARPDVVVNAAGRAWRADEAEMAAGNATLVERVVTALAALPGPPVRLVQLGSVHEYGAGDPAGATGEDHRPEPVTPYGRTKLLGTRAVLRGAREGSVEGVVLRLANVIGAGVPEGSLFGRVAAHLGEAAAARARGEHVAALRLPPLRAARDLVDAGDVADAVVAVATAPSAAVNGQVINVGRGEAVAMRALIDRMIALSGLDVPVTEAAEAPAARTDVARQCLDISRARRLLGWRPSRGLDDSLRNLLASVLPPERPSHSTPLGITAGVPAGEGK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGCGGCCTGACCGCGGGCGCGTGCCGGGGCTGTCGGTCGTGGTCCTGGGGAGCGGCGGGTTCCTGGGCCGTGGGCTCGGCGCGGCGTTCGCCTCGCGGGGTGCGCGGGTGCACCTGTTCTCCCGCGGCGGTCCGCCGCCGGTCACCGGTCCGCCCGCGGGCCGGACCACGACGGCCACGCGCCTGGACCTGCTGACGGCGGACGCGAAGGAGCTGCGGACGGCCTTGGCGGCGGCCCGCCCGGACGTCGTGGTGAACGCGGCGGGCCGGGCCTGGCGGGCCGACGAGGCGGAGATGGCCGCCGGCAACGCCACGCTCGTCGAGCGGGTCGTGACCGCCCTCGCCGCGCTCCCCGGCCCTCCGGTACGGCTGGTGCAGCTGGGCAGCGTCCACGAGTACGGAGCCGGCGACCCGGCCGGCGCCACGGGCGAGGACCACCGCCCCGAACCGGTCACGCCCTACGGCCGCACCAAACTCCTCGGGACGCGGGCCGTGCTGCGCGGGGCGCGGGAGGGAAGCGTCGAAGGGGTGGTGCTCCGGCTCGCCAACGTGATCGGCGCCGGGGTTCCCGAGGGCAGTCTCTTCGGCAGGGTGGCGGCCCATCTGGGTGAGGCGGCGGCGGCGCGGGCTCGCGGCGAGCACGTCGCCGCCCTCCGGCTGCCGCCGCTGCGCGCGGCCCGCGACCTGGTGGACGCCGGTGACGTCGCCGACGCGGTGGTGGCCGTGGCCACGGCCCCGTCGGCGGCCGTCAACGGTCAGGTGATCAACGTGGGCCGCGGCGAGGCGGTGGCCATGCGCGCGCTGATCGACCGGATGATCGCGCTCAGCGGCCTGGACGTCCCCGTGACCGAGGCCGCGGAGGCGCCGGCGGCCCGTACCGACGTGGCCCGTCAGTGTCTGGACATCTCCCGGGCCCGGCGCCTGCTGGGCTGGCGCCCCTCGCGCGGACTCGACGACTCCTTGCGGAACCTCCTGGCCTCCGTGCTGCCGCCGGAGCGTCCGTCGCACAGCACACCACTCGGCATCACGGCCGGAGTCCCGGCCGGAGAAGGGAAATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 60975,
                "end": 62285,
                "strand": 1,
                "locus_tag": "ctg1_61",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_61</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_61</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 60,975 - 62,285,\n (total: 1311 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) DegT_DnrJ_EryC1<br>\n \n  biosynthetic-additional (smcogs) SMCOG1056:DegT/DnrJ/EryC1/StrS aminotransferase (Score: 374.1; E-value: 1.3e-113)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01041.17 (DegT/DnrJ/EryC1/StrS aminotransferase family): [45:428](score: 313.0, e-value: 2.9e-93)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MIMSERKGRILEEVRAYHRETAPAREFVPGTTEIWPSGAVLEDADRVALVEAALELRIAAGTSSRKFESQFARRLKRRKAHLTNSGSSANLLAVSALMSHALEERRLKPGDEVITVAAGFPTTVNPILQNGLIPVFVDVDLGTYNATADRVAAAIGPKTRAVIIAHALGNPFEVTEIAQLCEQHDLFLIEDNCDAVGSLYDGKLTGTFGDMTTVSFYPAHHLTMGEGGCVLTSNLALARIVESLRDWGRDCWCEPGENDRCLKRFTYQMGTLPAGYDHKYIFSHVGYNLKATDIQAALGLTQLAKLDSFIEARRRNWQRLREGLDGVPGLLLPEATPRSEPSWFGFVITVDPEAPFSRAELVDFLEGRKIGTRRLFAGNLTRHPAYIDQPHRIVGDLANSDVITEHTFWIGVYPALTDEMLDYVTASIKEFVAARG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=50975&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_61_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MIMSERKGRILEEVRAYHRETAPAREFVPGTTEIWPSGAVLEDADRVALVEAALELRIAAGTSSRKFESQFARRLKRRKAHLTNSGSSANLLAVSALMSHALEERRLKPGDEVITVAAGFPTTVNPILQNGLIPVFVDVDLGTYNATADRVAAAIGPKTRAVIIAHALGNPFEVTEIAQLCEQHDLFLIEDNCDAVGSLYDGKLTGTFGDMTTVSFYPAHHLTMGEGGCVLTSNLALARIVESLRDWGRDCWCEPGENDRCLKRFTYQMGTLPAGYDHKYIFSHVGYNLKATDIQAALGLTQLAKLDSFIEARRRNWQRLREGLDGVPGLLLPEATPRSEPSWFGFVITVDPEAPFSRAELVDFLEGRKIGTRRLFAGNLTRHPAYIDQPHRIVGDLANSDVITEHTFWIGVYPALTDEMLDYVTASIKEFVAARG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGATCATGAGCGAGCGCAAGGGTCGGATTCTCGAAGAGGTCCGCGCGTATCACCGGGAGACCGCCCCGGCACGCGAGTTCGTCCCGGGGACGACGGAGATCTGGCCGTCCGGCGCGGTACTGGAGGACGCGGACCGAGTGGCGCTGGTGGAGGCCGCGCTGGAGCTGCGCATCGCCGCCGGGACCAGCTCCCGCAAGTTCGAGTCACAGTTCGCACGACGCCTCAAGCGCCGCAAGGCGCATCTGACCAACTCCGGTTCGTCGGCGAACCTGCTGGCCGTGTCGGCGCTGATGTCGCACGCACTGGAGGAGCGGCGGCTGAAGCCGGGCGACGAGGTCATCACGGTCGCGGCGGGCTTCCCCACCACGGTCAACCCGATCCTGCAGAACGGTCTCATCCCGGTCTTCGTGGACGTCGACCTCGGCACCTACAACGCGACGGCCGACCGGGTGGCCGCGGCGATCGGCCCCAAGACCCGCGCCGTCATCATCGCGCACGCGCTGGGCAACCCCTTCGAGGTCACGGAGATCGCCCAGCTCTGCGAACAGCACGACCTGTTCCTGATCGAGGACAACTGCGACGCGGTCGGCTCCCTCTACGACGGGAAGCTCACCGGCACCTTCGGCGACATGACGACGGTCAGCTTCTACCCGGCGCACCACTTGACCATGGGCGAGGGCGGCTGTGTGCTCACCTCCAACCTGGCCCTGGCCCGCATCGTGGAGTCGTTGCGCGACTGGGGGCGGGACTGCTGGTGCGAACCCGGTGAGAACGACCGCTGCCTGAAGCGGTTCACGTACCAGATGGGCACGCTGCCGGCCGGGTACGACCACAAGTACATCTTCTCCCACGTGGGGTACAACCTGAAGGCCACGGACATCCAGGCCGCACTCGGGCTCACGCAGCTGGCCAAGCTGGACTCCTTCATCGAGGCGCGGCGGCGCAACTGGCAGCGGCTGCGGGAGGGACTGGACGGGGTCCCGGGCCTGCTGCTGCCCGAGGCCACGCCCCGCTCCGAGCCCAGCTGGTTCGGCTTCGTCATCACCGTGGACCCCGAAGCGCCGTTCAGCCGCGCCGAGCTGGTCGACTTCCTGGAGGGCCGCAAGATCGGCACGCGTCGGCTCTTCGCCGGGAACCTGACCCGTCACCCGGCCTACATCGACCAGCCGCACCGGATCGTGGGCGACCTGGCCAACAGCGACGTCATCACCGAGCACACCTTCTGGATCGGGGTCTACCCGGCGCTCACGGACGAGATGCTGGACTACGTCACCGCCTCGATCAAGGAGTTCGTGGCCGCGCGCGGCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 62336,
                "end": 63100,
                "strand": 1,
                "locus_tag": "ctg1_62",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_62</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_62</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 62,336 - 63,100,\n (total: 765 nt)<br>\n <br>\n \n  biosynthetic-additional (rule-based-clusters) RmlD_sub_bind<br>\n \n  biosynthetic-additional (smcogs) SMCOG1010:NAD-dependent epimerase/dehydratase (Score: 84; E-value: 2.1e-25)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01370.21 (NAD dependent epimerase/dehydratase family): [18:177](score: 63.6, e-value: 1.9e-17)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01370.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity<br>\n  \n   PF01370.21: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0050662' target='_blank'>GO:0050662</a>: coenzyme binding<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MDIVGTGFLARNLRPLAGRHPDTVALAAGVSWASGTSDADFAREAALLREVAGRCRDTGRRLLFFSTAATGMYGLADGPGREDVPVTPCTPYGAHKLALEGVLRDSGADHLILRLGHLVGPHQPEHQLLPTLVRQLREGMVRVHRGAARDLIGVEDVITVVDHLLAAGPRAETVNVASGFAVPVEDVVGHLEQALGLRARREFVETGGRQHVISTEKLRSLVPQTAHMGFGPSYYRRILGDFAASVASGATAPA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=52336&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_62_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MDIVGTGFLARNLRPLAGRHPDTVALAAGVSWASGTSDADFAREAALLREVAGRCRDTGRRLLFFSTAATGMYGLADGPGREDVPVTPCTPYGAHKLALEGVLRDSGADHLILRLGHLVGPHQPEHQLLPTLVRQLREGMVRVHRGAARDLIGVEDVITVVDHLLAAGPRAETVNVASGFAVPVEDVVGHLEQALGLRARREFVETGGRQHVISTEKLRSLVPQTAHMGFGPSYYRRILGDFAASVASGATAPA\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGGACATTGTGGGAACCGGTTTCCTGGCGCGGAACCTGCGCCCGCTGGCCGGCCGGCATCCGGACACCGTGGCTTTGGCGGCCGGGGTGTCGTGGGCGAGCGGCACCTCCGACGCGGACTTCGCCCGCGAGGCGGCGCTGTTGCGCGAGGTCGCCGGCCGGTGCCGCGACACCGGCCGGCGGCTGCTCTTCTTCTCCACCGCGGCGACCGGCATGTACGGACTCGCCGACGGGCCCGGCCGGGAGGACGTCCCGGTGACCCCCTGTACCCCTTACGGCGCGCACAAGCTCGCCCTGGAAGGAGTGCTGCGCGACTCCGGCGCCGACCATCTGATCCTCCGGCTGGGGCACCTGGTCGGCCCGCACCAGCCCGAGCACCAGCTGCTGCCCACCCTGGTACGGCAGCTGCGCGAGGGGATGGTCCGGGTGCACCGGGGCGCGGCCCGGGATCTGATCGGCGTGGAGGACGTCATCACCGTCGTCGACCATCTCCTCGCCGCCGGTCCGCGCGCCGAGACGGTCAACGTGGCGTCCGGTTTCGCCGTACCGGTGGAGGACGTCGTCGGCCACCTCGAGCAGGCGCTCGGACTGCGGGCGCGCCGGGAGTTCGTCGAGACGGGCGGCCGCCAGCACGTCATCTCGACGGAGAAGCTGCGCTCCCTCGTGCCGCAGACCGCGCACATGGGGTTCGGCCCCTCCTACTACCGGCGGATCCTCGGGGACTTCGCGGCCTCCGTGGCGTCCGGCGCCACCGCACCTGCCTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 63127,
                "end": 64080,
                "strand": 1,
                "locus_tag": "ctg1_63",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_63</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_63</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 63,127 - 64,080,\n (total: 954 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTHHRNRTRNDRRRTVRRAVALAGAALLLAGLHGPAPAAPAPPVSAADASYTAGAPATVDLVSTATEFTAPATTRPGPTTFRASTTQSGKGWIGLARLKDGKGWDDFLDVLSRALSDTPSDVPRGAKDLDETAVLLGGLVIHPGQPGTFTQHLRPGRYLLFDYLTAGDAEPRHRWLTVTGEASGRFPEPTATVVARNVPGVGPRFEVRGSLRAGRPLRYVNRIPGQVNELLFVKIAEGTTEAELKAWFDALPDDGTFPPDSPFRSVSLGSLHLSTGRSSVVRVPLEPDRYAAITYSKDATDGIKLVKKGLFAVVDVH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=53127&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_63_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTHHRNRTRNDRRRTVRRAVALAGAALLLAGLHGPAPAAPAPPVSAADASYTAGAPATVDLVSTATEFTAPATTRPGPTTFRASTTQSGKGWIGLARLKDGKGWDDFLDVLSRALSDTPSDVPRGAKDLDETAVLLGGLVIHPGQPGTFTQHLRPGRYLLFDYLTAGDAEPRHRWLTVTGEASGRFPEPTATVVARNVPGVGPRFEVRGSLRAGRPLRYVNRIPGQVNELLFVKIAEGTTEAELKAWFDALPDDGTFPPDSPFRSVSLGSLHLSTGRSSVVRVPLEPDRYAAITYSKDATDGIKLVKKGLFAVVDVH\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACGCACCACAGGAACCGGACGAGGAACGACCGTCGGCGCACCGTGCGCCGAGCGGTCGCGCTGGCCGGTGCCGCACTTCTGCTGGCCGGACTGCACGGGCCCGCCCCCGCGGCCCCCGCGCCCCCGGTGAGCGCGGCGGACGCCTCGTACACCGCCGGGGCGCCGGCCACGGTGGACCTCGTCTCGACCGCGACGGAGTTCACCGCACCGGCCACCACCCGCCCGGGACCGACCACGTTCCGCGCCTCGACCACCCAGTCGGGCAAGGGCTGGATCGGGCTGGCCCGGCTGAAGGACGGCAAGGGCTGGGACGACTTCCTGGACGTTCTCTCCCGCGCGCTGTCCGACACCCCGTCCGACGTTCCGCGGGGTGCCAAGGACCTGGACGAGACCGCCGTTCTGCTCGGAGGGCTGGTGATCCACCCCGGACAGCCCGGGACGTTCACGCAGCACCTGCGTCCGGGACGGTATCTGCTGTTCGACTACCTCACGGCCGGCGACGCCGAGCCTCGGCACCGCTGGCTGACGGTCACCGGCGAAGCCTCCGGCCGGTTCCCGGAGCCGACCGCGACCGTCGTGGCGAGGAACGTCCCCGGCGTCGGTCCGCGCTTCGAGGTCCGTGGCAGTCTCCGCGCCGGCCGGCCGCTGCGCTACGTCAACCGGATCCCCGGGCAGGTGAACGAACTGCTTTTCGTGAAGATCGCGGAGGGGACCACCGAGGCGGAGCTCAAGGCCTGGTTCGACGCCCTGCCCGACGACGGCACCTTCCCGCCCGATTCTCCGTTCCGCTCGGTCAGTCTCGGCAGCCTGCACCTGTCCACGGGCCGCTCGTCCGTCGTGCGGGTCCCGCTGGAGCCCGACCGGTACGCGGCGATCACCTACTCGAAGGACGCCACCGACGGCATCAAGCTCGTCAAGAAGGGCCTGTTCGCCGTCGTCGACGTGCACTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 64135,
                "end": 65538,
                "strand": 1,
                "locus_tag": "ctg1_64",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_64</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_64</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 64,135 - 65,538,\n (total: 1404 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF03559.14 (NDP-hexose 2,3-dehydratase): [34:242](score: 288.8, e-value: 1.7e-86)<br>\n \n  PF03559.14 (NDP-hexose 2,3-dehydratase): [256:459](score: 263.9, e-value: 7.5e-79)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTPPSLPQARANTRRVTERLGLSAATSRGAHLPTDRFSAWLAERGSANAFRVDRIPFAELDGWSFEETTGNLVHRSGRFFTVEGMRVTERDEPYGDGPFAEWHQPVIKQPEVGILGILAKEFDGVLHFLMQAKMEPGNPNLLQLSPTVQATRSNYTKAHQGADVKYIQHFVGPGRGRVVADALQSEHGSWFFRKANRNMIVEATGDVPLLDDFCWLTLGQIAELLHRDNVVNMDSRTVLSCLPVPETADGALHSDVELLSWITGERARHDVHAERVPLAGLPGWHRHETAIEHEEGRYFKVVAVSVQAGNREVTSWTQPLFEPVGQGVTAFLTRTFDGVPHVLVHARVEGGFLDTVELGPTVQYTPANYAHLPEKERPPYLDTVLEAPAERIRYEAVHAEEGGRFLNAESRYLLVDADERDAPLDPPPGYAWVTPDQLTWLVRHGHYLNVQARTLLACLNARAAVAR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=54135&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_64_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"VTPPSLPQARANTRRVTERLGLSAATSRGAHLPTDRFSAWLAERGSANAFRVDRIPFAELDGWSFEETTGNLVHRSGRFFTVEGMRVTERDEPYGDGPFAEWHQPVIKQPEVGILGILAKEFDGVLHFLMQAKMEPGNPNLLQLSPTVQATRSNYTKAHQGADVKYIQHFVGPGRGRVVADALQSEHGSWFFRKANRNMIVEATGDVPLLDDFCWLTLGQIAELLHRDNVVNMDSRTVLSCLPVPETADGALHSDVELLSWITGERARHDVHAERVPLAGLPGWHRHETAIEHEEGRYFKVVAVSVQAGNREVTSWTQPLFEPVGQGVTAFLTRTFDGVPHVLVHARVEGGFLDTVELGPTVQYTPANYAHLPEKERPPYLDTVLEAPAERIRYEAVHAEEGGRFLNAESRYLLVDADERDAPLDPPPGYAWVTPDQLTWLVRHGHYLNVQARTLLACLNARAAVAR\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"GTGACGCCACCTTCCCTCCCGCAGGCCCGCGCCAACACGCGGCGGGTGACGGAACGCCTCGGGCTGTCCGCCGCCACCTCCCGGGGCGCTCACCTGCCGACCGACCGCTTCTCCGCATGGCTCGCCGAACGTGGCAGCGCCAACGCCTTCCGCGTGGACCGGATCCCCTTCGCCGAGCTGGACGGCTGGTCGTTCGAGGAGACCACCGGCAATCTCGTGCACCGCAGCGGCAGGTTCTTCACGGTCGAGGGCATGCGGGTGACCGAGCGGGACGAACCCTACGGCGACGGCCCGTTCGCCGAGTGGCACCAGCCCGTGATCAAGCAGCCCGAGGTGGGCATCCTGGGCATCCTGGCCAAGGAGTTCGACGGGGTCCTGCACTTCCTCATGCAGGCGAAGATGGAGCCCGGCAATCCCAACCTGCTCCAGCTCTCCCCCACGGTGCAGGCCACTCGCAGCAACTACACCAAGGCCCATCAGGGCGCGGATGTGAAGTACATACAGCACTTCGTCGGTCCCGGGCGTGGCCGGGTCGTCGCGGACGCCCTGCAGTCCGAGCACGGTTCGTGGTTCTTCCGCAAGGCCAACCGCAACATGATCGTGGAGGCCACCGGCGACGTGCCGCTCCTCGACGACTTCTGCTGGCTCACCCTGGGACAGATCGCCGAACTGCTGCACCGGGACAATGTCGTCAACATGGACTCGCGGACGGTCCTGTCCTGCCTCCCGGTCCCGGAGACGGCGGACGGCGCCCTGCACTCCGACGTCGAGCTGCTGTCCTGGATCACCGGTGAGCGCGCCCGGCACGATGTGCACGCCGAACGTGTCCCGCTGGCCGGGCTGCCCGGCTGGCACCGCCATGAGACGGCCATCGAGCACGAGGAGGGCCGGTACTTCAAAGTGGTGGCCGTGTCCGTACAGGCGGGCAACCGCGAGGTCACCAGCTGGACCCAGCCGCTGTTCGAGCCGGTCGGCCAGGGGGTGACCGCGTTCCTCACCCGCACCTTCGACGGCGTCCCGCACGTGCTGGTGCACGCCCGGGTCGAGGGGGGCTTCCTCGACACCGTCGAACTGGGCCCCACGGTCCAGTACACCCCCGCCAACTACGCCCACCTGCCGGAGAAGGAACGCCCGCCGTACCTCGACACCGTGCTGGAGGCCCCGGCGGAGCGGATCCGCTACGAGGCCGTGCACGCGGAGGAGGGGGGCCGGTTCCTCAACGCCGAGAGCCGGTACCTGCTCGTCGACGCCGACGAACGGGACGCTCCCCTCGACCCGCCGCCCGGATACGCGTGGGTCACTCCCGACCAGCTGACCTGGCTGGTCCGTCACGGCCACTACCTGAACGTCCAGGCGCGCACGCTGCTCGCCTGCCTCAACGCCCGTGCGGCGGTCGCCCGATGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 65535,
                "end": 66494,
                "strand": 1,
                "locus_tag": "ctg1_65",
                "type": "biosynthetic-additional",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_65</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_65</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 65,535 - 66,494,\n (total: 960 nt)<br>\n <br>\n \n  biosynthetic-additional (smcogs) SMCOG1079:oxidoreductase (Score: 267; E-value: 4.6e-81)<br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01408.22 (Oxidoreductase family, NAD-binding Rossmann fold): [4:122](score: 79.8, e-value: 2.8e-22)<br>\n \n <br>\n \n\n \n\n\n \n  <br>\n  <span class=\"bold\"> Gene Ontology terms for PFAM domains:</span><br>\n  \n   PF01408.22: <a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity<br>\n  \n  <br>\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MSAPVRIGVLGCADIAVRRMLPAFTASPDVEVAAVASRDRGRAERTAGRFGCRPVHGYAELLDRDDVQAVYVPLPAALHAHWVEAALEAGKHVLAEKPLTTDPDTTERLLELAGKQGVALMENVMFLHHPRHEAVRRLVADGRIGEPRSLHAAFTIPPLPDSDIRYDPGLGGGALADVGLYPLRAALHFLGPELEVIGARLARGPGRRVETSGAALLGTPDGVTAHVTFGMEHAYLSRYELWGSEGRITVDRAFTPPADFVPLVGLHTSAGTEEIRLTPADQVAATVAAFVASVRAGHAPGADTLRQAVLLDAVRHRSG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=55535&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_65_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MSAPVRIGVLGCADIAVRRMLPAFTASPDVEVAAVASRDRGRAERTAGRFGCRPVHGYAELLDRDDVQAVYVPLPAALHAHWVEAALEAGKHVLAEKPLTTDPDTTERLLELAGKQGVALMENVMFLHHPRHEAVRRLVADGRIGEPRSLHAAFTIPPLPDSDIRYDPGLGGGALADVGLYPLRAALHFLGPELEVIGARLARGPGRRVETSGAALLGTPDGVTAHVTFGMEHAYLSRYELWGSEGRITVDRAFTPPADFVPLVGLHTSAGTEEIRLTPADQVAATVAAFVASVRAGHAPGADTLRQAVLLDAVRHRSG\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGAGCGCGCCGGTGCGTATCGGGGTGCTCGGCTGCGCCGACATCGCGGTACGGCGGATGCTCCCCGCGTTCACCGCCTCCCCGGACGTCGAGGTCGCAGCCGTCGCCAGCCGTGACCGGGGCAGGGCGGAGAGGACGGCGGGGCGCTTCGGCTGCCGGCCCGTCCACGGGTACGCGGAGCTGCTGGACCGCGACGACGTGCAGGCGGTGTACGTGCCGCTGCCGGCCGCCCTGCACGCGCACTGGGTGGAGGCGGCACTCGAGGCCGGCAAGCACGTGCTCGCCGAGAAGCCCCTGACGACGGACCCGGACACCACCGAACGCCTGCTGGAGCTGGCCGGCAAGCAGGGCGTGGCGCTGATGGAGAACGTGATGTTCCTTCATCATCCCCGGCACGAGGCGGTACGGCGCCTCGTCGCCGACGGGCGGATCGGCGAACCGAGGTCGCTGCACGCGGCGTTCACCATCCCTCCGCTCCCCGACAGCGACATCCGGTACGACCCCGGCCTGGGCGGCGGCGCGCTGGCGGACGTCGGCCTCTACCCGCTCCGGGCCGCACTGCACTTCCTGGGCCCTGAGCTCGAAGTGATCGGCGCCCGGCTCGCCCGGGGTCCCGGTCGGCGGGTCGAGACGTCCGGCGCGGCACTGCTGGGCACCCCCGACGGAGTCACCGCGCACGTCACGTTCGGCATGGAGCACGCCTATCTGTCGCGGTACGAACTGTGGGGCAGCGAGGGACGGATCACCGTTGACCGGGCGTTCACCCCGCCGGCCGACTTCGTCCCCCTGGTCGGCCTGCACACGTCCGCGGGTACGGAGGAGATCCGGCTGACGCCCGCCGACCAGGTCGCGGCGACGGTCGCCGCGTTCGTCGCCTCGGTCAGGGCCGGTCACGCGCCGGGCGCGGACACTCTGCGGCAGGCCGTTCTGCTGGACGCCGTACGCCACAGGTCCGGGTGA\">Copy to clipboard</span><br>\n</div>"
            },
            {
                "start": 66559,
                "end": 66753,
                "strand": 1,
                "locus_tag": "ctg1_66",
                "type": "other",
                "description": "<div class=\"focus-intro\">\n <strong><span class=\"serif\">ctg1_66</span></strong><br>\n \n <br>\n Locus tag: <span class=\"serif\">ctg1_66</span><br>\n Protein ID: <span class=\"serif\">None</span><br>\n Gene: <span class=\"serif\">None</span><br>\n \n Location: 66,559 - 66,753,\n (total: 195 nt)<br>\n <br>\n \n</div>\n<div class=\"focus-info\">\n \n\n \n <br>\n <span class=\"bold\">PFAM hits:</span><br>\n \n  PF01039.22 (Carboxyl transferase domain): [23:63](score: 40.4, e-value: 1.4e-10)<br>\n \n <br>\n \n\n \n\n\n \n</div>\n<div class=\"focus-urls\">\n <a href=\"http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=MTVELHEIRAQALAGPSEKATRAQHAKGKLTARERIELLLDAGSFREVEQLRRHRATGFGLEEKK&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch\" target=\"_new\">NCBI BlastP on this gene</a><br>\n <a href=\"http://www.ncbi.nlm.nih.gov/projects/sviewer/?Db=gene&amp;DbFrom=protein&amp;Cmd=Link&amp;noslider=1&amp;id=contig_38&amp;from=56559&amp;to=66753\" target=\"_new\">View genomic context</a><br>\n \n  <a href=\"knownclusterblast/region1/ctg1_66_mibig_hits.html\" target=\"_new\">MiBIG Hits</a><br>\n \n \n \n \n</div>\n<div class=\"focus-clipboard\">\n AA sequence: <span class=\"clipboard-copy\" data-seq=\"MTVELHEIRAQALAGPSEKATRAQHAKGKLTARERIELLLDAGSFREVEQLRRHRATGFGLEEKK\">Copy to clipboard</span><br>\n Nucleotide sequence: <span class=\"clipboard-copy\" data-seq=\"ATGACGGTCGAGCTGCACGAGATCCGTGCCCAGGCACTGGCCGGCCCGAGCGAGAAGGCGACCCGGGCGCAGCACGCCAAGGGGAAGCTGACCGCGCGGGAGCGCATCGAACTGCTGCTGGACGCGGGGTCGTTCCGTGAGGTGGAGCAGTTGCGGCGGCACCGGGCGACCGGTTTCGGTCTGGAGGAGAAGAAG\">Copy to clipboard</span><br>\n</div>"
            }
        ],
        "clusters": [
            {
                "start": 1,
                "end": 66752,
                "tool": "",
                "neighbouring_start": 0,
                "neighbouring_end": 66753,
                "product": "CC 1: neighbouring",
                "kind": "candidatecluster",
                "prefix": "",
                "height": 0
            },
            {
                "start": 1,
                "end": 17111,
                "tool": "",
                "neighbouring_start": 0,
                "neighbouring_end": 17112,
                "product": "CC 2: single",
                "kind": "candidatecluster",
                "prefix": "",
                "height": 1
            },
            {
                "start": 10554,
                "end": 66752,
                "tool": "",
                "neighbouring_start": 10553,
                "neighbouring_end": 66753,
                "product": "CC 3: single",
                "kind": "candidatecluster",
                "prefix": "",
                "height": 2
            },
            {
                "start": 43622,
                "end": 66752,
                "tool": "",
                "neighbouring_start": 43621,
                "neighbouring_end": 66753,
                "product": "CC 4: single",
                "kind": "candidatecluster",
                "prefix": "",
                "height": 1
            },
            {
                "start": 6620,
                "end": 7112,
                "tool": "rule-based-clusters",
                "neighbouring_start": 0,
                "neighbouring_end": 17112,
                "product": "phenazine",
                "height": 4,
                "kind": "protocluster",
                "prefix": ""
            },
            {
                "start": 45553,
                "end": 48051,
                "tool": "rule-based-clusters",
                "neighbouring_start": 10553,
                "neighbouring_end": 66753,
                "product": "T2PKS",
                "height": 6,
                "kind": "protocluster",
                "prefix": ""
            },
            {
                "start": 53621,
                "end": 57854,
                "tool": "rule-based-clusters",
                "neighbouring_start": 43621,
                "neighbouring_end": 66753,
                "product": "oligosaccharide",
                "height": 4,
                "kind": "protocluster",
                "prefix": ""
            }
        ],
        "ttaCodons": [
            {
                "start": 1618,
                "end": 1620,
                "strand": -1,
                "containedBy": [
                    "ctg1_2"
                ]
            },
            {
                "start": 14998,
                "end": 15000,
                "strand": 1,
                "containedBy": [
                    "ctg1_16"
                ]
            },
            {
                "start": 24848,
                "end": 24850,
                "strand": 1,
                "containedBy": [
                    "ctg1_24"
                ]
            },
            {
                "start": 33955,
                "end": 33957,
                "strand": -1,
                "containedBy": [
                    "ctg1_34"
                ]
            }
        ],
        "type": "T2PKS,oligosaccharide,phenazine",
        "products": [
            "phenazine",
            "T2PKS",
            "oligosaccharide"
        ],
        "anchor": "r1c1"
    }
};
var details_data = {
    "nrpspks": {
        "r1c1": {
            "id": "r1c1",
            "orfs": [
                {
                    "id": "ctg1_30",
                    "sequence": "MTTNTMEKTLLGKAALVTGGGRGIGAATALRLAREGADVAVTYVNGKEAAEDVVRAVEALGRRAVALRADAGDPQEASGAVGAAVRELGRLDVLVNNAGVGLLGPLETLSPADVDRVLAVNVRGVFLASRAAAAVLPRGGRIVTVGTCMTQRVPGPGGTLYAMSKAALVGLTKALARELGERGITANIVHPGPIDTDMNPADGPYAAGQAAATALGRFGTAAEVAETIVHLAGAAYVTGAEFAVDGGHAA",
                    "domains": [
                        {
                            "type": "PKS_KR",
                            "start": 14,
                            "end": 177,
                            "predictions": [
                                [
                                    "KR activity",
                                    "inactive"
                                ],
                                [
                                    "KR stereochemistry",
                                    "C2"
                                ]
                            ],
                            "napdoslink": "",
                            "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=ALVTGGGRGIGAATALRLAREGADVAVTYVNGKEAAEDVVRAVEALGRRAVALRADAGDPQEASGAVGAAVRELGRLDVLVNNAGVGLLGPLETLSPADVDRVLAVNVRGVFLASRAAAAVLPRGGRIVTVGTCMTQRVPGPGGTLYAMSKAALVGLTKALAR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
                            "sequence": "ALVTGGGRGIGAATALRLAREGADVAVTYVNGKEAAEDVVRAVEALGRRAVALRADAGDPQEASGAVGAAVRELGRLDVLVNNAGVGLLGPLETLSPADVDRVLAVNVRGVFLASRAAAAVLPRGGRIVTVGTCMTQRVPGPGGTLYAMSKAALVGLTKALAR",
                            "dna_sequence": "ATGACCACGAACACGATGGAGAAGACCCTGCTCGGCAAGGCGGCGCTGGTGACCGGCGGCGGCCGCGGCATCGGCGCCGCGACGGCGCTCCGGCTGGCGCGGGAGGGCGCCGACGTCGCGGTGACGTATGTGAACGGCAAGGAGGCCGCGGAGGACGTCGTACGGGCCGTCGAGGCCCTGGGGCGGCGCGCGGTGGCACTCCGGGCGGACGCCGGCGACCCGCAGGAGGCGTCGGGGGCGGTGGGCGCCGCGGTCCGTGAACTGGGGCGTCTGGACGTCCTCGTGAACAACGCGGGCGTCGGCCTGCTCGGCCCGCTGGAGACCCTCTCCCCCGCCGACGTGGACCGGGTGCTCGCGGTGAACGTCCGCGGTGTCTTCCTGGCCTCGCGCGCGGCGGCCGCCGTGCTGCCACGCGGGGGCCGGATCGTCACCGTGGGCACGTGCATGACGCAGCGGGTGCCCGGCCCCGGCGGGACGCTCTACGCCATGAGCAAGGCGGCGCTGGTGGGGCTGACCAAGGCGCTGGCACGGGAGTTGGGCGAGCGCGGGATCACGGCGAACATCGTCCACCCCGGGCCGATCGACACGGACATGAACCCGGCCGACGGCCCGTACGCGGCCGGGCAGGCGGCGGCGACCGCGCTGGGGCGCTTCGGCACGGCCGCGGAGGTGGCGGAGACGATCGTCCATCTCGCGGGCGCGGCGTACGTGACCGGGGCGGAGTTCGCGGTGGACGGGGGGCACGCGGCCTGA",
                            "abbreviation": "KR",
                            "html_class": "jsdomain-mod-kr"
                        }
                    ],
                    "modules": [
                        {
                            "start": 14,
                            "end": 177,
                            "complete": false,
                            "iterative": false,
                            "monomer": "",
                            "multi_cds": null,
                            "match_id": null
                        }
                    ]
                },
                {
                    "id": "ctg1_47",
                    "sequence": "VSGAYPRRVVITGIGVTAPGGVGVKNFWNTLSGGHTATRRITFFDPSPFRSQVAAEVDFDAELLGLSAQEIRRMDRAAQFAVVTARDAVADSGLEFTALDPHRTGVTIGSAVGATMGLDQEYRTVSDSGRLDLVDHTYAVPHLYNHLVPSSFAAEVAWAVGAEGPATVVSTGCTSGLDAVGYAADLIREGSADVMVAGATDAPISPITVACFDAIKATTPRNDDPEHASRPFDGTRNGFVLGEGSAVFVLEELGSARRRGAHVYAEIAGYATRSNAFHMTGLRPDGREMAEAIRVALDEARLAPGAIDYVNAHGSGTKQNDRHETAAFKRSLGEHAYAVPVSSIKSMVGHSLGAIGSIEIAASALAMEHGVVPPTANLHTPDPECDLDYVPLTAREWPTDAVLSVGSGFGGFQSAMVLARPDRRTA",
                    "domains": [
                        {
                            "type": "PKS_KS(Iterative-KS)",
                            "start": 8,
                            "end": 418,
                            "predictions": [],
                            "napdoslink": "http://napdos.ucsd.edu/cgi-bin/process_request.cgi?query_type=aa&amp;ref_seq_file=all_KS_public_12062011.faa&amp;Sequence=%3EKS_domain_from_antiSMASH%0DVVITGIGVTAPGGVGVKNFWNTLSGGHTATRRITFFDPSPFRSQVAAEVDFDAELLGLSAQEIRRMDRAAQFAVVTARDAVADSGLEFTALDPHRTGVTIGSAVGATMGLDQEYRTVSDSGRLDLVDHTYAVPHLYNHLVPSSFAAEVAWAVGAEGPATVVSTGCTSGLDAVGYAADLIREGSADVMVAGATDAPISPITVACFDAIKATTPRNDDPEHASRPFDGTRNGFVLGEGSAVFVLEELGSARRRGAHVYAEIAGYATRSNAFHMTGLRPDGREMAEAIRVALDEARLAPGAIDYVNAHGSGTKQNDRHETAAFKRSLGEHAYAVPVSSIKSMVGHSLGAIGSIEIAASALAMEHGVVPPTANLHTPDPECDLDYVPLTAREWPTDAVLSVGSGFGGFQSAMVL",
                            "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VVITGIGVTAPGGVGVKNFWNTLSGGHTATRRITFFDPSPFRSQVAAEVDFDAELLGLSAQEIRRMDRAAQFAVVTARDAVADSGLEFTALDPHRTGVTIGSAVGATMGLDQEYRTVSDSGRLDLVDHTYAVPHLYNHLVPSSFAAEVAWAVGAEGPATVVSTGCTSGLDAVGYAADLIREGSADVMVAGATDAPISPITVACFDAIKATTPRNDDPEHASRPFDGTRNGFVLGEGSAVFVLEELGSARRRGAHVYAEIAGYATRSNAFHMTGLRPDGREMAEAIRVALDEARLAPGAIDYVNAHGSGTKQNDRHETAAFKRSLGEHAYAVPVSSIKSMVGHSLGAIGSIEIAASALAMEHGVVPPTANLHTPDPECDLDYVPLTAREWPTDAVLSVGSGFGGFQSAMVL&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
                            "sequence": "VVITGIGVTAPGGVGVKNFWNTLSGGHTATRRITFFDPSPFRSQVAAEVDFDAELLGLSAQEIRRMDRAAQFAVVTARDAVADSGLEFTALDPHRTGVTIGSAVGATMGLDQEYRTVSDSGRLDLVDHTYAVPHLYNHLVPSSFAAEVAWAVGAEGPATVVSTGCTSGLDAVGYAADLIREGSADVMVAGATDAPISPITVACFDAIKATTPRNDDPEHASRPFDGTRNGFVLGEGSAVFVLEELGSARRRGAHVYAEIAGYATRSNAFHMTGLRPDGREMAEAIRVALDEARLAPGAIDYVNAHGSGTKQNDRHETAAFKRSLGEHAYAVPVSSIKSMVGHSLGAIGSIEIAASALAMEHGVVPPTANLHTPDPECDLDYVPLTAREWPTDAVLSVGSGFGGFQSAMVL",
                            "dna_sequence": "GTGAGCGGCGCGTACCCCCGGCGCGTGGTGATCACCGGCATCGGAGTCACCGCCCCCGGCGGCGTGGGCGTCAAGAACTTCTGGAACACGCTGTCCGGCGGGCACACCGCGACCCGTCGCATCACCTTCTTCGATCCCTCCCCCTTCCGCTCCCAAGTCGCCGCGGAGGTGGACTTCGACGCGGAGCTGCTGGGACTGAGCGCCCAGGAGATCCGGCGGATGGACCGCGCCGCCCAGTTCGCCGTGGTCACAGCCCGGGACGCGGTGGCCGACAGCGGCCTGGAGTTCACCGCCCTGGACCCGCACCGTACCGGCGTCACCATCGGCAGCGCGGTCGGCGCCACGATGGGACTGGACCAGGAGTACCGCACGGTCAGCGACAGCGGCCGGCTCGACCTGGTCGACCACACCTACGCGGTTCCGCACCTGTACAACCACCTGGTCCCCAGTTCCTTCGCCGCGGAGGTGGCCTGGGCGGTGGGCGCGGAGGGGCCGGCCACCGTGGTGTCCACCGGCTGCACCTCCGGGCTGGACGCCGTGGGCTACGCCGCCGACCTGATCCGGGAAGGCTCGGCCGACGTCATGGTGGCCGGCGCCACCGACGCTCCCATCTCCCCCATCACGGTGGCCTGCTTCGACGCGATCAAGGCGACGACCCCGCGCAACGACGACCCCGAGCACGCCTCACGCCCCTTCGACGGCACCCGTAACGGCTTCGTGCTGGGCGAGGGTTCGGCCGTGTTCGTCCTGGAGGAACTCGGCAGCGCCCGGCGGCGCGGCGCCCACGTCTACGCGGAGATCGCCGGTTACGCCACGCGCAGCAACGCCTTCCACATGACGGGCCTGCGCCCCGACGGCCGGGAGATGGCCGAGGCCATCCGCGTCGCGCTGGACGAGGCACGCCTGGCCCCCGGGGCCATCGACTACGTCAACGCGCACGGTTCGGGCACCAAGCAGAACGACCGCCACGAGACCGCCGCGTTCAAGCGCAGCCTCGGAGAGCACGCCTACGCCGTGCCGGTCAGCTCCATCAAGTCGATGGTGGGCCACTCGCTGGGAGCCATCGGCTCCATCGAGATCGCGGCGAGCGCGCTGGCCATGGAGCACGGCGTCGTACCGCCCACCGCCAACCTGCACACCCCGGACCCCGAGTGCGACCTGGACTACGTCCCGCTCACCGCGCGGGAGTGGCCCACCGACGCCGTGCTGTCGGTGGGCAGCGGCTTCGGCGGTTTCCAGAGCGCCATGGTGCTCGCCCGTCCCGATCGGAGGACCGCATGA",
                            "abbreviation": "KS",
                            "html_class": "jsdomain-ketosynthase"
                        }
                    ],
                    "modules": [
                        {
                            "start": 8,
                            "end": 418,
                            "complete": false,
                            "iterative": true,
                            "monomer": "",
                            "multi_cds": null,
                            "match_id": null
                        }
                    ]
                },
                {
                    "id": "ctg1_48",
                    "sequence": "MSATDVRAAVTGLGVVAPNGLGTEAYWTATRKGVSGIGRVTRFVPDQYPAQLAGEIDGFDAHEHLPGRLLPQTDRMTQLALVAADWAFQDAAVRPEDLPGFEMGVITAGSSGGFEFGQRELQALWSKGSRYVSAYQSFAWFYAVNSGQISIRNGMRGPSGVVVSDQAGGLDAVAQARRQLRKGTRLVMSGAVDASICPWGWVAQMTSNRLSTGRDPARAYLPFDDAAAGHVPGEGGALLVMEDLQQARARGARIYGEIAGYGATLDPRPGSGRPPGLRKAVELALADAGAAPGDIDVVFADAAALPDLDRIEAETITAVFGARAVPVTAPKTMTGRLYSGAAPLDLAAAFLAMRDEVIPPSVGVTPSPGHDLDLVVGQERPAPVRSALVLARGHGGFNSAAVVRAA",
                    "domains": [
                        {
                            "type": "PKS_KS(Iterative-KS)",
                            "start": 50,
                            "end": 404,
                            "predictions": [],
                            "napdoslink": "http://napdos.ucsd.edu/cgi-bin/process_request.cgi?query_type=aa&amp;ref_seq_file=all_KS_public_12062011.faa&amp;Sequence=%3EKS_domain_from_antiSMASH%0DQLAGEIDGFDAHEHLPGRLLPQTDRMTQLALVAADWAFQDAAVRPEDLPGFEMGVITAGSSGGFEFGQRELQALWSKGSRYVSAYQSFAWFYAVNSGQISIRNGMRGPSGVVVSDQAGGLDAVAQARRQLRKGTRLVMSGAVDASICPWGWVAQMTSNRLSTGRDPARAYLPFDDAAAGHVPGEGGALLVMEDLQQARARGARIYGEIAGYGATLDPRPGSGRPPGLRKAVELALADAGAAPGDIDVVFADAAALPDLDRIEAETITAVFGARAVPVTAPKTMTGRLYSGAAPLDLAAAFLAMRDEVIPPSVGVTPSPGHDLDLVVGQERPAPVRSALVLARGHGGFNSAAVVR",
                            "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=QLAGEIDGFDAHEHLPGRLLPQTDRMTQLALVAADWAFQDAAVRPEDLPGFEMGVITAGSSGGFEFGQRELQALWSKGSRYVSAYQSFAWFYAVNSGQISIRNGMRGPSGVVVSDQAGGLDAVAQARRQLRKGTRLVMSGAVDASICPWGWVAQMTSNRLSTGRDPARAYLPFDDAAAGHVPGEGGALLVMEDLQQARARGARIYGEIAGYGATLDPRPGSGRPPGLRKAVELALADAGAAPGDIDVVFADAAALPDLDRIEAETITAVFGARAVPVTAPKTMTGRLYSGAAPLDLAAAFLAMRDEVIPPSVGVTPSPGHDLDLVVGQERPAPVRSALVLARGHGGFNSAAVVR&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
                            "sequence": "QLAGEIDGFDAHEHLPGRLLPQTDRMTQLALVAADWAFQDAAVRPEDLPGFEMGVITAGSSGGFEFGQRELQALWSKGSRYVSAYQSFAWFYAVNSGQISIRNGMRGPSGVVVSDQAGGLDAVAQARRQLRKGTRLVMSGAVDASICPWGWVAQMTSNRLSTGRDPARAYLPFDDAAAGHVPGEGGALLVMEDLQQARARGARIYGEIAGYGATLDPRPGSGRPPGLRKAVELALADAGAAPGDIDVVFADAAALPDLDRIEAETITAVFGARAVPVTAPKTMTGRLYSGAAPLDLAAAFLAMRDEVIPPSVGVTPSPGHDLDLVVGQERPAPVRSALVLARGHGGFNSAAVVR",
                            "dna_sequence": "ATGAGCGCGACGGACGTCCGGGCCGCCGTCACCGGACTGGGTGTCGTCGCGCCCAACGGGCTCGGCACGGAGGCCTACTGGACCGCCACCCGCAAGGGGGTCAGCGGCATCGGACGCGTCACGCGTTTCGTGCCCGACCAGTATCCCGCCCAACTGGCGGGCGAGATCGACGGGTTCGACGCGCACGAGCACCTGCCGGGCCGGCTGCTGCCGCAGACCGACCGGATGACCCAGCTCGCGCTGGTGGCCGCGGACTGGGCCTTCCAGGACGCCGCGGTCCGGCCGGAGGACCTTCCCGGGTTCGAGATGGGCGTCATCACCGCCGGCTCGTCCGGGGGCTTCGAGTTCGGCCAGCGGGAGCTGCAGGCCCTGTGGAGCAAGGGCAGCAGGTACGTCAGCGCCTACCAGTCCTTCGCCTGGTTCTACGCCGTCAACAGCGGTCAGATATCCATCCGCAACGGCATGCGCGGTCCCAGCGGTGTGGTCGTCAGCGACCAGGCCGGCGGGCTCGACGCGGTCGCCCAGGCACGTCGGCAGCTCCGCAAGGGCACGCGTCTGGTGATGTCGGGCGCCGTCGACGCCTCGATCTGTCCCTGGGGCTGGGTCGCCCAGATGACGAGCAACCGGCTGAGCACCGGCCGTGACCCGGCACGCGCCTACCTCCCCTTCGACGACGCGGCGGCCGGACACGTGCCCGGTGAGGGCGGCGCCCTGCTCGTCATGGAAGACCTGCAGCAGGCACGGGCCCGGGGGGCGCGGATCTACGGCGAGATCGCGGGATACGGCGCCACGCTGGACCCGCGGCCGGGCAGCGGACGGCCTCCCGGCCTGCGCAAGGCCGTCGAACTCGCCCTGGCCGACGCCGGTGCGGCGCCCGGTGACATCGACGTGGTGTTCGCCGACGCGGCCGCCCTGCCCGACCTCGACCGGATCGAGGCGGAGACGATCACGGCGGTGTTCGGCGCCCGGGCCGTGCCCGTGACGGCCCCCAAGACGATGACCGGGCGGCTCTACTCGGGGGCGGCGCCGCTGGACCTGGCCGCGGCGTTCCTCGCCATGCGGGACGAGGTGATTCCGCCGTCCGTCGGTGTCACCCCCTCCCCCGGTCACGACCTGGACCTGGTCGTCGGCCAGGAACGGCCGGCCCCGGTGCGCTCCGCCCTGGTACTCGCCCGCGGCCACGGCGGTTTCAACTCCGCGGCCGTGGTGCGCGCGGCCTGA",
                            "abbreviation": "KS",
                            "html_class": "jsdomain-ketosynthase"
                        }
                    ],
                    "modules": [
                        {
                            "start": 50,
                            "end": 404,
                            "complete": false,
                            "iterative": true,
                            "monomer": "",
                            "multi_cds": null,
                            "match_id": null
                        }
                    ]
                },
                {
                    "id": "ctg1_49",
                    "sequence": "MPAHEFTLEDLKRILREGAGADEGVDLDGDILDTDFGLLGYESLALLETGGRIEREFGITLDDETLTDAATPRSLLEAVNALLVPAEVG",
                    "domains": [
                        {
                            "type": "ACP",
                            "start": 12,
                            "end": 81,
                            "predictions": [],
                            "napdoslink": "",
                            "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=RILREGAGADEGVDLDGDILDTDFGLLGYESLALLETGGRIEREFGITLDDETLTDAATPRSLLEAVNA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
                            "sequence": "RILREGAGADEGVDLDGDILDTDFGLLGYESLALLETGGRIEREFGITLDDETLTDAATPRSLLEAVNA",
                            "dna_sequence": "ATGCCCGCCCATGAGTTCACACTTGAGGACCTCAAGCGCATTCTGCGCGAGGGGGCCGGCGCGGACGAAGGCGTCGATCTCGACGGCGACATCCTCGACACCGACTTCGGACTGCTGGGCTACGAGTCCCTGGCGCTGCTGGAGACCGGCGGCAGGATCGAGCGCGAGTTCGGTATCACCCTCGACGACGAGACGCTGACCGACGCCGCGACCCCGCGGTCGCTGCTGGAGGCCGTCAACGCCCTGCTGGTGCCGGCCGAGGTCGGCTGA",
                            "abbreviation": "",
                            "html_class": "jsdomain-transport"
                        }
                    ],
                    "modules": [
                        {
                            "start": 12,
                            "end": 81,
                            "complete": false,
                            "iterative": false,
                            "monomer": "",
                            "multi_cds": null,
                            "match_id": null
                        }
                    ]
                },
                {
                    "id": "ctg1_50",
                    "sequence": "MTQQNPRVALVTGATSGIGLAVTRRLARQGHRVFLCARTETGVTRTVKDLLDEGLDVDGAPCDVRSGADVKRFVEQAVDRFGTIDVLVNNAGRSGGGVTADISDDLWSDVIDTNLNSVFRMTREVLTTGGMREKDRGRIINVASTAGKQGVVLGAPYSASKHGVVGFTKALGNELAPTGITVNAVCPGYVETPMAQRVRQGYAAAYDTTEDAILEKFQAKIPLGRYSTPEEVAGLVGYLASDTAASITSQALNVCGGLGNF",
                    "domains": [
                        {
                            "type": "PKS_KR",
                            "start": 7,
                            "end": 162,
                            "predictions": [
                                [
                                    "KR activity",
                                    "inactive"
                                ],
                                [
                                    "KR stereochemistry",
                                    "C1"
                                ]
                            ],
                            "napdoslink": "",
                            "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VALVTGATSGIGLAVTRRLARQGHRVFLCARTETGVTRTVKDLLDEGLDVDGAPCDVRSGADVKRFVEQAVDRFGTIDVLVNNAGRSGGGVTADISDDLWSDVIDTNLNSVFRMTREVLTTGGMREKDRGRIINVASTAGKQGVVLGAPYSASKH&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
                            "sequence": "VALVTGATSGIGLAVTRRLARQGHRVFLCARTETGVTRTVKDLLDEGLDVDGAPCDVRSGADVKRFVEQAVDRFGTIDVLVNNAGRSGGGVTADISDDLWSDVIDTNLNSVFRMTREVLTTGGMREKDRGRIINVASTAGKQGVVLGAPYSASKH",
                            "dna_sequence": "ATGACGCAGCAGAACCCGAGGGTCGCCCTCGTCACGGGCGCGACCAGCGGCATCGGCCTGGCGGTGACCAGGCGGCTGGCCCGCCAGGGCCACCGGGTGTTCCTCTGCGCCCGCACCGAGACCGGCGTGACCCGCACGGTCAAGGACCTGCTGGACGAGGGACTGGACGTGGACGGCGCCCCGTGCGACGTACGCTCCGGTGCCGACGTCAAGCGGTTCGTGGAGCAGGCCGTCGACCGCTTCGGCACCATCGACGTACTCGTCAACAACGCGGGCAGGTCGGGCGGCGGAGTCACCGCCGACATCTCCGACGACCTCTGGTCCGACGTGATCGACACCAATCTCAACAGCGTCTTCCGCATGACGCGTGAGGTGCTCACCACGGGCGGCATGCGCGAGAAGGACCGGGGCCGGATCATCAACGTCGCCTCCACCGCGGGCAAGCAGGGCGTGGTGCTCGGCGCCCCCTACTCGGCCTCCAAGCACGGCGTGGTCGGGTTCACCAAGGCACTCGGCAACGAACTCGCGCCCACCGGCATCACCGTCAACGCCGTCTGCCCCGGTTACGTCGAGACACCGATGGCCCAGCGGGTGCGCCAGGGCTACGCGGCCGCCTACGACACCACCGAGGACGCGATCCTCGAGAAGTTCCAGGCGAAGATCCCGCTCGGCCGTTACTCGACCCCCGAGGAGGTCGCGGGCCTGGTCGGCTACCTGGCCTCCGACACCGCCGCCTCCATCACCTCCCAGGCGCTGAACGTCTGCGGCGGCCTGGGCAACTTCTGA",
                            "abbreviation": "KR",
                            "html_class": "jsdomain-mod-kr"
                        }
                    ],
                    "modules": [
                        {
                            "start": 7,
                            "end": 162,
                            "complete": false,
                            "iterative": false,
                            "monomer": "",
                            "multi_cds": null,
                            "match_id": null
                        }
                    ]
                },
                {
                    "id": "ctg1_51",
                    "sequence": "MTTRQVEHEITVEAPAAAVYRLIAEVENWPRIFPPTIHVDHVERSTGEERIRIWATANGEAKNWTSRRTLDPERLRITFRQEVSTPPVAAMGGAWVIEPLSGDSARIRLLHDYRAVDDDPAGLRWIDEAVDRNSRAELAALKTNVELAHAAEDLTFSFEDTVHITGSAKDAYDFVDEAGLWAERLPHVASVRFTEDTPGLQTLEMDTRAKDGSTHTTKSYRVTFPHHRIAYKQVTLPALMTLHTGLWTFTENESGVTATSQHTVTLDTENIARVLGPDATVADARAYVQGALSANSLATLGHAKDHAEKRR",
                    "domains": [
                        {
                            "type": "Polyketide_cyc2",
                            "start": 4,
                            "end": 146,
                            "predictions": [],
                            "napdoslink": "",
                            "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=QVEHEITVEAPAAAVYRLIAEVENWPRIFPPTIHVDHVERSTGEERIRIWATANGEAKNWTSRRTLDPERLRITFRQEVSTPPVAAMGGAWVIEPLSGDSARIRLLHDYRAVDDDPAGLRWIDEAVDRNSRAELAALKTNVE&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
                            "sequence": "QVEHEITVEAPAAAVYRLIAEVENWPRIFPPTIHVDHVERSTGEERIRIWATANGEAKNWTSRRTLDPERLRITFRQEVSTPPVAAMGGAWVIEPLSGDSARIRLLHDYRAVDDDPAGLRWIDEAVDRNSRAELAALKTNVE",
                            "dna_sequence": "ATGACGACCCGTCAGGTCGAGCACGAGATCACCGTCGAGGCCCCGGCCGCCGCCGTCTACCGGCTGATCGCCGAGGTGGAGAACTGGCCGCGGATCTTTCCTCCCACCATCCATGTCGACCATGTCGAGCGCTCCACGGGCGAGGAGCGCATCCGGATCTGGGCGACCGCCAACGGCGAGGCGAAGAACTGGACCTCGCGCCGCACACTGGACCCGGAGCGTCTGCGGATCACCTTCCGGCAGGAGGTGTCGACCCCACCGGTGGCCGCCATGGGCGGCGCGTGGGTCATCGAGCCGCTGTCGGGCGACTCGGCCCGGATCCGGCTGCTGCACGACTACCGGGCCGTCGACGACGACCCCGCGGGCCTGCGCTGGATCGACGAGGCCGTCGACCGCAACTCCCGCGCCGAGCTGGCCGCGCTCAAGACCAACGTGGAACTGGCCCACGCCGCCGAGGACCTCACCTTCTCCTTCGAGGACACCGTGCACATCACCGGCTCCGCCAAGGACGCCTACGACTTCGTCGACGAGGCGGGGCTGTGGGCGGAGCGGCTGCCTCACGTGGCCTCGGTCCGCTTCACGGAGGACACCCCCGGGCTGCAGACGCTGGAGATGGACACCCGGGCCAAGGACGGCTCGACGCACACCACGAAGTCGTACCGGGTGACGTTCCCGCACCACAGGATCGCCTACAAGCAGGTGACCCTGCCCGCGTTGATGACCCTGCACACCGGCCTGTGGACGTTCACGGAGAACGAGAGCGGGGTCACCGCCACCTCCCAGCACACCGTCACCCTCGACACGGAGAACATCGCCCGGGTCCTCGGCCCCGACGCGACCGTGGCCGATGCCCGCGCGTACGTCCAGGGCGCGCTGAGCGCCAACAGCCTGGCCACCCTCGGCCATGCCAAGGACCACGCCGAGAAGCGGCGCTGA",
                            "abbreviation": "",
                            "html_class": "jsdomain-other"
                        },
                        {
                            "type": "Polyketide_cyc2",
                            "start": 155,
                            "end": 298,
                            "predictions": [],
                            "napdoslink": "",
                            "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=FSFEDTVHITGSAKDAYDFVDEAGLWAERLPHVASVRFTEDTPGLQTLEMDTRAKDGSTHTTKSYRVTFPHHRIAYKQVTLPALMTLHTGLWTFTENESGVTATSQHTVTLDTENIARVLGPDATVADARAYVQGALSANSLA&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
                            "sequence": "FSFEDTVHITGSAKDAYDFVDEAGLWAERLPHVASVRFTEDTPGLQTLEMDTRAKDGSTHTTKSYRVTFPHHRIAYKQVTLPALMTLHTGLWTFTENESGVTATSQHTVTLDTENIARVLGPDATVADARAYVQGALSANSLA",
                            "dna_sequence": "ATGACGACCCGTCAGGTCGAGCACGAGATCACCGTCGAGGCCCCGGCCGCCGCCGTCTACCGGCTGATCGCCGAGGTGGAGAACTGGCCGCGGATCTTTCCTCCCACCATCCATGTCGACCATGTCGAGCGCTCCACGGGCGAGGAGCGCATCCGGATCTGGGCGACCGCCAACGGCGAGGCGAAGAACTGGACCTCGCGCCGCACACTGGACCCGGAGCGTCTGCGGATCACCTTCCGGCAGGAGGTGTCGACCCCACCGGTGGCCGCCATGGGCGGCGCGTGGGTCATCGAGCCGCTGTCGGGCGACTCGGCCCGGATCCGGCTGCTGCACGACTACCGGGCCGTCGACGACGACCCCGCGGGCCTGCGCTGGATCGACGAGGCCGTCGACCGCAACTCCCGCGCCGAGCTGGCCGCGCTCAAGACCAACGTGGAACTGGCCCACGCCGCCGAGGACCTCACCTTCTCCTTCGAGGACACCGTGCACATCACCGGCTCCGCCAAGGACGCCTACGACTTCGTCGACGAGGCGGGGCTGTGGGCGGAGCGGCTGCCTCACGTGGCCTCGGTCCGCTTCACGGAGGACACCCCCGGGCTGCAGACGCTGGAGATGGACACCCGGGCCAAGGACGGCTCGACGCACACCACGAAGTCGTACCGGGTGACGTTCCCGCACCACAGGATCGCCTACAAGCAGGTGACCCTGCCCGCGTTGATGACCCTGCACACCGGCCTGTGGACGTTCACGGAGAACGAGAGCGGGGTCACCGCCACCTCCCAGCACACCGTCACCCTCGACACGGAGAACATCGCCCGGGTCCTCGGCCCCGACGCGACCGTGGCCGATGCCCGCGCGTACGTCCAGGGCGCGCTGAGCGCCAACAGCCTGGCCACCCTCGGCCATGCCAAGGACCACGCCGAGAAGCGGCGCTGA",
                            "abbreviation": "",
                            "html_class": "jsdomain-other"
                        }
                    ],
                    "modules": []
                },
                {
                    "id": "ctg1_52",
                    "sequence": "MAAPDTDVIVVGAGPSGLVLAGDLRAGGARVTVLERLARPTTESRASVLHARTLHLLAERGLLRRFGQLPAAGPGHFGGIPLDLSEAGDSPYAGQWKAPQTHVEAVLAAWATELGAEVRRGLTVTGLTRSSDRVRVVAVAPGGRRLRLDASYVVGCDGEDSAVRRLGGFGFPGAAATKELLRADLAGIELRERRFERHPRGVANARRGPDGVTRIMVHAFDRTPGPSRTPAFDDVCAVWARVTGEDITGARPVWLNAFDNARRQADGYRDGRVFLAGDAAHVQLPVGGQALNLGLQDAMDLGPKLAAHLAGRAGDEVLDTYDTVRRPVGARVLTNIEAQAQLLFGGPEVDPLRAVFRELLDLPAARRHLAAMVSGLDGGRPAWAGTGGPGKPAAPAPTRQDIRHRRITMGKLFGKTALVSGSSRGIGRATALRLARDGALVAVHCSSNREAAEETVAAIEKDGGRGFSVLAELGVPGDVHELFLALERELKERTGDTTLDILVNNAGVMGGVDPEELTPEQFDRLFAVNAKAPYFLVQRALANLPDGGRIINISSGLTRVANPQEVAYAMTKGAVDQLTLHFAKHLGPRGITVNSVGPGITDNGSPVFDDPEAVAAMAGYSVFNRVGETRDIADVVAFLASDDSRWITGSYLDASGGTLLGG",
                    "domains": [
                        {
                            "type": "PKS_KR",
                            "start": 415,
                            "end": 594,
                            "predictions": [
                                [
                                    "KR activity",
                                    "inactive"
                                ],
                                [
                                    "KR stereochemistry",
                                    "C2"
                                ]
                            ],
                            "napdoslink": "",
                            "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=TALVSGSSRGIGRATALRLARDGALVAVHCSSNREAAEETVAAIEKDGGRGFSVLAELGVPGDVHELFLALERELKERTGDTTLDILVNNAGVMGGVDPEELTPEQFDRLFAVNAKAPYFLVQRALANLPDGGRIINISSGLTRVANPQEVAYAMTKGAVDQLTLHFAKHLGPRGITVN&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
                            "sequence": "TALVSGSSRGIGRATALRLARDGALVAVHCSSNREAAEETVAAIEKDGGRGFSVLAELGVPGDVHELFLALERELKERTGDTTLDILVNNAGVMGGVDPEELTPEQFDRLFAVNAKAPYFLVQRALANLPDGGRIINISSGLTRVANPQEVAYAMTKGAVDQLTLHFAKHLGPRGITVN",
                            "dna_sequence": "ATGGCGGCGCCGGACACCGATGTGATCGTCGTGGGAGCCGGGCCGTCCGGGCTCGTGCTCGCCGGGGACCTGCGGGCCGGCGGGGCGCGGGTGACCGTACTGGAACGGCTGGCGCGGCCCACCACCGAGTCCCGGGCGTCGGTCCTGCACGCACGCACCCTGCACCTGCTGGCCGAACGGGGTCTGCTGCGACGGTTCGGTCAGCTGCCCGCGGCCGGACCCGGTCACTTCGGCGGCATCCCTCTCGACCTGAGCGAGGCCGGGGACAGCCCGTACGCCGGACAGTGGAAGGCGCCTCAGACCCACGTCGAAGCCGTCCTCGCCGCATGGGCCACGGAACTCGGCGCCGAGGTGCGGCGGGGACTCACGGTGACCGGCCTGACCCGGAGCTCCGACCGGGTGCGTGTCGTCGCCGTCGCACCGGGCGGGCGGCGCCTGCGGCTGGACGCCTCCTACGTCGTCGGCTGCGACGGCGAGGACAGCGCCGTACGGCGGCTGGGCGGCTTCGGCTTCCCGGGGGCCGCGGCCACCAAGGAACTGCTGCGCGCCGACCTGGCCGGCATCGAACTGCGGGAGCGGCGTTTCGAGCGTCACCCCCGGGGCGTGGCCAACGCCCGCCGCGGGCCGGACGGCGTCACCCGCATCATGGTCCACGCCTTCGACCGGACCCCCGGACCGTCCCGTACCCCCGCCTTCGACGACGTCTGCGCGGTGTGGGCGCGCGTCACCGGCGAGGACATCACCGGCGCCCGGCCCGTCTGGCTCAACGCCTTCGACAACGCACGCCGGCAGGCGGACGGGTACCGCGACGGCCGGGTGTTCCTCGCCGGGGACGCGGCGCACGTCCAGCTGCCGGTGGGTGGCCAGGCACTCAACCTCGGTCTGCAGGACGCCATGGACCTGGGTCCGAAGCTCGCCGCTCACCTGGCCGGCCGGGCCGGTGACGAGGTGCTGGACACCTACGACACGGTCCGTCGTCCGGTGGGCGCCCGCGTCCTCACCAACATCGAGGCCCAGGCGCAGCTGTTGTTCGGCGGGCCCGAAGTGGATCCGTTGCGGGCGGTTTTCCGTGAATTGCTGGACCTCCCGGCGGCCCGCCGTCATCTGGCCGCCATGGTCAGCGGGCTCGACGGCGGCCGTCCGGCGTGGGCCGGCACCGGCGGGCCGGGGAAGCCGGCCGCCCCCGCCCCGACTCGTCAGGACATCAGGCACAGGAGGATCACCATGGGCAAGCTCTTCGGCAAGACCGCACTCGTCTCCGGCTCCAGCCGGGGCATCGGACGGGCCACGGCCCTCCGGCTGGCCCGCGACGGGGCGCTGGTCGCGGTGCACTGCTCCAGCAACCGGGAGGCGGCCGAGGAGACGGTCGCGGCCATCGAGAAGGACGGTGGCCGCGGGTTCTCCGTGCTGGCCGAACTCGGGGTGCCCGGTGATGTGCACGAGCTGTTCCTGGCCCTGGAAAGGGAGCTGAAGGAACGCACCGGAGACACCACGCTCGACATCCTGGTGAACAACGCCGGGGTGATGGGCGGGGTGGATCCCGAGGAACTGACCCCCGAGCAGTTCGACCGCCTCTTCGCCGTCAACGCGAAGGCACCGTACTTCCTGGTGCAGCGCGCCCTGGCCAACCTCCCCGACGGCGGGCGGATCATCAACATCTCCTCGGGGCTGACCCGGGTCGCGAACCCCCAGGAGGTGGCGTACGCGATGACCAAGGGCGCCGTCGACCAGCTCACCCTGCACTTCGCCAAACACCTCGGCCCGCGCGGCATCACCGTCAACAGTGTGGGCCCGGGCATCACCGACAACGGGTCACCCGTGTTCGACGACCCGGAGGCGGTGGCCGCGATGGCGGGCTACTCGGTGTTCAACCGGGTCGGTGAGACCCGCGACATCGCCGATGTGGTGGCTTTCCTGGCGAGCGACGACTCCCGCTGGATCACCGGCTCCTACCTGGACGCCAGCGGCGGCACCCTGCTCGGCGGCTGA",
                            "abbreviation": "KR",
                            "html_class": "jsdomain-mod-kr"
                        }
                    ],
                    "modules": [
                        {
                            "start": 415,
                            "end": 594,
                            "complete": false,
                            "iterative": false,
                            "monomer": "",
                            "multi_cds": null,
                            "match_id": null
                        }
                    ]
                },
                {
                    "id": "ctg1_59",
                    "sequence": "MRILVTGAAGFIGSHFVRSLLADEYRGWEGAQVTALDKLTYAGNRENLPASHERLVFVRGDVCDRSLLRELLPGHDAVVHFAAESHVDRSLEGAGEFFRTNVLGTQTVLDAVLESGVERVVHVSTDEVYGSITEGSWTEEWPLAPNSPYAASKAGSDLVARAYWRTHGVDLSITRCSNNYGPYQHPEKVIPLFVTNLLEGGQVPLYGDGRNVREWLHVADHCRGIHLVLNEGRAGEIYNIGGGNEYTNLDLTRKLLELTGAGEEKIRRVADRKAHDLRYSIDESKIREELGYAPRIGFEEGLAETVAWYRDNPDWWKAVKHGTGRAA",
                    "domains": [
                        {
                            "type": "NAD_binding_4",
                            "start": 4,
                            "end": 181,
                            "predictions": [],
                            "napdoslink": "",
                            "blastlink": "http://blast.ncbi.nlm.nih.gov/Blast.cgi?PAGE=Proteins&amp;PROGRAM=blastp&amp;BLAST_PROGRAMS=blastp&amp;QUERY=VTGAAGFIGSHFVRSLLADEYRGWEGAQVTALDKLTYAGNRENLPASHERLVFVRGDVCDRSLLRELLPGHDAVVHFAAESHVDRSLEGAGEFFRTNVLGTQTVLDAVLESGVERVVHVSTDEVYGSITEGSWTEEWPLAPNSPYAASKAGSDLVARAYWRTHGVDLSITRCSNNYG&amp;LINK_LOC=protein&amp;PAGE_TYPE=BlastSearch",
                            "sequence": "VTGAAGFIGSHFVRSLLADEYRGWEGAQVTALDKLTYAGNRENLPASHERLVFVRGDVCDRSLLRELLPGHDAVVHFAAESHVDRSLEGAGEFFRTNVLGTQTVLDAVLESGVERVVHVSTDEVYGSITEGSWTEEWPLAPNSPYAASKAGSDLVARAYWRTHGVDLSITRCSNNYG",
                            "dna_sequence": "ATGAGGATTCTTGTCACCGGAGCGGCGGGCTTCATCGGCTCGCACTTCGTCCGCAGTCTGCTGGCGGACGAGTACCGCGGCTGGGAAGGCGCCCAGGTCACCGCCCTGGACAAGCTGACCTACGCCGGCAACCGGGAGAACCTGCCCGCCTCGCACGAGCGCCTGGTGTTCGTCCGCGGCGACGTGTGCGACCGGTCCCTGCTCCGCGAACTGCTGCCCGGCCACGACGCCGTGGTGCACTTCGCGGCCGAGTCCCACGTGGACCGGTCCCTGGAGGGGGCCGGGGAGTTCTTCCGGACGAACGTGCTGGGCACCCAGACCGTGCTGGACGCCGTGCTGGAGAGCGGGGTCGAGCGGGTGGTGCACGTCTCCACCGACGAGGTCTACGGCTCGATCACGGAGGGCTCCTGGACGGAGGAGTGGCCGCTGGCGCCCAACTCGCCCTACGCGGCCTCGAAGGCGGGCTCGGACCTGGTCGCCCGCGCCTACTGGCGGACGCACGGCGTGGACCTGTCGATCACCCGCTGCTCCAACAACTACGGCCCCTACCAGCACCCCGAGAAGGTCATTCCGCTCTTCGTGACCAATCTGCTGGAGGGCGGTCAAGTCCCGCTGTACGGGGACGGACGCAACGTGCGCGAGTGGCTCCACGTGGCCGACCACTGCCGCGGCATCCACCTGGTGCTGAACGAGGGCCGGGCCGGGGAGATCTACAACATCGGCGGCGGCAACGAGTACACCAACCTCGATCTCACCCGGAAGCTGCTGGAACTGACCGGCGCCGGCGAGGAGAAGATCCGCCGGGTGGCCGATCGCAAGGCGCACGACCTGCGGTACTCGATCGACGAGTCGAAGATCCGGGAGGAACTCGGCTACGCGCCCCGGATCGGGTTCGAGGAGGGTCTGGCGGAGACCGTGGCCTGGTACCGCGACAACCCCGACTGGTGGAAGGCCGTCAAGCACGGGACGGGCCGTGCGGCCTGA",
                            "abbreviation": "NAD",
                            "html_class": "jsdomain-other"
                        }
                    ],
                    "modules": []
                }
            ]
        }
    },
    "pfam": {
        "r1c1": {
            "pfamOrfs": [
                {
                    "id": "ctg1_2",
                    "seqLength": 459,
                    "pfams": [
                        {
                            "start": 72,
                            "end": 178,
                            "name": "AAA",
                            "accession": "PF00004.29",
                            "description": "ATPase family associated with various cellular activities (AAA)",
                            "translation": "VLLYGPPGTGKTTLARLTAAVADRHFVALSALTSGVKELRDVMSEARRRRDRQGRRTVLFIDEVHRFSRTQQDALLGAVEDGQVLLVAATTENPSFSVVSPLLSRL",
                            "evalue": "1.9e-15",
                            "score": "57.5",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
                            ],
                            "html_class": "pfam-type-other"
                        },
                        {
                            "start": 208,
                            "end": 284,
                            "name": "AAA_assoc_2",
                            "accession": "PF16193.5",
                            "description": "AAA C-terminal domain",
                            "translation": "VLLEPEAEDVLVRLAAGDARSALTALEASAEGVTGTGGSAVDVAAVERAVSGTTVRYDRQGDQHHDVVSAFIKSIR",
                            "evalue": "8e-22",
                            "score": "77.4",
                            "go_terms": [],
                            "html_class": "pfam-type-other"
                        },
                        {
                            "start": 284,
                            "end": 450,
                            "name": "MgsA_C",
                            "accession": "PF12002.8",
                            "description": "MgsA AAA+ ATPase C terminal",
                            "translation": "GSDPDAALHYLARMLVAGEDPRFIARRLLVHASEDVGLADPTALQAAVAAAQTVQFIGMPEARLALAQATVHLATAPKSNTVLVGIDEAMSDVRAGAVGEVPPHLRHSRYTGAKELGNGVGYRYPHRTPEGVLPQQYPPGDLVGRDYYRPTDRGGERDLRERLSRL",
                            "evalue": "5.5e-67",
                            "score": "224.9",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_3",
                    "seqLength": 285,
                    "pfams": [
                        {
                            "start": 9,
                            "end": 277,
                            "name": "PhzC-PhzF",
                            "accession": "PF02567.16",
                            "description": "Phenazine biosynthesis-like protein",
                            "translation": "DVFTDVPLEGNPTAVFLDASGLSPGRMQQIAQEMHLSETVFVLPAENDGDVRVRIFTPVNELPFAGHPTLGAAVVLGESHDAKELRMETAKGTVTFELERDDDGRTVAAAMWQPLPVWRTYDRTDELLAALDLVDTGSTLPVEVYDNGPRHVFVGLDGVPALSSLEPDQRILARLPDMAANCFTGSGNRWRLRMFSPAYGVVEDAATGSAAGSIAVHLARYGLAPFGEWIDIRQGIEMGRPSTMRARVTGTPDRIDAVQVAGSAVVVA",
                            "evalue": "1.2e-70",
                            "score": "238.3",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_4",
                    "seqLength": 558,
                    "pfams": [
                        {
                            "start": 229,
                            "end": 330,
                            "name": "Asparaginase",
                            "accession": "PF00710.20",
                            "description": "Asparaginase, N-terminal",
                            "translation": "VQEVLGSGEFTGAQWLEGSPTVDETLYWLGLLVDTKVPLVGHAAQRRHQSLSADGDRNVVDGVKFIASGVALDERGEDRVGACVVVDELVYSARDVTKVDA",
                            "evalue": "1.7e-06",
                            "score": "27.7",
                            "go_terms": [],
                            "html_class": "pfam-type-other"
                        }
                    ]
                },
                {
                    "id": "ctg1_5",
                    "seqLength": 161,
                    "pfams": [
                        {
                            "start": 13,
                            "end": 147,
                            "name": "DUF488",
                            "accession": "PF04343.13",
                            "description": "Protein of unknown function, DUF488",
                            "translation": "VDSYLERLRQADVRLLLDVRQRRGVRGPDYAWANSRRLQAALAEAGIAYEHRRELAPTTELRQLQYAEDARLGVGKRSRSELAAAYTRRYTAEILDPADLGPIVAGLPSRGTTALFCVERDPEACHRSLVARRL",
                            "evalue": "3.6e-16",
                            "score": "59.9",
                            "go_terms": [],
                            "html_class": "pfam-type-other"
                        }
                    ]
                },
                {
                    "id": "ctg1_6",
                    "seqLength": 336,
                    "pfams": [
                        {
                            "start": 10,
                            "end": 86,
                            "name": "Dimerisation2",
                            "accession": "PF16864.5",
                            "description": "Dimerisation domain",
                            "translation": "VVDIITGGWRAQALYTAVRLGLPDHVAAGRDNDAELAKATGASEGGVHRLMRLLVAMEVFTGSDATGYRGTRMSAA",
                            "evalue": "9.7e-08",
                            "score": "31.9",
                            "go_terms": [],
                            "html_class": "pfam-type-other"
                        },
                        {
                            "start": 108,
                            "end": 314,
                            "name": "Methyltransf_2",
                            "accession": "PF00891.18",
                            "description": "O-methyltransferase domain",
                            "translation": "WDHAHHAISTESSGFEIAYGRPFYDYLGEAPATARRFRRTMNAASMFFHRVPAVFDFAGKKVVDVGGGGGQLLATVLTAAPTATGTLFDREHMAAKAREHLEAAVGPGRVQVVGGDMFAGVPEGGDVYILCRVLAGHDDEDVVRVFEHCRRGMTDASARLLILDRFVEDENPTVLPALWDLHLLMTTGGEHRTVERITRLLARAGL",
                            "evalue": "2.4e-30",
                            "score": "105.4",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008171' target='_blank'>GO:0008171</a>: O-methyltransferase activity"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_7",
                    "seqLength": 148,
                    "pfams": [
                        {
                            "start": 17,
                            "end": 142,
                            "name": "3-dmu-9_3-mt",
                            "accession": "PF06983.13",
                            "description": "3-demethylubiquinone-9 3-methyltransferase",
                            "translation": "LNPYLAFDGDARQALEFYHQVLGGTLDLGTYGDFGSAELPDPDKIMHATLTTADGFTLMAWDVPERVPFTPGTNVALYLGGDDPRLREHFEKLSAGGTVTLPLEKQMWGDEAGTLVDRFGITWMV",
                            "evalue": "3.5e-07",
                            "score": "30.8",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_8",
                    "seqLength": 163,
                    "pfams": [
                        {
                            "start": 17,
                            "end": 163,
                            "name": "PHZA_PHZB",
                            "accession": "PF03284.13",
                            "description": "Phenazine biosynthesis protein A/B",
                            "translation": "RARHRAVVADYMTRKGENRLTRYLLFTEDGSAGLYTSDTGEPVVSVGHEKLKAHGEWSLRMFPDWEWKNVEIFETQDPNRFWVECDGEGRILYPDYPPGYYKNHFLHSFELEDGRIKRQREFMNPFEQLRALGIEVPKINRGGIPT",
                            "evalue": "7.4e-73",
                            "score": "243.3",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0017000' target='_blank'>GO:0017000</a>: antibiotic biosynthetic process"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_9",
                    "seqLength": 618,
                    "pfams": [
                        {
                            "start": 47,
                            "end": 169,
                            "name": "GATase_7",
                            "accession": "PF13537.6",
                            "description": "Glutamine amidotransferase domain",
                            "translation": "HRRLAVIDIEGGTQPMVLPTDDGPVAITYSGEVYNYTELRGELLRRGHRFETRSDTEVVLHGYAEWGEAVAERLNGMFAFAIWDARVEKLVLIRDRMGVKPLYYSATDDGVLFGSEPKAILA",
                            "evalue": "2e-47",
                            "score": "160.1",
                            "go_terms": [],
                            "html_class": "pfam-type-other"
                        },
                        {
                            "start": 239,
                            "end": 608,
                            "name": "Asn_synthase",
                            "accession": "PF00733.21",
                            "description": "Asparagine synthase",
                            "translation": "VRELLEDIVSRQTVSDVPRCTLLSGGLDSSVITALAAAKLGRPGEHGEAGEKVRSFAVDFVGRENDFVADELRGTTDAPYAREVAAHVGSLHEAIVLDHAAIADPDVRRAVITARDSPLSLGDMDTSLYLLFQAIKEQSTVALSGESADEVFGGYRWFHQPEVQAAQTFPWMAVFVSGARAQVSDRFNADITAALDLPTYIKDRYAEAVREVERAEGESDHEMRMRVMCHLHLTRFVRMLLERKDRISMAVGLEVRVPFCDHRLVEYVYNTPWSLKTFDGREKSLLRAATADLLPRSVLERVKAPYPATLDPHYTGALLQQSKELLTTDDPVFDLVDRDWLEAITRHDPATMPIDVRNGMERVLDLSTW",
                            "evalue": "3.4e-85",
                            "score": "286.8",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004066' target='_blank'>GO:0004066</a>: asparagine synthase (glutamine-hydrolyzing) activity",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006529' target='_blank'>GO:0006529</a>: asparagine biosynthetic process"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_10",
                    "seqLength": 206,
                    "pfams": [
                        {
                            "start": 28,
                            "end": 114,
                            "name": "Putative_PNPOx",
                            "accession": "PF01243.20",
                            "description": "Pyridoxamine 5'-phosphate oxidase",
                            "translation": "DSAVADAVQQPGALALATVDARRRVSNRIVQVLHVRPAGLVFASHTDSRKGRELAGTPWASGVLYWREVGRQVSVSGPARPLPAGE",
                            "evalue": "1.4e-13",
                            "score": "50.8",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        },
                        {
                            "start": 164,
                            "end": 206,
                            "name": "PNP_phzG_C",
                            "accession": "PF10590.9",
                            "description": "Pyridoxine 5'-phosphate oxidase C-terminal dimerisation region",
                            "translation": "WTGYLLEPEAVEFWQSEPQDGLHRRLRYEREGSSWLTRRLQP",
                            "evalue": "9.1e-12",
                            "score": "44.9",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_12",
                    "seqLength": 634,
                    "pfams": [
                        {
                            "start": 122,
                            "end": 387,
                            "name": "Chorismate_bind",
                            "accession": "PF00425.18",
                            "description": "chorismate binding enzyme",
                            "translation": "DDAYADIVSDVLDREIGTGEGSNFVIKRSFVTGITGYSTRSALSLFRRLLTRESGAYWTFIVHTGTRTFVGATPERHVSLRDGVAAMTPISGTYRYPATGPALPEVLEFLTDGKETDELYMVLDEELKMMARVCRRGGRVKGPYLREMTWLAHTEYTIEGDSDLDPRDVLRETMFAPTVTGSPLENACRVIARHEPAGRGYYGGIVALIGRDAAGAHAMDSAILIRTADIDSSGTDGTADVRVGVGATLVRHSDPEAETAETRTK",
                            "evalue": "9.9e-43",
                            "score": "146.5",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        },
                        {
                            "start": 442,
                            "end": 621,
                            "name": "GATase",
                            "accession": "PF00117.28",
                            "description": "Glutamine amidotransferase class-I",
                            "translation": "IVDAEDTFSAMLAHQLRAVGLSVTPTRFDEPLHFAGHDLVVMGPGPGDPRQTDHPRMARLTSAVEELLDRRIPFLAVCLSHQLLSRRLGLGIRRRDVPNQGAQREIDLFGSPARVGFYNSFSARALSSRLRCPGVGEVDVCLDADTGEVHALRGPHFASVQFHLESVLTQDSERVLAEL",
                            "evalue": "1.3e-19",
                            "score": "70.7",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_13",
                    "seqLength": 207,
                    "pfams": [
                        {
                            "start": 32,
                            "end": 204,
                            "name": "Isochorismatase",
                            "accession": "PF00857.20",
                            "description": "Isochorismatase family",
                            "translation": "ALLVHDMQRYFLAPFPPAVRDPLVRHCAQLRRRCAALGVPVFYTAQPGGMTDEERGLLKDFWGPGMRVDPEDRRIVEELTPAPADQVLTKWRYSAFFRSDLLTQLRTRGRDQLIVCGVYAHVGVLATALEAFTNDIQPFLVADALGDFSADYHRLALDYAAERCAVVTTTEE",
                            "evalue": "8.8e-40",
                            "score": "136.7",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_14",
                    "seqLength": 374,
                    "pfams": [
                        {
                            "start": 1,
                            "end": 136,
                            "name": "DAHP_synth_2",
                            "accession": "PF01474.16",
                            "description": "Class-II DAHP synthetase family",
                            "translation": "RNMLAELPGLVDPASLDRLRNRLAAVAAGQALVVQAGDCAEDFAECTAGDVKRRADLLDVLAGVMNEITHRPVIKVGRIGGQYAKPRSATTETVAGVELPVYRGHMVNGAEPDPEARRPDPRRLLTGYHAAHQVF",
                            "evalue": "1.6e-43",
                            "score": "148.9",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003849' target='_blank'>GO:0003849</a>: 3-deoxy-7-phosphoheptulonate synthase activity",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009073' target='_blank'>GO:0009073</a>: aromatic amino acid family biosynthetic process"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        },
                        {
                            "start": 149,
                            "end": 354,
                            "name": "DAHP_synth_2",
                            "accession": "PF01474.16",
                            "description": "Class-II DAHP synthetase family",
                            "translation": "AVWTSHEALLLDYEVPMVRADREGRLALTSTHWPWIGERTRQPDGAHVALLSEVVNPVACKIGPRTTTTELLDLCARLDPARTPGRLTLIARMGAGAAAELLPPLVRAVRTAGHPVIWLADPMHGNTVTTAEGRKTRVVETVVREVTAFQDAVRSAGATPGGIHLETTPDAVTECADVPEATDHIGDKYTSLCDPRLNPRQAISV",
                            "evalue": "2.6e-76",
                            "score": "256.9",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003849' target='_blank'>GO:0003849</a>: 3-deoxy-7-phosphoheptulonate synthase activity",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009073' target='_blank'>GO:0009073</a>: aromatic amino acid family biosynthetic process"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_18",
                    "seqLength": 121,
                    "pfams": [
                        {
                            "start": 17,
                            "end": 62,
                            "name": "HTH_5",
                            "accession": "PF01022.20",
                            "description": "Bacterial regulatory protein, arsR family",
                            "translation": "HPVRIRVLELLQHGPVPVRDLLADIDIEPSSLSQQLAVLRRSGIV",
                            "evalue": "2.3e-08",
                            "score": "33.7",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of transcription, DNA-templated"
                            ],
                            "html_class": "pfam-type-regulatory"
                        }
                    ]
                },
                {
                    "id": "ctg1_19",
                    "seqLength": 787,
                    "pfams": [
                        {
                            "start": 505,
                            "end": 525,
                            "name": "SWIM",
                            "accession": "PF04434.17",
                            "description": "SWIM zinc finger",
                            "translation": "RCSCPDSGHPCKHAAALCYQ",
                            "evalue": "1e-05",
                            "score": "25.0",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008270' target='_blank'>GO:0008270</a>: zinc ion binding"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_20",
                    "seqLength": 955,
                    "pfams": [
                        {
                            "start": 318,
                            "end": 447,
                            "name": "DUF3670",
                            "accession": "PF12419.8",
                            "description": "SNF2 Helicase protein",
                            "translation": "VPDVLALSEDELSDLLGVAATRLAAAGVAVHWPRDLAQDLTATAVVRPAPGSATDGTGFFESEDLLRFGWQIALGGDPLGEAEMDALAEAHRPVVRLRDQWVLVDPALVRKARKRDLGLLDPVDALSVA",
                            "evalue": "7.8e-33",
                            "score": "113.2",
                            "go_terms": [],
                            "html_class": "pfam-type-other"
                        },
                        {
                            "start": 509,
                            "end": 765,
                            "name": "SNF2_N",
                            "accession": "PF00176.23",
                            "description": "SNF2 family N-terminal domain",
                            "translation": "LGGCLADDMGLGKTVTLIALHLKRARPEPTLVVCPASLLGNWQREITRFAPGVPVRRFHGPDRTLEELDGGFVLTTYGTMRSAAPTLAEQRWGMVVADEAQHVKNPHSATAKALRTIPAPARVALTGTPVENNLSELWALLDWTTPGLLGPLKSFRARHARAVETGEDEQAVERLARLVRPFLLRRKKSDPGIVPELPPKTETDHPVPLTREQAALYEAVVRESMVAIETAQGMGRRGLVLKLLTALKQICDHPAL",
                            "evalue": "4.3e-49",
                            "score": "167.1",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0005524' target='_blank'>GO:0005524</a>: ATP binding"
                            ],
                            "html_class": "pfam-type-other"
                        },
                        {
                            "start": 783,
                            "end": 895,
                            "name": "Helicase_C",
                            "accession": "PF00271.31",
                            "description": "Helicase conserved C-terminal domain",
                            "translation": "KLALLDELLDTVLAEDGSALVFTQYVGMARLITRHLAERAVPVDLLHGGTPVPERERMVDRFQSGAVPVLVLSLKAAGTGLNLTRAGHVVHFDRWWNPAVEEQATDRAYRIG",
                            "evalue": "4.4e-16",
                            "score": "59.2",
                            "go_terms": [],
                            "html_class": "pfam-type-other"
                        }
                    ]
                },
                {
                    "id": "ctg1_22",
                    "seqLength": 382,
                    "pfams": [
                        {
                            "start": 37,
                            "end": 348,
                            "name": "ROK",
                            "accession": "PF00480.20",
                            "description": "ROK family",
                            "translation": "TVGIDIGGTKVMAGVVDADGNILEKLRTETPDKSKSPKVVEDTIVELVLDLSDRHDVHAVGIGAAGWVDADRNRVLFAPHLSWRNEPLRDRLADRLAVPVLVDNDANSAAWAEWRFGAGSGEDNLVMITLGTGIGGAILEDGKVKRGKYGVAGEFGHMQVVPGGHRCPCGNRGCWEQYSSGNALVREAKELAAADSPVAYGIIEHVKGNIADISGPMITELAREGDAMCIELLQDIGQWLGVGIANLAAALDPSCFVIGGGVSAADDLLIGPARDAFKRQLTGRGYRPEARIVRAQLGPEAGMVGAADLAR",
                            "evalue": "9.8e-81",
                            "score": "271.4",
                            "go_terms": [],
                            "html_class": "pfam-type-other"
                        }
                    ]
                },
                {
                    "id": "ctg1_23",
                    "seqLength": 254,
                    "pfams": [
                        {
                            "start": 24,
                            "end": 87,
                            "name": "GntR",
                            "accession": "PF00392.21",
                            "description": "Bacterial regulatory proteins, gntR family",
                            "translation": "YFQLSQQLESAIEHGTLTPGTLLGNEIELAARLGLSRPTVRQAIQSLVDKGLLVRRRGVGTQV",
                            "evalue": "6.6e-16",
                            "score": "57.7",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003700' target='_blank'>GO:0003700</a>: DNA-binding transcription factor activity",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of transcription, DNA-templated"
                            ],
                            "html_class": "pfam-type-regulatory"
                        },
                        {
                            "start": 107,
                            "end": 244,
                            "name": "UTRA",
                            "accession": "PF07702.13",
                            "description": "UTRA domain",
                            "translation": "AGQRPTTAVLVNTMVTASAEVAAALGVTEGTEVHRIERLRSAHGEPIAYLCNYIPPALLDLDTGQLEATGLYRLMRAAGITLHSARQTIGARAATAAEAERLREQPGAPLLTMQRVTFDDTGRAVEYGTHTYRPSRY",
                            "evalue": "4.8e-40",
                            "score": "136.7",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of transcription, DNA-templated"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_24",
                    "seqLength": 340,
                    "pfams": [
                        {
                            "start": 0,
                            "end": 118,
                            "name": "GFO_IDH_MocA",
                            "accession": "PF01408.22",
                            "description": "Oxidoreductase family, NAD-binding Rossmann fold",
                            "translation": "MRIGVIGTGRIGTIHAHTLSRHREVGSLILTDVDPARAQALAHRLGETAAPGVDEIYTWGVDAVVITAATSAHADLIGRAARAGLPVFCEKPIALDLAGTLQAITEVETAGTVLQMGF",
                            "evalue": "1.1e-17",
                            "score": "64.9",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        },
                        {
                            "start": 129,
                            "end": 227,
                            "name": "GFO_IDH_MocA_C",
                            "accession": "PF02894.17",
                            "description": "Oxidoreductase family, C-terminal alpha/beta domain",
                            "translation": "REAVRAGRLGRLHTVRAMTSDAEPPAPSRLAQSGGLYRDTLIHDFDVLRWVTGREVVDVYAGGSDAGPPMFREAGDVDTGAALLTLDDGTLATVTGTR",
                            "evalue": "6.1e-07",
                            "score": "29.5",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055114' target='_blank'>GO:0055114</a>: oxidation-reduction process"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_25",
                    "seqLength": 168,
                    "pfams": [
                        {
                            "start": 50,
                            "end": 102,
                            "name": "4HBT",
                            "accession": "PF03061.22",
                            "description": "Thioesterase superfamily",
                            "translation": "NGFLHGGVLAYAADNALTFAAGAVLGPAVLTGGFSVQYLRPATGRALRARAR",
                            "evalue": "3.5e-06",
                            "score": "27.3",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_26",
                    "seqLength": 224,
                    "pfams": [
                        {
                            "start": 5,
                            "end": 118,
                            "name": "Response_reg",
                            "accession": "PF00072.24",
                            "description": "Response regulator receiver domain",
                            "translation": "VLLVDDDPLVRAGLSFMLGGAGDIEIVGEAADGGEVGALVDRTRPDVVLMDIRMPSVDGLTATESLRTREDAPQVVVLTTFHADDQVLRALRAGAAGFVLKDTPPTEIVAAVR",
                            "evalue": "8.6e-27",
                            "score": "93.5",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system"
                            ],
                            "html_class": "pfam-type-regulatory"
                        },
                        {
                            "start": 157,
                            "end": 212,
                            "name": "GerE",
                            "accession": "PF00196.19",
                            "description": "Bacterial regulatory proteins, luxR family",
                            "translation": "LNDREREVAVAVGRGLANAEIAAELYMSVATVKTHVSRILAKLGLNNRVQIALLA",
                            "evalue": "1e-13",
                            "score": "50.6",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of transcription, DNA-templated"
                            ],
                            "html_class": "pfam-type-regulatory"
                        }
                    ]
                },
                {
                    "id": "ctg1_27",
                    "seqLength": 416,
                    "pfams": [
                        {
                            "start": 214,
                            "end": 278,
                            "name": "HisKA_3",
                            "accession": "PF07730.13",
                            "description": "Histidine kinase",
                            "translation": "REAIAREMHDVLAHRLTLLSVHAGALEFRPDAPREEVARAAGVIRESAHEALQDLREIIGVLRA",
                            "evalue": "2.6e-14",
                            "score": "53.5",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000155' target='_blank'>GO:0000155</a>: phosphorelay sensor kinase activity",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0046983' target='_blank'>GO:0046983</a>: protein dimerization activity",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000160' target='_blank'>GO:0000160</a>: phosphorelay signal transduction system",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016021' target='_blank'>GO:0016021</a>: integral component of membrane"
                            ],
                            "html_class": "pfam-type-regulatory"
                        }
                    ]
                },
                {
                    "id": "ctg1_29",
                    "seqLength": 122,
                    "pfams": [
                        {
                            "start": 36,
                            "end": 116,
                            "name": "Ribonuclease",
                            "accession": "PF00545.20",
                            "description": "ribonuclease",
                            "translation": "LPAEAHDTLDLIDQGGPFPFEQDGTVFQNREGILPDRSSGYYHEYTVITPGSPTRGARRIVTGEEYQEDYYTADHYASFD",
                            "evalue": "3e-28",
                            "score": "98.4",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003723' target='_blank'>GO:0003723</a>: RNA binding",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004521' target='_blank'>GO:0004521</a>: endoribonuclease activity"
                            ],
                            "html_class": "pfam-type-other"
                        }
                    ]
                },
                {
                    "id": "ctg1_30",
                    "seqLength": 250,
                    "pfams": [
                        {
                            "start": 21,
                            "end": 247,
                            "name": "adh_short_C2",
                            "accession": "PF13561.6",
                            "description": "Enoyl-(Acyl carrier protein) reductase",
                            "translation": "RGIGAATALRLAREGADVAVTYVNGKEAAEDVVRAVEALGRRAVALRADAGDPQEASGAVGAAVRELGRLDVLVNNAGVGLLGPLETLSPADVDRVLAVNVRGVFLASRAAAAVLPRGGRIVTVGTCMTQRVPGPGGTLYAMSKAALVGLTKALARELGERGITANIVHPGPIDTDMNPADGPYAAGQAAATALGRFGTAAEVAETIVHLAGAAYVTGAEFAVDGG",
                            "evalue": "9.5e-57",
                            "score": "192.2",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_31",
                    "seqLength": 371,
                    "pfams": [
                        {
                            "start": 41,
                            "end": 201,
                            "name": "Allantoicase",
                            "accession": "PF03561.15",
                            "description": "Allantoicase repeat",
                            "translation": "GAGVIAANDEFFAQRENLLLPGRAVFDPERFGHKGKIMDGWETRRRRGTSAGHPWPTDDDHDWALIRLGTPGVVRGVVVDTAHFRGNYPQAVSVEGTAVDGSPSPEDLLADDVKWTTLVPRTAIGGHAANGFAVTAEQRFTHLRLNQHPDGGIARLRVYG",
                            "evalue": "4.6e-46",
                            "score": "156.4",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004037' target='_blank'>GO:0004037</a>: allantoicase activity",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000256' target='_blank'>GO:0000256</a>: allantoin catabolic process"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        },
                        {
                            "start": 223,
                            "end": 352,
                            "name": "Allantoicase",
                            "accession": "PF03561.15",
                            "description": "Allantoicase repeat",
                            "translation": "GGRVEDASDRFYSPAANTIRPGRSQKMDDGWETRRRRDHGHDWITYRLVAQSQIRALEIDTAYLKGNAAGWASVSVRDGEDGDWREILPRTRLQPDTNHRFVLPDPAVGTHARVDIHPDGGISRLRLFG",
                            "evalue": "4.4e-34",
                            "score": "117.5",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004037' target='_blank'>GO:0004037</a>: allantoicase activity",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0000256' target='_blank'>GO:0000256</a>: allantoin catabolic process"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_32",
                    "seqLength": 446,
                    "pfams": [
                        {
                            "start": 53,
                            "end": 426,
                            "name": "Amidohydro_1",
                            "accession": "PF01979.20",
                            "description": "Amidohydrolase family",
                            "translation": "VLLPGLVDTHVHVNDPGRTEWEGFWTATRAAAAGGITTLVDMPLNSLPPTTTVDHLRVKRKTAADKAHVDVGFWGGALPDNVADLRPLHEAGVFGFKAFLSPSGVDEFPHLDEEQLARSLAEIAAFDGLLIVHAEDPGHLAGAPQRGGPRYADFLASRPRLAEDTAIARLLEQARRFDARVHVLHLSSADALPLLAEARADGVRVTVETCPHYLTLTAEEVPDGASEFKCCPPIRESANQDLLWRALADGTVDCVVTDHSPSTADLKTDDFATAWGGISGLQLSLPAVWTEARRRGHTLEDVVRWMATRTARLAGLDARKGAVAPGHDADFAVLAPDESFTVDPAALQHRNRVTAYAGRTLYGVVRSTWLRGR",
                            "evalue": "9.5e-26",
                            "score": "90.9",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016787' target='_blank'>GO:0016787</a>: hydrolase activity"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_33",
                    "seqLength": 268,
                    "pfams": [
                        {
                            "start": 21,
                            "end": 73,
                            "name": "HTH_IclR",
                            "accession": "PF09339.10",
                            "description": "IclR helix-turn-helix domain",
                            "translation": "SLERAFDLLERMADAGGEVGLSELSASSGLPLPTIHRLMRTLVACGYVRQQP",
                            "evalue": "6.8e-18",
                            "score": "64.2",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006355' target='_blank'>GO:0006355</a>: regulation of transcription, DNA-templated"
                            ],
                            "html_class": "pfam-type-regulatory"
                        },
                        {
                            "start": 134,
                            "end": 257,
                            "name": "IclR",
                            "accession": "PF01614.18",
                            "description": "Bacterial transcriptional regulator",
                            "translation": "MRMFTEVGRRVLPHSTGVGKALLAGFPPEEVRALLGRTGMPAATEKTITTADGFLAALEEVRRQGYAIDDNEQEIGVRCLAVPVPDAPTAAAISISGPAGRVTEAATERIVPVLQQIATELSE",
                            "evalue": "8.6e-31",
                            "score": "106.5",
                            "go_terms": [],
                            "html_class": "pfam-type-regulatory"
                        }
                    ]
                },
                {
                    "id": "ctg1_35",
                    "seqLength": 203,
                    "pfams": [
                        {
                            "start": 13,
                            "end": 178,
                            "name": "NTP_transf_3",
                            "accession": "PF12804.7",
                            "description": "MobA-like NTP transferase domain",
                            "translation": "GLLLAAGGGRRLGGHPKALLTHRGRPLVEHAARVLRAGGCAGVHVVLGARADEVRARAVLPDCVLVDNPDWEQGMGSSLRAGLHSLAGTGAGAALVLLVDQPGIGPEAVARVRGRYRSPQSLVSAAYEGVRGHPVLFGAAHWAGIAATATGDRGARAYLREHADR",
                            "evalue": "2.1e-35",
                            "score": "122.5",
                            "go_terms": [],
                            "html_class": "pfam-type-other"
                        }
                    ]
                },
                {
                    "id": "ctg1_37",
                    "seqLength": 541,
                    "pfams": [
                        {
                            "start": 17,
                            "end": 539,
                            "name": "Malate_synthase",
                            "accession": "PF01274.22",
                            "description": "Malate synthase",
                            "translation": "PRQEEVLTDTALAFVAELHRRFTPRRDELLARRAERRAGIARTATLDFLPETAAIRADDSWKVAPAPPALEDRRVEITGPTDRKMTINALNSGAKVWLADFEDASAPTWENVVTGQLNLIDAYTRAIDFTDPGSGKSYALRPEEELATVVTRPRGWHLDERHLTDPEGTPVPGALVDFGLYFFHNAKRLIDLGKGPYFYLPKTESHLEARLWNDVFVFAQDYLGIPRGTVRATVLIETITAAYEMEEILYELRDHASGLNAGRWDYLFSIVKNFRDGGEKFVLPDRNAVTMTAPFMRAYTELLVRTCHKRGAHAIGGMAAFIPSRRDAEVNKVAFEKVRADKDREANDGFDGSWVAHPDLVPIAMESFDQVLGDKPNQKDRLREDVDVKAADLIAVDSLDARPTYAGLVNAVQVGIRYIEAWLRGLGAVAIFNLMEDAATAEISRSQIWQWINAGVVLDNGERVTAELAREVAAEELANIRAEAGEEAFAAGNWQQAHDLLLKVALDEDYADFLTLPAYEQL",
                            "evalue": "5.7e-207",
                            "score": "688.1",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0004474' target='_blank'>GO:0004474</a>: malate synthase activity",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0006097' target='_blank'>GO:0006097</a>: glyoxylate cycle"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_38",
                    "seqLength": 92,
                    "pfams": [
                        {
                            "start": 6,
                            "end": 79,
                            "name": "Rdx",
                            "accession": "PF10262.9",
                            "description": "Rdx family",
                            "translation": "RVEIEYCTQCRWLPRAAWLAQELLTTFEQELTELALRPGTGGVFVVRVGDEVVWDRREQGFPEPTAVKRAVRD",
                            "evalue": "1.3e-28",
                            "score": "99.0",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_40",
                    "seqLength": 372,
                    "pfams": [
                        {
                            "start": 14,
                            "end": 357,
                            "name": "Oxidored_FMN",
                            "accession": "PF00724.20",
                            "description": "NADH:flavin oxidoreductase / NADH oxidase family",
                            "translation": "RPFSVGGLNLPNRVVMAPMTREFSPGGVPGEDVARYYARRAAGGVGLLVTEGSYIDHASAGNSARVPHFYGDKALAGWSAVAEAVHREGGRIMPQLWHVGMDRATGNPPVPDAPRIGPSGIALDGSHSGREMTQADIDNVVAAYASAAASAEALGFDGVEIHGGHGYLVDQFLWAHTNRRTDGYGGDVARRTRFAAEIVAACRAAVSDDFPISFRLSQWKVNHYGARIAETPQELETVLGLLAEAGADVFHCSTRRFHLPEFEGSDLNLAGWAKKLSGKPAVSVGSVGMSNEFLDVFQGEQAAVTDIGNLLDRMERDEFDLIAVGRALLGDPEWLTKILSGRT",
                            "evalue": "2.1e-59",
                            "score": "201.5",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0010181' target='_blank'>GO:0010181</a>: FMN binding",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055114' target='_blank'>GO:0055114</a>: oxidation-reduction process"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_41",
                    "seqLength": 522,
                    "pfams": [
                        {
                            "start": 24,
                            "end": 417,
                            "name": "MFS_1",
                            "accession": "PF07690.16",
                            "description": "Major Facilitator Superfamily",
                            "translation": "LMLGIFLATLDGQIVSTALPTIVGDLGGLELFSWSVTAYLLTMAASTPLWGKLGDLYGRKGAYTNSVVLFLIGTVLCGLARNMEQLIAFRAVQGLGAGGLMVGALSVIGVLVPPEGRGRIQSMVGVMMPVAFVGGPLLGGLVTEHLDWRWAFYVNVPVGLVALLAVAKGVRLPAQRVTGHVDYAGAALLTSGVLALTLLAGWAGTTYAWLSWQITALAALVAVSLAWFVRVERRAAEPITPPRLFARREFTLAQVLSLLVGAILISVVNYLPQYMQFVQGASPTASGMLILPLMLGMLSAQLTTGRLMDRGGLDRIVPLTGASVTVAGALLLLLLGSATPVAAASALTLVVGIGVGMLMQSTLLTTMNNADPRDMGAATGTVTLVRTIGGSLG",
                            "evalue": "1.5e-46",
                            "score": "158.9",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport"
                            ],
                            "html_class": "pfam-type-transport"
                        }
                    ]
                },
                {
                    "id": "ctg1_42",
                    "seqLength": 199,
                    "pfams": [
                        {
                            "start": 9,
                            "end": 155,
                            "name": "FMN_red",
                            "accession": "PF03358.15",
                            "description": "NADPH-dependent FMN reductase",
                            "translation": "RTAVIIGSTRDGRFGPVVTDWITGHMSERECMTVDVIDLVATPLPTVFPAFGQPPSDEVVVQLGEVTPRLAAADAFVIVTPEYNHSFPAALKNAIDWHNEQWHAKPVGFVSYGGLSGGLRAVEQLRVVLAEVHAVTIRNTVSFHNY",
                            "evalue": "1.2e-36",
                            "score": "125.8",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_43",
                    "seqLength": 245,
                    "pfams": [
                        {
                            "start": 38,
                            "end": 82,
                            "name": "TetR_N",
                            "accession": "PF00440.23",
                            "description": "Bacterial regulatory proteins, tetR family",
                            "translation": "ARAAVTLADAEGLDAVTMRRLATELGVAPMAAYRYVTGKDELIE",
                            "evalue": "5.5e-08",
                            "score": "32.5",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003677' target='_blank'>GO:0003677</a>: DNA binding"
                            ],
                            "html_class": "pfam-type-regulatory"
                        },
                        {
                            "start": 93,
                            "end": 242,
                            "name": "TetR_C_1",
                            "accession": "PF02909.17",
                            "description": "Tetracyclin repressor-like, C-terminal domain",
                            "translation": "LPQDTDSWRTTMHTLAQRIRDVLLRHSWVTRATWCAPTPNQLAVPEAALAALDGLGLDADTAMVVYSTVTSYVHGAVNAEVGVTQLLRVHGWSSREEARSGLASQMAWLLSTGRFPMYERYIGEAGRKDDLEWQFETGLECVLDGISER",
                            "evalue": "1.2e-18",
                            "score": "67.4",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0045892' target='_blank'>GO:0045892</a>: negative regulation of transcription, DNA-templated"
                            ],
                            "html_class": "pfam-type-other"
                        }
                    ]
                },
                {
                    "id": "ctg1_45",
                    "seqLength": 495,
                    "pfams": [
                        {
                            "start": 2,
                            "end": 334,
                            "name": "FAD_binding_3",
                            "accession": "PF01494.19",
                            "description": "FAD binding domain",
                            "translation": "ASVIVAGAGPAGLMLAGELRLAGVDVIVLDRLMERTGESRGLGFTTRTMEVFDQRGLLHRFGDMGTSNAGHFGGLPVDFGVLDSVHEAAKTVPQSDTETMLEGWVRELGADIRRGHEMVTLHDHGDHVEAEVRGPGGEEIRLTAPFLVGCDGGRSTVRKAAGFDFPGTAATLEMYLADIKGVDLQPRLIGETFPGGMVMCGPLGNRGVTRIIVCERGTPPRRRTEPPSYAEVAAAWQRITGIDISHAEHEWVSAFGDATRLVTEYRRGRVLLAGDAAHIHLPAGGQGMNTGIQDAVNLGWKLAAVVRGTAPEELLDTYHAERYPVGERLMMN",
                            "evalue": "5.1e-98",
                            "score": "328.5",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0071949' target='_blank'>GO:0071949</a>: FAD binding"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_46",
                    "seqLength": 108,
                    "pfams": [
                        {
                            "start": 1,
                            "end": 106,
                            "name": "Cyclase_polyket",
                            "accession": "PF04673.12",
                            "description": "Polyketide synthesis cyclase",
                            "translation": "HSTLIVARMEPRSAEDVARLFGEFDGTEMPHRMGTRRRQLFSYRGLYFHLQDFDTEDGGERIEAAKTDPRFVGISEDLKPFITAYDPATWRSPADAMAQRFYHWT",
                            "evalue": "8.3e-44",
                            "score": "148.1",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0030639' target='_blank'>GO:0030639</a>: polyketide biosynthetic process"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_47",
                    "seqLength": 426,
                    "pfams": [
                        {
                            "start": 6,
                            "end": 254,
                            "name": "ketoacyl-synt",
                            "accession": "PF00109.26",
                            "description": "Beta-ketoacyl synthase, N-terminal domain",
                            "translation": "RRVVITGIGVTAPGGVGVKNFWNTLSGGHTATRRITFFDPSPFRSQVAAEVDFDAELLGLSAQEIRRMDRAAQFAVVTARDAVADSGLEFTALDPHRTGVTIGSAVGATMGLDQEYRTVSDSGRLDLVDHTYAVPHLYNHLVPSSFAAEVAWAVGAEGPATVVSTGCTSGLDAVGYAADLIREGSADVMVAGATDAPISPITVACFDAIKATTPRNDDPEHASRPFDGTRNGFVLGEGSAVFVLEELG",
                            "evalue": "1.7e-54",
                            "score": "185.1",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        },
                        {
                            "start": 263,
                            "end": 378,
                            "name": "Ketoacyl-synt_C",
                            "accession": "PF02801.22",
                            "description": "Beta-ketoacyl synthase, C-terminal domain",
                            "translation": "YAEIAGYATRSNAFHMTGLRPDGREMAEAIRVALDEARLAPGAIDYVNAHGSGTKQNDRHETAAFKRSLGEHAYAVPVSSIKSMVGHSLGAIGSIEIAASALAMEHGVVPPTANL",
                            "evalue": "5.8e-36",
                            "score": "123.1",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_48",
                    "seqLength": 406,
                    "pfams": [
                        {
                            "start": 8,
                            "end": 247,
                            "name": "ketoacyl-synt",
                            "accession": "PF00109.26",
                            "description": "Beta-ketoacyl synthase, N-terminal domain",
                            "translation": "AVTGLGVVAPNGLGTEAYWTATRKGVSGIGRVTRFVPDQYPAQLAGEIDGFDAHEHLPGRLLPQTDRMTQLALVAADWAFQDAAVRPEDLPGFEMGVITAGSSGGFEFGQRELQALWSKGSRYVSAYQSFAWFYAVNSGQISIRNGMRGPSGVVVSDQAGGLDAVAQARRQLRKGTRLVMSGAVDASICPWGWVAQMTSNRLSTGRDPARAYLPFDDAAAGHVPGEGGALLVMEDLQQA",
                            "evalue": "6.7e-41",
                            "score": "140.5",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        },
                        {
                            "start": 254,
                            "end": 364,
                            "name": "Ketoacyl-synt_C",
                            "accession": "PF02801.22",
                            "description": "Beta-ketoacyl synthase, C-terminal domain",
                            "translation": "YGEIAGYGATLDPRPGSGRPPGLRKAVELALADAGAAPGDIDVVFADAAALPDLDRIEAETITAVFGARAVPVTAPKTMTGRLYSGAAPLDLAAAFLAMRDEVIPPSVGV",
                            "evalue": "1.9e-19",
                            "score": "69.8",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_49",
                    "seqLength": 89,
                    "pfams": [
                        {
                            "start": 22,
                            "end": 79,
                            "name": "PP-binding",
                            "accession": "PF00550.25",
                            "description": "Phosphopantetheine attachment site",
                            "translation": "EGVDLDGDILDTDFGLLGYESLALLETGGRIEREFGITLDDETLTDAATPRSLLEAV",
                            "evalue": "1.8e-09",
                            "score": "37.8",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_50",
                    "seqLength": 261,
                    "pfams": [
                        {
                            "start": 7,
                            "end": 201,
                            "name": "adh_short",
                            "accession": "PF00106.25",
                            "description": "short chain dehydrogenase",
                            "translation": "VALVTGATSGIGLAVTRRLARQGHRVFLCARTETGVTRTVKDLLDEGLDVDGAPCDVRSGADVKRFVEQAVDRFGTIDVLVNNAGRSGGGVTADISDDLWSDVIDTNLNSVFRMTREVLTTGGMREKDRGRIINVASTAGKQGVVLGAPYSASKHGVVGFTKALGNELAPTGITVNAVCPGYVETPMAQRVRQG",
                            "evalue": "5.8e-66",
                            "score": "221.7",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_51",
                    "seqLength": 311,
                    "pfams": [
                        {
                            "start": 3,
                            "end": 146,
                            "name": "Polyketide_cyc2",
                            "accession": "PF10604.9",
                            "description": "Polyketide cyclase / dehydrase and lipid transport",
                            "translation": "RQVEHEITVEAPAAAVYRLIAEVENWPRIFPPTIHVDHVERSTGEERIRIWATANGEAKNWTSRRTLDPERLRITFRQEVSTPPVAAMGGAWVIEPLSGDSARIRLLHDYRAVDDDPAGLRWIDEAVDRNSRAELAALKTNVE",
                            "evalue": "7.3e-12",
                            "score": "45.8",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        },
                        {
                            "start": 155,
                            "end": 298,
                            "name": "Polyketide_cyc2",
                            "accession": "PF10604.9",
                            "description": "Polyketide cyclase / dehydrase and lipid transport",
                            "translation": "FSFEDTVHITGSAKDAYDFVDEAGLWAERLPHVASVRFTEDTPGLQTLEMDTRAKDGSTHTTKSYRVTFPHHRIAYKQVTLPALMTLHTGLWTFTENESGVTATSQHTVTLDTENIARVLGPDATVADARAYVQGALSANSLA",
                            "evalue": "3.3e-07",
                            "score": "30.7",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_52",
                    "seqLength": 662,
                    "pfams": [
                        {
                            "start": 4,
                            "end": 334,
                            "name": "FAD_binding_3",
                            "accession": "PF01494.19",
                            "description": "FAD binding domain",
                            "translation": "DTDVIVVGAGPSGLVLAGDLRAGGARVTVLERLARPTTESRASVLHARTLHLLAERGLLRRFGQLPAAGPGHFGGIPLDLSEAGDSPYAGQWKAPQTHVEAVLAAWATELGAEVRRGLTVTGLTRSSDRVRVVAVAPGGRRLRLDASYVVGCDGEDSAVRRLGGFGFPGAAATKELLRADLAGIELRERRFERHPRGVANARRGPDGVTRIMVHAFDRTPGPSRTPAFDDVCAVWARVTGEDITGARPVWLNAFDNARRQADGYRDGRVFLAGDAAHVQLPVGGQALNLGLQDAMDLGPKLAAHLAGRAGDEVLDTYDTVRRPVGARVLT",
                            "evalue": "3.3e-66",
                            "score": "223.9",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0071949' target='_blank'>GO:0071949</a>: FAD binding"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        },
                        {
                            "start": 420,
                            "end": 657,
                            "name": "adh_short_C2",
                            "accession": "PF13561.6",
                            "description": "Enoyl-(Acyl carrier protein) reductase",
                            "translation": "GSSRGIGRATALRLARDGALVAVHCSSNREAAEETVAAIEKDGGRGFSVLAELGVPGDVHELFLALERELKERTGDTTLDILVNNAGVMGGVDPEELTPEQFDRLFAVNAKAPYFLVQRALANLPDGGRIINISSGLTRVANPQEVAYAMTKGAVDQLTLHFAKHLGPRGITVNSVGPGITDNGSPVFDDPEAVAAMAGYSVFNRVGETRDIADVVAFLASDDSRWITGSYLDASGG",
                            "evalue": "5e-46",
                            "score": "157.2",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_53",
                    "seqLength": 412,
                    "pfams": [
                        {
                            "start": 34,
                            "end": 369,
                            "name": "MFS_1",
                            "accession": "PF07690.16",
                            "description": "Major Facilitator Superfamily",
                            "translation": "MLIDALEVSVVLVALPAMGRDLGLSMYGGQWMMSGFAAGFAALLLLGPRLAARWGRRRVYLAALTVFIAASLAGGLTDEGAVLAATRVVKGMCAALTAPTGLAIIGTVFRPGPEQSRAVSVYSLFGAAGFTVGLLSSGALTELSWRWNPVFPAPFAVLLLLAGVRLVPGDTGRTSAEPLRPAMARLVRNGPFVRSALCAATLNGTYLGLLLLLTHWLHDTWGWSSWETALAFLPACVPLALALPFAGRMVARFGTGPLIAAGGCATALGCATALLTGAPGTYVTGVLPVLLCVEAGFVLSFAALNLQAVSGIPAERRSTAVPVYQTAVQLGPLLS",
                            "evalue": "8.5e-39",
                            "score": "133.5",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0055085' target='_blank'>GO:0055085</a>: transmembrane transport"
                            ],
                            "html_class": "pfam-type-transport"
                        }
                    ]
                },
                {
                    "id": "ctg1_54",
                    "seqLength": 430,
                    "pfams": [
                        {
                            "start": 230,
                            "end": 313,
                            "name": "DUF1205",
                            "accession": "PF06722.12",
                            "description": "Protein of unknown function (DUF1205)",
                            "translation": "TRIPVRRVPYTGAGRLPGWLHTRPERPRVVLSLGVSRRKIFGRYSGFPMREFFASVSELDIEVVATLNSQQLDAAGTLPGNVR",
                            "evalue": "4.1e-14",
                            "score": "52.4",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        },
                        {
                            "start": 305,
                            "end": 398,
                            "name": "UDPGT",
                            "accession": "PF00201.18",
                            "description": "UDP-glucoronosyl and UDP-glucosyl transferase",
                            "translation": "GTLPGNVRAVEYVPLNQVLPTASAIIHHGGGGTFSSAVAHQVPQLVMPLVMWDEMVTARYVRDMGAGLVADPDALDVAEMHKQLVRLLEDPSF",
                            "evalue": "7.1e-06",
                            "score": "25.1",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016758' target='_blank'>GO:0016758</a>: transferase activity, transferring hexosyl groups"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_55",
                    "seqLength": 398,
                    "pfams": [
                        {
                            "start": 176,
                            "end": 272,
                            "name": "DUF1205",
                            "accession": "PF06722.12",
                            "description": "Protein of unknown function (DUF1205)",
                            "translation": "DPCPPTLRLPGGEPGTPIRYVPYSGGGEVPAWVRADDGPRAGRRRVAVSLGNTLALHGVGFTRALLRALAASPGTEILVTLPEPYRSRIGPLPDTV",
                            "evalue": "2e-11",
                            "score": "43.9",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_56",
                    "seqLength": 193,
                    "pfams": [
                        {
                            "start": 5,
                            "end": 176,
                            "name": "dTDP_sugar_isom",
                            "accession": "PF00908.17",
                            "description": "dTDP-4-dehydrorhamnose 3,5-epimerase",
                            "translation": "LPLPGTYVITPELIPDPRGSFYEAMRGDLLEEATGVPFLPRQINYSVSRRHTLRGIHSVRIPPGQAKYVTCVRGALRDIVVDLRIGSPTFGEHRVNVLDADSGRSVYVPEGVGHGFLALTDDACICYVVSSTYVPGTQIDINPLDPDLGLPWDCPEPPLISDKDAKAPTVA",
                            "evalue": "9.5e-51",
                            "score": "171.8",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0008830' target='_blank'>GO:0008830</a>: dTDP-4-dehydrorhamnose 3,5-epimerase activity"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_57",
                    "seqLength": 376,
                    "pfams": [
                        {
                            "start": 168,
                            "end": 263,
                            "name": "DUF1205",
                            "accession": "PF06722.12",
                            "description": "Protein of unknown function (DUF1205)",
                            "translation": "VDICPPSLRPAGAAPAQPMRYVPANAQRRLETWMVTRGERRRILVTSGSRVAKESYDKNFDFLRGLTADVASWDVELIVAAPDGTADALRDGLPG",
                            "evalue": "1.9e-17",
                            "score": "63.1",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_58",
                    "seqLength": 355,
                    "pfams": [
                        {
                            "start": 1,
                            "end": 235,
                            "name": "NTP_transferase",
                            "accession": "PF00483.23",
                            "description": "Nucleotidyl transferase",
                            "translation": "KALVLAGGSGTRLRPFSYSMPKQLIPIANTPVLVHVLDSVRELGVTEVGVIVGNRGPEIEAVLGDGSRFGVRITYIPQDEPRGLAHTVVIARDFLGPDDFVMYLGDNMLPDGIAETAAEFVRHRPAAHVVVHKVADPRSFGVAELGPDGEVRRLVEKPREPRSDLALIGVYFFTAAIHEAVASIEPSARGELEITDAVQWLLSSGADVRASRYDGYWKDTGKVEDVLECNSHLL",
                            "evalue": "2.1e-49",
                            "score": "168.3",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016779' target='_blank'>GO:0016779</a>: nucleotidyltransferase activity",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0009058' target='_blank'>GO:0009058</a>: biosynthetic process"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_59",
                    "seqLength": 327,
                    "pfams": [
                        {
                            "start": 2,
                            "end": 241,
                            "name": "Epimerase",
                            "accession": "PF01370.21",
                            "description": "NAD dependent epimerase/dehydratase family",
                            "translation": "ILVTGAAGFIGSHFVRSLLADEYRGWEGAQVTALDKLTYAGNRENLPASHERLVFVRGDVCDRSLLRELLPGHDAVVHFAAESHVDRSLEGAGEFFRTNVLGTQTVLDAVLESGVERVVHVSTDEVYGSITEGSWTEEWPLAPNSPYAASKAGSDLVARAYWRTHGVDLSITRCSNNYGPYQHPEKVIPLFVTNLLEGGQVPLYGDGRNVREWLHVADHCRGIHLVLNEGRAGEIYNIG",
                            "evalue": "6e-66",
                            "score": "222.4",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0050662' target='_blank'>GO:0050662</a>: coenzyme binding"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_60",
                    "seqLength": 352,
                    "pfams": [
                        {
                            "start": 12,
                            "end": 258,
                            "name": "Epimerase",
                            "accession": "PF01370.21",
                            "description": "NAD dependent epimerase/dehydratase family",
                            "translation": "VVVLGSGGFLGRGLGAAFASRGARVHLFSRGGPPPVTGPPAGRTTTATRLDLLTADAKELRTALAAARPDVVVNAAGRAWRADEAEMAAGNATLVERVVTALAALPGPPVRLVQLGSVHEYGAGDPAGATGEDHRPEPVTPYGRTKLLGTRAVLRGAREGSVEGVVLRLANVIGAGVPEGSLFGRVAAHLGEAAAARARGEHVAALRLPPLRAARDLVDAGDVADAVVAVATAPSAAVNGQVINVG",
                            "evalue": "2.5e-30",
                            "score": "105.7",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0050662' target='_blank'>GO:0050662</a>: coenzyme binding"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_61",
                    "seqLength": 436,
                    "pfams": [
                        {
                            "start": 45,
                            "end": 428,
                            "name": "DegT_DnrJ_EryC1",
                            "accession": "PF01041.17",
                            "description": "DegT/DnrJ/EryC1/StrS aminotransferase family",
                            "translation": "RVALVEAALELRIAAGTSSRKFESQFARRLKRRKAHLTNSGSSANLLAVSALMSHALEERRLKPGDEVITVAAGFPTTVNPILQNGLIPVFVDVDLGTYNATADRVAAAIGPKTRAVIIAHALGNPFEVTEIAQLCEQHDLFLIEDNCDAVGSLYDGKLTGTFGDMTTVSFYPAHHLTMGEGGCVLTSNLALARIVESLRDWGRDCWCEPGENDRCLKRFTYQMGTLPAGYDHKYIFSHVGYNLKATDIQAALGLTQLAKLDSFIEARRRNWQRLREGLDGVPGLLLPEATPRSEPSWFGFVITVDPEAPFSRAELVDFLEGRKIGTRRLFAGNLTRHPAYIDQPHRIVGDLANSDVITEHTFWIGVYPALTDEMLDYVTASI",
                            "evalue": "2.9e-93",
                            "score": "313.0",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_62",
                    "seqLength": 254,
                    "pfams": [
                        {
                            "start": 18,
                            "end": 177,
                            "name": "Epimerase",
                            "accession": "PF01370.21",
                            "description": "NAD dependent epimerase/dehydratase family",
                            "translation": "RHPDTVALAAGVSWASGTSDADFAREAALLREVAGRCRDTGRRLLFFSTAATGMYGLADGPGREDVPVTPCTPYGAHKLALEGVLRDSGADHLILRLGHLVGPHQPEHQLLPTLVRQLREGMVRVHRGAARDLIGVEDVITVVDHLLAAGPRAETVNVA",
                            "evalue": "1.9e-17",
                            "score": "63.6",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0003824' target='_blank'>GO:0003824</a>: catalytic activity",
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0050662' target='_blank'>GO:0050662</a>: coenzyme binding"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_64",
                    "seqLength": 467,
                    "pfams": [
                        {
                            "start": 34,
                            "end": 242,
                            "name": "Hexose_dehydrat",
                            "accession": "PF03559.14",
                            "description": "NDP-hexose 2,3-dehydratase",
                            "translation": "DRFSAWLAERGSANAFRVDRIPFAELDGWSFEETTGNLVHRSGRFFTVEGMRVTERDEPYGDGPFAEWHQPVIKQPEVGILGILAKEFDGVLHFLMQAKMEPGNPNLLQLSPTVQATRSNYTKAHQGADVKYIQHFVGPGRGRVVADALQSEHGSWFFRKANRNMIVEATGDVPLLDDFCWLTLGQIAELLHRDNVVNMDSRTVLSCL",
                            "evalue": "1.7e-86",
                            "score": "288.8",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        },
                        {
                            "start": 256,
                            "end": 459,
                            "name": "Hexose_dehydrat",
                            "accession": "PF03559.14",
                            "description": "NDP-hexose 2,3-dehydratase",
                            "translation": "ELLSWITGERARHDVHAERVPLAGLPGWHRHETAIEHEEGRYFKVVAVSVQAGNREVTSWTQPLFEPVGQGVTAFLTRTFDGVPHVLVHARVEGGFLDTVELGPTVQYTPANYAHLPEKERPPYLDTVLEAPAERIRYEAVHAEEGGRFLNAESRYLLVDADERDAPLDPPPGYAWVTPDQLTWLVRHGHYLNVQARTLLACL",
                            "evalue": "7.5e-79",
                            "score": "263.9",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_65",
                    "seqLength": 319,
                    "pfams": [
                        {
                            "start": 4,
                            "end": 122,
                            "name": "GFO_IDH_MocA",
                            "accession": "PF01408.22",
                            "description": "Oxidoreductase family, NAD-binding Rossmann fold",
                            "translation": "VRIGVLGCADIAVRRMLPAFTASPDVEVAAVASRDRGRAERTAGRFGCRPVHGYAELLDRDDVQAVYVPLPAALHAHWVEAALEAGKHVLAEKPLTTDPDTTERLLELAGKQGVALME",
                            "evalue": "2.8e-22",
                            "score": "79.8",
                            "go_terms": [
                                "<a class='external-link' href='http://amigo.geneontology.org/amigo/term/GO:0016491' target='_blank'>GO:0016491</a>: oxidoreductase activity"
                            ],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                },
                {
                    "id": "ctg1_66",
                    "seqLength": 65,
                    "pfams": [
                        {
                            "start": 23,
                            "end": 63,
                            "name": "Carboxyl_trans",
                            "accession": "PF01039.22",
                            "description": "Carboxyl transferase domain",
                            "translation": "QHAKGKLTARERIELLLDAGSFREVEQLRRHRATGFGLEE",
                            "evalue": "1.4e-10",
                            "score": "40.4",
                            "go_terms": [],
                            "html_class": "pfam-type-biosynthetic"
                        }
                    ]
                }
            ]
        }
    }
};
var resultsData = {
    "r1c1": {
        "antismash.modules.cluster_compare": {
            "MIBiG": {
                "ProtoToRegion_RiQ": {
                    "reference_clusters": {
                        "BGC0000231.1: 189-5010": {
                            "start": 189,
                            "end": 5010,
                            "links": [
                                {
                                    "query": "ctg1_50",
                                    "subject": "CAA54861.1",
                                    "query_loc": 48987,
                                    "subject_loc": 3593
                                },
                                {
                                    "query": "ctg1_49",
                                    "subject": "CAA54860.1",
                                    "query_loc": 48263,
                                    "subject_loc": 2943
                                },
                                {
                                    "query": "ctg1_51",
                                    "subject": "CAA54862.1",
                                    "query_loc": 49868,
                                    "subject_loc": 4530
                                },
                                {
                                    "query": "ctg1_47",
                                    "subject": "CAA54858.1",
                                    "query_loc": 46193,
                                    "subject_loc": 823
                                },
                                {
                                    "query": "ctg1_48",
                                    "subject": "CAA54859.1",
                                    "query_loc": 47440,
                                    "subject_loc": 2073
                                }
                            ],
                            "reverse": false,
                            "genes": [
                                {
                                    "locus_tag": "CAA54859.1",
                                    "start": 1454,
                                    "end": 2693,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_48"
                                    }
                                },
                                {
                                    "locus_tag": "CAA54862.1",
                                    "start": 4050,
                                    "end": 5010,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_51"
                                    }
                                },
                                {
                                    "locus_tag": "CAA54858.1",
                                    "start": 189,
                                    "end": 1458,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_47"
                                    }
                                },
                                {
                                    "locus_tag": "CAA54861.1",
                                    "start": 3200,
                                    "end": 3986,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_50"
                                    }
                                },
                                {
                                    "locus_tag": "CAA54860.1",
                                    "start": 2808,
                                    "end": 3078,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_49"
                                    }
                                }
                            ]
                        },
                        "BGC0000229.1: 0-41909": {
                            "start": 0,
                            "end": 41909,
                            "links": [
                                {
                                    "query": "ctg1_49",
                                    "subject": "AGO50612.1",
                                    "query_loc": 48263,
                                    "subject_loc": 13928
                                },
                                {
                                    "query": "ctg1_56",
                                    "subject": "AGO50619.1",
                                    "query_loc": 56430,
                                    "subject_loc": 22045
                                },
                                {
                                    "query": "ctg1_59",
                                    "subject": "AGO50622.1",
                                    "query_loc": 59438,
                                    "subject_loc": 25010
                                },
                                {
                                    "query": "ctg1_47",
                                    "subject": "AGO50610.1",
                                    "query_loc": 46193,
                                    "subject_loc": 11859
                                },
                                {
                                    "query": "ctg1_61",
                                    "subject": "AGO50624.1",
                                    "query_loc": 61629,
                                    "subject_loc": 27201
                                },
                                {
                                    "query": "ctg1_54",
                                    "subject": "AGO50617.1",
                                    "query_loc": 54267,
                                    "subject_loc": 19839
                                },
                                {
                                    "query": "ctg1_40",
                                    "subject": "AGO50604.1",
                                    "query_loc": 38570,
                                    "subject_loc": 4280
                                },
                                {
                                    "query": "ctg1_48",
                                    "subject": "AGO50611.1",
                                    "query_loc": 47440,
                                    "subject_loc": 13106
                                },
                                {
                                    "query": "ctg1_66",
                                    "subject": "AGO50629.1",
                                    "query_loc": 66655,
                                    "subject_loc": 32856
                                },
                                {
                                    "query": "ctg1_58",
                                    "subject": "AGO50621.1",
                                    "query_loc": 58416,
                                    "subject_loc": 23988
                                },
                                {
                                    "query": "ctg1_45",
                                    "subject": "AGO50609.1",
                                    "query_loc": 44473,
                                    "subject_loc": 10139
                                },
                                {
                                    "query": "ctg1_43",
                                    "subject": "AGO50607.1",
                                    "query_loc": 42005,
                                    "subject_loc": 7661
                                },
                                {
                                    "query": "ctg1_37",
                                    "subject": "AGO50602.1",
                                    "query_loc": 35870,
                                    "subject_loc": 1575
                                },
                                {
                                    "query": "ctg1_42",
                                    "subject": "AGO50606.1",
                                    "query_loc": 41206,
                                    "subject_loc": 6911
                                },
                                {
                                    "query": "ctg1_64",
                                    "subject": "AGO50627.1",
                                    "query_loc": 64836,
                                    "subject_loc": 30410
                                },
                                {
                                    "query": "ctg1_57",
                                    "subject": "AGO50620.1",
                                    "query_loc": 57288,
                                    "subject_loc": 22860
                                },
                                {
                                    "query": "ctg1_50",
                                    "subject": "AGO50613.1",
                                    "query_loc": 48987,
                                    "subject_loc": 14584
                                },
                                {
                                    "query": "ctg1_39",
                                    "subject": "AGO50603.1",
                                    "query_loc": 37468,
                                    "subject_loc": 3143
                                },
                                {
                                    "query": "ctg1_62",
                                    "subject": "AGO50625.1",
                                    "query_loc": 62717,
                                    "subject_loc": 28288
                                },
                                {
                                    "query": "ctg1_51",
                                    "subject": "AGO50614.1",
                                    "query_loc": 49868,
                                    "subject_loc": 15465
                                },
                                {
                                    "query": "ctg1_41",
                                    "subject": "AGO50605.1",
                                    "query_loc": 40093,
                                    "subject_loc": 5822
                                },
                                {
                                    "query": "ctg1_55",
                                    "subject": "AGO50618.1",
                                    "query_loc": 55541,
                                    "subject_loc": 21122
                                },
                                {
                                    "query": "ctg1_52",
                                    "subject": "AGO50615.1",
                                    "query_loc": 51331,
                                    "subject_loc": 16928
                                },
                                {
                                    "query": "ctg1_65",
                                    "subject": "AGO50628.1",
                                    "query_loc": 66014,
                                    "subject_loc": 31588
                                },
                                {
                                    "query": "ctg1_60",
                                    "subject": "AGO50623.1",
                                    "query_loc": 60448,
                                    "subject_loc": 26041
                                },
                                {
                                    "query": "ctg1_53",
                                    "subject": "AGO50616.1",
                                    "query_loc": 52961,
                                    "subject_loc": 18544
                                },
                                {
                                    "query": "ctg1_35",
                                    "subject": "AGO50601.1",
                                    "query_loc": 34541,
                                    "subject_loc": 300
                                },
                                {
                                    "query": "ctg1_63",
                                    "subject": "AGO50626.1",
                                    "query_loc": 63603,
                                    "subject_loc": 29176
                                },
                                {
                                    "query": "ctg1_44",
                                    "subject": "AGO50608.1",
                                    "query_loc": 43073,
                                    "subject_loc": 8648
                                }
                            ],
                            "reverse": false,
                            "genes": [
                                {
                                    "locus_tag": "AGO50612.1",
                                    "start": 13793,
                                    "end": 14063,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_49"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50601.1",
                                    "start": 0,
                                    "end": 600,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_35"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50625.1",
                                    "start": 27906,
                                    "end": 28671,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_62"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50607.1",
                                    "start": 7241,
                                    "end": 8081,
                                    "strand": 1,
                                    "function": "regulatory",
                                    "linked": {
                                        "1": "ctg1_43"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50629.1",
                                    "start": 32088,
                                    "end": 33624,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_66"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50626.1",
                                    "start": 28699,
                                    "end": 29653,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_63"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50610.1",
                                    "start": 11219,
                                    "end": 12500,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_47"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50622.1",
                                    "start": 24518,
                                    "end": 25502,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_59"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50609.1",
                                    "start": 9395,
                                    "end": 10883,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_45"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50615.1",
                                    "start": 15934,
                                    "end": 17923,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_52"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50602.1",
                                    "start": 762,
                                    "end": 2388,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_37"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50633.1",
                                    "start": 39587,
                                    "end": 40613,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "AGO50611.1",
                                    "start": 12496,
                                    "end": 13717,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_48"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50630.1",
                                    "start": 34148,
                                    "end": 35738,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "AGO50605.1",
                                    "start": 5063,
                                    "end": 6581,
                                    "strand": -1,
                                    "function": "transport",
                                    "linked": {
                                        "1": "ctg1_41"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50606.1",
                                    "start": 6611,
                                    "end": 7211,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_42"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50621.1",
                                    "start": 23454,
                                    "end": 24522,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_58"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50604.1",
                                    "start": 3721,
                                    "end": 4840,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_40"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50608.1",
                                    "start": 8227,
                                    "end": 9070,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_44"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50618.1",
                                    "start": 20515,
                                    "end": 21730,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_55"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50627.1",
                                    "start": 29708,
                                    "end": 31112,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_64"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50613.1",
                                    "start": 14191,
                                    "end": 14977,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_50"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50631.1",
                                    "start": 36424,
                                    "end": 37135,
                                    "strand": -1,
                                    "function": "regulatory",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "AGO50634.1",
                                    "start": 40952,
                                    "end": 41909,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "AGO50616.1",
                                    "start": 17935,
                                    "end": 19153,
                                    "strand": 1,
                                    "function": "transport",
                                    "linked": {
                                        "1": "ctg1_53"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50620.1",
                                    "start": 22295,
                                    "end": 23426,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_57"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50619.1",
                                    "start": 21798,
                                    "end": 22293,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_56"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50614.1",
                                    "start": 14997,
                                    "end": 15933,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_51"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50628.1",
                                    "start": 31108,
                                    "end": 32068,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_65"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50624.1",
                                    "start": 26549,
                                    "end": 27854,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_61"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50617.1",
                                    "start": 19193,
                                    "end": 20486,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_54"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50632.1",
                                    "start": 37801,
                                    "end": 39598,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "AGO50603.1",
                                    "start": 2681,
                                    "end": 3605,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_39"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50623.1",
                                    "start": 25536,
                                    "end": 26547,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_60"
                                    }
                                }
                            ]
                        },
                        "BGC0001723.1: 128-10733": {
                            "start": 128,
                            "end": 10733,
                            "links": [
                                {
                                    "query": "ctg1_50",
                                    "subject": "ovmT",
                                    "query_loc": 48987,
                                    "subject_loc": 5412
                                },
                                {
                                    "query": "ctg1_47",
                                    "subject": "ovmP",
                                    "query_loc": 46193,
                                    "subject_loc": 2689
                                },
                                {
                                    "query": "ctg1_46",
                                    "subject": "ovmC",
                                    "query_loc": 45393,
                                    "subject_loc": 1890
                                },
                                {
                                    "query": "ctg1_51",
                                    "subject": "ovmA",
                                    "query_loc": 49868,
                                    "subject_loc": 6305
                                },
                                {
                                    "query": "ctg1_49",
                                    "subject": "ovmS",
                                    "query_loc": 48263,
                                    "subject_loc": 4761
                                },
                                {
                                    "query": "ctg1_48",
                                    "subject": "ovmK",
                                    "query_loc": 47440,
                                    "subject_loc": 3933
                                },
                                {
                                    "query": "ctg1_45",
                                    "subject": "ovmOI",
                                    "query_loc": 44473,
                                    "subject_loc": 872
                                },
                                {
                                    "query": "ctg1_52",
                                    "subject": "ovmOII",
                                    "query_loc": 51331,
                                    "subject_loc": 7504
                                }
                            ],
                            "reverse": false,
                            "genes": [
                                {
                                    "locus_tag": "ovmA",
                                    "start": 5831,
                                    "end": 6779,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_51"
                                    }
                                },
                                {
                                    "locus_tag": "ovmP",
                                    "start": 2053,
                                    "end": 3325,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_47"
                                    }
                                },
                                {
                                    "locus_tag": "ovmK",
                                    "start": 3321,
                                    "end": 4545,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_48"
                                    }
                                },
                                {
                                    "locus_tag": "ovmOII",
                                    "start": 6768,
                                    "end": 8241,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_52"
                                    }
                                },
                                {
                                    "locus_tag": "ovmF",
                                    "start": 9854,
                                    "end": 10733,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "ovmOIII",
                                    "start": 8260,
                                    "end": 9781,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "ovmOI",
                                    "start": 128,
                                    "end": 1616,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_45"
                                    }
                                },
                                {
                                    "locus_tag": "ovmS",
                                    "start": 4625,
                                    "end": 4898,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_49"
                                    }
                                },
                                {
                                    "locus_tag": "ovmC",
                                    "start": 1724,
                                    "end": 2057,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_46"
                                    }
                                },
                                {
                                    "locus_tag": "ovmT",
                                    "start": 5021,
                                    "end": 5804,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_50"
                                    }
                                }
                            ]
                        },
                        "BGC0000234.1: 152-6978": {
                            "start": 152,
                            "end": 6978,
                            "links": [
                                {
                                    "query": "ctg1_50",
                                    "subject": "AAB36565.1",
                                    "query_loc": 48987,
                                    "subject_loc": 5607
                                },
                                {
                                    "query": "ctg1_46",
                                    "subject": "jadI",
                                    "query_loc": 45393,
                                    "subject_loc": 2184
                                },
                                {
                                    "query": "ctg1_47",
                                    "subject": "jadA",
                                    "query_loc": 46193,
                                    "subject_loc": 2979
                                },
                                {
                                    "query": "ctg1_51",
                                    "subject": "AAB36566.1",
                                    "query_loc": 49868,
                                    "subject_loc": 6511
                                },
                                {
                                    "query": "ctg1_49",
                                    "subject": "acp",
                                    "query_loc": 48263,
                                    "subject_loc": 5002
                                },
                                {
                                    "query": "ctg1_48",
                                    "subject": "AAB36563.1",
                                    "query_loc": 47440,
                                    "subject_loc": 4217
                                }
                            ],
                            "reverse": false,
                            "genes": [
                                {
                                    "locus_tag": "acp",
                                    "start": 4867,
                                    "end": 5137,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_49"
                                    }
                                },
                                {
                                    "locus_tag": "jadA",
                                    "start": 2345,
                                    "end": 3614,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_47"
                                    }
                                },
                                {
                                    "locus_tag": "AAB36565.1",
                                    "start": 5210,
                                    "end": 6005,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_50"
                                    }
                                },
                                {
                                    "locus_tag": "AAB36563.1",
                                    "start": 3610,
                                    "end": 4825,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_48"
                                    }
                                },
                                {
                                    "locus_tag": "jadI",
                                    "start": 2019,
                                    "end": 2349,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_46"
                                    }
                                },
                                {
                                    "locus_tag": "jadJ",
                                    "start": 152,
                                    "end": 1907,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "AAB36566.1",
                                    "start": 6045,
                                    "end": 6978,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_51"
                                    }
                                }
                            ]
                        },
                        "BGC0000248.1: 1435-5236": {
                            "start": 1435,
                            "end": 5236,
                            "links": [
                                {
                                    "query": "ctg1_47",
                                    "subject": "ncnA",
                                    "query_loc": 46193,
                                    "subject_loc": 2068
                                },
                                {
                                    "query": "ctg1_48",
                                    "subject": "ncnB",
                                    "query_loc": 47440,
                                    "subject_loc": 3342
                                },
                                {
                                    "query": "ctg1_49",
                                    "subject": "ncnC",
                                    "query_loc": 48263,
                                    "subject_loc": 4161
                                },
                                {
                                    "query": "ctg1_51",
                                    "subject": "ncnD",
                                    "query_loc": 49868,
                                    "subject_loc": 4762
                                }
                            ],
                            "reverse": false,
                            "genes": [
                                {
                                    "locus_tag": "ncnD",
                                    "start": 4288,
                                    "end": 5236,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_51"
                                    }
                                },
                                {
                                    "locus_tag": "ncnB",
                                    "start": 2697,
                                    "end": 3987,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_48"
                                    }
                                },
                                {
                                    "locus_tag": "ncnA",
                                    "start": 1435,
                                    "end": 2701,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_47"
                                    }
                                },
                                {
                                    "locus_tag": "ncnC",
                                    "start": 4031,
                                    "end": 4292,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_49"
                                    }
                                }
                            ]
                        },
                        "BGC0001769.1: 0-44740": {
                            "start": 0,
                            "end": 44740,
                            "links": [
                                {
                                    "query": "ctg1_59",
                                    "subject": "sqnS3",
                                    "query_loc": 59438,
                                    "subject_loc": 24090
                                },
                                {
                                    "query": "ctg1_61",
                                    "subject": "sqnS5",
                                    "query_loc": 61629,
                                    "subject_loc": 26281
                                },
                                {
                                    "query": "ctg1_56",
                                    "subject": "sqnS1",
                                    "query_loc": 56430,
                                    "subject_loc": 21128
                                },
                                {
                                    "query": "ctg1_50",
                                    "subject": "sqnK",
                                    "query_loc": 48987,
                                    "subject_loc": 13617
                                },
                                {
                                    "query": "ctg1_66",
                                    "subject": "sqnP",
                                    "query_loc": 66655,
                                    "subject_loc": 32773
                                },
                                {
                                    "query": "ctg1_47",
                                    "subject": "sqnH",
                                    "query_loc": 46193,
                                    "subject_loc": 10670
                                },
                                {
                                    "query": "ctg1_46",
                                    "subject": "sqnBB",
                                    "query_loc": 45393,
                                    "subject_loc": 9856
                                },
                                {
                                    "query": "ctg1_58",
                                    "subject": "sqnS2",
                                    "query_loc": 58416,
                                    "subject_loc": 23068
                                },
                                {
                                    "query": "ctg1_45",
                                    "subject": "sqnF",
                                    "query_loc": 44473,
                                    "subject_loc": 8936
                                },
                                {
                                    "query": "ctg1_54",
                                    "subject": "sqnG1",
                                    "query_loc": 54267,
                                    "subject_loc": 18926
                                },
                                {
                                    "query": "ctg1_51",
                                    "subject": "sqnL",
                                    "query_loc": 49868,
                                    "subject_loc": 14519
                                },
                                {
                                    "query": "ctg1_48",
                                    "subject": "sqnI",
                                    "query_loc": 47440,
                                    "subject_loc": 11906
                                },
                                {
                                    "query": "ctg1_57",
                                    "subject": "sqnG3",
                                    "query_loc": 57288,
                                    "subject_loc": 21943
                                },
                                {
                                    "query": "ctg1_64",
                                    "subject": "sqnS7",
                                    "query_loc": 64836,
                                    "subject_loc": 29548
                                },
                                {
                                    "query": "ctg1_49",
                                    "subject": "sqnJ",
                                    "query_loc": 48263,
                                    "subject_loc": 12839
                                },
                                {
                                    "query": "ctg1_42",
                                    "subject": "sqnC",
                                    "query_loc": 41206,
                                    "subject_loc": 5736
                                },
                                {
                                    "query": "ctg1_43",
                                    "subject": "sqnD",
                                    "query_loc": 42005,
                                    "subject_loc": 6524
                                },
                                {
                                    "query": "ctg1_65",
                                    "subject": "sqnS8",
                                    "query_loc": 66014,
                                    "subject_loc": 30723
                                },
                                {
                                    "query": "ctg1_52",
                                    "subject": "sqnM",
                                    "query_loc": 51331,
                                    "subject_loc": 15988
                                },
                                {
                                    "query": "ctg1_55",
                                    "subject": "sqnG2",
                                    "query_loc": 55541,
                                    "subject_loc": 20205
                                },
                                {
                                    "query": "ctg1_41",
                                    "subject": "sqnB",
                                    "query_loc": 40093,
                                    "subject_loc": 4615
                                },
                                {
                                    "query": "ctg1_53",
                                    "subject": "sqnN",
                                    "query_loc": 52961,
                                    "subject_loc": 17614
                                },
                                {
                                    "query": "ctg1_62",
                                    "subject": "sqnS6",
                                    "query_loc": 62717,
                                    "subject_loc": 27361
                                },
                                {
                                    "query": "ctg1_60",
                                    "subject": "sqnS4",
                                    "query_loc": 60448,
                                    "subject_loc": 25156
                                },
                                {
                                    "query": "ctg1_63",
                                    "subject": "sqnO",
                                    "query_loc": 63603,
                                    "subject_loc": 28295
                                },
                                {
                                    "query": "ctg1_44",
                                    "subject": "sqnE",
                                    "query_loc": 43073,
                                    "subject_loc": 7448
                                }
                            ],
                            "reverse": false,
                            "genes": [
                                {
                                    "locus_tag": "sqnW",
                                    "start": 41990,
                                    "end": 42845,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnA",
                                    "start": 2628,
                                    "end": 3768,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnB",
                                    "start": 3825,
                                    "end": 5406,
                                    "strand": -1,
                                    "function": "transport",
                                    "linked": {
                                        "1": "ctg1_41"
                                    }
                                },
                                {
                                    "locus_tag": "sqnO",
                                    "start": 27808,
                                    "end": 28783,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_63"
                                    }
                                },
                                {
                                    "locus_tag": "sqnG2",
                                    "start": 19598,
                                    "end": 20813,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_55"
                                    }
                                },
                                {
                                    "locus_tag": "sqnC",
                                    "start": 5436,
                                    "end": 6036,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_42"
                                    }
                                },
                                {
                                    "locus_tag": "sqnS8",
                                    "start": 30245,
                                    "end": 31202,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_65"
                                    }
                                },
                                {
                                    "locus_tag": "sqnN",
                                    "start": 17007,
                                    "end": 18222,
                                    "strand": 1,
                                    "function": "transport",
                                    "linked": {
                                        "1": "ctg1_53"
                                    }
                                },
                                {
                                    "locus_tag": "sqnY",
                                    "start": 44059,
                                    "end": 44740,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnI",
                                    "start": 11293,
                                    "end": 12520,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_48"
                                    }
                                },
                                {
                                    "locus_tag": "sqnT",
                                    "start": 38556,
                                    "end": 40383,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnZ",
                                    "start": 0,
                                    "end": 1605,
                                    "strand": 1,
                                    "function": "transport",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnCC",
                                    "start": 31198,
                                    "end": 31963,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnDD",
                                    "start": 33640,
                                    "end": 34318,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnQ",
                                    "start": 34394,
                                    "end": 36023,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnS4",
                                    "start": 24679,
                                    "end": 25633,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_60"
                                    }
                                },
                                {
                                    "locus_tag": "sqnP",
                                    "start": 31977,
                                    "end": 33570,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_66"
                                    }
                                },
                                {
                                    "locus_tag": "sqnS3",
                                    "start": 23598,
                                    "end": 24582,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_59"
                                    }
                                },
                                {
                                    "locus_tag": "sqnEE",
                                    "start": 36140,
                                    "end": 36578,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnM",
                                    "start": 14989,
                                    "end": 16987,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_52"
                                    }
                                },
                                {
                                    "locus_tag": "sqnL",
                                    "start": 14051,
                                    "end": 14987,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_51"
                                    }
                                },
                                {
                                    "locus_tag": "sqnAA",
                                    "start": 1758,
                                    "end": 2499,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnS5",
                                    "start": 25629,
                                    "end": 26934,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_61"
                                    }
                                },
                                {
                                    "locus_tag": "sqnS7",
                                    "start": 28848,
                                    "end": 30249,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_64"
                                    }
                                },
                                {
                                    "locus_tag": "sqnD",
                                    "start": 6155,
                                    "end": 6893,
                                    "strand": 1,
                                    "function": "regulatory",
                                    "linked": {
                                        "1": "ctg1_43"
                                    }
                                },
                                {
                                    "locus_tag": "sqnU",
                                    "start": 40375,
                                    "end": 41455,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnV",
                                    "start": 41488,
                                    "end": 41899,
                                    "strand": -1,
                                    "function": "regulatory",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnS2",
                                    "start": 22534,
                                    "end": 23602,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_58"
                                    }
                                },
                                {
                                    "locus_tag": "sqnS1",
                                    "start": 20881,
                                    "end": 21376,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_56"
                                    }
                                },
                                {
                                    "locus_tag": "sqnH",
                                    "start": 10043,
                                    "end": 11297,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_47"
                                    }
                                },
                                {
                                    "locus_tag": "sqnE",
                                    "start": 7022,
                                    "end": 7874,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_44"
                                    }
                                },
                                {
                                    "locus_tag": "sqnBB",
                                    "start": 9693,
                                    "end": 10020,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_46"
                                    }
                                },
                                {
                                    "locus_tag": "sqnX",
                                    "start": 42973,
                                    "end": 43987,
                                    "strand": 1,
                                    "function": "transport",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnS6",
                                    "start": 26979,
                                    "end": 27744,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_62"
                                    }
                                },
                                {
                                    "locus_tag": "sqnG3",
                                    "start": 21378,
                                    "end": 22509,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_57"
                                    }
                                },
                                {
                                    "locus_tag": "sqnG1",
                                    "start": 18280,
                                    "end": 19573,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_54"
                                    }
                                },
                                {
                                    "locus_tag": "sqnR",
                                    "start": 37133,
                                    "end": 37898,
                                    "strand": -1,
                                    "function": "regulatory",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnF",
                                    "start": 8192,
                                    "end": 9680,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_45"
                                    }
                                },
                                {
                                    "locus_tag": "sqnJ",
                                    "start": 12704,
                                    "end": 12974,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_49"
                                    }
                                },
                                {
                                    "locus_tag": "sqnK",
                                    "start": 13224,
                                    "end": 14010,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_50"
                                    }
                                }
                            ]
                        },
                        "BGC0001384.1: 2468-44008": {
                            "start": 2468,
                            "end": 44008,
                            "links": [
                                {
                                    "query": "ctg1_46",
                                    "subject": "sprC",
                                    "query_loc": 45393,
                                    "subject_loc": 13425
                                },
                                {
                                    "query": "ctg1_66",
                                    "subject": "sprU",
                                    "query_loc": 66655,
                                    "subject_loc": 36382
                                },
                                {
                                    "query": "ctg1_50",
                                    "subject": "sprG",
                                    "query_loc": 48987,
                                    "subject_loc": 17040
                                },
                                {
                                    "query": "ctg1_47",
                                    "subject": "sprD",
                                    "query_loc": 46193,
                                    "subject_loc": 14225
                                },
                                {
                                    "query": "ctg1_59",
                                    "subject": "sprM",
                                    "query_loc": 59438,
                                    "subject_loc": 27500
                                },
                                {
                                    "query": "ctg1_61",
                                    "subject": "sprO",
                                    "query_loc": 61629,
                                    "subject_loc": 29757
                                },
                                {
                                    "query": "ctg1_58",
                                    "subject": "sprL",
                                    "query_loc": 58416,
                                    "subject_loc": 26478
                                },
                                {
                                    "query": "ctg1_45",
                                    "subject": "sprB",
                                    "query_loc": 44473,
                                    "subject_loc": 12505
                                },
                                {
                                    "query": "ctg1_48",
                                    "subject": "sprE",
                                    "query_loc": 47440,
                                    "subject_loc": 15484
                                },
                                {
                                    "query": "ctg1_51",
                                    "subject": "sprH",
                                    "query_loc": 49868,
                                    "subject_loc": 17941
                                },
                                {
                                    "query": "ctg1_57",
                                    "subject": "sprGT3",
                                    "query_loc": 57288,
                                    "subject_loc": 25353
                                },
                                {
                                    "query": "ctg1_56",
                                    "subject": "sprK",
                                    "query_loc": 56430,
                                    "subject_loc": 24502
                                },
                                {
                                    "query": "ctg1_62",
                                    "subject": "sprP",
                                    "query_loc": 62717,
                                    "subject_loc": 30850
                                },
                                {
                                    "query": "ctg1_64",
                                    "subject": "sprR",
                                    "query_loc": 64836,
                                    "subject_loc": 33158
                                },
                                {
                                    "query": "ctg1_52",
                                    "subject": "sprI",
                                    "query_loc": 51331,
                                    "subject_loc": 19405
                                },
                                {
                                    "query": "ctg1_65",
                                    "subject": "sprS",
                                    "query_loc": 66014,
                                    "subject_loc": 34333
                                },
                                {
                                    "query": "ctg1_54",
                                    "subject": "sprGT1",
                                    "query_loc": 54267,
                                    "subject_loc": 22334
                                },
                                {
                                    "query": "ctg1_40",
                                    "subject": "spr3",
                                    "query_loc": 38570,
                                    "subject_loc": 6697
                                },
                                {
                                    "query": "ctg1_42",
                                    "subject": "spr5",
                                    "query_loc": 41206,
                                    "subject_loc": 9275
                                },
                                {
                                    "query": "ctg1_49",
                                    "subject": "sprF",
                                    "query_loc": 48263,
                                    "subject_loc": 16290
                                },
                                {
                                    "query": "ctg1_55",
                                    "subject": "sprGT2",
                                    "query_loc": 55541,
                                    "subject_loc": 23615
                                },
                                {
                                    "query": "ctg1_43",
                                    "subject": "sprR2",
                                    "query_loc": 42005,
                                    "subject_loc": 10062
                                },
                                {
                                    "query": "ctg1_53",
                                    "subject": "sprJ",
                                    "query_loc": 52961,
                                    "subject_loc": 21025
                                },
                                {
                                    "query": "ctg1_41",
                                    "subject": "spr4",
                                    "query_loc": 40093,
                                    "subject_loc": 8154
                                },
                                {
                                    "query": "ctg1_63",
                                    "subject": "sprQ",
                                    "query_loc": 63603,
                                    "subject_loc": 31822
                                },
                                {
                                    "query": "ctg1_44",
                                    "subject": "sprA",
                                    "query_loc": 43073,
                                    "subject_loc": 10948
                                },
                                {
                                    "query": "ctg1_60",
                                    "subject": "sprN",
                                    "query_loc": 60448,
                                    "subject_loc": 28554
                                }
                            ],
                            "reverse": false,
                            "genes": [
                                {
                                    "locus_tag": "spr5",
                                    "start": 8975,
                                    "end": 9575,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_42"
                                    }
                                },
                                {
                                    "locus_tag": "sprH",
                                    "start": 17473,
                                    "end": 18409,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_51"
                                    }
                                },
                                {
                                    "locus_tag": "sprB",
                                    "start": 11761,
                                    "end": 13249,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_45"
                                    }
                                },
                                {
                                    "locus_tag": "sprO",
                                    "start": 29102,
                                    "end": 30413,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_61"
                                    }
                                },
                                {
                                    "locus_tag": "sprGT3",
                                    "start": 24788,
                                    "end": 25919,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_57"
                                    }
                                },
                                {
                                    "locus_tag": "spr4",
                                    "start": 7364,
                                    "end": 8945,
                                    "strand": -1,
                                    "function": "transport",
                                    "linked": {
                                        "1": "ctg1_41"
                                    }
                                },
                                {
                                    "locus_tag": "sprGT2",
                                    "start": 23008,
                                    "end": 24223,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_55"
                                    }
                                },
                                {
                                    "locus_tag": "sprK",
                                    "start": 24219,
                                    "end": 24786,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_56"
                                    }
                                },
                                {
                                    "locus_tag": "sprT",
                                    "start": 34808,
                                    "end": 35573,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sprR3",
                                    "start": 40792,
                                    "end": 41575,
                                    "strand": -1,
                                    "function": "regulatory",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sprG",
                                    "start": 16647,
                                    "end": 17433,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_50"
                                    }
                                },
                                {
                                    "locus_tag": "sprJ",
                                    "start": 20419,
                                    "end": 21631,
                                    "strand": 1,
                                    "function": "transport",
                                    "linked": {
                                        "1": "ctg1_53"
                                    }
                                },
                                {
                                    "locus_tag": "sprD",
                                    "start": 13585,
                                    "end": 14866,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_47"
                                    }
                                },
                                {
                                    "locus_tag": "sprE",
                                    "start": 14862,
                                    "end": 16107,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_48"
                                    }
                                },
                                {
                                    "locus_tag": "sprU",
                                    "start": 35586,
                                    "end": 37179,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_66"
                                    }
                                },
                                {
                                    "locus_tag": "spr1",
                                    "start": 2468,
                                    "end": 3950,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sprP",
                                    "start": 30468,
                                    "end": 31233,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_62"
                                    }
                                },
                                {
                                    "locus_tag": "spr3",
                                    "start": 6138,
                                    "end": 7257,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_40"
                                    }
                                },
                                {
                                    "locus_tag": "sprZ",
                                    "start": 39763,
                                    "end": 40201,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sprX",
                                    "start": 37218,
                                    "end": 37902,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "spr2",
                                    "start": 4750,
                                    "end": 6217,
                                    "strand": -1,
                                    "function": "transport",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sprY",
                                    "start": 38024,
                                    "end": 39647,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sprS",
                                    "start": 33855,
                                    "end": 34812,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_65"
                                    }
                                },
                                {
                                    "locus_tag": "sprR1",
                                    "start": 4091,
                                    "end": 4439,
                                    "strand": -1,
                                    "function": "regulatory",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sprA",
                                    "start": 10483,
                                    "end": 11413,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_44"
                                    }
                                },
                                {
                                    "locus_tag": "sprQ",
                                    "start": 31281,
                                    "end": 32364,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_63"
                                    }
                                },
                                {
                                    "locus_tag": "sprM",
                                    "start": 27008,
                                    "end": 27992,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_59"
                                    }
                                },
                                {
                                    "locus_tag": "sprR",
                                    "start": 32458,
                                    "end": 33859,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_64"
                                    }
                                },
                                {
                                    "locus_tag": "sprI",
                                    "start": 18411,
                                    "end": 20400,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_52"
                                    }
                                },
                                {
                                    "locus_tag": "sprGT1",
                                    "start": 21688,
                                    "end": 22981,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_54"
                                    }
                                },
                                {
                                    "locus_tag": "sprL",
                                    "start": 25944,
                                    "end": 27012,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_58"
                                    }
                                },
                                {
                                    "locus_tag": "sprF",
                                    "start": 16103,
                                    "end": 16478,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_49"
                                    }
                                },
                                {
                                    "locus_tag": "sprR2",
                                    "start": 9693,
                                    "end": 10431,
                                    "strand": 1,
                                    "function": "regulatory",
                                    "linked": {
                                        "1": "ctg1_43"
                                    }
                                },
                                {
                                    "locus_tag": "sprN",
                                    "start": 28002,
                                    "end": 29106,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_60"
                                    }
                                },
                                {
                                    "locus_tag": "spr6",
                                    "start": 42115,
                                    "end": 44008,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sprC",
                                    "start": 13262,
                                    "end": 13589,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_46"
                                    }
                                }
                            ]
                        },
                        "BGC0000278.1: 25-5408": {
                            "start": 25,
                            "end": 5408,
                            "links": [
                                {
                                    "query": "ctg1_61",
                                    "subject": "urdQ",
                                    "query_loc": 61629,
                                    "subject_loc": 1720
                                },
                                {
                                    "query": "ctg1_62",
                                    "subject": "urdR",
                                    "query_loc": 62717,
                                    "subject_loc": 2785
                                },
                                {
                                    "query": "ctg1_64",
                                    "subject": "urdS",
                                    "query_loc": 64836,
                                    "subject_loc": 3900
                                },
                                {
                                    "query": "ctg1_65",
                                    "subject": "urdT",
                                    "query_loc": 66014,
                                    "subject_loc": 5004
                                },
                                {
                                    "query": "ctg1_60",
                                    "subject": "urdZ3",
                                    "query_loc": 60448,
                                    "subject_loc": 545
                                }
                            ],
                            "reverse": false,
                            "genes": [
                                {
                                    "locus_tag": "urdZ3",
                                    "start": 25,
                                    "end": 1066,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_60"
                                    }
                                },
                                {
                                    "locus_tag": "urdT",
                                    "start": 4601,
                                    "end": 5408,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_65"
                                    }
                                },
                                {
                                    "locus_tag": "urdQ",
                                    "start": 1068,
                                    "end": 2373,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_61"
                                    }
                                },
                                {
                                    "locus_tag": "urdS",
                                    "start": 3195,
                                    "end": 4605,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_64"
                                    }
                                },
                                {
                                    "locus_tag": "urdR",
                                    "start": 2413,
                                    "end": 3157,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_62"
                                    }
                                }
                            ]
                        },
                        "BGC0000268.1: 497-77076": {
                            "start": 497,
                            "end": 77076,
                            "links": [
                                {
                                    "query": "ctg1_46",
                                    "subject": "schP9",
                                    "query_loc": 45393,
                                    "subject_loc": 52768
                                },
                                {
                                    "query": "ctg1_47",
                                    "subject": "schP8",
                                    "query_loc": 46193,
                                    "subject_loc": 51950
                                },
                                {
                                    "query": "ctg1_61",
                                    "subject": "schS3",
                                    "query_loc": 61629,
                                    "subject_loc": 36522
                                },
                                {
                                    "query": "ctg1_59",
                                    "subject": "schS5",
                                    "query_loc": 59438,
                                    "subject_loc": 38658
                                },
                                {
                                    "query": "ctg1_50",
                                    "subject": "schP5",
                                    "query_loc": 48987,
                                    "subject_loc": 49334
                                },
                                {
                                    "query": "ctg1_45",
                                    "subject": "schP10",
                                    "query_loc": 44473,
                                    "subject_loc": 53731
                                },
                                {
                                    "query": "ctg1_56",
                                    "subject": "schS8",
                                    "query_loc": 56430,
                                    "subject_loc": 41728
                                },
                                {
                                    "query": "ctg1_64",
                                    "subject": "schS2",
                                    "query_loc": 64836,
                                    "subject_loc": 34059
                                },
                                {
                                    "query": "ctg1_49",
                                    "subject": "schP6",
                                    "query_loc": 48263,
                                    "subject_loc": 49902
                                },
                                {
                                    "query": "ctg1_54",
                                    "subject": "schS10",
                                    "query_loc": 54267,
                                    "subject_loc": 43943
                                },
                                {
                                    "query": "ctg1_48",
                                    "subject": "schP7",
                                    "query_loc": 47440,
                                    "subject_loc": 50709
                                },
                                {
                                    "query": "ctg1_57",
                                    "subject": "schS7",
                                    "query_loc": 57288,
                                    "subject_loc": 40868
                                },
                                {
                                    "query": "ctg1_65",
                                    "subject": "schS1",
                                    "query_loc": 66014,
                                    "subject_loc": 32822
                                },
                                {
                                    "query": "ctg1_55",
                                    "subject": "schS9",
                                    "query_loc": 55541,
                                    "subject_loc": 42671
                                },
                                {
                                    "query": "ctg1_53",
                                    "subject": "schA20",
                                    "query_loc": 52961,
                                    "subject_loc": 45234
                                },
                                {
                                    "query": "ctg1_41",
                                    "subject": "schA23",
                                    "query_loc": 40093,
                                    "subject_loc": 58000
                                },
                                {
                                    "query": "ctg1_51",
                                    "subject": "schP4",
                                    "query_loc": 49868,
                                    "subject_loc": 48438
                                },
                                {
                                    "query": "ctg1_52",
                                    "subject": "schP3",
                                    "query_loc": 51331,
                                    "subject_loc": 46880
                                },
                                {
                                    "query": "ctg1_42",
                                    "subject": "CAH10122.1",
                                    "query_loc": 41206,
                                    "subject_loc": 56894
                                },
                                {
                                    "query": "ctg1_58",
                                    "subject": "schS6",
                                    "query_loc": 58416,
                                    "subject_loc": 39682
                                },
                                {
                                    "query": "ctg1_40",
                                    "subject": "schA24",
                                    "query_loc": 38570,
                                    "subject_loc": 59438
                                },
                                {
                                    "query": "ctg1_43",
                                    "subject": "schA21",
                                    "query_loc": 42005,
                                    "subject_loc": 56099
                                },
                                {
                                    "query": "ctg1_66",
                                    "subject": "schP2",
                                    "query_loc": 66655,
                                    "subject_loc": 30818
                                },
                                {
                                    "query": "ctg1_60",
                                    "subject": "schS4",
                                    "query_loc": 60448,
                                    "subject_loc": 37654
                                },
                                {
                                    "query": "ctg1_44",
                                    "subject": "schP11",
                                    "query_loc": 43073,
                                    "subject_loc": 55142
                                }
                            ],
                            "reverse": true,
                            "genes": [
                                {
                                    "locus_tag": "schA7",
                                    "start": 10222,
                                    "end": 11704,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schP11",
                                    "start": 54704,
                                    "end": 55580,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_44"
                                    }
                                },
                                {
                                    "locus_tag": "schA5",
                                    "start": 7071,
                                    "end": 7965,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA10",
                                    "start": 13682,
                                    "end": 14561,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA9",
                                    "start": 13076,
                                    "end": 13670,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA31",
                                    "start": 69584,
                                    "end": 70373,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA17",
                                    "start": 23236,
                                    "end": 24619,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA15",
                                    "start": 20024,
                                    "end": 22100,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA19",
                                    "start": 26092,
                                    "end": 27883,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA33",
                                    "start": 72197,
                                    "end": 73847,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schS6",
                                    "start": 39148,
                                    "end": 40216,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_58"
                                    }
                                },
                                {
                                    "locus_tag": "schA27",
                                    "start": 64201,
                                    "end": 64954,
                                    "strand": -1,
                                    "function": "regulatory",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA6",
                                    "start": 8040,
                                    "end": 9921,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schS9",
                                    "start": 42085,
                                    "end": 43258,
                                    "strand": -1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_55"
                                    }
                                },
                                {
                                    "locus_tag": "schA18",
                                    "start": 25014,
                                    "end": 26022,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schP4",
                                    "start": 47969,
                                    "end": 48908,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_51"
                                    }
                                },
                                {
                                    "locus_tag": "schA4",
                                    "start": 6217,
                                    "end": 6883,
                                    "strand": -1,
                                    "function": "regulatory",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schP3",
                                    "start": 45968,
                                    "end": 47792,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_52"
                                    }
                                },
                                {
                                    "locus_tag": "schP2",
                                    "start": 30032,
                                    "end": 31604,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_66"
                                    }
                                },
                                {
                                    "locus_tag": "schA14",
                                    "start": 18844,
                                    "end": 20005,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA25",
                                    "start": 60241,
                                    "end": 61093,
                                    "strand": 1,
                                    "function": "regulatory",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA24",
                                    "start": 58879,
                                    "end": 59998,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_40"
                                    }
                                },
                                {
                                    "locus_tag": "schA3",
                                    "start": 4586,
                                    "end": 5666,
                                    "strand": -1,
                                    "function": "transport",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA21",
                                    "start": 55721,
                                    "end": 56477,
                                    "strand": -1,
                                    "function": "regulatory",
                                    "linked": {
                                        "1": "ctg1_43"
                                    }
                                },
                                {
                                    "locus_tag": "schP10",
                                    "start": 52989,
                                    "end": 54474,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_45"
                                    }
                                },
                                {
                                    "locus_tag": "schA1",
                                    "start": 497,
                                    "end": 1481,
                                    "strand": 1,
                                    "function": "transport",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "CAH10132.1",
                                    "start": 70496,
                                    "end": 72167,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA28",
                                    "start": 65980,
                                    "end": 66589,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schS10",
                                    "start": 43297,
                                    "end": 44590,
                                    "strand": -1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_54"
                                    }
                                },
                                {
                                    "locus_tag": "schS5",
                                    "start": 38165,
                                    "end": 39152,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_59"
                                    }
                                },
                                {
                                    "locus_tag": "schP1",
                                    "start": 28018,
                                    "end": 29872,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "CAH10103.1",
                                    "start": 16239,
                                    "end": 17175,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schP5",
                                    "start": 48934,
                                    "end": 49735,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_50"
                                    }
                                },
                                {
                                    "locus_tag": "schP6",
                                    "start": 49767,
                                    "end": 50037,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_49"
                                    }
                                },
                                {
                                    "locus_tag": "schA26",
                                    "start": 62332,
                                    "end": 63931,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schS4",
                                    "start": 37174,
                                    "end": 38134,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_60"
                                    }
                                },
                                {
                                    "locus_tag": "schP8",
                                    "start": 51319,
                                    "end": 52582,
                                    "strand": -1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_47"
                                    }
                                },
                                {
                                    "locus_tag": "CAH10099.1",
                                    "start": 11715,
                                    "end": 12678,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schS2",
                                    "start": 33360,
                                    "end": 34758,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_64"
                                    }
                                },
                                {
                                    "locus_tag": "schA20",
                                    "start": 44622,
                                    "end": 45846,
                                    "strand": -1,
                                    "function": "transport",
                                    "linked": {
                                        "1": "ctg1_53"
                                    }
                                },
                                {
                                    "locus_tag": "schA2",
                                    "start": 1514,
                                    "end": 2402,
                                    "strand": 1,
                                    "function": "transport",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA13",
                                    "start": 17171,
                                    "end": 18848,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "CAH10122.1",
                                    "start": 56594,
                                    "end": 57194,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_42"
                                    }
                                },
                                {
                                    "locus_tag": "schS1",
                                    "start": 32311,
                                    "end": 33334,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_65"
                                    }
                                },
                                {
                                    "locus_tag": "schA11",
                                    "start": 14576,
                                    "end": 15980,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schP7",
                                    "start": 50096,
                                    "end": 51323,
                                    "strand": -1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_48"
                                    }
                                },
                                {
                                    "locus_tag": "schP9",
                                    "start": 52605,
                                    "end": 52932,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_46"
                                    }
                                },
                                {
                                    "locus_tag": "schA30",
                                    "start": 67520,
                                    "end": 69065,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA23",
                                    "start": 57208,
                                    "end": 58792,
                                    "strand": 1,
                                    "function": "transport",
                                    "linked": {
                                        "1": "ctg1_41"
                                    }
                                },
                                {
                                    "locus_tag": "CAH10129.1",
                                    "start": 66592,
                                    "end": 67477,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schS8",
                                    "start": 41433,
                                    "end": 42024,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_56"
                                    }
                                },
                                {
                                    "locus_tag": "schA16",
                                    "start": 22246,
                                    "end": 23140,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schS3",
                                    "start": 35870,
                                    "end": 37175,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_61"
                                    }
                                },
                                {
                                    "locus_tag": "schA34",
                                    "start": 74160,
                                    "end": 77076,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schS7",
                                    "start": 40300,
                                    "end": 41437,
                                    "strand": -1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_57"
                                    }
                                }
                            ]
                        },
                        "BGC0000716.1: 435-27161": {
                            "start": 435,
                            "end": 27161,
                            "links": [
                                {
                                    "query": "ctg1_59",
                                    "subject": "spcJ",
                                    "query_loc": 59438,
                                    "subject_loc": 22186
                                }
                            ],
                            "reverse": true,
                            "genes": [
                                {
                                    "locus_tag": "spcH",
                                    "start": 19457,
                                    "end": 20498,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "spcR",
                                    "start": 6304,
                                    "end": 7297,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "AAD45557.1",
                                    "start": 25121,
                                    "end": 27161,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "spcA",
                                    "start": 9899,
                                    "end": 10700,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "AAD45542.1",
                                    "start": 4948,
                                    "end": 5263,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "AAB66653.1",
                                    "start": 5115,
                                    "end": 5388,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "spcI",
                                    "start": 20690,
                                    "end": 21629,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "spcD",
                                    "start": 13371,
                                    "end": 14160,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "spcB",
                                    "start": 10814,
                                    "end": 11993,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "spcF",
                                    "start": 17723,
                                    "end": 18536,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "spcG",
                                    "start": 18564,
                                    "end": 19383,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "insA",
                                    "start": 435,
                                    "end": 1608,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "spcK",
                                    "start": 22858,
                                    "end": 23770,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "spcC",
                                    "start": 12019,
                                    "end": 13345,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "spcX",
                                    "start": 14257,
                                    "end": 15451,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "spcY",
                                    "start": 16812,
                                    "end": 17721,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "spcE",
                                    "start": 15507,
                                    "end": 16791,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "spcT",
                                    "start": 8527,
                                    "end": 9829,
                                    "strand": -1,
                                    "function": "transport",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "spcJ",
                                    "start": 21693,
                                    "end": 22680,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_59"
                                    }
                                },
                                {
                                    "locus_tag": "spcN",
                                    "start": 7525,
                                    "end": 8518,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "aph_6_",
                                    "start": 3617,
                                    "end": 4541,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "AAD45540.1",
                                    "start": 2695,
                                    "end": 3466,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                }
                            ]
                        }
                    }
                },
                "RegionToRegion_RiQ": {
                    "reference_clusters": {
                        "BGC0000231.1: 189-5010": {
                            "start": 189,
                            "end": 5010,
                            "links": [
                                {
                                    "query": "ctg1_50",
                                    "subject": "CAA54861.1",
                                    "query_loc": 48987,
                                    "subject_loc": 3593
                                },
                                {
                                    "query": "ctg1_49",
                                    "subject": "CAA54860.1",
                                    "query_loc": 48263,
                                    "subject_loc": 2943
                                },
                                {
                                    "query": "ctg1_51",
                                    "subject": "CAA54862.1",
                                    "query_loc": 49868,
                                    "subject_loc": 4530
                                },
                                {
                                    "query": "ctg1_47",
                                    "subject": "CAA54858.1",
                                    "query_loc": 46193,
                                    "subject_loc": 823
                                },
                                {
                                    "query": "ctg1_48",
                                    "subject": "CAA54859.1",
                                    "query_loc": 47440,
                                    "subject_loc": 2073
                                }
                            ],
                            "reverse": false,
                            "genes": [
                                {
                                    "locus_tag": "CAA54859.1",
                                    "start": 1454,
                                    "end": 2693,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_48"
                                    }
                                },
                                {
                                    "locus_tag": "CAA54862.1",
                                    "start": 4050,
                                    "end": 5010,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_51"
                                    }
                                },
                                {
                                    "locus_tag": "CAA54858.1",
                                    "start": 189,
                                    "end": 1458,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_47"
                                    }
                                },
                                {
                                    "locus_tag": "CAA54861.1",
                                    "start": 3200,
                                    "end": 3986,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_50"
                                    }
                                },
                                {
                                    "locus_tag": "CAA54860.1",
                                    "start": 2808,
                                    "end": 3078,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_49"
                                    }
                                }
                            ]
                        },
                        "BGC0000229.1: 0-41909": {
                            "start": 0,
                            "end": 41909,
                            "links": [
                                {
                                    "query": "ctg1_49",
                                    "subject": "AGO50612.1",
                                    "query_loc": 48263,
                                    "subject_loc": 13928
                                },
                                {
                                    "query": "ctg1_56",
                                    "subject": "AGO50619.1",
                                    "query_loc": 56430,
                                    "subject_loc": 22045
                                },
                                {
                                    "query": "ctg1_59",
                                    "subject": "AGO50622.1",
                                    "query_loc": 59438,
                                    "subject_loc": 25010
                                },
                                {
                                    "query": "ctg1_47",
                                    "subject": "AGO50610.1",
                                    "query_loc": 46193,
                                    "subject_loc": 11859
                                },
                                {
                                    "query": "ctg1_61",
                                    "subject": "AGO50624.1",
                                    "query_loc": 61629,
                                    "subject_loc": 27201
                                },
                                {
                                    "query": "ctg1_54",
                                    "subject": "AGO50617.1",
                                    "query_loc": 54267,
                                    "subject_loc": 19839
                                },
                                {
                                    "query": "ctg1_40",
                                    "subject": "AGO50604.1",
                                    "query_loc": 38570,
                                    "subject_loc": 4280
                                },
                                {
                                    "query": "ctg1_48",
                                    "subject": "AGO50611.1",
                                    "query_loc": 47440,
                                    "subject_loc": 13106
                                },
                                {
                                    "query": "ctg1_66",
                                    "subject": "AGO50629.1",
                                    "query_loc": 66655,
                                    "subject_loc": 32856
                                },
                                {
                                    "query": "ctg1_58",
                                    "subject": "AGO50621.1",
                                    "query_loc": 58416,
                                    "subject_loc": 23988
                                },
                                {
                                    "query": "ctg1_45",
                                    "subject": "AGO50609.1",
                                    "query_loc": 44473,
                                    "subject_loc": 10139
                                },
                                {
                                    "query": "ctg1_43",
                                    "subject": "AGO50607.1",
                                    "query_loc": 42005,
                                    "subject_loc": 7661
                                },
                                {
                                    "query": "ctg1_37",
                                    "subject": "AGO50602.1",
                                    "query_loc": 35870,
                                    "subject_loc": 1575
                                },
                                {
                                    "query": "ctg1_42",
                                    "subject": "AGO50606.1",
                                    "query_loc": 41206,
                                    "subject_loc": 6911
                                },
                                {
                                    "query": "ctg1_64",
                                    "subject": "AGO50627.1",
                                    "query_loc": 64836,
                                    "subject_loc": 30410
                                },
                                {
                                    "query": "ctg1_57",
                                    "subject": "AGO50620.1",
                                    "query_loc": 57288,
                                    "subject_loc": 22860
                                },
                                {
                                    "query": "ctg1_50",
                                    "subject": "AGO50613.1",
                                    "query_loc": 48987,
                                    "subject_loc": 14584
                                },
                                {
                                    "query": "ctg1_39",
                                    "subject": "AGO50603.1",
                                    "query_loc": 37468,
                                    "subject_loc": 3143
                                },
                                {
                                    "query": "ctg1_62",
                                    "subject": "AGO50625.1",
                                    "query_loc": 62717,
                                    "subject_loc": 28288
                                },
                                {
                                    "query": "ctg1_51",
                                    "subject": "AGO50614.1",
                                    "query_loc": 49868,
                                    "subject_loc": 15465
                                },
                                {
                                    "query": "ctg1_41",
                                    "subject": "AGO50605.1",
                                    "query_loc": 40093,
                                    "subject_loc": 5822
                                },
                                {
                                    "query": "ctg1_55",
                                    "subject": "AGO50618.1",
                                    "query_loc": 55541,
                                    "subject_loc": 21122
                                },
                                {
                                    "query": "ctg1_52",
                                    "subject": "AGO50615.1",
                                    "query_loc": 51331,
                                    "subject_loc": 16928
                                },
                                {
                                    "query": "ctg1_65",
                                    "subject": "AGO50628.1",
                                    "query_loc": 66014,
                                    "subject_loc": 31588
                                },
                                {
                                    "query": "ctg1_60",
                                    "subject": "AGO50623.1",
                                    "query_loc": 60448,
                                    "subject_loc": 26041
                                },
                                {
                                    "query": "ctg1_53",
                                    "subject": "AGO50616.1",
                                    "query_loc": 52961,
                                    "subject_loc": 18544
                                },
                                {
                                    "query": "ctg1_35",
                                    "subject": "AGO50601.1",
                                    "query_loc": 34541,
                                    "subject_loc": 300
                                },
                                {
                                    "query": "ctg1_63",
                                    "subject": "AGO50626.1",
                                    "query_loc": 63603,
                                    "subject_loc": 29176
                                },
                                {
                                    "query": "ctg1_44",
                                    "subject": "AGO50608.1",
                                    "query_loc": 43073,
                                    "subject_loc": 8648
                                }
                            ],
                            "reverse": false,
                            "genes": [
                                {
                                    "locus_tag": "AGO50612.1",
                                    "start": 13793,
                                    "end": 14063,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_49"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50601.1",
                                    "start": 0,
                                    "end": 600,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_35"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50625.1",
                                    "start": 27906,
                                    "end": 28671,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_62"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50607.1",
                                    "start": 7241,
                                    "end": 8081,
                                    "strand": 1,
                                    "function": "regulatory",
                                    "linked": {
                                        "1": "ctg1_43"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50629.1",
                                    "start": 32088,
                                    "end": 33624,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_66"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50626.1",
                                    "start": 28699,
                                    "end": 29653,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_63"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50610.1",
                                    "start": 11219,
                                    "end": 12500,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_47"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50622.1",
                                    "start": 24518,
                                    "end": 25502,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_59"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50609.1",
                                    "start": 9395,
                                    "end": 10883,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_45"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50615.1",
                                    "start": 15934,
                                    "end": 17923,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_52"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50602.1",
                                    "start": 762,
                                    "end": 2388,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_37"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50633.1",
                                    "start": 39587,
                                    "end": 40613,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "AGO50611.1",
                                    "start": 12496,
                                    "end": 13717,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_48"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50630.1",
                                    "start": 34148,
                                    "end": 35738,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "AGO50605.1",
                                    "start": 5063,
                                    "end": 6581,
                                    "strand": -1,
                                    "function": "transport",
                                    "linked": {
                                        "1": "ctg1_41"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50606.1",
                                    "start": 6611,
                                    "end": 7211,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_42"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50621.1",
                                    "start": 23454,
                                    "end": 24522,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_58"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50604.1",
                                    "start": 3721,
                                    "end": 4840,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_40"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50608.1",
                                    "start": 8227,
                                    "end": 9070,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_44"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50618.1",
                                    "start": 20515,
                                    "end": 21730,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_55"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50627.1",
                                    "start": 29708,
                                    "end": 31112,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_64"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50613.1",
                                    "start": 14191,
                                    "end": 14977,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_50"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50631.1",
                                    "start": 36424,
                                    "end": 37135,
                                    "strand": -1,
                                    "function": "regulatory",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "AGO50634.1",
                                    "start": 40952,
                                    "end": 41909,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "AGO50616.1",
                                    "start": 17935,
                                    "end": 19153,
                                    "strand": 1,
                                    "function": "transport",
                                    "linked": {
                                        "1": "ctg1_53"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50620.1",
                                    "start": 22295,
                                    "end": 23426,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_57"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50619.1",
                                    "start": 21798,
                                    "end": 22293,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_56"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50614.1",
                                    "start": 14997,
                                    "end": 15933,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_51"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50628.1",
                                    "start": 31108,
                                    "end": 32068,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_65"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50624.1",
                                    "start": 26549,
                                    "end": 27854,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_61"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50617.1",
                                    "start": 19193,
                                    "end": 20486,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_54"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50632.1",
                                    "start": 37801,
                                    "end": 39598,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "AGO50603.1",
                                    "start": 2681,
                                    "end": 3605,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_39"
                                    }
                                },
                                {
                                    "locus_tag": "AGO50623.1",
                                    "start": 25536,
                                    "end": 26547,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_60"
                                    }
                                }
                            ]
                        },
                        "BGC0001723.1: 128-10733": {
                            "start": 128,
                            "end": 10733,
                            "links": [
                                {
                                    "query": "ctg1_50",
                                    "subject": "ovmT",
                                    "query_loc": 48987,
                                    "subject_loc": 5412
                                },
                                {
                                    "query": "ctg1_47",
                                    "subject": "ovmP",
                                    "query_loc": 46193,
                                    "subject_loc": 2689
                                },
                                {
                                    "query": "ctg1_46",
                                    "subject": "ovmC",
                                    "query_loc": 45393,
                                    "subject_loc": 1890
                                },
                                {
                                    "query": "ctg1_51",
                                    "subject": "ovmA",
                                    "query_loc": 49868,
                                    "subject_loc": 6305
                                },
                                {
                                    "query": "ctg1_49",
                                    "subject": "ovmS",
                                    "query_loc": 48263,
                                    "subject_loc": 4761
                                },
                                {
                                    "query": "ctg1_48",
                                    "subject": "ovmK",
                                    "query_loc": 47440,
                                    "subject_loc": 3933
                                },
                                {
                                    "query": "ctg1_45",
                                    "subject": "ovmOI",
                                    "query_loc": 44473,
                                    "subject_loc": 872
                                },
                                {
                                    "query": "ctg1_52",
                                    "subject": "ovmOII",
                                    "query_loc": 51331,
                                    "subject_loc": 7504
                                }
                            ],
                            "reverse": false,
                            "genes": [
                                {
                                    "locus_tag": "ovmA",
                                    "start": 5831,
                                    "end": 6779,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_51"
                                    }
                                },
                                {
                                    "locus_tag": "ovmP",
                                    "start": 2053,
                                    "end": 3325,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_47"
                                    }
                                },
                                {
                                    "locus_tag": "ovmK",
                                    "start": 3321,
                                    "end": 4545,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_48"
                                    }
                                },
                                {
                                    "locus_tag": "ovmOII",
                                    "start": 6768,
                                    "end": 8241,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_52"
                                    }
                                },
                                {
                                    "locus_tag": "ovmF",
                                    "start": 9854,
                                    "end": 10733,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "ovmOIII",
                                    "start": 8260,
                                    "end": 9781,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "ovmOI",
                                    "start": 128,
                                    "end": 1616,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_45"
                                    }
                                },
                                {
                                    "locus_tag": "ovmS",
                                    "start": 4625,
                                    "end": 4898,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_49"
                                    }
                                },
                                {
                                    "locus_tag": "ovmC",
                                    "start": 1724,
                                    "end": 2057,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_46"
                                    }
                                },
                                {
                                    "locus_tag": "ovmT",
                                    "start": 5021,
                                    "end": 5804,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_50"
                                    }
                                }
                            ]
                        },
                        "BGC0000234.1: 152-6978": {
                            "start": 152,
                            "end": 6978,
                            "links": [
                                {
                                    "query": "ctg1_50",
                                    "subject": "AAB36565.1",
                                    "query_loc": 48987,
                                    "subject_loc": 5607
                                },
                                {
                                    "query": "ctg1_46",
                                    "subject": "jadI",
                                    "query_loc": 45393,
                                    "subject_loc": 2184
                                },
                                {
                                    "query": "ctg1_47",
                                    "subject": "jadA",
                                    "query_loc": 46193,
                                    "subject_loc": 2979
                                },
                                {
                                    "query": "ctg1_51",
                                    "subject": "AAB36566.1",
                                    "query_loc": 49868,
                                    "subject_loc": 6511
                                },
                                {
                                    "query": "ctg1_49",
                                    "subject": "acp",
                                    "query_loc": 48263,
                                    "subject_loc": 5002
                                },
                                {
                                    "query": "ctg1_48",
                                    "subject": "AAB36563.1",
                                    "query_loc": 47440,
                                    "subject_loc": 4217
                                }
                            ],
                            "reverse": false,
                            "genes": [
                                {
                                    "locus_tag": "acp",
                                    "start": 4867,
                                    "end": 5137,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_49"
                                    }
                                },
                                {
                                    "locus_tag": "jadA",
                                    "start": 2345,
                                    "end": 3614,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_47"
                                    }
                                },
                                {
                                    "locus_tag": "AAB36565.1",
                                    "start": 5210,
                                    "end": 6005,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_50"
                                    }
                                },
                                {
                                    "locus_tag": "AAB36563.1",
                                    "start": 3610,
                                    "end": 4825,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_48"
                                    }
                                },
                                {
                                    "locus_tag": "jadI",
                                    "start": 2019,
                                    "end": 2349,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_46"
                                    }
                                },
                                {
                                    "locus_tag": "jadJ",
                                    "start": 152,
                                    "end": 1907,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "AAB36566.1",
                                    "start": 6045,
                                    "end": 6978,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_51"
                                    }
                                }
                            ]
                        },
                        "BGC0000248.1: 1435-5236": {
                            "start": 1435,
                            "end": 5236,
                            "links": [
                                {
                                    "query": "ctg1_47",
                                    "subject": "ncnA",
                                    "query_loc": 46193,
                                    "subject_loc": 2068
                                },
                                {
                                    "query": "ctg1_48",
                                    "subject": "ncnB",
                                    "query_loc": 47440,
                                    "subject_loc": 3342
                                },
                                {
                                    "query": "ctg1_49",
                                    "subject": "ncnC",
                                    "query_loc": 48263,
                                    "subject_loc": 4161
                                },
                                {
                                    "query": "ctg1_51",
                                    "subject": "ncnD",
                                    "query_loc": 49868,
                                    "subject_loc": 4762
                                }
                            ],
                            "reverse": false,
                            "genes": [
                                {
                                    "locus_tag": "ncnD",
                                    "start": 4288,
                                    "end": 5236,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_51"
                                    }
                                },
                                {
                                    "locus_tag": "ncnB",
                                    "start": 2697,
                                    "end": 3987,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_48"
                                    }
                                },
                                {
                                    "locus_tag": "ncnA",
                                    "start": 1435,
                                    "end": 2701,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_47"
                                    }
                                },
                                {
                                    "locus_tag": "ncnC",
                                    "start": 4031,
                                    "end": 4292,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_49"
                                    }
                                }
                            ]
                        },
                        "BGC0001384.1: 2468-44008": {
                            "start": 2468,
                            "end": 44008,
                            "links": [
                                {
                                    "query": "ctg1_46",
                                    "subject": "sprC",
                                    "query_loc": 45393,
                                    "subject_loc": 13425
                                },
                                {
                                    "query": "ctg1_66",
                                    "subject": "sprU",
                                    "query_loc": 66655,
                                    "subject_loc": 36382
                                },
                                {
                                    "query": "ctg1_50",
                                    "subject": "sprG",
                                    "query_loc": 48987,
                                    "subject_loc": 17040
                                },
                                {
                                    "query": "ctg1_47",
                                    "subject": "sprD",
                                    "query_loc": 46193,
                                    "subject_loc": 14225
                                },
                                {
                                    "query": "ctg1_59",
                                    "subject": "sprM",
                                    "query_loc": 59438,
                                    "subject_loc": 27500
                                },
                                {
                                    "query": "ctg1_61",
                                    "subject": "sprO",
                                    "query_loc": 61629,
                                    "subject_loc": 29757
                                },
                                {
                                    "query": "ctg1_58",
                                    "subject": "sprL",
                                    "query_loc": 58416,
                                    "subject_loc": 26478
                                },
                                {
                                    "query": "ctg1_45",
                                    "subject": "sprB",
                                    "query_loc": 44473,
                                    "subject_loc": 12505
                                },
                                {
                                    "query": "ctg1_48",
                                    "subject": "sprE",
                                    "query_loc": 47440,
                                    "subject_loc": 15484
                                },
                                {
                                    "query": "ctg1_51",
                                    "subject": "sprH",
                                    "query_loc": 49868,
                                    "subject_loc": 17941
                                },
                                {
                                    "query": "ctg1_57",
                                    "subject": "sprGT3",
                                    "query_loc": 57288,
                                    "subject_loc": 25353
                                },
                                {
                                    "query": "ctg1_56",
                                    "subject": "sprK",
                                    "query_loc": 56430,
                                    "subject_loc": 24502
                                },
                                {
                                    "query": "ctg1_62",
                                    "subject": "sprP",
                                    "query_loc": 62717,
                                    "subject_loc": 30850
                                },
                                {
                                    "query": "ctg1_64",
                                    "subject": "sprR",
                                    "query_loc": 64836,
                                    "subject_loc": 33158
                                },
                                {
                                    "query": "ctg1_52",
                                    "subject": "sprI",
                                    "query_loc": 51331,
                                    "subject_loc": 19405
                                },
                                {
                                    "query": "ctg1_65",
                                    "subject": "sprS",
                                    "query_loc": 66014,
                                    "subject_loc": 34333
                                },
                                {
                                    "query": "ctg1_54",
                                    "subject": "sprGT1",
                                    "query_loc": 54267,
                                    "subject_loc": 22334
                                },
                                {
                                    "query": "ctg1_40",
                                    "subject": "spr3",
                                    "query_loc": 38570,
                                    "subject_loc": 6697
                                },
                                {
                                    "query": "ctg1_42",
                                    "subject": "spr5",
                                    "query_loc": 41206,
                                    "subject_loc": 9275
                                },
                                {
                                    "query": "ctg1_49",
                                    "subject": "sprF",
                                    "query_loc": 48263,
                                    "subject_loc": 16290
                                },
                                {
                                    "query": "ctg1_55",
                                    "subject": "sprGT2",
                                    "query_loc": 55541,
                                    "subject_loc": 23615
                                },
                                {
                                    "query": "ctg1_43",
                                    "subject": "sprR2",
                                    "query_loc": 42005,
                                    "subject_loc": 10062
                                },
                                {
                                    "query": "ctg1_53",
                                    "subject": "sprJ",
                                    "query_loc": 52961,
                                    "subject_loc": 21025
                                },
                                {
                                    "query": "ctg1_41",
                                    "subject": "spr4",
                                    "query_loc": 40093,
                                    "subject_loc": 8154
                                },
                                {
                                    "query": "ctg1_63",
                                    "subject": "sprQ",
                                    "query_loc": 63603,
                                    "subject_loc": 31822
                                },
                                {
                                    "query": "ctg1_44",
                                    "subject": "sprA",
                                    "query_loc": 43073,
                                    "subject_loc": 10948
                                },
                                {
                                    "query": "ctg1_60",
                                    "subject": "sprN",
                                    "query_loc": 60448,
                                    "subject_loc": 28554
                                }
                            ],
                            "reverse": false,
                            "genes": [
                                {
                                    "locus_tag": "spr5",
                                    "start": 8975,
                                    "end": 9575,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_42"
                                    }
                                },
                                {
                                    "locus_tag": "sprH",
                                    "start": 17473,
                                    "end": 18409,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_51"
                                    }
                                },
                                {
                                    "locus_tag": "sprB",
                                    "start": 11761,
                                    "end": 13249,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_45"
                                    }
                                },
                                {
                                    "locus_tag": "sprO",
                                    "start": 29102,
                                    "end": 30413,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_61"
                                    }
                                },
                                {
                                    "locus_tag": "sprGT3",
                                    "start": 24788,
                                    "end": 25919,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_57"
                                    }
                                },
                                {
                                    "locus_tag": "spr4",
                                    "start": 7364,
                                    "end": 8945,
                                    "strand": -1,
                                    "function": "transport",
                                    "linked": {
                                        "1": "ctg1_41"
                                    }
                                },
                                {
                                    "locus_tag": "sprGT2",
                                    "start": 23008,
                                    "end": 24223,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_55"
                                    }
                                },
                                {
                                    "locus_tag": "sprK",
                                    "start": 24219,
                                    "end": 24786,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_56"
                                    }
                                },
                                {
                                    "locus_tag": "sprT",
                                    "start": 34808,
                                    "end": 35573,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sprR3",
                                    "start": 40792,
                                    "end": 41575,
                                    "strand": -1,
                                    "function": "regulatory",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sprG",
                                    "start": 16647,
                                    "end": 17433,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_50"
                                    }
                                },
                                {
                                    "locus_tag": "sprJ",
                                    "start": 20419,
                                    "end": 21631,
                                    "strand": 1,
                                    "function": "transport",
                                    "linked": {
                                        "1": "ctg1_53"
                                    }
                                },
                                {
                                    "locus_tag": "sprD",
                                    "start": 13585,
                                    "end": 14866,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_47"
                                    }
                                },
                                {
                                    "locus_tag": "sprE",
                                    "start": 14862,
                                    "end": 16107,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_48"
                                    }
                                },
                                {
                                    "locus_tag": "sprU",
                                    "start": 35586,
                                    "end": 37179,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_66"
                                    }
                                },
                                {
                                    "locus_tag": "spr1",
                                    "start": 2468,
                                    "end": 3950,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sprP",
                                    "start": 30468,
                                    "end": 31233,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_62"
                                    }
                                },
                                {
                                    "locus_tag": "spr3",
                                    "start": 6138,
                                    "end": 7257,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_40"
                                    }
                                },
                                {
                                    "locus_tag": "sprZ",
                                    "start": 39763,
                                    "end": 40201,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sprX",
                                    "start": 37218,
                                    "end": 37902,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "spr2",
                                    "start": 4750,
                                    "end": 6217,
                                    "strand": -1,
                                    "function": "transport",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sprY",
                                    "start": 38024,
                                    "end": 39647,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sprS",
                                    "start": 33855,
                                    "end": 34812,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_65"
                                    }
                                },
                                {
                                    "locus_tag": "sprR1",
                                    "start": 4091,
                                    "end": 4439,
                                    "strand": -1,
                                    "function": "regulatory",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sprA",
                                    "start": 10483,
                                    "end": 11413,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_44"
                                    }
                                },
                                {
                                    "locus_tag": "sprQ",
                                    "start": 31281,
                                    "end": 32364,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_63"
                                    }
                                },
                                {
                                    "locus_tag": "sprM",
                                    "start": 27008,
                                    "end": 27992,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_59"
                                    }
                                },
                                {
                                    "locus_tag": "sprR",
                                    "start": 32458,
                                    "end": 33859,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_64"
                                    }
                                },
                                {
                                    "locus_tag": "sprI",
                                    "start": 18411,
                                    "end": 20400,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_52"
                                    }
                                },
                                {
                                    "locus_tag": "sprGT1",
                                    "start": 21688,
                                    "end": 22981,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_54"
                                    }
                                },
                                {
                                    "locus_tag": "sprL",
                                    "start": 25944,
                                    "end": 27012,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_58"
                                    }
                                },
                                {
                                    "locus_tag": "sprF",
                                    "start": 16103,
                                    "end": 16478,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_49"
                                    }
                                },
                                {
                                    "locus_tag": "sprR2",
                                    "start": 9693,
                                    "end": 10431,
                                    "strand": 1,
                                    "function": "regulatory",
                                    "linked": {
                                        "1": "ctg1_43"
                                    }
                                },
                                {
                                    "locus_tag": "sprN",
                                    "start": 28002,
                                    "end": 29106,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_60"
                                    }
                                },
                                {
                                    "locus_tag": "spr6",
                                    "start": 42115,
                                    "end": 44008,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sprC",
                                    "start": 13262,
                                    "end": 13589,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_46"
                                    }
                                }
                            ]
                        },
                        "BGC0001769.1: 0-44740": {
                            "start": 0,
                            "end": 44740,
                            "links": [
                                {
                                    "query": "ctg1_59",
                                    "subject": "sqnS3",
                                    "query_loc": 59438,
                                    "subject_loc": 24090
                                },
                                {
                                    "query": "ctg1_61",
                                    "subject": "sqnS5",
                                    "query_loc": 61629,
                                    "subject_loc": 26281
                                },
                                {
                                    "query": "ctg1_56",
                                    "subject": "sqnS1",
                                    "query_loc": 56430,
                                    "subject_loc": 21128
                                },
                                {
                                    "query": "ctg1_50",
                                    "subject": "sqnK",
                                    "query_loc": 48987,
                                    "subject_loc": 13617
                                },
                                {
                                    "query": "ctg1_66",
                                    "subject": "sqnP",
                                    "query_loc": 66655,
                                    "subject_loc": 32773
                                },
                                {
                                    "query": "ctg1_47",
                                    "subject": "sqnH",
                                    "query_loc": 46193,
                                    "subject_loc": 10670
                                },
                                {
                                    "query": "ctg1_46",
                                    "subject": "sqnBB",
                                    "query_loc": 45393,
                                    "subject_loc": 9856
                                },
                                {
                                    "query": "ctg1_58",
                                    "subject": "sqnS2",
                                    "query_loc": 58416,
                                    "subject_loc": 23068
                                },
                                {
                                    "query": "ctg1_45",
                                    "subject": "sqnF",
                                    "query_loc": 44473,
                                    "subject_loc": 8936
                                },
                                {
                                    "query": "ctg1_54",
                                    "subject": "sqnG1",
                                    "query_loc": 54267,
                                    "subject_loc": 18926
                                },
                                {
                                    "query": "ctg1_51",
                                    "subject": "sqnL",
                                    "query_loc": 49868,
                                    "subject_loc": 14519
                                },
                                {
                                    "query": "ctg1_48",
                                    "subject": "sqnI",
                                    "query_loc": 47440,
                                    "subject_loc": 11906
                                },
                                {
                                    "query": "ctg1_57",
                                    "subject": "sqnG3",
                                    "query_loc": 57288,
                                    "subject_loc": 21943
                                },
                                {
                                    "query": "ctg1_64",
                                    "subject": "sqnS7",
                                    "query_loc": 64836,
                                    "subject_loc": 29548
                                },
                                {
                                    "query": "ctg1_49",
                                    "subject": "sqnJ",
                                    "query_loc": 48263,
                                    "subject_loc": 12839
                                },
                                {
                                    "query": "ctg1_42",
                                    "subject": "sqnC",
                                    "query_loc": 41206,
                                    "subject_loc": 5736
                                },
                                {
                                    "query": "ctg1_43",
                                    "subject": "sqnD",
                                    "query_loc": 42005,
                                    "subject_loc": 6524
                                },
                                {
                                    "query": "ctg1_65",
                                    "subject": "sqnS8",
                                    "query_loc": 66014,
                                    "subject_loc": 30723
                                },
                                {
                                    "query": "ctg1_52",
                                    "subject": "sqnM",
                                    "query_loc": 51331,
                                    "subject_loc": 15988
                                },
                                {
                                    "query": "ctg1_55",
                                    "subject": "sqnG2",
                                    "query_loc": 55541,
                                    "subject_loc": 20205
                                },
                                {
                                    "query": "ctg1_41",
                                    "subject": "sqnB",
                                    "query_loc": 40093,
                                    "subject_loc": 4615
                                },
                                {
                                    "query": "ctg1_53",
                                    "subject": "sqnN",
                                    "query_loc": 52961,
                                    "subject_loc": 17614
                                },
                                {
                                    "query": "ctg1_62",
                                    "subject": "sqnS6",
                                    "query_loc": 62717,
                                    "subject_loc": 27361
                                },
                                {
                                    "query": "ctg1_60",
                                    "subject": "sqnS4",
                                    "query_loc": 60448,
                                    "subject_loc": 25156
                                },
                                {
                                    "query": "ctg1_63",
                                    "subject": "sqnO",
                                    "query_loc": 63603,
                                    "subject_loc": 28295
                                },
                                {
                                    "query": "ctg1_44",
                                    "subject": "sqnE",
                                    "query_loc": 43073,
                                    "subject_loc": 7448
                                }
                            ],
                            "reverse": false,
                            "genes": [
                                {
                                    "locus_tag": "sqnW",
                                    "start": 41990,
                                    "end": 42845,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnA",
                                    "start": 2628,
                                    "end": 3768,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnB",
                                    "start": 3825,
                                    "end": 5406,
                                    "strand": -1,
                                    "function": "transport",
                                    "linked": {
                                        "1": "ctg1_41"
                                    }
                                },
                                {
                                    "locus_tag": "sqnO",
                                    "start": 27808,
                                    "end": 28783,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_63"
                                    }
                                },
                                {
                                    "locus_tag": "sqnG2",
                                    "start": 19598,
                                    "end": 20813,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_55"
                                    }
                                },
                                {
                                    "locus_tag": "sqnC",
                                    "start": 5436,
                                    "end": 6036,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_42"
                                    }
                                },
                                {
                                    "locus_tag": "sqnS8",
                                    "start": 30245,
                                    "end": 31202,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_65"
                                    }
                                },
                                {
                                    "locus_tag": "sqnN",
                                    "start": 17007,
                                    "end": 18222,
                                    "strand": 1,
                                    "function": "transport",
                                    "linked": {
                                        "1": "ctg1_53"
                                    }
                                },
                                {
                                    "locus_tag": "sqnY",
                                    "start": 44059,
                                    "end": 44740,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnI",
                                    "start": 11293,
                                    "end": 12520,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_48"
                                    }
                                },
                                {
                                    "locus_tag": "sqnT",
                                    "start": 38556,
                                    "end": 40383,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnZ",
                                    "start": 0,
                                    "end": 1605,
                                    "strand": 1,
                                    "function": "transport",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnCC",
                                    "start": 31198,
                                    "end": 31963,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnDD",
                                    "start": 33640,
                                    "end": 34318,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnQ",
                                    "start": 34394,
                                    "end": 36023,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnS4",
                                    "start": 24679,
                                    "end": 25633,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_60"
                                    }
                                },
                                {
                                    "locus_tag": "sqnP",
                                    "start": 31977,
                                    "end": 33570,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_66"
                                    }
                                },
                                {
                                    "locus_tag": "sqnS3",
                                    "start": 23598,
                                    "end": 24582,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_59"
                                    }
                                },
                                {
                                    "locus_tag": "sqnEE",
                                    "start": 36140,
                                    "end": 36578,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnM",
                                    "start": 14989,
                                    "end": 16987,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_52"
                                    }
                                },
                                {
                                    "locus_tag": "sqnL",
                                    "start": 14051,
                                    "end": 14987,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_51"
                                    }
                                },
                                {
                                    "locus_tag": "sqnAA",
                                    "start": 1758,
                                    "end": 2499,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnS5",
                                    "start": 25629,
                                    "end": 26934,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_61"
                                    }
                                },
                                {
                                    "locus_tag": "sqnS7",
                                    "start": 28848,
                                    "end": 30249,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_64"
                                    }
                                },
                                {
                                    "locus_tag": "sqnD",
                                    "start": 6155,
                                    "end": 6893,
                                    "strand": 1,
                                    "function": "regulatory",
                                    "linked": {
                                        "1": "ctg1_43"
                                    }
                                },
                                {
                                    "locus_tag": "sqnU",
                                    "start": 40375,
                                    "end": 41455,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnV",
                                    "start": 41488,
                                    "end": 41899,
                                    "strand": -1,
                                    "function": "regulatory",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnS2",
                                    "start": 22534,
                                    "end": 23602,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_58"
                                    }
                                },
                                {
                                    "locus_tag": "sqnS1",
                                    "start": 20881,
                                    "end": 21376,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_56"
                                    }
                                },
                                {
                                    "locus_tag": "sqnH",
                                    "start": 10043,
                                    "end": 11297,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_47"
                                    }
                                },
                                {
                                    "locus_tag": "sqnE",
                                    "start": 7022,
                                    "end": 7874,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_44"
                                    }
                                },
                                {
                                    "locus_tag": "sqnBB",
                                    "start": 9693,
                                    "end": 10020,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_46"
                                    }
                                },
                                {
                                    "locus_tag": "sqnX",
                                    "start": 42973,
                                    "end": 43987,
                                    "strand": 1,
                                    "function": "transport",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnS6",
                                    "start": 26979,
                                    "end": 27744,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_62"
                                    }
                                },
                                {
                                    "locus_tag": "sqnG3",
                                    "start": 21378,
                                    "end": 22509,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_57"
                                    }
                                },
                                {
                                    "locus_tag": "sqnG1",
                                    "start": 18280,
                                    "end": 19573,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_54"
                                    }
                                },
                                {
                                    "locus_tag": "sqnR",
                                    "start": 37133,
                                    "end": 37898,
                                    "strand": -1,
                                    "function": "regulatory",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "sqnF",
                                    "start": 8192,
                                    "end": 9680,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_45"
                                    }
                                },
                                {
                                    "locus_tag": "sqnJ",
                                    "start": 12704,
                                    "end": 12974,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_49"
                                    }
                                },
                                {
                                    "locus_tag": "sqnK",
                                    "start": 13224,
                                    "end": 14010,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_50"
                                    }
                                }
                            ]
                        },
                        "BGC0000278.1: 25-5408": {
                            "start": 25,
                            "end": 5408,
                            "links": [
                                {
                                    "query": "ctg1_61",
                                    "subject": "urdQ",
                                    "query_loc": 61629,
                                    "subject_loc": 1720
                                },
                                {
                                    "query": "ctg1_62",
                                    "subject": "urdR",
                                    "query_loc": 62717,
                                    "subject_loc": 2785
                                },
                                {
                                    "query": "ctg1_64",
                                    "subject": "urdS",
                                    "query_loc": 64836,
                                    "subject_loc": 3900
                                },
                                {
                                    "query": "ctg1_65",
                                    "subject": "urdT",
                                    "query_loc": 66014,
                                    "subject_loc": 5004
                                },
                                {
                                    "query": "ctg1_60",
                                    "subject": "urdZ3",
                                    "query_loc": 60448,
                                    "subject_loc": 545
                                }
                            ],
                            "reverse": false,
                            "genes": [
                                {
                                    "locus_tag": "urdZ3",
                                    "start": 25,
                                    "end": 1066,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_60"
                                    }
                                },
                                {
                                    "locus_tag": "urdT",
                                    "start": 4601,
                                    "end": 5408,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_65"
                                    }
                                },
                                {
                                    "locus_tag": "urdQ",
                                    "start": 1068,
                                    "end": 2373,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_61"
                                    }
                                },
                                {
                                    "locus_tag": "urdS",
                                    "start": 3195,
                                    "end": 4605,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_64"
                                    }
                                },
                                {
                                    "locus_tag": "urdR",
                                    "start": 2413,
                                    "end": 3157,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_62"
                                    }
                                }
                            ]
                        },
                        "BGC0000885.1: 0-16706": {
                            "start": 0,
                            "end": 16706,
                            "links": [
                                {
                                    "query": "ctg1_9",
                                    "subject": "nspN",
                                    "query_loc": 8069,
                                    "subject_loc": 13138
                                }
                            ],
                            "reverse": true,
                            "genes": [
                                {
                                    "locus_tag": "BAJ08176.1",
                                    "start": 14071,
                                    "end": 15688,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "nspI",
                                    "start": 8729,
                                    "end": 9584,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "nspE",
                                    "start": 10858,
                                    "end": 11242,
                                    "strand": 1,
                                    "function": "biosynthetic",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "BAJ08177.1",
                                    "start": 15701,
                                    "end": 16706,
                                    "strand": -1,
                                    "function": "regulatory",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "nspS",
                                    "start": 4170,
                                    "end": 4812,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "nspH",
                                    "start": 9598,
                                    "end": 10702,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "BAJ08168.1",
                                    "start": 4855,
                                    "end": 6076,
                                    "strand": 1,
                                    "function": "transport",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "nspJ",
                                    "start": 7419,
                                    "end": 8706,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "nspF",
                                    "start": 11267,
                                    "end": 12185,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "nspT",
                                    "start": 1375,
                                    "end": 2521,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "BAJ08164.1",
                                    "start": 0,
                                    "end": 1206,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "nspA",
                                    "start": 2755,
                                    "end": 4174,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "nspN",
                                    "start": 12207,
                                    "end": 14070,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_9"
                                    }
                                },
                                {
                                    "locus_tag": "nspR",
                                    "start": 6222,
                                    "end": 7191,
                                    "strand": 1,
                                    "function": "regulatory",
                                    "linked": {}
                                }
                            ]
                        },
                        "BGC0000268.1: 497-77076": {
                            "start": 497,
                            "end": 77076,
                            "links": [
                                {
                                    "query": "ctg1_46",
                                    "subject": "schP9",
                                    "query_loc": 45393,
                                    "subject_loc": 52768
                                },
                                {
                                    "query": "ctg1_47",
                                    "subject": "schP8",
                                    "query_loc": 46193,
                                    "subject_loc": 51950
                                },
                                {
                                    "query": "ctg1_61",
                                    "subject": "schS3",
                                    "query_loc": 61629,
                                    "subject_loc": 36522
                                },
                                {
                                    "query": "ctg1_59",
                                    "subject": "schS5",
                                    "query_loc": 59438,
                                    "subject_loc": 38658
                                },
                                {
                                    "query": "ctg1_50",
                                    "subject": "schP5",
                                    "query_loc": 48987,
                                    "subject_loc": 49334
                                },
                                {
                                    "query": "ctg1_45",
                                    "subject": "schP10",
                                    "query_loc": 44473,
                                    "subject_loc": 53731
                                },
                                {
                                    "query": "ctg1_56",
                                    "subject": "schS8",
                                    "query_loc": 56430,
                                    "subject_loc": 41728
                                },
                                {
                                    "query": "ctg1_64",
                                    "subject": "schS2",
                                    "query_loc": 64836,
                                    "subject_loc": 34059
                                },
                                {
                                    "query": "ctg1_49",
                                    "subject": "schP6",
                                    "query_loc": 48263,
                                    "subject_loc": 49902
                                },
                                {
                                    "query": "ctg1_54",
                                    "subject": "schS10",
                                    "query_loc": 54267,
                                    "subject_loc": 43943
                                },
                                {
                                    "query": "ctg1_48",
                                    "subject": "schP7",
                                    "query_loc": 47440,
                                    "subject_loc": 50709
                                },
                                {
                                    "query": "ctg1_57",
                                    "subject": "schS7",
                                    "query_loc": 57288,
                                    "subject_loc": 40868
                                },
                                {
                                    "query": "ctg1_65",
                                    "subject": "schS1",
                                    "query_loc": 66014,
                                    "subject_loc": 32822
                                },
                                {
                                    "query": "ctg1_55",
                                    "subject": "schS9",
                                    "query_loc": 55541,
                                    "subject_loc": 42671
                                },
                                {
                                    "query": "ctg1_53",
                                    "subject": "schA20",
                                    "query_loc": 52961,
                                    "subject_loc": 45234
                                },
                                {
                                    "query": "ctg1_41",
                                    "subject": "schA23",
                                    "query_loc": 40093,
                                    "subject_loc": 58000
                                },
                                {
                                    "query": "ctg1_51",
                                    "subject": "schP4",
                                    "query_loc": 49868,
                                    "subject_loc": 48438
                                },
                                {
                                    "query": "ctg1_52",
                                    "subject": "schP3",
                                    "query_loc": 51331,
                                    "subject_loc": 46880
                                },
                                {
                                    "query": "ctg1_42",
                                    "subject": "CAH10122.1",
                                    "query_loc": 41206,
                                    "subject_loc": 56894
                                },
                                {
                                    "query": "ctg1_58",
                                    "subject": "schS6",
                                    "query_loc": 58416,
                                    "subject_loc": 39682
                                },
                                {
                                    "query": "ctg1_40",
                                    "subject": "schA24",
                                    "query_loc": 38570,
                                    "subject_loc": 59438
                                },
                                {
                                    "query": "ctg1_43",
                                    "subject": "schA21",
                                    "query_loc": 42005,
                                    "subject_loc": 56099
                                },
                                {
                                    "query": "ctg1_66",
                                    "subject": "schP2",
                                    "query_loc": 66655,
                                    "subject_loc": 30818
                                },
                                {
                                    "query": "ctg1_60",
                                    "subject": "schS4",
                                    "query_loc": 60448,
                                    "subject_loc": 37654
                                },
                                {
                                    "query": "ctg1_44",
                                    "subject": "schP11",
                                    "query_loc": 43073,
                                    "subject_loc": 55142
                                }
                            ],
                            "reverse": true,
                            "genes": [
                                {
                                    "locus_tag": "schA7",
                                    "start": 10222,
                                    "end": 11704,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schP11",
                                    "start": 54704,
                                    "end": 55580,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_44"
                                    }
                                },
                                {
                                    "locus_tag": "schA5",
                                    "start": 7071,
                                    "end": 7965,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA10",
                                    "start": 13682,
                                    "end": 14561,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA9",
                                    "start": 13076,
                                    "end": 13670,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA31",
                                    "start": 69584,
                                    "end": 70373,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA17",
                                    "start": 23236,
                                    "end": 24619,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA15",
                                    "start": 20024,
                                    "end": 22100,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA19",
                                    "start": 26092,
                                    "end": 27883,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA33",
                                    "start": 72197,
                                    "end": 73847,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schS6",
                                    "start": 39148,
                                    "end": 40216,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_58"
                                    }
                                },
                                {
                                    "locus_tag": "schA27",
                                    "start": 64201,
                                    "end": 64954,
                                    "strand": -1,
                                    "function": "regulatory",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA6",
                                    "start": 8040,
                                    "end": 9921,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schS9",
                                    "start": 42085,
                                    "end": 43258,
                                    "strand": -1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_55"
                                    }
                                },
                                {
                                    "locus_tag": "schA18",
                                    "start": 25014,
                                    "end": 26022,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schP4",
                                    "start": 47969,
                                    "end": 48908,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_51"
                                    }
                                },
                                {
                                    "locus_tag": "schA4",
                                    "start": 6217,
                                    "end": 6883,
                                    "strand": -1,
                                    "function": "regulatory",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schP3",
                                    "start": 45968,
                                    "end": 47792,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_52"
                                    }
                                },
                                {
                                    "locus_tag": "schP2",
                                    "start": 30032,
                                    "end": 31604,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_66"
                                    }
                                },
                                {
                                    "locus_tag": "schA14",
                                    "start": 18844,
                                    "end": 20005,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA25",
                                    "start": 60241,
                                    "end": 61093,
                                    "strand": 1,
                                    "function": "regulatory",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA24",
                                    "start": 58879,
                                    "end": 59998,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_40"
                                    }
                                },
                                {
                                    "locus_tag": "schA3",
                                    "start": 4586,
                                    "end": 5666,
                                    "strand": -1,
                                    "function": "transport",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA21",
                                    "start": 55721,
                                    "end": 56477,
                                    "strand": -1,
                                    "function": "regulatory",
                                    "linked": {
                                        "1": "ctg1_43"
                                    }
                                },
                                {
                                    "locus_tag": "schP10",
                                    "start": 52989,
                                    "end": 54474,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_45"
                                    }
                                },
                                {
                                    "locus_tag": "schA1",
                                    "start": 497,
                                    "end": 1481,
                                    "strand": 1,
                                    "function": "transport",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "CAH10132.1",
                                    "start": 70496,
                                    "end": 72167,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA28",
                                    "start": 65980,
                                    "end": 66589,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schS10",
                                    "start": 43297,
                                    "end": 44590,
                                    "strand": -1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_54"
                                    }
                                },
                                {
                                    "locus_tag": "schS5",
                                    "start": 38165,
                                    "end": 39152,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_59"
                                    }
                                },
                                {
                                    "locus_tag": "schP1",
                                    "start": 28018,
                                    "end": 29872,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "CAH10103.1",
                                    "start": 16239,
                                    "end": 17175,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schP5",
                                    "start": 48934,
                                    "end": 49735,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_50"
                                    }
                                },
                                {
                                    "locus_tag": "schP6",
                                    "start": 49767,
                                    "end": 50037,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_49"
                                    }
                                },
                                {
                                    "locus_tag": "schA26",
                                    "start": 62332,
                                    "end": 63931,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schS4",
                                    "start": 37174,
                                    "end": 38134,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_60"
                                    }
                                },
                                {
                                    "locus_tag": "schP8",
                                    "start": 51319,
                                    "end": 52582,
                                    "strand": -1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_47"
                                    }
                                },
                                {
                                    "locus_tag": "CAH10099.1",
                                    "start": 11715,
                                    "end": 12678,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schS2",
                                    "start": 33360,
                                    "end": 34758,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_64"
                                    }
                                },
                                {
                                    "locus_tag": "schA20",
                                    "start": 44622,
                                    "end": 45846,
                                    "strand": -1,
                                    "function": "transport",
                                    "linked": {
                                        "1": "ctg1_53"
                                    }
                                },
                                {
                                    "locus_tag": "schA2",
                                    "start": 1514,
                                    "end": 2402,
                                    "strand": 1,
                                    "function": "transport",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA13",
                                    "start": 17171,
                                    "end": 18848,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "CAH10122.1",
                                    "start": 56594,
                                    "end": 57194,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {
                                        "1": "ctg1_42"
                                    }
                                },
                                {
                                    "locus_tag": "schS1",
                                    "start": 32311,
                                    "end": 33334,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_65"
                                    }
                                },
                                {
                                    "locus_tag": "schA11",
                                    "start": 14576,
                                    "end": 15980,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schP7",
                                    "start": 50096,
                                    "end": 51323,
                                    "strand": -1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_48"
                                    }
                                },
                                {
                                    "locus_tag": "schP9",
                                    "start": 52605,
                                    "end": 52932,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_46"
                                    }
                                },
                                {
                                    "locus_tag": "schA30",
                                    "start": 67520,
                                    "end": 69065,
                                    "strand": 1,
                                    "function": "biosynthetic-additional",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schA23",
                                    "start": 57208,
                                    "end": 58792,
                                    "strand": 1,
                                    "function": "transport",
                                    "linked": {
                                        "1": "ctg1_41"
                                    }
                                },
                                {
                                    "locus_tag": "CAH10129.1",
                                    "start": 66592,
                                    "end": 67477,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schS8",
                                    "start": 41433,
                                    "end": 42024,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_56"
                                    }
                                },
                                {
                                    "locus_tag": "schA16",
                                    "start": 22246,
                                    "end": 23140,
                                    "strand": 1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schS3",
                                    "start": 35870,
                                    "end": 37175,
                                    "strand": -1,
                                    "function": "biosynthetic-additional",
                                    "linked": {
                                        "1": "ctg1_61"
                                    }
                                },
                                {
                                    "locus_tag": "schA34",
                                    "start": 74160,
                                    "end": 77076,
                                    "strand": -1,
                                    "function": "other",
                                    "linked": {}
                                },
                                {
                                    "locus_tag": "schS7",
                                    "start": 40300,
                                    "end": 41437,
                                    "strand": -1,
                                    "function": "biosynthetic",
                                    "linked": {
                                        "1": "ctg1_57"
                                    }
                                }
                            ]
                        }
                    }
                }
            }
        }
    }
};
